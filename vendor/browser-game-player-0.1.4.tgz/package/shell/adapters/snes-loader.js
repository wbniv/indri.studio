/*
 * bsnes-jg-wasm loader — drives our Emscripten build of bsnes-jg 2.1.0 (the exact
 * core the llvm-mos-65816 differential gate trusts). Boots a .sfc, renders the
 * core's framebuffer to a <canvas>, maps the keyboard to an SNES pad, and runs an
 * in-browser fidelity self-check that reproduces the gate's headless WRAM assert.
 *
 * The core module (web/cores/bsnes_jg.js) is built by ./build.sh. No libretro,
 * no EmulatorJS — just Module._bjg_* calls.
 */
(function () {
  "use strict";

  // An embedding page (e.g. the indri.studio inline embed) can point the loader
  // at assets under a base path and pick the boot ROM; defaults reproduce the
  // standalone page (relative paths, the zoom demo).
  var BASE = (window.BJG_BASE || "");
  var DEFAULT_ROM = (window.BJG_DEFAULT_ROM || "mandel-display");

  // Content-hash cache-busting. The page (fresh HTML) injects window.BJG_BUST: a map of
  // relative asset path -> short SHA of that file's bytes. bust() appends "?v=<sha>" so each
  // asset can be cached immutably forever, yet a re-synced file (same filename, new content =
  // new sha) gets a NEW url and is re-fetched — no stale ROM after a deploy. Absent map (older
  // embed) -> plain path, so it still works.
  function bust(path) {
    var b = window.BJG_BUST;
    return BASE + path + (b && b[path] ? "?v=" + b[path] : "");
  }

  // SNES controller bits — must match Bsnes::Input::Gamepad in src/bsnes.hpp.
  var JOY = {
    B: 1 << 15, Y: 1 << 14, Select: 1 << 13, Start: 1 << 12,
    Up: 1 << 11, Down: 1 << 10, Left: 1 << 9, Right: 1 << 8,
    A: 1 << 7, X: 1 << 6, L: 1 << 5, R: 1 << 4
  };
  // Keyboard -> pad. Z/X = B/A, A/S = Y/X (the common SNES-on-keyboard layout).
  var KEYMAP = {
    ArrowUp: JOY.Up, ArrowDown: JOY.Down, ArrowLeft: JOY.Left, ArrowRight: JOY.Right,
    KeyZ: JOY.B, KeyX: JOY.A, KeyA: JOY.Y, KeyS: JOY.X,
    Enter: JOY.Start, ShiftRight: JOY.Select, ShiftLeft: JOY.Select,
    KeyQ: JOY.L, KeyW: JOY.R
  };

  var Module = null;       // the instantiated Emscripten module
  var manifest = null;     // roms/manifest.json
  var current = null;      // current rom id
  var pad = 0;             // port-0 button mask
  var touchRelease = 0;    // timer for a manifest-driven synthetic D-pad tap
  var touchNavPressed = 0; // synthetic bit currently owned by that timer
  var hostPaused = false;
  var running = false;     // RAF loop active
  var rafId = 0;
  var imageData = null;
  var runLabel = "";       // status prefix for the running ROM
  var dimsShown = false;   // whether status already carries WxH
  var revealed = false;    // true once the first non-black live frame has been drawn
                           //  (until then the baked preview stays on the canvas)

  var canvas = document.getElementById("screen");
  var ctx = canvas.getContext("2d", { alpha: false });
  var statusEl = document.getElementById("status");
  var checkEl = document.getElementById("checkresult");
  var bannerEl = document.getElementById("banner");

  function status(msg) { if (statusEl) statusEl.textContent = msg; if (window.BJG_PLAYER_HOOKS && msg.indexOf("error:") === 0) window.BJG_PLAYER_HOOKS.error(msg); }

  function clearTouchNav() {
    clearTimeout(touchRelease);
    touchRelease = 0;
    if (touchNavPressed) pad &= ~touchNavPressed;
    touchNavPressed = 0;
  }

  // --- core module loading ---------------------------------------------------

  function loadCoreScript() {
    return new Promise(function (resolve, reject) {
      if (window.BsnesJg) return resolve(window.BsnesJg);
      var s = document.createElement("script");
      s.src = bust("cores/bsnes_jg.js");
      s.onload = function () { resolve(window.BsnesJg); };
      s.onerror = function () { reject(new Error("core not built")); };
      document.body.appendChild(s);
    });
  }

  // --- rendering -------------------------------------------------------------

  function present() {
    var w = Module._bjg_video_w(), h = Module._bjg_video_h(), pitch = Module._bjg_video_pitch();
    if (!w || !h) return;
    // bsnes hands us a 512-wide buffer for lores content (256 logical px doubled)
    // and ~240 scanlines incl. overscan. Collapse the 2x horizontal doubling and
    // crop to the 224 visible NTSC lines — the true 256x224 logical frame, square
    // pixels at the SNES 8:7 aspect (matches the gate's jgxcheck PNG). Without
    // this the picture is stretched 2x wide.
    var step = w >= 512 ? 2 : 1;
    var ow = (w / step) | 0;
    // Skip the top NTSC overscan when the core hands us a tall buffer. Measured
    // per-row on this build (2026-07-27, deterministic frames after _bjg_reset):
    // the 512x240 buffer carries content in rows [8,232) — yoff=0 would add an
    // 8px black band and crop the bottom rows instead. A 224-line buffer (h<232)
    // is already flush, so the offset degrades to 0. Supersedes aaacbae, whose
    // "flush at buffer top" rationale described the headless jgxcheck capture.
    var yoff = h >= 232 ? 8 : 0;
    var avail = h - yoff;
    var oh = avail < 224 ? avail : 224;
    var heap = Module.HEAPU32;               // re-fetch each frame (may grow)
    var base = Module._bjg_video() >>> 2;    // uint32 index
    // Pre-ROM only: hold the poster until the core emits a non-black frame. loadRomBytes() sets
    // `revealed` as soon as the ROM is accepted, so from that point every frame is drawn — black
    // boot frames included. This branch now only covers the window before a ROM is loaded.
    if (!revealed) {
      var lit = false;
      for (var sy = yoff; sy < yoff + oh && !lit; sy += 8) {
        var sb = base + sy * pitch;
        for (var sx = 0; sx < ow; sx += 8)
          if (heap[sb + sx * step] & 0xffffff) { lit = true; break; }
      }
      if (!lit) return;                      // still blank — leave the preview up
      revealed = true;
    }
    if (!imageData || canvas.width !== ow || canvas.height !== oh) {
      canvas.width = ow; canvas.height = oh;
      imageData = ctx.createImageData(ow, oh);
    }
    if (!dimsShown && runLabel) { status(runLabel + " · " + ow + "×" + oh); dimsShown = true; }
    var out = imageData.data;
    var di = 0;
    for (var y = 0; y < oh; y++) {
      var si = base + (y + yoff) * pitch;
      for (var x = 0; x < ow; x++) {
        var px = heap[si + x * step];        // 0x00RRGGBB
        out[di++] = (px >>> 16) & 0xff;      // R
        out[di++] = (px >>> 8) & 0xff;       // G
        out[di++] = px & 0xff;               // B
        out[di++] = 255;                     // A
      }
    }
    ctx.putImageData(imageData, 0, 0);
  }

  function frame() {
    if (!running) return;
    Module._bjg_set_input(0, pad);
    Module._bjg_run();
    present();
    rafId = requestAnimationFrame(frame);
  }

  function startLoop() {
    if (running || hostPaused) return;
    running = true;
    rafId = requestAnimationFrame(frame);
  }
  function stopLoop() {
    running = false;
    if (rafId) cancelAnimationFrame(rafId);
    rafId = 0;
    clearTouchNav();
  }

  // --- ROM loading -----------------------------------------------------------

  function loadRomBytes(bytes) {
    var ptr = Module._malloc(bytes.length);
    Module.HEAPU8.set(bytes, ptr);
    var ok = Module._bjg_load(ptr, bytes.length);
    Module._free(ptr);
    // The ROM is about to run, so the poster has done its job: clear to black and let present()
    // draw every frame from here, including the black ones. Holding the preview until the first
    // *lit* frame (the old `revealed` behaviour) meant the page opened on a screenshot of the
    // FINISHED demo, which reads as leftover state from a previous session — and every demo now
    // fades its title card up from black, so the hold fired on all 113 pages rather than just the
    // one long-force-blanking demo it was added for.
    if (ok === 1 && ctx) {
      revealed = true;
      ctx.fillStyle = "#000";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }
    return ok === 1;
  }

  function playUrl(id) {
    current = id;
    stopLoop();
    badge(null, "");
    markActive(id);
    status("loading " + id + ".sfc…");
    return fetch(bust("roms/" + id + ".sfc"))
      .then(function (r) { if (!r.ok) throw new Error("fetch " + id); return r.arrayBuffer(); })
      .then(function (buf) {
        if (!loadRomBytes(new Uint8Array(buf))) throw new Error("core rejected ROM");
        runLabel = "running " + id + ".sfc"; dimsShown = false;
        status(runLabel);
        startLoop();
        updateCheckButton(id);
        // ?verify=1 auto-runs the fidelity self-check once the ROM is up — the
        // hook CI's headless gate drives (poll #checkresult for PASS/MISMATCH).
        if (new URLSearchParams(location.search).get("verify") === "1" && !window.__bjgAutoVerified) {
          window.__bjgAutoVerified = true;
          setTimeout(verify, 0);
        }
      })
      .catch(function (e) { status("error: " + e.message); });
  }

  function playFile(file) {
    current = null;
    stopLoop();
    badge(null, "");
    document.querySelectorAll("#picker button[data-rom]").forEach(function (b) {
      b.removeAttribute("aria-current");
    });
    status("loading " + file.name + "…");
    file.arrayBuffer().then(function (buf) {
      if (!loadRomBytes(new Uint8Array(buf))) { status("error: core rejected " + file.name); return; }
      runLabel = "running " + file.name; dimsShown = false;
      status(runLabel);
      startLoop();
      updateCheckButton(null);
    });
  }

  // --- fidelity self-check (mirrors dev/jgxcheck.cpp) ------------------------

  function romMeta(id) {
    if (!manifest || !id) return null;
    return manifest.roms.find(function (r) { return r.id === id; }) || null;
  }

  function updateCheckButton(id) {
    var btn = document.getElementById("verify");
    if (!btn) return;
    var meta = romMeta(id);
    if (meta && meta.selfcheck) {
      btn.disabled = false;
      btn.title = "Reproduce the gate's headless assert in this tab";
    } else {
      btn.disabled = true;
      btn.title = "No gate reference for this ROM";
    }
  }

  // The host page owns the badge element's base class and matches its CSS on
  // `.<base>.<state>` — `rp-badge` in astro/SnesPlayer.astro and embed/snippet.html,
  // plain `badge` in web/index.html. So the state is swapped with classList rather
  // than assigned through .className, which would drop that base class and leave
  // every `.rp-badge.pass` / `.badge.warn` rule unmatched.
  function badgeState(cls) {
    if (!checkEl) return;
    checkEl.classList.remove("running", "pass", "fail", "warn");
    if (cls) checkEl.classList.add(cls);
  }

  function badge(cls, text) {
    if (!checkEl) return;
    badgeState(cls);
    checkEl.textContent = text;
  }

  // Poll the machine that is already running, instead of power-cycling: a demo whose "displayed"
  // state is meaningful (e.g. the gallery's browsing cursor) would have that state destroyed by a
  // reload before anything could be read. sc.record gives byte offsets from sc.off; sc.state
  // reaches sc.ready only once every field describes the same, coherent verdict — the ROM's
  // publication barrier (see "What the ROM publishes" / "The player / manifest contract" in
  // docs/plans/2026-07-28-gallery-per-image-selfcheck.md, llvm-mos-65816). Deliberately does NOT
  // stopLoop(): the live rAF loop keeps applying the visitor's keyboard/touch input every frame
  // (see frame()), which is what lets navigation during the check be observed at all (step 5).
  function verifyLiveRecord(sc) {
    var rec = sc.record, poll = sc.poll || 120, total = sc.frames, done = 0;
    var target = null, retargets = 0;
    badge("running", "verifying…");
    (function chunk() {
      for (var i = 0; i < poll; i++) Module._bjg_run();
      done += poll;
      present();
      var wram = Module._bjg_wram() >>> 0, u8 = Module.HEAPU8, base = wram + Number(sc.off);
      var state = u8[base + rec.state];
      var work = state ? u8[base + rec.work] : null;   // ignore every field while state==0
      var name = (sc.titles && work != null) ? sc.titles[work] : (work != null ? "work " + work : null);
      if (work != null && target != null && work !== target) {
        // the visitor navigated mid-check
        if (++retargets > 1) {
          badge("fail", "navigation kept restarting the check — hold on one artwork and try again");
          return;
        }
        target = work; done = 0;
        badge("running", "following your navigation to " + name);
        setTimeout(chunk, 0);
        return;
      }
      if (work != null && target == null) target = work;
      if (state !== sc.ready) {
        if (done >= total) {
          badge("warn", "⏱ still verifying " + (name || "…") + " — not finished within " + total + " frames");
          return;
        }
        badge("running", name ? ("verifying " + name + "… " + done + "/" + total) : "verifying… " + done + "/" + total);
        setTimeout(chunk, 0);
        return;
      }
      var z = u8[base + rec.z[0]] | (u8[base + rec.z[0] + 1] << 8);
      var ok = u8[base + rec.ok];
      var want = sc.oracle[work];
      if (ok === 1 && z === want) {
        badge("pass", "✓ FIDELITY " + name + " — repacked on-SNES to " + z + " B == host oracle");
      } else if (ok !== 1) {
        badge("fail", "✗ FAILED " + name + " — the ROM's own byte-compare rejected its repack");
      } else {
        badge("fail", "✗ MISMATCH " + name + " got " + z + " want " + want);
      }
      // no startLoop(): the live loop was never stopped, so it is already resuming on its own —
      // the visitor's browsing position was never touched by this check.
    })();
  }

  // Power on, run `frames` frames, then read WRAM and compare — exactly what the
  // gate's jgxcheck does. Runs in chunks so the tab stays responsive.
  function verify() {
    var meta = romMeta(current);
    if (!meta || !meta.selfcheck) return;
    var sc = meta.selfcheck;
    if (sc.mode === "live-record") { verifyLiveRecord(sc); return; }
    var off = Number(sc.off), len = sc.len, want = Number(sc.want), total = sc.frames;

    stopLoop();
    // re-load this ROM to power on cleanly, like the gate's harness.
    fetch(bust("roms/" + current + ".sfc"))
      .then(function (r) { return r.arrayBuffer(); })
      .then(function (buf) {
        loadRomBytes(new Uint8Array(buf));
        badgeState("running");
        var done = 0;
        function chunk() {
          var n = Math.min(120, total - done);
          for (var i = 0; i < n; i++) Module._bjg_run();
          done += n;
          badge("running", "verifying… " + done + "/" + total + " frames");
          present();
          if (done < total) { setTimeout(chunk, 0); return; }
          // read `len` little-endian bytes of WRAM at `off`
          var wram = Module._bjg_wram() >>> 0;
          var u8 = Module.HEAPU8;
          var got = 0;
          for (var k = 0; k < len; k++) got |= u8[wram + off + k] << (8 * k);
          got >>>= 0;
          var hexGot = "0x" + got.toString(16).toUpperCase();
          var hexWant = "0x" + (want >>> 0).toString(16).toUpperCase();
          if (got === want) {
            badge("pass", "✓ FIDELITY " + hexGot + " == gate (" + sc.label + ", " + total + " frames)");
          } else {
            badge("fail", "✗ MISMATCH got " + hexGot + " want " + hexWant);
          }
          // resume the live demo from the verified state (frame `total`, image
          // already on screen) rather than a fresh black power-on.
          startLoop();
        }
        setTimeout(chunk, 0);
      });
  }

  // --- input -----------------------------------------------------------------

  function onKey(down) {
    return function (e) {
      var bit = KEYMAP[e.code];
      if (bit === undefined) return;
      e.preventDefault();
      if (down) pad |= bit; else pad &= ~bit;
    };
  }

  // --- UI wiring -------------------------------------------------------------

  function markActive(id) {
    document.querySelectorAll("#picker button[data-rom]").forEach(function (b) {
      b.setAttribute("aria-current", b.dataset.rom === id ? "true" : "false");
    });
  }

  function showProvenance() {
    fetch(bust("cores/PROVENANCE.json"))
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (p) {
        if (!p || !bannerEl) return;
        var emver = (String(p.emscripten || "").match(/\d+\.\d+\.\d+/) || ["?"])[0];
        bannerEl.innerHTML =
          "Running <b>" + p.core + " " + p.version + "</b> — the exact cycle-accurate core " +
          "the differential gate trusts (sha256 <code>" + String(p.sha256).slice(0, 12) +
          "…</code>, emscripten " + emver + "). Hit <b>Verify fidelity</b> to reproduce the " +
          "gate's headless WRAM assert in this tab.";
      })
      .catch(function () {});
  }

  // Pause the run loop when the canvas scrolls out of view (resume on return),
  // so an embedded demo doesn't burn a CPU core while the reader is elsewhere.
  function observeVisibility() {
    var target = document.getElementById("game") || canvas;
    if (!target || typeof IntersectionObserver === "undefined") return;
    new IntersectionObserver(function (entries) {
      if (entries[0].isIntersecting) {
        if (Module && Module._bjg_loaded && Module._bjg_loaded()) startLoop();
      } else {
        stopLoop();
      }
    }, { threshold: 0.05 }).observe(target);
  }

  // Paint the baked preview onto the canvas as a LOADING POSTER, so the page shows the demo
  // rather than a black box while the ~3.9 MB core downloads. It is cleared to black the moment
  // the ROM is accepted (see loadRomBytes), so the emulator always starts from a blank screen and
  // the title card fades up over black. A ROM without a preview/<id>.png just 404s the image and
  // keeps the default black — no error path needed.
  function paintPreview(id) {
    if (!id || !ctx || (window.BJG_PLAYER_HOOKS && !window.BJG_PLAYER_HOOKS.previews.includes(id))) return;
    var img = new Image();
    img.onload = function () {
      if (revealed) return;                  // live already took over
      ctx.imageSmoothingEnabled = false;     // crisp nearest-neighbour upscale (the SNES look)
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    };
    img.src = bust("preview/" + id + ".png");
  }

  function init() {
    // The picker, file input, verify button and drag-drop target are all
    // optional — an embed may render just the canvas + status. Guard each.
    document.querySelectorAll("#picker button[data-rom]").forEach(function (b) {
      b.addEventListener("click", function () { playUrl(b.dataset.rom); });
    });
    var fileEl = document.getElementById("file");
    if (fileEl) fileEl.addEventListener("change", function (e) {
      if (e.target.files[0]) playFile(e.target.files[0]);
    });
    var verifyEl = document.getElementById("verify");
    if (verifyEl) verifyEl.addEventListener("click", verify);

    // BEGIN SHARED FULLSCREEN CONTROLLER — canonical copy lives in bsnes-jg-wasm;
    // sites vendor this file verbatim via `bsnes-jg-player sync`, never edit a site copy.
    (function () {
      if (window.__bjgFullscreenCleanup) window.__bjgFullscreenCleanup();

      var fsEl = document.getElementById(window.BJG_PLAYER_HOOKS ? "snes-native-fullscreen" : "fullscreen");
      var wrap = canvas && canvas.parentElement;
      if (!fsEl || !wrap) return;

      var request = wrap.requestFullscreen || wrap.webkitRequestFullscreen;
      if (!request) { fsEl.style.display = "none"; return; }

      var fitRaf = 0;
      var settleRaf = 0;
      function activeElement() {
        return document.fullscreenElement || document.webkitFullscreenElement;
      }
      function px(value) {
        var n = parseFloat(value);
        return Number.isFinite(n) ? n : 0;
      }
      function fitFullscreenCanvas() {
        fitRaf = 0;
        if (activeElement() !== wrap) return;
        var style = getComputedStyle(wrap);
        var padW = px(style.paddingLeft) + px(style.paddingRight);
        var padH = px(style.paddingTop) + px(style.paddingBottom);
        var availW = wrap.clientWidth - padW;
        var availH = wrap.clientHeight - padH;
        // Mobile landscape fullscreen can leave the layout viewport larger than
        // the actually visible viewport while browser chrome/orientation settles.
        // Never size against a box larger than the pixels the user can see.
        if (window.visualViewport) {
          availW = Math.min(availW, window.visualViewport.width - padW);
          availH = Math.min(availH, window.visualViewport.height - padH);
        }
        // Leave one CSS pixel on every edge. This absorbs fractional safe-area
        // values and device-pixel rounding instead of letting a limiting edge crop.
        availW = Math.max(0, Math.floor(availW) - 2);
        availH = Math.max(0, Math.floor(availH) - 2);
        // The core's backing buffer can switch to a native 512x240 frame. That is storage
        // resolution, not the intended SNES display shape; fullscreen must remain 256:224 (8:7).
        var displayW = 8;
        var displayH = 7;
        var scale = Math.min(availW / displayW, availH / displayH);
        if (!(scale > 0)) return;
        wrap.style.setProperty("--bjg-fs-width", Math.max(1, Math.floor(displayW * scale)) + "px");
        wrap.style.setProperty("--bjg-fs-height", Math.max(1, Math.floor(displayH * scale)) + "px");
      }
      function scheduleFullscreenFit() {
        if (fitRaf) cancelAnimationFrame(fitRaf);
        fitRaf = requestAnimationFrame(fitFullscreenCanvas);
      }
      function settleFullscreenFit() {
        scheduleFullscreenFit();
        if (settleRaf) cancelAnimationFrame(settleRaf);
        settleRaf = requestAnimationFrame(function () {
          scheduleFullscreenFit();
          settleRaf = requestAnimationFrame(scheduleFullscreenFit);
        });
      }
      function onFullscreenChange() {
        var active = activeElement() === wrap;
        fsEl.textContent = active ? "Exit full" : "Fullscreen";
        if (active) settleFullscreenFit();
        else {
          wrap.style.removeProperty("--bjg-fs-width");
          wrap.style.removeProperty("--bjg-fs-height");
        }
      }
      function onFullscreenResize() {
        if (activeElement() === wrap) settleFullscreenFit();
      }
      function onFullscreenClick() {
        if (activeElement()) {
          var exit = document.exitFullscreen || document.webkitExitFullscreen;
          if (exit) Promise.resolve(exit.call(document)).catch(onFullscreenChange);
        } else {
          Promise.resolve(request.call(wrap)).then(settleFullscreenFit).catch(onFullscreenChange);
        }
      }

      fsEl.addEventListener("click", onFullscreenClick);
      document.addEventListener("fullscreenchange", onFullscreenChange);
      document.addEventListener("webkitfullscreenchange", onFullscreenChange);
      window.addEventListener("resize", onFullscreenResize);
      window.addEventListener("orientationchange", onFullscreenResize);
      if (window.visualViewport) {
        window.visualViewport.addEventListener("resize", onFullscreenResize);
        window.visualViewport.addEventListener("scroll", onFullscreenResize);
      }

      var oldStyle = document.getElementById("bjg-fullscreen-style");
      if (oldStyle) oldStyle.remove();
      var styleEl = document.createElement("style");
      styleEl.id = "bjg-fullscreen-style";
      styleEl.textContent =
        ".rp-screen:-webkit-full-screen,.rp-screen:fullscreen{" +
          "box-sizing:border-box;display:grid;place-items:center;width:100%;height:100%;margin:0;" +
          "padding:env(safe-area-inset-top,0px) env(safe-area-inset-right,0px) " +
                  "env(safe-area-inset-bottom,0px) env(safe-area-inset-left,0px);" +
          "overflow:hidden;background:#000;border:0;border-radius:0;line-height:0;" +
        "}" +
        ".rp-screen:-webkit-full-screen canvas,.rp-screen:fullscreen canvas{" +
          "display:block;width:var(--bjg-fs-width,auto);height:var(--bjg-fs-height,auto);" +
          "max-width:100%;max-height:100%;aspect-ratio:8/7;image-rendering:pixelated;" +
        "}";
      document.head.appendChild(styleEl);

      window.__bjgFullscreenCleanup = function () {
        if (fitRaf) cancelAnimationFrame(fitRaf);
        if (settleRaf) cancelAnimationFrame(settleRaf);
        fsEl.removeEventListener("click", onFullscreenClick);
        document.removeEventListener("fullscreenchange", onFullscreenChange);
        document.removeEventListener("webkitfullscreenchange", onFullscreenChange);
        window.removeEventListener("resize", onFullscreenResize);
        window.removeEventListener("orientationchange", onFullscreenResize);
        if (window.visualViewport) {
          window.visualViewport.removeEventListener("resize", onFullscreenResize);
          window.visualViewport.removeEventListener("scroll", onFullscreenResize);
        }
        wrap.style.removeProperty("--bjg-fs-width");
        wrap.style.removeProperty("--bjg-fs-height");
      };
    }());
    // END SHARED FULLSCREEN CONTROLLER

    window.addEventListener("keydown", onKey(true));
    window.addEventListener("keyup", onKey(false));
    // In-ROM touch controls (e.g. a gallery's sprite chevrons — not DOM
    // controls). A ROM opts in via its manifest entry:
    //   "touchNav": { "left": [x, y, w, h], "right": [x, y, w, h] }
    // in logical canvas pixels; taps inside a rect press that pad button for
    // one tap-length. Taps elsewhere stay inert. (Was hardcoded to the
    // lzss-gallery slug; the rects moved into roms/manifest.json.)
    function touchNavBits() {
      var meta = romMeta(current);
      return meta && meta.touchNav ? meta.touchNav : null;
    }
    function touchNavBitAt(tn, x, y) {
      function hit(r) { return r && x >= r[0] && x < r[0] + r[2] && y >= r[1] && y < r[1] + r[3]; }
      if (hit(tn.left)) return JOY.Left;
      if (hit(tn.right)) return JOY.Right;
      return 0;
    }
    canvas.addEventListener("pointerdown", function (e) {
      var tn = touchNavBits();
      if (!tn) return;
      var r = canvas.getBoundingClientRect();
      if (!r.width || !r.height) return;
      // The shared shell can letterbox the canvas. Map the displayed image,
      // not the black margins, back to the ROM's logical touch rectangles.
      var scale = Math.min(r.width / canvas.width, r.height / canvas.height);
      var left = r.left + (r.width - canvas.width * scale) / 2;
      var top = r.top + (r.height - canvas.height * scale) / 2;
      var x = (e.clientX - left) / scale;
      var y = (e.clientY - top) / scale;
      var bit = touchNavBitAt(tn, x, y);
      if (!bit) return;
      e.preventDefault();
      clearTouchNav();
      touchNavPressed = bit;
      pad |= bit;
      touchRelease = setTimeout(clearTouchNav, 120);
    }, { passive: false });
    /* Do not clear on pointerup: a quick click can otherwise begin and end
       between emulated input samples.  An accepted tap is a full 120 ms pulse. */
    canvas.addEventListener("pointercancel", clearTouchNav);
    window.addEventListener("blur", clearTouchNav);
    var game = document.getElementById("game");
    if (game) {
      ["dragover", "drop"].forEach(function (ev) {
        game.addEventListener(ev, function (e) { e.preventDefault(); });
      });
      game.addEventListener("drop", function (e) {
        if (e.dataTransfer.files[0]) playFile(e.dataTransfer.files[0]);
      });
    }

    // Show the baked preview before anything loads (covers the core download + ROM boot).
    var bootRom = new URLSearchParams(location.search).get("rom") || DEFAULT_ROM;
    paintPreview(bootRom);

    status("loading core…");
    Promise.all([
      loadCoreScript().then(function (factory) {
        return factory({ locateFile: function (p) {           // bust the wasm Emscripten loads
          return (p && p.slice(-5) === ".wasm") ? bust("cores/" + p) : p;
        }});
      }),
      fetch(bust("roms/manifest.json")).then(function (r) { return r.json(); })
    ]).then(function (res) {
      Module = res[0];
      window.__bjg = Module;     // exposed for debugging / automated checks
      manifest = res[1];
      showProvenance();
      if (!window.BJG_PLAYER_HOOKS) observeVisibility();
      window.__bjgPlayer = {
        pause: function () { hostPaused = true; stopLoop(); pad = 0; Module._bjg_set_input(0, 0); },
        resume: function () { hostPaused = false; if (Module._bjg_loaded()) startLoop(); },
        release: function () { clearTouchNav(); pad = 0; Module._bjg_set_input(0, 0); },
        get state() { return { running: running, pad: pad, current: current }; }
      };
      playUrl(bootRom).then(function () {
        if (Module._bjg_loaded() && window.BJG_PLAYER_HOOKS) window.BJG_PLAYER_HOOKS.ready();
      });
    }).catch(function (e) {
      if (window.BJG_PLAYER_HOOKS) window.BJG_PLAYER_HOOKS.error("Could not load the SNES core or manifest.", e);
      status("");
      if (bannerEl) {
        bannerEl.innerHTML =
          "<b>Core not built.</b> Run <code>build.sh</code> to compile " +
          "<code>bsnes_jg.{js,wasm}</code>, then reload. (" + e.message + ")";
        bannerEl.className = "banner warn";
      }
    });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
