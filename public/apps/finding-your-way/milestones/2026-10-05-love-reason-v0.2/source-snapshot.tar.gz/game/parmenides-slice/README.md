# Temple, Love and Reason native prototype

This playable pass runs in the existing World Foundry native runtime. It contains the Temple, Love street and Reason's ordered plane/grove. Reason includes the White-Clad Self, Wild Self, younger self, an ordering apparatus, both conclusions and all four changed Temple returns. Truth is the next-chapter marker. Geometry is original Blender authoring; the source scaffold supplies WF infrastructure only. Will's production order is to finish every realm's functionality before art passes.

- [x] Original Blender scene and models exported through the WF Blender exporter.
- [x] Default third-person follower and switchable first-person movement.
- [x] Both Love encounters, evidence gate, confirmation and source-correct Temple returns.
- [x] Both Love speakers withdraw after their accounts; unfinished Love visits retain encounters, and Reason's gate explains the required threshold commitment.
- [x] Reason encounters, apparatus, revealed grove, explicit commitments and four source-derived Temple histories.
- [x] Street-facing Temple return signs; world labels suspended under modal text; remote Left cancels without committing.
- [x] Level-owned journal, replay and reduced decorative motion.
- [x] Native desktop behavioral checks and Chromecast launch/Select/Home-resume checks on both devices.
- [ ] Complete phone acceptance, durable saves, full animation/voice work and final art.

Build with `task native:build`. The editable [Blender scene](build/parmenides_slice.blend), generated Forth, source LEV, native IFF files and frozen APK are produced under `build/`. [build-receipt.json](build/build-receipt.json) identifies the latest APK and native library hashes. Build products and the local development signing key are ignored by Git.

The builder requires Blender with `wf_blender` enabled, Pillow, the existing Rust WF asset tools, Android SDK build-tools 34.0.0 and Java/keytool. It reads `/home/will/WorldFoundry-wbniv`; it does not edit or rebuild engine sources. The runtime is reused from the existing condo release APK, with its two native libraries preserved byte for byte. The APK uses `org.worldfoundry.wf_game.parmenides`, so it installs alongside other WF apps.

Run `task native:verify` for native desktop behavioral checks covering both Love choices and all four Reason histories in both perspectives. Debug transforms place encounter fixtures; native input opens and advances arguments and commits choices. These are behavioral tests, not an entirely input-driven traversal or phone certification. The Linux debug screenshot path returned stale/blank frames in this environment; actual Chromecast screenshots are linked in the [Reason implementation report](../../docs/diagnostics/parmenides/reason/implementation.md).

Install through `task native:install`, or run `task native:check`. Both default to Chromecast 1 (`chromecast-test-01`); `DEVICE=all` remains available. Will requests installation on Chromecast 1 after each completed iteration for play/review. These delegate to `task chromecast:*` in the WF checkout and verify the frozen APK hash before submission. They never use direct device control. The app registration has already been deployed through WF's administrator tool; `register_coordinator.py` retains the reproducible, hash-reviewed one-line addition.

On the TV remote, Up/Down walks forward/backward, Left/Right turns, a short Select press interacts or advances dialogue, and holding Select switches perspective. Left closes an open sheet without committing. Complete Love, then enter the purple/blue Reason portal. Hear the White-Clad Self to reveal the grove, operate the apparatus and hear the Wild Self, then speak with the younger self. Complete these encounters before choosing either threshold; its concluding account commits only at the final page. Gamepads and the optional WF phone controller provide A/interact, B/perspective, C/journal or close, and D/reduced motion. The initial WF controller panel can be dismissed with Back; Back after that retains Android's exit behavior.

The newspaper is original replacement prose. Both Love accounts, all Reason arguments and all four post-Reason Temple accounts retain source text; the weather apparatus is authored gameplay adaptation. This prototype adapts the intro into a short onboarding sheet. It uses session-local state in one native level with three regions; quitting restarts the chapter. Re-entering unfinished Love or Reason preserves its encounters; replaying a completed realm resets its encounters. Replaying Love clears its prior commitment and all downstream Reason progress. Both Love speakers withdraw through immediate visibility changes; animated departures are deferred. Whole-object idle/tapestry transforms demonstrate decorative motion, not exported skeletal character clips. The journal is a static Love summary. Face rendering investigation, durable saves, final voice performance, simultaneous touch move/look and phone thermal acceptance remain open.

The played Temple/Love APK and its Blender/source snapshot are preserved in the [milestone archive](../milestones/README.md).

WF runtime copyright and GPL-2.0 notices remain those of World Foundry. Its source checkout is the corresponding local runtime source reference. Source for this chapter is [blender_scene.py](blender_scene.py), [chapter_script.py](chapter_script.py) and [build.py](build.py). Authored with Codex, GPT-6; no verified tool-version or reasoning-effort value was available to include.
