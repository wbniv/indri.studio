"""Exercise the actual native chapter on desktop; no Chromecast access.

Debug transforms arrange encounter fixtures; real native input advances every
argument and confirms the choices. This is not proof of Android gameplay.
"""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'build'
EVIDENCE=ROOT.parents[1]/'docs/diagnostics/parmenides/reason/desktop'
if '--supplemental-text' in sys.argv:EVIDENCE=EVIDENCE/'supplemental-text'
EVIDENCE.mkdir(parents=True,exist_ok=True)
WF=Path('/home/will/WorldFoundry-wbniv')
sys.path.insert(0,str(WF/'tests'))
from debug_bridge_client import BridgeClient

ids=json.loads((OUT/'actors.json').read_text())['ids']
content=json.loads((OUT/'content.json').read_text())
groups=content['groups']
cards={card['id']:card for card in content['cards']}
(EVIDENCE/'build-receipt.json').write_text((OUT/'build-receipt.json').read_text())
player=ids['Player']
results=[]
transcripts=[]
env=dict(os.environ,DISPLAY=os.environ.get('DISPLAY',':0'),LD_LIBRARY_PATH=str(WF/'engine/libs'))
log=(EVIDENCE/'engine.log').open('w')
proc=subprocess.Popen([str(WF/'engine/wf_game'),'-L'+str(OUT/'parmenides_slice-standalone.iff'),'-record_video',
    '--debug-port','7814','--debug-bind','127.0.0.1','--debug-print-actors','-width=1280','-height=720',
    '--vram-width=4096','--vram-height=2048','--vram-slot-width=512','--vram-slot-height=512',
    '--vram-perm-width=2048','--vram-perm-height=2048'],cwd=OUT,env=env,stdout=log,stderr=subprocess.STDOUT)
b=None
def value(m):return b.mailbox_values.get((player,m))
def check(label,condition):
    results.append({'check':label,'passed':bool(condition)})
    print(label,condition,flush=True)
    if not condition:raise AssertionError(label)
def tap(bit=1,frames=5):
    b.inject_input('joystick1_raw',bit,frames);time.sleep(.35)
def snap(name):
    target=EVIDENCE/(name+'.png')
    target.unlink(missing_ok=True)
    b.send({'op':'screenshot','filename':str(target)});time.sleep(.4)
def position(x,y):
    b.send({'op':'scene:set_transform','idx':player,'pos':[x,y,.16]});time.sleep(.4)
def read_pages(label,expected,terminal=0):
    observed=[]
    for expected_id in expected:
        actual=value(140)
        observed.append(actual)
        if actual!=expected_id:
            check(label+' exact page order',False)
        tap()
    transcripts.append({'interaction':label,'camera':value(101),'cards':observed,
                        'text':[cards[index]['text'] for index in observed],
                        'sources':[cards[index]['source'] for index in observed]})
    check(label+' intended text only, correct stop',observed==expected and value(140)==terminal)
def read_argument(x,y,key,flag,following=()):
    position(x,y);tap();check('argument opens',value(140)>0)
    read_pages(key,groups[key]+[index for extra in following for index in groups[extra]])
    check('complete encounter '+str(flag),value(flag)==1)
try:
    b=BridgeClient(port=7814,timeout=12)
    for m in [100,101,102,103,104,105,106,107,108,130,140,150,151,152,153,154,155,156,157,
              160,161,162,163,164,226,228,229,230,234,242,243,244,245,247,248,251,252,3009,3010,3011,3014]:b.watch(player,m)
    time.sleep(1)
    check('chapter initializes',value(100)==1)
    snap('intro');read_pages('intro',groups['intro']);check('intro dismisses',value(140)==0)
    if '--supplemental-text' in sys.argv:
        position(3,3);tap();read_pages('goddess before Love',groups['intro'])
        tap(4);read_pages('journal',groups['journal'])
        tap(4);check('journal can reopen',value(140)==groups['journal'][0]);tap(4)
        check('journal closes without other text',value(140)==0)
        check('native process alive',proc.poll() is None)
        raise SystemExit(0)
    snap('temple-third-person')
    position(7,8);tap();check('Reason gated before Love',value(140)==groups['reason_unavailable'][0]);read_pages('Reason prerequisite',groups['reason_unavailable'])
    tap(2);check('first person',value(101)==1);snap('temple-first-person')
    tap(2);check('third person',value(101)==0)
    start=value(3010);tap(2048,60);time.sleep(.9)
    check('native forward movement',value(3010)>start+.2)
    position(0,8);tap();check('physical Love portal',value(102)==1)
    snap('love-street')
    position(94,11);tap();check('choice gated before encounters',value(140)==16);read_pages('Love early choice gate',groups['locked'])
    read_argument(96,1,'first',103)
    check('First Love departs with label',value(251)==0 and value(247)==0)
    read_argument(104,2,'starlet',104)
    check('starlet departs with label',value(252)==0 and value(248)==0)
    position(100,6);tap();snap('newspaper');read_pages('newspaper',groups['paper']);check('paper completes',value(105)==1)
    position(100,-8);tap();check('Temple return does not commit Love',value(102)==0 and value(106)==0)
    position(7,8);tap();check('Reason requires commitment after all encounters',value(140)==groups['reason_unavailable'][0]);read_pages('Reason after uncommitted Love',groups['reason_unavailable'])
    position(0,8);tap();check('unfinished Love retains all encounters',value(102)==1 and all(value(m)==1 for m in (103,104,105)))
    position(94,11);tap();check('Being confirmation',value(140)==14);read_pages('Love Being confirmation',groups['affirm'],groups['return_being'][0])
    check('Being committed',value(107)==1 and value(106)==1 and value(102)==0)
    snap('temple-return-being');read_pages('Love Being return',groups['return_being'])
    position(3,3);tap();read_pages('goddess after Love Being',groups['return_being'])
    position(0,8);tap();check('Love replay resets encounters',value(103)==0 and value(104)==0 and value(105)==0)
    check('Love replay clears prior commitment',value(106)==0 and value(107)==0)
    check('Love replay restores both speakers and labels',all(value(m)!=0 for m in (251,252,247,248)))
    read_argument(96,1,'first',103);read_argument(104,2,'starlet',104);position(100,6);tap();read_pages('newspaper replay',groups['paper'])
    position(106,11);tap();check('NotBeing confirmation',value(140)==15);read_pages('Love NotBeing confirmation',groups['deny'],groups['return_notbeing'][0])
    check('NotBeing committed',value(107)==-1 and value(102)==0)
    snap('temple-return-notbeing');read_pages('Love NotBeing return',groups['return_notbeing'])
    position(3,3);tap();read_pages('goddess after Love NotBeing',groups['return_notbeing'])
    tap(8);check('reduced motion',value(108)==1)
    tap(4);check('journal',value(140)==19);tap(4);check('journal closes without choice',value(140)==0)
    tap(1,50);time.sleep(.8);check('remote held Select switches perspective',value(101)==1)
    for mode in (0,1):
        if value(101)!=mode:tap(2)
        for love,reason,history in ((1,1,'5a'),(1,-1,'5b'),(-1,1,'5c'),(-1,-1,'5d')):
            prefix=f'{history} camera={mode}: '
            # Both Love choices were played above. These fixtures select the prior history.
            b.set_mailbox(107,love,idx=player);time.sleep(.2)
            position(7,8);tap();check(prefix+'Reason portal',value(102)==2)
            check(prefix+'replay resets encounters',all(value(m)==0 for m in (150,151,152,153,154,155,156,157)))
            position(193,13);tap();check(prefix+'early commitment gated',value(140)==groups['reason_locked'][0]);read_pages(prefix+'early gate',groups['reason_locked'])
            position(200,10);tap();check(prefix+'child waits for both accounts',value(140)==groups['reason_wait'][0]);read_pages(prefix+'child waiting',groups['reason_wait'])
            position(196,1);tap();check(prefix+'White opens',value(140)==groups['white'][0])
            check(prefix+'world labels hidden under dialogue',all(value(m)==0 for m in (242,243,244,245)))
            read_pages(prefix+'White and grove',groups['white']+groups['grove'])
            check(prefix+'White and grove completed',value(150)==1 and value(140)==0 and value(163)!=0 and value(160)==0)
            if mode==0 and history=='5a':
                position(200,-8);tap();check('Reason return does not commit',value(102)==0 and value(154)==0)
                position(7,8);tap();check('unfinished Reason retains White and grove',value(102)==2 and value(150)==1 and value(163)!=0)
            read_argument(204,7,'wild',151)
            position(200,10);tap();check(prefix+'child still waits for apparatus',value(140)==groups['reason_wait'][0]);read_pages(prefix+'child still waiting',groups['reason_wait'])
            read_argument(200,3,'apparatus_order',152,('apparatus_limit',))
            check(prefix+'apparatus changes without choosing',value(157)==1 and value(164)!=0 and value(154)==0 and value(155)==0)
            read_argument(200,11,'child',153)
            position(193 if reason==1 else 207,13);tap()
            confirmation=groups['reason_affirm' if reason==1 else 'reason_deny'][0]
            check(prefix+'explicit confirmation',value(140)==confirmation)
            tap(16384);check(prefix+'Left cancels without committing',value(140)==0 and value(154)==0)
            tap();check(prefix+'confirmation reopens',value(140)==confirmation)
            read_pages(prefix+'chosen conclusion',groups['reason_affirm' if reason==1 else 'reason_deny']+
                       groups['why_axis' if reason==1 else 'rain_reply'],groups['return_'+history][0])
            check(prefix+'correct Temple history',value(102)==0 and value(154)==1 and value(155)==reason and
                  value(156)==int(history[-1],36)-9 and value(140)==groups['return_'+history][0])
            check(prefix+'source-correct walls and windows',bool(value(228))==(reason==1) and bool(value(229))==(reason==1))
            check(prefix+'Love tapestries retained',bool(value(234))==(love==1) and value(230)==0)
            check(prefix+'Truth portal enabled',value(226)!=0)
            check(prefix+'return labels hidden',value(242)==0)
            read_pages(prefix+'Temple return',groups['return_'+history])
            check(prefix+'labels restore after overlay',value(140)==0 and value(242)!=0)
            position(3,3);tap();read_pages(prefix+'goddess return replay',groups['return_'+history])
            position(-7,8);tap();check(prefix+'Truth identifies pending realm',value(140)==groups['truth_next'][0]);read_pages(prefix+'Truth marker',groups['truth_next'])
    position(0,8);tap()
    check('Love replay clears all downstream Reason progress',value(102)==1 and all(value(m)==0 for m in (150,151,152,153,154,155,156,157)))
    check('native process alive',proc.poll() is None)
finally:
    (EVIDENCE/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    (EVIDENCE/'transcripts.json').write_text(json.dumps(transcripts,indent=2)+'\n')
    if b:b.close()
    proc.terminate()
    try:proc.wait(timeout=5)
    except subprocess.TimeoutExpired:proc.kill()
    log.close()
