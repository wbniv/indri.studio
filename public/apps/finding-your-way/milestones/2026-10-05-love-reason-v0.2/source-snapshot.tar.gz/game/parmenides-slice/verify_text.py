"""Audit chapter text against canonical sources, independently of gameplay routing."""
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[1]
data = json.loads((ROOT / 'build/content.json').read_text())
cards = {card['id']: card for card in data['cards']}
results = []

def check(label, condition):
    results.append({'check': label, 'passed': bool(condition)})
    if not condition:
        raise AssertionError(label)

def canonical(slug):
    raw = (PROJECT / 'src/content/pages' / (slug + '.md')).read_text()
    body = raw.split('---', 2)[2].split('<details', 1)[0]
    body = re.sub(r'!\[[^\]]*\]\([^)]*\)', '', body)
    return ' '.join(body.replace('*', '').replace('_', '').split())

def text_for(*keys):
    return ' '.join(cards[index]['text'] for key in keys for index in data['groups'][key])

try:
    indices = [index for pages in data['groups'].values() for index in pages]
    check('every card belongs to exactly one group', len(indices) == len(set(indices)) == len(cards))
    for key, pages in data['groups'].items():
        check(key + ': group identity and nonempty text', bool(pages) and all(cards[index]['key'] == key and cards[index]['text'] for index in pages))
        check(key + ': no image/frontmatter markup in delivery', not any('![](' in cards[index]['text'] or 'slug:' in cards[index]['text'] for index in pages))
    for key, slugs in {'first': ('loveb',), 'starlet': ('lovec', 'loved'), 'wild': ('reasonca',),
                       'child': ('reasonda',), 'why_axis': ('reasonbeinga',), 'rain_reply': ('reasonnotbeinga',),
                       'return_5a': ('5a',), 'return_5b': ('5b',), 'return_5c': ('5c',), 'return_5d': ('5d',)}.items():
        check(key + ': complete intended source, no extra words', text_for(key) == ' '.join(canonical(slug) for slug in slugs))
    check('White + transformation: complete reasonaa/reasonba, no other account', text_for('white', 'grove') == canonical('reasonaa') + ' ' + canonical('reasonba'))
    check('White stops before the grove narration', 'You feel a vast crack' not in text_for('white') and text_for('grove').startswith('You feel a vast crack'))
    for stem in ('reasona', 'reasonb', 'reasonc', 'reasond', 'reasonbeing', 'reasonnotbeing'):
        check(stem + ': history aliases have identical spoken content', canonical(stem + 'a') == canonical(stem + 'b'))
    check('apparatus does not contain either concluding account', canonical('reasonbeinga') not in text_for('apparatus_order', 'apparatus_limit') and canonical('reasonnotbeinga') not in text_for('apparatus_order', 'apparatus_limit'))
    check('Reason gate explains a commitment, not just encounters', all(term in text_for('reason_unavailable') for term in ('BEING', 'NOTBEING', 'confirmation', 'TEMPLE portal returns without choosing')))
finally:
    output = PROJECT / 'docs/diagnostics/parmenides/reason/text-audit.json'
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps({'build': json.loads((ROOT / 'build/build-receipt.json').read_text()), 'results': results}, indent=2) + '\n')
print(f'{len(results)} source-content checks passed')
