"""Original low-poly Temple/Love models, exported directly with WF's Blender exporter.

The chapter's behavior is level Forth, not engine code. Re-run to reproduce the
editable .blend, mesh IFF files, source LEV and actor/mailbox manifest.
"""
import json
import math
import os
from pathlib import Path

import addon_utils
import bpy

WF = Path(os.environ['FYW_WF_ROOT'])
OUT = Path(os.environ['FYW_SLICE_OUT'])
OAD = WF / 'wfsource/source/oas'
content = json.loads((OUT / 'content.json').read_text())
bpy.ops.wm.read_factory_settings(use_empty=True)
addon_utils.enable('wf_blender', default_set=False, persistent=False)
bpy.ops.wf.import_level(filepath=str(WF / 'wflevels/snowgoons-blender/snowgoons-blender.lev'))
scene = bpy.context.scene

def cls(obj):
    return Path(obj.get('wf_schema_path', '')).stem

keep = {'director','camera','levelobj','matte','light','room','camshot','target','player'}
seen = set()
for obj in list(bpy.data.objects):
    kind = cls(obj)
    if kind not in keep or kind in seen:
        bpy.data.objects.remove(obj, do_unlink=True)
    else:
        seen.add(kind)

def find(kind):
    return next(o for o in scene.objects if cls(o) == kind)

palette = dict(stone='#b8ad91', cream='#efe4c9', gold='#c7a45b', ink='#26343c',
               blue='#456b85', skin='#c89172', hair='#453d38', brown='#79614e',
               red='#ac5453', street='#697370', green='#5d897c', purple='#8173a1')
mats = {}
for name, hexcolor in palette.items():
    rgb = tuple(int(hexcolor[i:i+2],16)/255 for i in (1,3,5))
    mat = bpy.data.materials.new(name);mat.use_nodes = True
    mat.diffuse_color = (*rgb,1)
    mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value = (*rgb,1)
    mats[name] = mat

class Model:
    def __init__(self):
        self.verts = [];self.faces = [];self.materials = []
    def part(self, verts, faces, color):
        offset = len(self.verts);self.verts.extend(verts)
        from mathutils import Vector
        for f in faces:
            for i in range(1,len(f)-1):
                tri=(f[0],f[i],f[i+1])
                a,b,c=(Vector(verts[n]) for n in tri)
                if (b-a).cross(c-a).length < .00014:continue
                self.faces.append(tuple(offset+n for n in tri))
                self.materials.append(list(mats).index(color))
    def box(self, center, size, color):
        x,y,z=center;a,b,c=(v/2 for v in size)
        v=[(x+dx*a,y+dy*b,z+dz*c) for dx,dy,dz in
           [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]]
        self.part(v,[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],color)
    def cone(self, center, radius, height, color, top=None, sides=10):
        x,y,z=center;top=radius if top is None else top
        v=[(x+r*math.cos(i*math.tau/sides),y+r*math.sin(i*math.tau/sides),z+k*height)
           for k,r in [(0,radius),(1,top)] for i in range(sides)]
        f=[tuple(reversed(range(sides))),tuple(range(sides,2*sides))]
        f += [(i,(i+1)%sides,(i+1)%sides+sides,i+sides) for i in range(sides)]
        self.part(v,f,color)
    def sphere(self, center, size, color, sides=8, rings=5):
        x,y,z=center;a,b,c=size
        v=[(x+a*math.sin(j*math.pi/rings)*math.cos(i*math.tau/sides),
            y+b*math.sin(j*math.pi/rings)*math.sin(i*math.tau/sides),
            z+c*math.cos(j*math.pi/rings)) for j in range(rings+1) for i in range(sides)]
        f=[(j*sides+i,j*sides+(i+1)%sides,(j+1)*sides+(i+1)%sides,(j+1)*sides+i)
           for j in range(rings) for i in range(sides)]
        self.part(v,f,color)
    def beam(self,start,end,width,color):
        from mathutils import Vector
        a,b=Vector(start),Vector(end);direction=(b-a).normalized()
        side=direction.cross(Vector((0,1,0))).normalized()*width/2
        up=direction.cross(side).normalized()*width/2
        verts=[tuple(p+side*s+up*t) for p in (a,b) for s,t in [(-1,-1),(1,-1),(1,1),(-1,1)]]
        self.part(verts,[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],color)
    def object(self, name, location=(0,0,0), kind='statplat', visibility=1, mass=0):
        mesh=bpy.data.meshes.new(name+'_mesh');mesh.from_pydata(self.verts,[],self.faces);mesh.update()
        for mat in mats.values():mesh.materials.append(mat)
        for poly,index in zip(mesh.polygons,self.materials):poly.material_index=index
        obj=bpy.data.objects.new(name,mesh);scene.collection.objects.link(obj)
        obj.location=(*location,0) if len(location)==2 else location
        setup(obj,kind,visibility,mass)
        return obj

def setup(obj,kind='statplat',visibility=1,mass=0):
    obj['wf_schema_path']=str(OAD/(kind+'.oad'))
    obj['wf_Mesh Name']=obj.name.lower()+'.iff';obj['wf_original_mesh_name']=obj.name.lower()+'.iff'
    obj['wf_Model Type']='Mesh';obj['wf_Mobility']='Anchored'
    obj['wf_Mass']=float(mass);obj['wf_Visibility Mailbox']=visibility
    return obj

def cube(name, location, size, color, mass=0, visibility=1):
    m=Model();m.box((0,0,0),size,color)
    return m.object(name,location,visibility=visibility,mass=mass)

def label(name,text,location,width=3,color='cream'):
    mesh=bpy.data.meshes.new(name)
    mesh.from_pydata([(-width/2,0,0),(width/2,0,0),(width/2,0,width/8),(-width/2,0,width/8)],[],[(0,1,2,3)])
    mesh.uv_layers.new()
    for loop,uv in zip(mesh.uv_layers.active.data,[(0,1),(1,1),(1,0),(0,0)]):loop.uv=uv
    mat=bpy.data.materials.new(name);mat.use_nodes=True
    tex=mat.node_tree.nodes.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(OUT/(name+'.tga')))
    mat.node_tree.links.new(tex.outputs['Color'],mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'])
    mat['wf_double_sided']=True;mat['wf_prelit']=True;mesh.materials.append(mat)
    obj=bpy.data.objects.new(name,mesh);scene.collection.objects.link(obj);obj.location=location
    return setup(obj,visibility=242)

def arch(name,x,y,color='red',visibility=1):
    m=Model()
    for side in (-1,1):
        m.box((side*1.15,0,1.25),(.35,.5,2.5),'stone')
        m.box((side*1.15,0,.12),(.65,.75,.24),'stone')
    # Segmented semicircular arch in the XZ plane, open passage below it.
    for i in range(12):
        a=i*math.pi/12;b=(i+1)*math.pi/12
        v=[(r*math.cos(t),depth,2.45+r*math.sin(t))
           for depth in (-.25,.25) for r,t in [(1,a),(1,b),(1.35,b),(1.35,a)]]
        m.part(v,[(0,1,2,3),(7,6,5,4),(0,4,5,1),(1,5,6,2),(2,6,7,3),(3,7,4,0)],'stone')
    m.box((0,.26,1.3),(1.9,.03,2.6),color)
    obj=m.object(name,(x,y,0),visibility=visibility)
    return obj

def human(name,location,coat='blue',goddess=False):
    m=Model()
    if goddess:
        m.cone((0,0,.08),.42,1.1,'cream',.23)
    else:
        for side in (-1,1):
            m.box((.06,side*.115,.085),(.39,.18,.17),'brown')
            m.box((0,side*.115,.43),(.20,.19,.62),'brown')
    m.cone((0,0,.8),.27,.5,coat,.23,8)
    m.box((.235,0,1.11),(.045,.23,.33),'cream')
    for side in (-1,1):
        m.cone((0,side*.32,.84),.075,.37,coat,.09,6)
        m.sphere((.05,side*.33,.82),(.085,.075,.10),'skin',6,3)
    m.cone((0,0,1.3),.09,.10,'skin',sides=6)
    m.sphere((0,0,1.54),(.18,.16,.23),'skin')
    m.sphere((-.07,0,1.68),(.15,.18,.14),'hair')
    for side in (-1,1):m.box((.173,side*.073,1.575),(.02,.038,.026),'ink')
    m.box((.184,0,1.49),(.02,.068,.015),'brown')
    if goddess:
        for side in (-1,1):
            for i in range(4):
                tip=( -.10, side*(.7+i*.12),1.45+i*.2)
                m.part([(-.14,side*.2,1.1),tip,(-.16,side*(.67+i*.12),1.24+i*.2)],[(0,1,2),(2,1,0)],'gold')
        m.cone((0,0,1.75),.19,.06,'gold',sides=8)
    return m.object(name,location,kind='platform')

# Remove all scaffold render meshes; retain only its proven native actor setup.
for obj in scene.objects:
    obj['wf_Model Type']='None'
    obj['wf_Visibility Mailbox']=1
    obj.display_type='WIRE'
director=find('director');director['wf_Script']='\\ wf\n'
player=find('player');player.name='Player'
figure=human('traveler',(0,0,0));player.data=figure.data
bpy.data.objects.remove(figure,do_unlink=True)
for key in ('wf_original_bbox','wf_had_authored_bbox'):
    if key in player:del player[key]
player.location=(0,-5,.05);player.scale=(1,1,1);player.rotation_euler=(0,0,math.pi/2)
setup(player,'player',250,70);player.display_type='SOLID';player['wf_Mobility']='Physics'
for key,value in {'Running Acceleration':75.,'Running Deceleration':.85,'Max Ground Speed':4.,
                  'Jumping Acceleration':0.,'Falling Acceleration':9.81,'Air Acceleration':0.,
                  'Max Air Speed':4.,'Horiz Air Drag':1.5,'Turn Rate':0.,'Script Controls Input':'True'}.items():
    player['wf_'+key]=value

# Temple: spacious circular floor, pillars, open dome ribs and four living tapestries.
cube('temple_floor',(0,0,-.35),(26,28,.7),'stone',1000)
cube('temple_walk',(0,1,.012),(3,24,.024),'cream')
temple=Model();walls=Model()
for x in (-10,10):
    walls.box((x,0,.6),(.8,27,1.2),'stone')
    for y in (-10,-5,0,5,10):
        temple.cone((x,y,.1),.36,5.0,'cream',.3)
        temple.cone((x,y,4.9),.48,.25,'gold')
        temple.box((x,y,.15),(.85,.85,.3),'stone')
walls.box((0,13,.6),(20,.8,1.2),'stone')
walls.object('temple_walls',visibility=228)
glass=Model()
for x in (-9.9,9.9):
    for y in (-7,0,7):
        for i,color in enumerate(('red','gold','blue','green')):
            glass.box((x,y-.6+(i%2)*1.2,2.4+(i//2)*1.1),(.035,1.05,1.0),color)
glass.object('stained_glass',visibility=229)
for y in (-5,2,8):
    for i in range(16):
        if i in (7,8):continue  # An open crown admits light into the temple.
        a=i*math.pi/16;b=(i+1)*math.pi/16
        temple.beam((9.8*math.cos(a),y,5+5*math.sin(a)),
                    (9.8*math.cos(b),y,5+5*math.sin(b)),.22,'gold')
temple.object('temple_structure')
arch('love_portal',0,9,'red');label('love_sign','LOVE',(0,8.65,3.85))
arch('reason_purple',7,9,'purple',238);arch('reason_blue',7,9,'blue',239)
label('reason_sign','REASON',(7,8.65,3.85),3)
arch('truth_portal',-7,9,'gold',226)
truth_label=label('truth_sign','TRUTH / NEXT CHAPTER',(-7,8.65,3.85),4)
truth_label['wf_Visibility Mailbox']=241
goddess=human('Goddess',(3,3,0),coat='cream',goddess=True);goddess.rotation_euler.z=-math.pi/2
label('goddess_sign','THE GODDESS',(3,2.8,2.6),3)
cloth=[]
for i,(x,y) in enumerate([(-5,-1),(5,-1),(-5,5),(5,5)]):
    p=Model();p.box((0,0,2),(.65,.65,4),'stone');p.box((0,0,4.1),(1.7,.75,.25),'gold')
    p.object('pillar'+str(i),(x,y))
    for variant in (0,1):
        c=Model();c.box((0,-.42,2.5),(1.5,.025,2.9),['red','purple','blue','green'][i])
        # Different interlocking colored planes, not final realm emblems substituted for fractals.
        for j in range(5):
            c.box(((-1)**j*.27,-.45,1.4+j*.52),(.60,.015,.3),'gold' if variant else 'cream')
        obj=c.object('cloth'+str(i)+'v'+str(variant),(x,y),kind='platform',visibility=230+i+4*variant)
        cloth.append(obj)

# Love: a compact, walkable everyday street, with distinct physical encounters.
cube('love_floor',(100,4,-.35),(28,30,.7),'street',1000)
cube('love_road',(100,4,.012),(8,28,.025),'ink')
for x in (94,106):cube('pavement'+str(x),(x,4,.06),(4,28,.12),'stone',1000)
street=Model()
for side in (-1,1):
    for i in range(4):
        x=100+side*11;y=-7+i*6
        street.box((x,y,3),(4,5,6),'cream' if i%2 else 'stone')
        street.box((x-side*2.03,y,1.2),(.03,1.1,2.4),'brown')
        for z in (3.1,4.8):
            street.box((x-side*2.04,y+.9,z),(.04,1.1,.85),'blue')
            street.box((x-side*2.04,y-.9,z),(.04,1.1,.85),'blue')
for x in (95,105):
    street.cone((x,-3,.12),.11,3.3,'ink',sides=6)
    street.box((x,-3,3.25),(.5,.5,.4),'gold')
street.object('street_buildings')
first=human('FirstLove',(96,2,.12),coat='red');first.rotation_euler.z=-math.pi/4;first['wf_Visibility Mailbox']=251
starlet=human('Starlet',(104,3,.12),coat='green');starlet.rotation_euler.z=-3*math.pi/4;starlet['wf_Visibility Mailbox']=252
first_label=label('first_sign','FIRST LOVE',(96,1.7,2.5),3);first_label['wf_Visibility Mailbox']=247
starlet_label=label('starlet_sign','THE STARLET',(104,2.7,2.5),3);starlet_label['wf_Visibility Mailbox']=248
paper=Model();paper.box((0,0,.6),(1.1,.75,1.2),'brown');paper.box((0,0,1.22),(1.2,.85,.04),'cream')
for j in range(6):paper.box((0,-.24+j*.075,1.25),(.9,.018,.012),'ink')
paper.object('newspaper',(100,7,0));label('paper_sign','ADVICE COLUMN',(100,6.6,1.7),3)
book=Model();book.box((0,0,0),(.32,.08,.4),'brown');book.box((0,-.05,0),(.27,.015,.35),'cream')
book.object('biology_book',(104,2.67,1.15))
arch('being_exit',94,12,'gold');label('being_sign','BEING',(94,11.65,3.85),3)
arch('notbeing_exit',106,12,'ink');label('notbeing_sign','NOTBEING',(106,11.65,3.85),3)
arch('back_portal',100,-9,'red')
back_label=label('back_sign','TEMPLE',(100,-8.65,3.85),3)
back_label.rotation_euler.z=math.pi

# Reason is a functional graybox. Complete the white account to reveal a grove;
# operate the weather apparatus, hear the Wild Self, then meet the younger self.
cube('reason_floor',(200,4,-.35),(28,30,.7),'cream',1000)
reason_white=human('WhiteSelf',(196,1,.05),coat='cream');reason_white.rotation_euler.z=-math.pi/2
reason_white['wf_Visibility Mailbox']=160
white_label=label('white_sign','WHITE-CLAD SELF',(196,.7,2.5),3);white_label['wf_Visibility Mailbox']=243
reason_wild=human('WildSelf',(204,7,.05),coat='brown');reason_wild.rotation_euler.z=-math.pi/2
reason_wild['wf_Visibility Mailbox']=161
wild_label=label('wild_sign','WILD SELF',(204,6.7,2.5),3);wild_label['wf_Visibility Mailbox']=244
child=human('YoungerSelf',(200,11,.05),coat='blue');child.scale=(.67,.67,.67);child.rotation_euler.z=-math.pi/2
child['wf_Visibility Mailbox']=162
child_label=label('child_sign','YOUNGER SELF',(200,10.7,1.8),3);child_label['wf_Visibility Mailbox']=245
apparatus=Model();apparatus.box((0,0,.5),(1.8,.8,1),'stone')
for i in range(3):
    apparatus.cone((-.6+i*.6,0,1),.18,.4,'gold' if i==0 else 'blue',sides=8)
apparatus.object('weather_machine',(200,3,0))
label('apparatus_sign','WEATHER / WHY?',(200,2.55,1.65),3)
model_order=Model()
for i in range(3):model_order.box((-.6+i*.6,0,.02),(.35,.35,.04),'gold' if i==0 else 'blue')
model_order.object('weather_order',(200,3,1.46),visibility=164)
grove=Model()
grove.box((200,6,.012),(15,16,.025),'green')
for x,y in [(193,4),(207,4),(194,9),(206,11),(192,13),(208,13)]:
    grove.cone((x,y,0),.25,3.4,'brown',.17,7)
    grove.cone((x,y,2.6),1.5,2.3,'green',.15,9)
for i in range(10):
    y=2+i*1.1;x=200+2*math.sin(i*.5)
    grove.box((x,y,.08),(.45,1.5,.16),'brown')
grove.object('reason_grove',visibility=163)
arch('reason_being',193,14,'cream');label('rbeing_sign','BEING',(193,13.65,3.85),3)
arch('reason_notbeing',207,14,'ink');label('rnotbeing_sign','NOTBEING',(207,13.65,3.85),3)
arch('reason_back',200,-9,'purple')
reason_back=label('rback_sign','TEMPLE',(200,-8.65,3.85),3);reason_back.rotation_euler.z=math.pi

# Native camera rig: relative follower, switchable eye height, hiding the traveler only in first person.
target=find('target');target.name='CamTarget';target.location=(0,0,0)
look=target.copy();look.data=target.data.copy();scene.collection.objects.link(look);look.name='LookAt';look.location=(0,1.5,1.2)
shot=find('camshot');shot.name='FollowShot';shot.location=(0,-3.8,2.7)
for axis in 'XYZ':shot['wf_Position '+axis]='Relative'
shot['wf_Rotation']='Fixed';shot['wf_FOV']=60.;shot['wf_Hither']=.1;shot['wf_Yon']=200.
shot['wf_Pan Time In Seconds']=.12;shot['wf_Track Object']='Player';shot['wf_Target']='LookAt';shot['wf_Follow']='CamTarget'
shot['wf_Elasticity']=3.
camera=find('camera');camera.name='Camera';camera.location=(0,-8.8,2.75)
camera['wf_original_bbox']=(-.025,-.025,-.025,.025,.025,.025)
camera['wf_FoggingStartDistance']=999.;camera['wf_FoggingCompleteDistance']=1000.
camera['wf_Background Color']=0x26343c
light=find('light');light.rotation_euler=(0,-math.radians(52),math.radians(55))
light['wf_lightType']='Directional'
for c in ('Red','Green','Blue'):light['wf_light'+c]=.7
ambient=light.copy();scene.collection.objects.link(ambient);ambient.name='Ambient'
ambient['wf_lightType']='Ambient'
for c in ('Red','Green','Blue'):ambient['wf_light'+c]=.45
matte=find('matte');matte['wf_Matte Type']='Color';matte['wf_Background Color']=0x26343c
find('levelobj')['wf_Num Mailboxes']=512
room=find('room');room.location=(0,0,0);room.scale=(1,1,1)
room['wf_original_bbox']=(-40,-40,-10,240,40,50)
room.hide_render=True;room.hide_set(True)

# Readable dialogue is an ordinary textured mesh attached to the actual camera;
# WF has no scripted text HUD in this runtime. This keeps all behavior in the level.
panels=[]
for card in content['cards']:
    name='card_%02d'%card['id'];mesh=bpy.data.meshes.new(name)
    mesh.from_pydata([(-1.65,0,-.825),(1.65,0,-.825),(1.65,0,.825),(-1.65,0,.825)],[],[(0,1,2,3)])
    mesh.uv_layers.new()
    for loop,uv in zip(mesh.uv_layers.active.data,[(0,1),(1,1),(1,0),(0,0)]):loop.uv=uv
    mat=bpy.data.materials.new(name);mat.use_nodes=True
    tex=mat.node_tree.nodes.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(OUT/(name+'.tga')))
    mat.node_tree.links.new(tex.outputs['Color'],mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'])
    mat['wf_double_sided']=True;mat['wf_prelit']=True
    mesh.materials.append(mat)
    obj=bpy.data.objects.new(name,mesh);scene.collection.objects.link(obj);obj.location=(0,-3,2)
    setup(obj,'platform',260+card['id']);obj['wf_Moves Between Rooms']='True';panels.append(obj)

actors=[o for o in scene.objects if o.get('wf_schema_path')]
ids={o.name:i+1 for i,o in enumerate(actors)}
def actor(name):return str(ids[name])
groups=content['groups']
def card(key):return str(groups[key][0])

import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from chapter_script import make_script
script=make_script(ids,content, [o.name for o in [goddess,starlet,first,reason_white,reason_wild,child]+cloth])
player['wf_Script']=script;player['wf_ScriptLanguage']='Forth'
(OUT/'chapter.fth').write_text(script)
(OUT/'actors.json').write_text(json.dumps({'ids':ids,'mailboxes':{'cameraMode':101,'realm':102,'firstLoveComplete':103,'starletComplete':104,'paperComplete':105,'loveCompleted':106,'loveChoice':107,'reducedMotion':108,'focus':130,'dialogueCard':140,'whiteComplete':150,'wildComplete':151,'apparatusComplete':152,'childComplete':153,'reasonCompleted':154,'reasonChoice':155,'templeHistory':156}},indent=2))
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'parmenides_slice.blend'))
bpy.ops.wf.export_level(filepath=str(OUT/'parmenides_slice.lev'))
print('PARMENIDES: exported',len(actors),'actors; direct WF pipeline; no engine edits')
