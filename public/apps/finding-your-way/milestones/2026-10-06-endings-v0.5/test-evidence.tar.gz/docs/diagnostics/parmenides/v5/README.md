# Endings v5.0 verification

- [x] Functional checks pass: 2,902 native runtime, 358 source and 1,434 exported bitmap/UV checks; 921 dialogue sequences cover all 208 cards.
- [x] Exact complete source dialogue and all 33 eligible final edges in both views; only `10b` reaches `101b`.
- [x] Chromecast 1 job `J-61d1afcb0d3c`: exact APK install, launch, remote input, Home/resume and cleanup pass. [Receipt](cast1-review/receipt.json).
- [x] Reviewed three actual device captures. [Scoped review](cast1-review/visual-review.json).
- [ ] Text clipping/occlusion, inward-facing character/arch surfaces and camera obstruction fixes are deliberately deferred to v5.5 at Will's request. No full rendered text-visibility pass is claimed.

APK SHA-256: `7f7ba37d62c0a7dd2a0f161a5d40fceedc8eb686a67a9141eff333e7d518f151`. Native fixtures set encounter positions and earlier branch state; actual input opens, advances, cancels and confirms the accounts. This is functional regression evidence, not phone acceptance or an entirely input-driven journey. State is session-local. [Functional implementation](../endings/implementation.md).
