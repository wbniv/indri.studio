# Temple and Love native prototype

This first playable pass runs in the existing World Foundry native runtime. It contains a walkable Temple, Love street, two arguments, an inspectable newspaper, deliberate Being/NotBeing commitments and both changed Temple returns. Reason is a visible next-chapter marker. Geometry is original Blender authoring; the source scaffold supplies WF infrastructure only.

- [x] Original Blender scene and models exported through the WF Blender exporter.
- [x] Default third-person follower and switchable first-person movement.
- [x] Both Love encounters, evidence gate, confirmation and source-correct Temple returns.
- [x] Level-owned journal, replay and reduced decorative motion.
- [x] Native desktop behavioral checks and Chromecast launch/Select/Home-resume checks on both devices.
- [ ] Complete phone acceptance, durable saves, full animation/voice work and final art.

Build with `task native:build`. The editable [Blender scene](build/parmenides_slice.blend), generated Forth, source LEV, native IFF files and frozen APK are produced under `build/`. [build-receipt.json](build/build-receipt.json) identifies the latest APK and native library hashes. Build products and the local development signing key are ignored by Git.

The builder requires Blender with `wf_blender` enabled, Pillow, the existing Rust WF asset tools, Android SDK build-tools 34.0.0 and Java/keytool. It reads `/home/will/WorldFoundry-wbniv`; it does not edit or rebuild engine sources. The runtime is reused from the existing condo release APK, with its two native libraries preserved byte for byte. The APK uses `org.worldfoundry.wf_game.parmenides`, so it installs alongside other WF apps.

Run `task native:verify` for native desktop behavioral checks. Debug transforms place encounter fixtures; native input opens and advances arguments and commits choices. These are behavioral tests, not an entirely input-driven traversal or phone certification. The Linux debug screenshot path returned stale/blank frames in this environment; use the actual Chromecast screenshots linked in the [implementation report](../../docs/diagnostics/parmenides/implementation.md) as reviewed visual evidence.

Install through `task native:install DEVICE=all`, or run `task native:check DEVICE=all`. These delegate to `task chromecast:*` in the WF checkout and verify the frozen APK hash before submission. They never use direct device control. The app registration has already been deployed through WF's administrator tool; `register_coordinator.py` retains the reproducible, hash-reviewed one-line addition.

On the TV remote, Up/Down walks forward/backward, Left/Right turns, a short Select press interacts or advances dialogue, and holding Select switches perspective. Approach the red Love portal and press Select. Read both accounts and inspect the newspaper before committing at either street doorway. Gamepads and the optional WF phone controller provide A/interact, B/perspective, C/journal or close, and D/reduced motion. The initial WF controller panel can be dismissed with Back; Back after that retains Android's exit behavior.

The newspaper is original replacement prose. First Love's complete account and the starlet's complete account retain source text; the new characters and generic biology book are original models. This prototype adapts the intro into a short onboarding sheet. It uses session-local state in one native level with two regions; quitting restarts the chapter. Whole-object idle/tapestry transforms demonstrate decorative motion, not exported skeletal character clips. The journal is a static argument summary. No final voice performance, checkpoint, simultaneous touch move/look, or phone thermal acceptance is claimed.

WF runtime copyright and GPL-2.0 notices remain those of World Foundry. Its source checkout is the corresponding local runtime source reference. Source for this chapter is [blender_scene.py](blender_scene.py) and [build.py](build.py). Authored with Codex, GPT-6; no verified tool-version or reasoning-effort value was available to include.
