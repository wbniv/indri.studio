"""Submit only frozen APKs to the existing WF Chromecast coordinator."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('action',choices=['install','check'])
parser.add_argument('--device',default='all')
args=parser.parse_args()
receipt=json.loads((ROOT/'build/build-receipt.json').read_text())
apk=Path(receipt['apk'])
if hashlib.sha256(apk.read_bytes()).hexdigest()!=receipt['sha256']:
    raise SystemExit('Frozen APK changed after build; refusing submission.')
command=['task','chromecast:submit' if args.action=='install' else 'chromecast:check',
         'DEVICE='+args.device,'APP=parmenides','APK='+str(apk)]
command+=['WORKFLOW=install'] if args.action=='install' else ['VALIDATOR=poke-resume','DURATION=8']
subprocess.run(command,cwd='/home/will/WorldFoundry-wbniv',check=True)
