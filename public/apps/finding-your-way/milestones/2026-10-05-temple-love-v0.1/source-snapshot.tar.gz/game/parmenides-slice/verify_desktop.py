"""Exercise the actual native chapter on desktop; no Chromecast access.

Debug transforms arrange encounter fixtures; real native input advances every
argument and confirms the two choices. This is not proof of Android gameplay.
"""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'build'
EVIDENCE=ROOT.parents[1]/'docs/diagnostics/parmenides/desktop'
EVIDENCE.mkdir(parents=True,exist_ok=True)
WF=Path('/home/will/WorldFoundry-wbniv')
sys.path.insert(0,str(WF/'tests'))
from debug_bridge_client import BridgeClient

ids=json.loads((OUT/'actors.json').read_text())['ids']
player=ids['Player']
results=[]
env=dict(os.environ,DISPLAY=os.environ.get('DISPLAY',':0'),LD_LIBRARY_PATH=str(WF/'engine/libs'))
log=(EVIDENCE/'engine.log').open('w')
proc=subprocess.Popen([str(WF/'engine/wf_game'),'-L'+str(OUT/'parmenides_slice-standalone.iff'),'-record_video',
    '--debug-port','7814','--debug-bind','127.0.0.1','--debug-print-actors','-width=1280','-height=720',
    '--vram-width=4096','--vram-height=2048','--vram-slot-width=512','--vram-slot-height=512',
    '--vram-perm-width=2048','--vram-perm-height=2048'],cwd=OUT,env=env,stdout=log,stderr=subprocess.STDOUT)
b=None
def value(m):return b.mailbox_values.get((player,m))
def check(label,condition):
    results.append({'check':label,'passed':bool(condition)})
    print(label,condition,flush=True)
    if not condition:raise AssertionError(label)
def tap(bit=1,frames=5):
    b.inject_input('joystick1_raw',bit,frames);time.sleep(.35)
def snap(name):
    target=EVIDENCE/(name+'.png')
    target.unlink(missing_ok=True)
    b.send({'op':'screenshot','filename':str(target)});time.sleep(.4)
def position(x,y):
    b.send({'op':'scene:set_transform','idx':player,'pos':[x,y,.16]});time.sleep(.4)
def read_argument(x,y,last,flag):
    position(x,y);tap();check('argument opens',value(140)>0)
    for i in range(14):
        if value(140)==0:break
        tap()
    check('complete encounter '+str(flag),value(flag)==1)
try:
    b=BridgeClient(port=7814,timeout=12)
    for m in [100,101,102,103,104,105,106,107,108,130,140,3009,3010,3011,3014]:b.watch(player,m)
    time.sleep(1)
    check('chapter initializes',value(100)==1)
    snap('intro');tap();check('intro dismisses',value(140)==0)
    snap('temple-third-person')
    tap(2);check('first person',value(101)==1);snap('temple-first-person')
    tap(2);check('third person',value(101)==0)
    start=value(3010);tap(2048,60);time.sleep(.9)
    check('native forward movement',value(3010)>start+.2)
    position(0,8);tap();check('physical Love portal',value(102)==1)
    snap('love-street')
    position(94,11);tap();check('choice gated before encounters',value(140)==16);tap()
    read_argument(96,1,4,103)
    read_argument(104,2,12,104)
    position(100,6);tap();snap('newspaper');tap();check('paper completes',value(105)==1)
    position(94,11);tap();check('Being confirmation',value(140)==14);tap()
    check('Being committed',value(107)==1 and value(106)==1 and value(102)==0)
    snap('temple-return-being');tap()
    position(0,8);tap();check('Love replay resets encounters',value(103)==0 and value(104)==0 and value(105)==0)
    read_argument(96,1,4,103);read_argument(104,2,12,104);position(100,6);tap();tap()
    position(106,11);tap();check('NotBeing confirmation',value(140)==15);tap()
    check('NotBeing committed',value(107)==-1 and value(102)==0)
    snap('temple-return-notbeing');tap()
    tap(8);check('reduced motion',value(108)==1)
    tap(4);check('journal',value(140)==19);tap(4);check('journal closes without choice',value(140)==0)
    tap(1,50);time.sleep(.8);check('remote held Select switches perspective',value(101)==1)
    check('native process alive',proc.poll() is None)
finally:
    (EVIDENCE/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    if b:b.close()
    proc.terminate()
    try:proc.wait(timeout=5)
    except subprocess.TimeoutExpired:proc.kill()
    log.close()
