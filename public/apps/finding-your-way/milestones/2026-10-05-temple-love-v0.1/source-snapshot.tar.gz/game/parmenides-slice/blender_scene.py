"""Original low-poly Temple/Love models, exported directly with WF's Blender exporter.

The chapter's behavior is level Forth, not engine code. Re-run to reproduce the
editable .blend, mesh IFF files, source LEV and actor/mailbox manifest.
"""
import json
import math
import os
from pathlib import Path

import addon_utils
import bpy

WF = Path(os.environ['FYW_WF_ROOT'])
OUT = Path(os.environ['FYW_SLICE_OUT'])
OAD = WF / 'wfsource/source/oas'
content = json.loads((OUT / 'content.json').read_text())
bpy.ops.wm.read_factory_settings(use_empty=True)
addon_utils.enable('wf_blender', default_set=False, persistent=False)
bpy.ops.wf.import_level(filepath=str(WF / 'wflevels/snowgoons-blender/snowgoons-blender.lev'))
scene = bpy.context.scene

def cls(obj):
    return Path(obj.get('wf_schema_path', '')).stem

keep = {'director','camera','levelobj','matte','light','room','camshot','target','player'}
seen = set()
for obj in list(bpy.data.objects):
    kind = cls(obj)
    if kind not in keep or kind in seen:
        bpy.data.objects.remove(obj, do_unlink=True)
    else:
        seen.add(kind)

def find(kind):
    return next(o for o in scene.objects if cls(o) == kind)

palette = dict(stone='#b8ad91', cream='#efe4c9', gold='#c7a45b', ink='#26343c',
               blue='#456b85', skin='#c89172', hair='#453d38', brown='#79614e',
               red='#ac5453', street='#697370', green='#5d897c', purple='#8173a1')
mats = {}
for name, hexcolor in palette.items():
    rgb = tuple(int(hexcolor[i:i+2],16)/255 for i in (1,3,5))
    mat = bpy.data.materials.new(name);mat.use_nodes = True
    mat.diffuse_color = (*rgb,1)
    mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value = (*rgb,1)
    mats[name] = mat

class Model:
    def __init__(self):
        self.verts = [];self.faces = [];self.materials = []
    def part(self, verts, faces, color):
        offset = len(self.verts);self.verts.extend(verts)
        from mathutils import Vector
        for f in faces:
            for i in range(1,len(f)-1):
                tri=(f[0],f[i],f[i+1])
                a,b,c=(Vector(verts[n]) for n in tri)
                if (b-a).cross(c-a).length < .00014:continue
                self.faces.append(tuple(offset+n for n in tri))
                self.materials.append(list(mats).index(color))
    def box(self, center, size, color):
        x,y,z=center;a,b,c=(v/2 for v in size)
        v=[(x+dx*a,y+dy*b,z+dz*c) for dx,dy,dz in
           [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]]
        self.part(v,[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],color)
    def cone(self, center, radius, height, color, top=None, sides=10):
        x,y,z=center;top=radius if top is None else top
        v=[(x+r*math.cos(i*math.tau/sides),y+r*math.sin(i*math.tau/sides),z+k*height)
           for k,r in [(0,radius),(1,top)] for i in range(sides)]
        f=[tuple(reversed(range(sides))),tuple(range(sides,2*sides))]
        f += [(i,(i+1)%sides,(i+1)%sides+sides,i+sides) for i in range(sides)]
        self.part(v,f,color)
    def sphere(self, center, size, color, sides=8, rings=5):
        x,y,z=center;a,b,c=size
        v=[(x+a*math.sin(j*math.pi/rings)*math.cos(i*math.tau/sides),
            y+b*math.sin(j*math.pi/rings)*math.sin(i*math.tau/sides),
            z+c*math.cos(j*math.pi/rings)) for j in range(rings+1) for i in range(sides)]
        f=[(j*sides+i,j*sides+(i+1)%sides,(j+1)*sides+(i+1)%sides,(j+1)*sides+i)
           for j in range(rings) for i in range(sides)]
        self.part(v,f,color)
    def beam(self,start,end,width,color):
        from mathutils import Vector
        a,b=Vector(start),Vector(end);direction=(b-a).normalized()
        side=direction.cross(Vector((0,1,0))).normalized()*width/2
        up=direction.cross(side).normalized()*width/2
        verts=[tuple(p+side*s+up*t) for p in (a,b) for s,t in [(-1,-1),(1,-1),(1,1),(-1,1)]]
        self.part(verts,[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],color)
    def object(self, name, location=(0,0,0), kind='statplat', visibility=1, mass=0):
        mesh=bpy.data.meshes.new(name+'_mesh');mesh.from_pydata(self.verts,[],self.faces);mesh.update()
        for mat in mats.values():mesh.materials.append(mat)
        for poly,index in zip(mesh.polygons,self.materials):poly.material_index=index
        obj=bpy.data.objects.new(name,mesh);scene.collection.objects.link(obj)
        obj.location=(*location,0) if len(location)==2 else location
        setup(obj,kind,visibility,mass)
        return obj

def setup(obj,kind='statplat',visibility=1,mass=0):
    obj['wf_schema_path']=str(OAD/(kind+'.oad'))
    obj['wf_Mesh Name']=obj.name.lower()+'.iff';obj['wf_original_mesh_name']=obj.name.lower()+'.iff'
    obj['wf_Model Type']='Mesh';obj['wf_Mobility']='Anchored'
    obj['wf_Mass']=float(mass);obj['wf_Visibility Mailbox']=visibility
    return obj

def cube(name, location, size, color, mass=0, visibility=1):
    m=Model();m.box((0,0,0),size,color)
    return m.object(name,location,visibility=visibility,mass=mass)

def label(name,text,location,width=3,color='cream'):
    mesh=bpy.data.meshes.new(name)
    mesh.from_pydata([(-width/2,0,0),(width/2,0,0),(width/2,0,width/8),(-width/2,0,width/8)],[],[(0,1,2,3)])
    mesh.uv_layers.new()
    for loop,uv in zip(mesh.uv_layers.active.data,[(0,1),(1,1),(1,0),(0,0)]):loop.uv=uv
    mat=bpy.data.materials.new(name);mat.use_nodes=True
    tex=mat.node_tree.nodes.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(OUT/(name+'.tga')))
    mat.node_tree.links.new(tex.outputs['Color'],mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'])
    mat['wf_double_sided']=True;mat['wf_prelit']=True;mesh.materials.append(mat)
    obj=bpy.data.objects.new(name,mesh);scene.collection.objects.link(obj);obj.location=location
    return setup(obj)

def arch(name,x,y,color='red',visibility=1):
    m=Model()
    for side in (-1,1):
        m.box((side*1.15,0,1.25),(.35,.5,2.5),'stone')
        m.box((side*1.15,0,.12),(.65,.75,.24),'stone')
    # Segmented semicircular arch in the XZ plane, open passage below it.
    for i in range(12):
        a=i*math.pi/12;b=(i+1)*math.pi/12
        v=[(r*math.cos(t),depth,2.45+r*math.sin(t))
           for depth in (-.25,.25) for r,t in [(1,a),(1,b),(1.35,b),(1.35,a)]]
        m.part(v,[(0,1,2,3),(7,6,5,4),(0,4,5,1),(1,5,6,2),(2,6,7,3),(3,7,4,0)],'stone')
    m.box((0,.26,1.3),(1.9,.03,2.6),color)
    obj=m.object(name,(x,y,0),visibility=visibility)
    return obj

def human(name,location,coat='blue',goddess=False):
    m=Model()
    if goddess:
        m.cone((0,0,.08),.42,1.1,'cream',.23)
    else:
        for side in (-1,1):
            m.box((.06,side*.115,.085),(.39,.18,.17),'brown')
            m.box((0,side*.115,.43),(.20,.19,.62),'brown')
    m.cone((0,0,.8),.27,.5,coat,.23,8)
    m.box((.235,0,1.11),(.045,.23,.33),'cream')
    for side in (-1,1):
        m.cone((0,side*.32,.84),.075,.37,coat,.09,6)
        m.sphere((.05,side*.33,.82),(.085,.075,.10),'skin',6,3)
    m.cone((0,0,1.3),.09,.10,'skin',sides=6)
    m.sphere((0,0,1.54),(.18,.16,.23),'skin')
    m.sphere((-.07,0,1.68),(.15,.18,.14),'hair')
    for side in (-1,1):m.box((.173,side*.073,1.575),(.02,.038,.026),'ink')
    m.box((.184,0,1.49),(.02,.068,.015),'brown')
    if goddess:
        for side in (-1,1):
            for i in range(4):
                tip=( -.10, side*(.7+i*.12),1.45+i*.2)
                m.part([(-.14,side*.2,1.1),tip,(-.16,side*(.67+i*.12),1.24+i*.2)],[(0,1,2),(2,1,0)],'gold')
        m.cone((0,0,1.75),.19,.06,'gold',sides=8)
    return m.object(name,location,kind='platform')

# Remove all scaffold render meshes; retain only its proven native actor setup.
for obj in scene.objects:
    obj['wf_Model Type']='None'
    obj['wf_Visibility Mailbox']=1
    obj.display_type='WIRE'
director=find('director');director['wf_Script']='\\ wf\n'
player=find('player');player.name='Player'
figure=human('traveler',(0,0,0));player.data=figure.data
bpy.data.objects.remove(figure,do_unlink=True)
for key in ('wf_original_bbox','wf_had_authored_bbox'):
    if key in player:del player[key]
player.location=(0,-5,.05);player.scale=(1,1,1);player.rotation_euler=(0,0,math.pi/2)
setup(player,'player',250,70);player.display_type='SOLID';player['wf_Mobility']='Physics'
for key,value in {'Running Acceleration':75.,'Running Deceleration':.85,'Max Ground Speed':4.,
                  'Jumping Acceleration':0.,'Falling Acceleration':9.81,'Air Acceleration':0.,
                  'Max Air Speed':4.,'Horiz Air Drag':1.5,'Turn Rate':0.,'Script Controls Input':'True'}.items():
    player['wf_'+key]=value

# Temple: spacious circular floor, pillars, open dome ribs and four living tapestries.
cube('temple_floor',(0,0,-.35),(26,28,.7),'stone',1000)
cube('temple_walk',(0,1,.012),(3,24,.024),'cream')
temple=Model()
for x in (-10,10):
    temple.box((x,0,.6),(.8,27,1.2),'stone')
    for y in (-10,-5,0,5,10):
        temple.cone((x,y,.1),.36,5.0,'cream',.3)
        temple.cone((x,y,4.9),.48,.25,'gold')
        temple.box((x,y,.15),(.85,.85,.3),'stone')
temple.box((0,13,.6),(20,.8,1.2),'stone')
for y in (-5,2,8):
    for i in range(16):
        if i in (7,8):continue  # An open crown admits light into the temple.
        a=i*math.pi/16;b=(i+1)*math.pi/16
        temple.beam((9.8*math.cos(a),y,5+5*math.sin(a)),
                    (9.8*math.cos(b),y,5+5*math.sin(b)),.22,'gold')
temple.object('temple_structure')
arch('love_portal',0,9,'red');label('love_sign','LOVE',(0,8.65,3.85))
arch('reason_purple',7,9,'purple',238);arch('reason_blue',7,9,'blue',239)
label('reason_sign','REASON / NEXT CHAPTER',(7,8.65,3.85),4)
goddess=human('Goddess',(3,3,0),coat='cream',goddess=True);goddess.rotation_euler.z=-math.pi/2
label('goddess_sign','THE GODDESS',(3,2.8,2.6),3)
cloth=[]
for i,(x,y) in enumerate([(-5,-1),(5,-1),(-5,5),(5,5)]):
    p=Model();p.box((0,0,2),(.65,.65,4),'stone');p.box((0,0,4.1),(1.7,.75,.25),'gold')
    p.object('pillar'+str(i),(x,y))
    for variant in (0,1):
        c=Model();c.box((0,-.42,2.5),(1.5,.025,2.9),['red','purple','blue','green'][i])
        # Different interlocking colored planes, not final realm emblems substituted for fractals.
        for j in range(5):
            c.box(((-1)**j*.27,-.45,1.4+j*.52),(.60,.015,.3),'gold' if variant else 'cream')
        obj=c.object('cloth'+str(i)+'v'+str(variant),(x,y),kind='platform',visibility=230+i+4*variant)
        cloth.append(obj)

# Love: a compact, walkable everyday street, with distinct physical encounters.
cube('love_floor',(100,4,-.35),(28,30,.7),'street',1000)
cube('love_road',(100,4,.012),(8,28,.025),'ink')
for x in (94,106):cube('pavement'+str(x),(x,4,.06),(4,28,.12),'stone',1000)
street=Model()
for side in (-1,1):
    for i in range(4):
        x=100+side*11;y=-7+i*6
        street.box((x,y,3),(4,5,6),'cream' if i%2 else 'stone')
        street.box((x-side*2.03,y,1.2),(.03,1.1,2.4),'brown')
        for z in (3.1,4.8):
            street.box((x-side*2.04,y+.9,z),(.04,1.1,.85),'blue')
            street.box((x-side*2.04,y-.9,z),(.04,1.1,.85),'blue')
for x in (95,105):
    street.cone((x,-3,.12),.11,3.3,'ink',sides=6)
    street.box((x,-3,3.25),(.5,.5,.4),'gold')
street.object('street_buildings')
first=human('FirstLove',(96,2,.12),coat='red');first.rotation_euler.z=-math.pi/4;first['wf_Visibility Mailbox']=251
starlet=human('Starlet',(104,3,.12),coat='green');starlet.rotation_euler.z=-3*math.pi/4
label('first_sign','FIRST LOVE',(96,1.7,2.5),3)
label('starlet_sign','THE STARLET',(104,2.7,2.5),3)
paper=Model();paper.box((0,0,.6),(1.1,.75,1.2),'brown');paper.box((0,0,1.22),(1.2,.85,.04),'cream')
for j in range(6):paper.box((0,-.24+j*.075,1.25),(.9,.018,.012),'ink')
paper.object('newspaper',(100,7,0));label('paper_sign','ADVICE COLUMN',(100,6.6,1.7),3)
book=Model();book.box((0,0,0),(.32,.08,.4),'brown');book.box((0,-.05,0),(.27,.015,.35),'cream')
book.object('biology_book',(104,2.67,1.15))
arch('being_exit',94,12,'gold');label('being_sign','BEING',(94,11.65,3.85),3)
arch('notbeing_exit',106,12,'ink');label('notbeing_sign','NOTBEING',(106,11.65,3.85),3)
arch('back_portal',100,-9,'red');label('back_sign','TEMPLE',(100,-9.35,3.85),3)

# Native camera rig: relative follower, switchable eye height, hiding the traveler only in first person.
target=find('target');target.name='CamTarget';target.location=(0,0,0)
look=target.copy();look.data=target.data.copy();scene.collection.objects.link(look);look.name='LookAt';look.location=(0,1.5,1.2)
shot=find('camshot');shot.name='FollowShot';shot.location=(0,-3.8,2.7)
for axis in 'XYZ':shot['wf_Position '+axis]='Relative'
shot['wf_Rotation']='Fixed';shot['wf_FOV']=60.;shot['wf_Hither']=.1;shot['wf_Yon']=200.
shot['wf_Pan Time In Seconds']=.12;shot['wf_Track Object']='Player';shot['wf_Target']='LookAt';shot['wf_Follow']='CamTarget'
shot['wf_Elasticity']=3.
camera=find('camera');camera.name='Camera';camera.location=(0,-8.8,2.75)
camera['wf_original_bbox']=(-.025,-.025,-.025,.025,.025,.025)
camera['wf_FoggingStartDistance']=999.;camera['wf_FoggingCompleteDistance']=1000.
camera['wf_Background Color']=0x26343c
light=find('light');light.rotation_euler=(0,-math.radians(52),math.radians(55))
light['wf_lightType']='Directional'
for c in ('Red','Green','Blue'):light['wf_light'+c]=.7
ambient=light.copy();scene.collection.objects.link(ambient);ambient.name='Ambient'
ambient['wf_lightType']='Ambient'
for c in ('Red','Green','Blue'):ambient['wf_light'+c]=.45
matte=find('matte');matte['wf_Matte Type']='Color';matte['wf_Background Color']=0x26343c
find('levelobj')['wf_Num Mailboxes']=512
room=find('room');room.location=(0,0,0);room.scale=(1,1,1)
room['wf_original_bbox']=(-40,-40,-10,140,40,50)
room.hide_render=True;room.hide_set(True)

# Readable dialogue is an ordinary textured mesh attached to the actual camera;
# WF has no scripted text HUD in this runtime. This keeps all behavior in the level.
panels=[]
for card in content['cards']:
    name='card_%02d'%card['id'];mesh=bpy.data.meshes.new(name)
    mesh.from_pydata([(-1.65,0,-.825),(1.65,0,-.825),(1.65,0,.825),(-1.65,0,.825)],[],[(0,1,2,3)])
    mesh.uv_layers.new()
    for loop,uv in zip(mesh.uv_layers.active.data,[(0,1),(1,1),(1,0),(0,0)]):loop.uv=uv
    mat=bpy.data.materials.new(name);mat.use_nodes=True
    tex=mat.node_tree.nodes.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(OUT/(name+'.tga')))
    mat.node_tree.links.new(tex.outputs['Color'],mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'])
    mat['wf_double_sided']=True;mat['wf_prelit']=True
    mesh.materials.append(mat)
    obj=bpy.data.objects.new(name,mesh);scene.collection.objects.link(obj);obj.location=(0,-3,2)
    setup(obj,'platform',260+card['id']);obj['wf_Moves Between Rooms']='True';panels.append(obj)

actors=[o for o in scene.objects if o.get('wf_schema_path')]
ids={o.name:i+1 for i,o in enumerate(actors)}
def actor(name):return str(ids[name])
groups=content['groups']
def card(key):return str(groups[key][0])

script=r'''
\ Finding Your Way / Temple-Love first chapter. All state is level-owned.
: fy-wrap dup 0 < if 1 + then dup 1 >= if 1 - then ;
: fy-sin fy-wrap dup 0.5 > if 0.5 - -1 else 1 then >r
  2 * dup 1 swap - * dup 16 * swap 4 * 5 swap - / r> * ;
: fy-cos 0.25 + fy-sin ;
: fy-key 111 read-mailbox & 0 <> ;
: fy-pressed dup fy-key over 116 read-mailbox & 0 = & swap
  INDEXOF_HARDWARE_JOYSTICK1_RAW_JUSTPRESSED read-mailbox & 0 <> | ;
: fy-stop 0 INDEXOF_INPUT write-mailbox
  0 INDEXOF_XSPEED write-mailbox 0 INDEXOF_YSPEED write-mailbox ;
: fy-toggle 101 read-mailbox 0 = if 1 else 0 then 101 write-mailbox ;
: fy-near INDEXOF_Y_POS read-mailbox - dup * swap
  INDEXOF_X_POS read-mailbox - dup * + 6.25 < ;
: fy-teleport 127 write-mailbox 126 write-mailbox
  127 read-mailbox INDEXOF_Y_POS write-mailbox 126 read-mailbox INDEXOF_X_POS write-mailbox
  0.15 INDEXOF_Z_POS write-mailbox fy-stop 0 INDEXOF_ZSPEED write-mailbox
  0.25 114 write-mailbox ;
: fy-enter 100 -5 fy-teleport 1 102 write-mailbox
  0 103 write-mailbox 0 104 write-mailbox 0 105 write-mailbox
  0 140 write-mailbox ;
: fy-return 0 -3 fy-teleport 0 102 write-mailbox 0 140 write-mailbox ;
: fy-ready 103 read-mailbox 104 read-mailbox & 105 read-mailbox & ;
'''
script+=f': fy-cut-camera 126 read-mailbox INDEXOF_X_POS {actor("Camera")} write-actor-mailbox\n'
script+=f'127 read-mailbox 101 read-mailbox 0 = if 3.8 - else 0.6 + then INDEXOF_Y_POS {actor("Camera")} write-actor-mailbox\n'
script+=f'101 read-mailbox 0 = if 2.85 else 1.7 then INDEXOF_Z_POS {actor("Camera")} write-actor-mailbox\n'
for axis in 'XYZ':script+=f'0 INDEXOF_{axis}SPEED {actor("Camera")} write-actor-mailbox\n'
script+=';\n'
# Portal cuts move both native actors; the follower should never cross the empty gap between realms.
script=script.replace('0.25 114 write-mailbox ;','0.25 114 write-mailbox fy-cut-camera ;')
# Forth definitions resolve in source order.
start=script.index(': fy-cut-camera');end=script.index(';\n',start)+2
cut=script[start:end];script=script[:start]+script[end:]
script=script.replace(': fy-teleport',cut+'\n: fy-teleport',1)
script+=': fy-commit 107 write-mailbox 1 106 write-mailbox fy-return\n'
script+=f'107 read-mailbox 1 = if {card("return_being")} else {card("return_notbeing")} then 140 write-mailbox ;\n'
script+=': fy-advance\n'
for key,flag in [('first',103),('starlet',104),('paper',105)]:
    values=groups[key]
    script+=f'140 read-mailbox {values[-1]} = if 1 {flag} write-mailbox 0 140 write-mailbox else\n'
    if len(values)>1:
        script+=f'140 read-mailbox {values[0]} >= 140 read-mailbox {values[-1]} < & if 140 read-mailbox 1 + 140 write-mailbox else\n'
script+=f'140 read-mailbox {card("affirm")} = if 1 fy-commit else\n'
script+=f'140 read-mailbox {card("deny")} = if -1 fy-commit else 0 140 write-mailbox\n'
script+='then then '+('then '*sum(1+(len(groups[k])>1) for k in ('first','starlet','paper')))+';\n'
script+=': fy-focus 0 130 write-mailbox\n 102 read-mailbox 0 = if\n'
for x,y,focus in [(0,9,1),(3,3,2),(7,9,3)]:script+=f'{x} {y} fy-near if {focus} 130 write-mailbox then\n'
script+='else\n'
for x,y,focus in [(96,2,4),(104,3,5),(100,7,6),(94,12,7),(106,12,8),(100,-9,9)]:script+=f'{x} {y} fy-near if {focus} 130 write-mailbox then\n'
script+='then ;\n: fy-interact 140 read-mailbox 0 <> if fy-advance else\n'
script+='130 read-mailbox 1 = if fy-enter then\n'
script+=f'130 read-mailbox 2 = if 106 read-mailbox 0 = if {card("intro")} else 107 read-mailbox 1 = if {card("return_being")} else {card("return_notbeing")} then then 140 write-mailbox then\n'
script+=f'130 read-mailbox 3 = if {card("journal")} 140 write-mailbox then\n'
for focus,key in [(4,'first'),(5,'starlet'),(6,'paper')]:script+=f'130 read-mailbox {focus} = if {card(key)} 140 write-mailbox then\n'
for focus,key in [(7,'affirm'),(8,'deny')]:script+=f'130 read-mailbox {focus} = if fy-ready if {card(key)} else {card("locked")} then 140 write-mailbox then\n'
script+='130 read-mailbox 9 = if fy-return then\nthen ;\n'
script+=f': fy-init 100 read-mailbox 0 = if 1 100 write-mailbox 0.25 114 write-mailbox {card("intro")} 140 write-mailbox then ;\n'
script+=r'''
: fy-input
  INDEXOF_HARDWARE_JOYSTICK1_RAW read-mailbox 111 write-mailbox
  INDEXOF_DELTA_TIME read-mailbox 0 max 0.05 min 115 write-mailbox
  0 118 write-mailbox
  JOYSTICK_BUTTON_A fy-key if
    112 read-mailbox 115 read-mailbox + 112 write-mailbox
    112 read-mailbox 0.65 >= 113 read-mailbox 0 = & if fy-toggle 1 113 write-mailbox then
  else
    112 read-mailbox 0 > 113 read-mailbox 0 = & if 1 118 write-mailbox then
    \ Catch a short DPAD_CENTER down/up delivered within one engine frame.
    INDEXOF_HARDWARE_JOYSTICK1_RAW_JUSTPRESSED read-mailbox JOYSTICK_BUTTON_A & 0 <>
    112 read-mailbox 0 = & if 1 118 write-mailbox then
    0 112 write-mailbox 0 113 write-mailbox
  then
  JOYSTICK_BUTTON_B fy-pressed if fy-toggle then
'''
script+=f'JOYSTICK_BUTTON_C fy-pressed if 140 read-mailbox 0 = if {card("journal")} else 0 then 140 write-mailbox then\n'
script+=r'''
  JOYSTICK_BUTTON_D fy-pressed if 108 read-mailbox 0 = if 1 else 0 then 108 write-mailbox then
  fy-focus 118 read-mailbox 0 <> if fy-interact then
  140 read-mailbox 0 <> if fy-stop else
    JOYSTICK_BUTTON_LEFT fy-key if 1 else 0 then
    JOYSTICK_BUTTON_RIGHT fy-key if 1 else 0 then -
    115 read-mailbox * 6 / 114 read-mailbox + fy-wrap 114 write-mailbox
    114 read-mailbox INDEXOF_ROTATION_C write-mailbox
    111 read-mailbox 6144 & INDEXOF_INPUT write-mailbox
  then
  111 read-mailbox 116 write-mailbox
  110 read-mailbox 115 read-mailbox + 110 write-mailbox ;
: fy-camera
  114 read-mailbox fy-cos 120 write-mailbox 114 read-mailbox fy-sin 121 write-mailbox
  101 read-mailbox 0 = if -3.8 122 write-mailbox 2.7 123 write-mailbox 1.2 124 write-mailbox
  else 0.6 122 write-mailbox 1.55 123 write-mailbox 1.55 124 write-mailbox then
'''
for axis,mb in [('X',120),('Y',121)]:
    script+=f'{mb} read-mailbox 122 read-mailbox * INDEXOF_{axis}_POS {actor("FollowShot")} write-actor-mailbox\n'
    script+=f'{mb} read-mailbox 3 * INDEXOF_{axis}_POS {actor("LookAt")} write-actor-mailbox\n'
script+=f'123 read-mailbox INDEXOF_Z_POS {actor("FollowShot")} write-actor-mailbox\n124 read-mailbox INDEXOF_Z_POS {actor("LookAt")} write-actor-mailbox\n{actor("FollowShot")} INDEXOF_CAMSHOT write-mailbox ;\n'
script+=': fy-visual\n 101 read-mailbox 0 = 250 write-mailbox\n 103 read-mailbox 0 = 251 write-mailbox\n'
for i in range(4):
    script+=f'106 read-mailbox 0 = {230+i} write-mailbox\n106 read-mailbox 0 <> 107 read-mailbox 1 = & {234+i} write-mailbox\n'
script+='107 read-mailbox -1 <> 238 write-mailbox\n107 read-mailbox -1 = 239 write-mailbox\n'
for obj in [goddess,starlet,first]+cloth:
    script+=f'108 read-mailbox 0 = if 110 read-mailbox 0.25 * fy-sin 0.004 * 1 + else 1 then INDEXOF_Z_SCALE {actor(obj.name)} write-actor-mailbox\n'
for panel,c in zip(panels,content['cards']):
    idx=actor(panel.name)
    script+=f'140 read-mailbox {c["id"]} = {260+c["id"]} write-mailbox\n'
    for axis,mb in [('X',120),('Y',121)]:
        script+=f'INDEXOF_{axis}_POS {actor("Camera")} read-actor-mailbox {mb} read-mailbox 3 * + INDEXOF_{axis}_POS {idx} write-actor-mailbox\n'
    script+=f'INDEXOF_Z_POS {actor("Camera")} read-actor-mailbox 101 read-mailbox 0 = if 0.7 - then INDEXOF_Z_POS {idx} write-actor-mailbox\n'
    script+=f'114 read-mailbox 0.25 - INDEXOF_ROTATION_C {idx} write-actor-mailbox\n'
script+=';\nfy-init fy-input fy-camera fy-visual\n'
player['wf_Script']=script;player['wf_ScriptLanguage']='Forth'
(OUT/'chapter.fth').write_text(script)
(OUT/'actors.json').write_text(json.dumps({'ids':ids,'mailboxes':{'cameraMode':101,'realm':102,'firstLoveComplete':103,'starletComplete':104,'paperComplete':105,'loveCompleted':106,'loveChoice':107,'reducedMotion':108,'focus':130,'dialogueCard':140}},indent=2))
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'parmenides_slice.blend'))
bpy.ops.wf.export_level(filepath=str(OUT/'parmenides_slice.lev'))
print('PARMENIDES: exported',len(actors),'actors; direct WF pipeline; no engine edits')
