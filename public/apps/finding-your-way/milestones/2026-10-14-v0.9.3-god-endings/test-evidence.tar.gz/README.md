# God and endings art set — native review

This is the third set in the [full-level art plan](../../../plans/2026-10-14-full-level-art.md). It starts from the published v0.9.2 Reason/Truth build. The cumulative `chapter-art` stage now covers God, Being, Both, NotBeing and surgery without changing the native engine or story routes. The first matched Cast1 performance profile of the complete upgraded chapter follows publication.

## Control and fixture correction

The previous `god-shrine` world fixture placed the player at Y=43, past the summit and outside the useful scene view. A debug realm write alone also left the God room unloaded in the nine-room layout. The fixture now enters through the Temple's God portal, places the player at Y=29 for the summit, and adds a separate Y=2 ascent view. These positions change only the desktop visual review fixture.

| Control view | Capture |
| --- | --- |
| v0.9.2 ascent, camera 0 | [PNG](god-ascent-v092-view-0.png) |
| v0.9.2 ascent, camera 1 | [PNG](god-ascent-v092-view-1.png) |
| v0.9.2 summit, camera 1 | [PNG](god-shrine-v092-view-1.png) |

The ascent control has the older flat gray path and a black background behind sparse trees. The camera 0 summit view clips below the slope at this pose, so the summit review uses camera 1 before and after.

| Current work in progress | Capture |
| --- | --- |
| God ascent, camera 1 | [PNG](god-ascent-wip-view-1.png) |
| God summit, camera 1 | [PNG](god-shrine-wip-view-1.png) |

The God backdrop, forest floor and painted stone ascent render in the actual native scene. The first export placed visual actors just above the God room's bbox and the compiler warned they would not render; the corrected export has no room-assignment warning. The ascent path needed its existing slope mesh painted as well as its separate walkable surface. An early camera 0 still was a cleared framebuffer; the capture fixture now rejects a black frame and retries. The partial export's [1,499 checks](god-wip-asset-audit.json) are retained as development history.

## Reviewed source and composition

`art_god_style.py` paints the daylight forest and stone ascent, with visual-only greenery outside the walkable route. `art_ending_style.py` adds a warm sky and pale colonnade in Being, a paired light/dark stone passage in Both, restrained suspended fragments in NotBeing, and a tiled operating room ceiling with wall and monitor detail in surgery. Painted floor and ceiling surfaces use deterministic original images. The existing God slope, landings, ending supports, surgeons, portals, cameras, encounter actors and collision remain authoritative.

The reviewed standalone level SHA-256 is `1334288f83070fe9827ba05cc29e5eb09c11158f461cfae19e43ebcb640053da`. Captures are from the actual native renderer at 1280 × 720, not Blender previews or frame-rate measurements.

| View | Third person | First person |
| --- | --- | --- |
| God ascent | [PNG](god-ascent-view-0.png) | [PNG](god-ascent-view-1.png) |
| God summit | Camera 0 clips below the hill at this pose | [PNG](god-shrine-view-1.png) |
| Being | [PNG](10a-scene-camera0.png) | [PNG](10a-scene-camera1.png) |
| Both | [PNG](10b-scene-camera0.png) | [PNG](10b-scene-camera1.png) |
| NotBeing | [PNG](10c-scene-camera0.png) | [PNG](10c-scene-camera1.png) |
| Surgery | [PNG](101b-scene-camera0.png) | [PNG](101b-scene-camera1.png) |

The NotBeing visage is a timed visual: it appears in the captured first-person frame, while the earlier third-person frame shows the dark space and floating fragments. The patient camera remains the established upward shot in both preferences.

## Checks

- [x] [Asset audit](asset-audit.json): 2,228 exported bitmap, UV, binding and room checks passed.
- [x] [UV audit](uv-audit.json): 194 art meshes and 48 sheet-gutter checks passed.
- [x] [Winding audit](winding-audit.json): 238 meshes, no inward closed components or inconsistent edges, native triangle ordering matched.
- [x] [God route](god-story-check/results.json): 164 native checks, including input-driven ascent, checkpoint rescue, encounters, final doors and earlier-realm replay.
- [x] [Ending smoke](ending-story-check/results.json): 266 native checks across the three endings and surgery in both camera modes, including cancellation, source progression, patient framing and return.
- [x] Same-camera ending visual walkthrough reached every closing scene and surgery through its real narrative transition.
- [ ] Signed APK, browser play update, Cast1 install/launch review and public screenshot.
- [ ] Full-level Cast1 profile against the frozen v0.9 full-tour baseline, after publication.

## Work in progress

- [x] Correct God room entry and the ascent/summit visual fixtures.
- [x] Author deterministic original sky and path texture sources, and visual-only terrain beyond the route.
- [x] Export and inspect God ascent and summit in camera 1; confirm new scenery renders in the nine-room layout.
- [x] Reject cleared camera 0 captures and inspect the God ascent in both camera modes.
- [x] Extend the art through Being, Both, NotBeing and surgery; inspect their ending transitions and patient view.
- [x] Run asset, UV, winding, collision and targeted story checks.
- [ ] Commit and publish the completed set with APK, browser build and a small wrapped screenshot on the app page.
- [ ] Profile the completed chapter on Cast1 against the frozen v0.9 full-tour baseline.
