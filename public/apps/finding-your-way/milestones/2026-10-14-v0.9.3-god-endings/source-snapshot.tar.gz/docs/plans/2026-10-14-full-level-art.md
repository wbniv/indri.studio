# Continue the v0.9 art direction through the chapter

Status: active, 2026-10-14. The Temple and Goddess style proof shipped in v0.9. This plan continues that visual direction through the remaining chapter without reducing artwork to meet a frame-rate target.

## Baseline and comparison rule

The frozen v0.9 cast1 performance record is [v09-release-cast1-2026-10-14](../diagnostics/parmenides/v09-release-cast1-2026-10-14/README.md). It uses the published engine, artwork, texture slots and nine-room layout. The original 30-second-warmup profiles record mostly the last view of each three-scene fixture. A [full-tour baseline](../diagnostics/parmenides/v09-release-cast1-2026-10-14/full-tour-baseline.md) uses the same APKs with zero warmup and evaluates five-second windows wholly within each scene. Use each scene's **same fixture, camera mode, engine, profile arguments and measurement method** for before/after comparisons. The g0/g1 fixture script has changed since the older October 9 receipts, so those older measurements are context only.

The existing visual references are the [art bible](../art-bible/references.html) and the accepted Temple/Goddess art in `art_style_proof.py`. The art bible gives scene targets, not assets to project onto geometry. Keep new art original and reproducible from source.

## Passes

1. **Love street — completed 2026-10-14:** bring the facades, pavement, planters, balcony foliage, lamps, distant street silhouette and principal characters toward the warm, inhabited Love reference. Start with the principal street view. Preserve the walkable route, door pivots, encounter IDs and dialogue visibility. See the [Love set review](../diagnostics/parmenides/chapter-art-love-2026-10-14/README.md).
2. **Reason and Truth — completed 2026-10-14:** give ordered Reason its pale tiled expanse and distant horizon; make the grove variant read as a distinct transformed state. Develop Truth's wood courtroom, witness focus and case exhibit under its own warm lighting. Keep their story gates and camera framing intact. See the [Reason and Truth review](../diagnostics/parmenides/chapter-art-reason-truth-2026-10-14/README.md).
3. **God and endings:** build the ascent's terrain, greenery and icon setting, then bring Being, Both, Notbeing and the surgery view toward their reference compositions. Include the transformed and return views in the same-camera review.

For each of the three sets above, capture the changed scene from the established camera, inspect phone-width crops and interaction views, and run the asset/UV/winding/collision and story checks relevant to the area. **Commit and publish each completed set separately after those checks.** Each publication includes an Android APK, the updated browser play page, and a small screenshot beside its release text on the Finding Your Way app page. The Love set shipped as v0.9.1 before work on Reason and Truth continues. A set does not require a Cast1 performance comparison before publication; install and launch checks remain part of release verification. Keep the frozen v0.9 baseline and the unchanged engine as the comparison point. **Defer Cast1 profiling until the artwork is upgraded through the end of the level.** Then run all five matched tours, record per-scene presented FPS, frame pacing, geometry, draw counts and memory, and compare the finished art with v0.9. Handle any subsequent engine/GPU optimization as a separately measured change; preserve the artwork.

## Implementation boundary

Extend the `style-proof` art stage so the published v0.9 composition remains a fixed comparison point. Do not change the native engine or room-render scope as part of an art pass. Keep actor names, collision bounds, motion pivots, mailboxes, portal routes and narrative visibility stable. New decorative meshes should use explicit harmless collision bounds or existing collision, as appropriate. Reuse the established baked/prelit texture method where it improves the scene; keep readable characters under the room lights.

The next deliverable is God and the endings. Profile the complete upgraded level after that art pass is finished.
