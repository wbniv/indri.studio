"""Iteration C: original Reason/Truth art, keeping native encounter identities.

Closed solids use the proven painted atlas. Collision bounds are inherited;
new dressing is mass zero and never becomes a philosophical prerequisite.
"""
import math
from art_temple_love import replace, person
from art_models import face, hand

STAGE='reason-truth'
TREES=[(193,4),(207,4),(194,9),(206,11),(192,13),(208,13)]
SIGNS=('white_sign','wild_sign','child_sign','apparatus_sign','rbeing_sign','rnotbeing_sign','rback_sign',
       'prosecutor_sign','defence_sign','student_sign','facts_sign','interpretations_sign','judge_sign','tbeing_sign','tnotbeing_sign','tback_sign')

def transfer(scene,M,name,mesh):
    obj=replace(scene,M,name,mesh);obj['art_stage']=STAGE;return obj

def figure(M,role):
    m=M();seated=role in ('Judge','OldLady','DefenceAttorney');wild=role=='WildSelf'
    coat={'WhiteSelf':'cream','WildSelf':'green','YoungerSelf':'blue','Prosecutor':'ink',
          'DefenceAttorney':'ink','Student':'green','Judge':'ink','OldLady':'purple'}[role]
    base=.53 if seated else .85;shift=-.26 if seated else 0
    for side in (-1,1):
        m.box((.09,side*.13,.085),(.34,.18,.17),'hair')
        if seated:
            m.beam((shift,side*.13,.54),(.05,side*.13,.50),.17,'brown')
            m.loft([(.16,.03,side*.13,.08,.08),(.50,.03,side*.13,.085,.087)],'brown',8)
        else:m.loft([(.13,0,side*.12,.075,.08),(.47,0,side*.12,.085,.09),(.86,0,side*.12,.10,.11)],'skin' if role=='WhiteSelf' else 'brown',8)
    m.loft([(base,shift,0,.16,.19),(base+.22,shift,0,.14,.20),
            (base+.40,shift-.015,0,.13,.25),(base+.48,shift-.02,0,.10,.19)],coat,10)
    m.box((shift+.14,0,base+.25),(.027,.12,.34),'cream')
    for side in (-1,1):
        elbow=(shift+.07,side*.29,base+.19)
        endpoint=(shift+.21,side*.24,base+.04) if seated else (shift+.12,side*.33,base+.04)
        m.beam((shift,side*.24,base+.41),elbow,.14,coat);m.beam(elbow,endpoint,.12,coat)
        hand(m,*endpoint)
    start=len(m.verts);ps=len(m.projections);face(m,role in ('Prosecutor','OldLady'))
    for i in range(start,len(m.verts)):
        x,y,z=m.verts[i];m.verts[i]=(x+shift,y,z+base-.85)
    for i in range(ps,len(m.projections)):
        color,bounds=m.projections[i]
        if role in ('Judge','OldLady') and color=='hair':color='stone'
        m.projections[i]=(color,[(lo+d,hi+d) for (lo,hi),d in zip(bounds,(shift,0,base-.85))])
    if role in ('WhiteSelf','WildSelf'):
        m.beam((shift+.17,-.17,base+.02),(shift+.15,.17,base+.43),.05,'brown')
        m.box((shift,-.25,base+.02),(.16,.15,.24),'brown')
        m.loft([(base-.08,shift,0,.18,.22),(base+.03,shift,0,.17,.21)],coat,10)
        if wild:
            for i in range(5):
                m.blade([(-.23+i*.105,base+.10),(-.12+i*.105,base+.06),(-.18+i*.105,base-.19-(i%2)*.08)],shift+.19,.042,'green')
            m.blade([(-.14,base+.83),(.02,base+.96),(.12,base+.85),(.04,base+.72)],shift+.10,.06,'hair')
    if role in ('Prosecutor','Judge'):
        m.loft([(.13,shift,0,.22,.31),(base+.05,shift,0,.17,.23)],'ink',10)
        for side in (-1,1):m.beam((shift+.15,side*.14,base+.44),(shift+.19,side*.16,.23),.06,'gold')
    if role=='DefenceAttorney':
        for side in (-1,1):
            for dz in (-.035,.035):m.beam((shift+.155,side*.035,base+.735+dz),(shift+.155,side*.105,base+.735+dz),.018,'ink')
            for yy in (side*.035,side*.105):m.beam((shift+.155,yy,base+.70),(shift+.155,yy,base+.77),.018,'ink')
        m.beam((shift+.15,-.035,base+.735),(shift+.15,.035,base+.735),.019,'ink')
        m.blade([(-.025,base+.43),(.025,base+.43),(.035,base+.15),(0,base+.11),(-.035,base+.15)],shift+.17,.035,'blue')
    if role=='Judge':
        m.loft([(base+.58,shift+.085,0,.055,.09),(base+.67,shift+.075,0,.04,.10)],'stone',8)
    return m

def bench(M,width=4.5,chair=False):
    m=M();width=.74 if chair else width
    for x in (-width/2+.12,width/2-.12):
        for y in (-.22,.22):m.box((x,y,.24),(.12,.12,.48),'brown')
        m.beam((x,.23,.30),(x,.31,1.05),.11,'brown')
    for y in (-.22,0,.22):m.box((0,y,.53),(width,.18,.11),'brown')
    for z in (.74,.95):m.box((0,.30,z),(width,.10,.15),'brown')
    return m

def dress(M,scene,out):
    import bpy
    replaced=[];added=[]
    def put(name,m):
        if name.startswith('gallery_bench_') or name.endswith('_lectern') or name in ('facts_table','interpretations_table','hearing_bench'):
            # Baseline cube actors have centered origins. Ground-authored
            # furniture must be converted to that local frame, not moved along
            # with its actor and original collision box. Translate UV bounds
            # with the vertices so projection remains identical.
            dz=-scene.objects[name].location.z
            m.verts=[(x,y,z+dz) for x,y,z in m.verts]
            m.projections=[(color,[*bounds[:2],(bounds[2][0]+dz,bounds[2][1]+dz)]) for color,bounds in m.projections]
        obj=transfer(scene,M,name,m);replaced.append(name);return obj
    for name in ('WhiteSelf','WildSelf','YoungerSelf','Prosecutor','DefenceAttorney','Student','Judge','OldLady'):
        obj=put(name,figure(M,name));obj['art_role']='principal character'
        # Shared character artwork belongs to the existing permanent asset
        # heap; this keeps the unchanged Room0 8MiB arena within its limit.
        obj['wf_Moves Between Rooms']='True'
    # Seated advocates and gallery feet meet the floor, rather than old graybox
    # solid bench tops. Collision footprints remain the baseline boxes.
    scene.objects['OldLady'].location.z=.05
    scene.objects['Judge'].location.z=.30
    for name in ('DefenceAttorney','Judge'):
        actor=scene.objects[name];chair=bench(M,chair=True)
        if name=='Judge':chair.box((0,0,-.125),(1.15,1.05,.25),'brown')
        obj=chair.object(name+'Chair',tuple(actor.location));obj.rotation_euler.z=actor.rotation_euler.z+math.pi/2;added.append(obj.name)
    m=M();m.box((0,0,.27),(.42,.25,.50),'purple');m.box((0,-.14,.34),(.28,.025,.30),'purple')
    for x in (-.14,.14):m.beam((x,0,.51),(x,0,.69),.035,'brown')
    m.beam((-.14,0,.69),(.14,0,.69),.04,'brown');m.box((0,-.155,.46),(.09,.025,.055),'gold')
    put('purple_bag',m).location=(293,-5,.05)
    # Ordered apparatus: a visible basin, heat source, vapor chimney and cloud
    # collector; all remain within the established 1.8 x .8 collision footprint.
    m=M();m.box((0,0,.45),(1.8,.8,.9),'stone');m.box((0,0,.92),(1.9,.9,.10),'steel')
    m.cone((-.60,0,.98),.23,.16,'red',sides=10);m.cone((-.60,0,1.14),.19,.12,'blue',sides=10)
    m.cone((0,0,.98),.17,.42,'steel',.13,10);m.sphere((0,0,1.39),(.27,.22,.14),'cream',8,4)
    m.cone((.60,0,1),.24,.20,'blue',sides=10)
    for a,b in [((-.6,0,1.22),(0,0,1.48)),((0,0,1.48),(.6,0,1.31))]:m.beam(a,b,.04,'steel')
    put('weather_machine',m)
    m=M()
    for i in range(3):m.cone((-.60+i*.60,0,0),.16,.045,'gold' if i==0 else 'blue',sides=10)
    put('weather_order',m)
    for i in range(3):
        m=M();m.sphere((0,0,0),(.04,.045,.06),'blue',6,4)
        added.append(m.object('ReasonRain'+str(i),(200.60,3,1.35-i*.14),kind='platform',visibility=164).name)
    # Grove shares the old footprint. Broad root courses branch away from the
    # apparatus/encounter approaches. Canopies have useful local sway pivots.
    m=M();m.box((200,6,.012),(15,16,.025),'green')
    for x,y in TREES:
        m.loft([(0,x,y,.28,.31),(1.1,x+.08,y-.03,.24,.25),(3.25,x-.09,y,.16,.18)],'brown',8)
        for side in (-1,1):m.beam((x,y,2.1),(x+side*.8,y+.28,3.0),.14,'brown')
        canopy=M();canopy.sphere((0,0,.42),(1.5,1.25,1.0),'green',8,4)
        canopy.sphere((-.6,.1,-.05),(.9,.88,.65),'green',8,4)
        added.append(canopy.object('ReasonCanopy'+str(len(added)),(x,y,3.15),kind='platform',visibility=163).name)
    for i in range(11):
        y=2+i;x=200+2*math.sin(i*.5)
        m.beam((x,y,.06),(x+1.0*math.cos(i),y+1,.09),.16,'brown')
        if i%2==0:m.beam((x,y,.06),(x-1.0,y+.45,.07),.11,'brown')
    put('reason_grove',m)
    m=M()
    for i in range(12):
        x=200+1.2*math.sin(i*.6);y=.5+i
        m.beam((x,y,.024),(200+1.2*math.sin((i+1)*.6),y+1,.024),.10,'ink')
    added.append(m.object('ReasonCrack',visibility=163).name)
    # Full court kit: timber panels, plaster upper walls and repeated columns.
    m=M()
    for x in (287,313):
        m.box((x,5,1.1),(.55,37,2.2),'brown')
        for y in (-9,-3,3,9,15,21):
            m.box((x,y,2.8),(.75,.6,5.6),'stone')
            m.box((x,y,.15),(1,.9,.30),'stone');m.box((x,y,5.45),(1,.9,.30),'cream')
        for y in (-6,0,6,12,18):
            m.box((x,y,3.65),(.25,5.2,2.7),'plaster')
            for dy in (-2.7,2.7):m.box((x,y+dy,1.1),(.70,.08,1.8),'cream')
    m.box((300,23,1.25),(26,.55,2.5),'brown');put('court_structure',m)
    for x in (292,308):
        for y in (-5,-2):put(f'gallery_bench_{x}_{y}',bench(M))
    for i,(x,y) in enumerate(((291,-2),(309,-2),(308,-5))):
        obj=person(M,'CourtGallery'+str(i),(x,y,.05),i,seated=True,principal=False);obj.rotation_euler.z=math.pi/2
        obj['wf_Moves Between Rooms']='True'
        obj['art_role']='background gallery';added.append(obj.name)
    for name in ('prosecutor_lectern','defenceattorney_lectern'):
        m=M();m.box((0,0,.10),(1,.65,.20),'brown');m.box((0,.03,.51),(.62,.36,.8),'brown');m.box((0,0,1.09),(1.05,.7,.13),'brown')
        m.box((0,-.19,.56),(.43,.035,.55),'cream');put(name,m)
    for name in ('facts_table','interpretations_table'):
        m=M()
        for x in (-.57,.57):
            for y in (-.47,.47):m.box((x,y,.36),(.12,.12,.72),'brown')
        m.box((0,0,.78),(1.4,1.2,.12),'brown');put(name,m)
    for name,color in (('facts_document','blue'),('interpretations_document','gold')):
        m=M();m.box((0,0,0),(.95,.65,.04),'paper')
        for x in (-.43,.43):m.box((x,0,.024),(.035,.58,.009),color)
        put(name,m)
    for name,color in (('facts_lines','blue'),('interpretations_lines','gold')):
        m=M()
        for i in range(5):m.box((0,-.23+i*.11,0),(.65-(i%2)*.09,.027,.014),color)
        put(name,m)
    # Evidence stays the existing source-derived accounts; no unreported sweet
    # contents or guilt prop is inserted. Presentation duplicates their two
    # readable document silhouettes at the hearing bench, not new testimony.
    m=M();m.box((0,0,.10),(4.5,1.2,.2),'brown');m.box((0,.15,.65),(4.25,.65,1.1),'brown');m.box((0,0,1.29),(4.7,1.3,.13),'brown')
    for x in (-1.5,0,1.5):m.box((x,-.19,.66),(1.25,.05,.8),'cream')
    put('hearing_bench',m)
    m=M();m.cone((0,0,0),.07,.5,'brown',sides=8)
    m.box((0,0,.45),(.18,.37,.19),'brown');m.cone((0,0,.15),.075,.04,'gold',sides=8)
    gavel=put('gavel',m);gavel.rotation_euler.y=math.pi/2;gavel['art_pivot']='gavel grip'
    m=M()
    for x,color in ((-.65,'blue'),(.65,'gold')):
        m.box((x,0,0),(.86,.56,.024),'paper')
        for j in range(4):m.box((x,-.18+j*.11,.018),(.63,.025,.008),color)
    put('presented_exhibits',m)
    for name in SIGNS:
        obj=scene.objects[name];obj.location.x+=1.85;obj.location.z=1.5 if name=='child_sign' else 1.65;obj.scale=(.7,.7,.7)
    for obj in scene.objects:
        if obj.name in added:obj['art_stage']=STAGE
    return dict(stage=STAGE,replaced=replaced,added=added,
        reused=['Player','Goddess','Temple and Love iteration-B kit','all source dialogue meshes','all narrative actor names and original collision bounds','unchanged 8MiB Room0 / 16MiB permanent heap limits'],
        pending=['Native/device rendering and phone cost','God/final hub iteration D','Endings/surgery iteration E','Max feedback after all iterations'],
        originality='Original procedural Blender closed solids; shared original painted diffuse; no borrowed likeness or unreported evidence',
        collision='All existing replacement collision boxes retained; new canopy, rain, chairs and gallery dressing mass zero')

MOTION=[dict(name='Reason root/grove arrival',actors=['reason_grove','ReasonCanopy*'],trigger='White-Clad Self completion; no modal sheet',loop=False,
             timingSeconds=2.4,representation='level rigid Z-scale from grounded contact; decorative progress cannot choose or gate a route',reduced='immediate full grove',measuredCost='phone pending'),
        dict(name='Reason cloud and rain',actors=['ReasonRain0','ReasonRain1','ReasonRain2'],trigger='apparatus operated; no modal sheet',loop=True,
             timingHz=.35,amplitudeMeters=.28,representation='three staggered rigid drops',reduced='stable illustrative drops',measuredCost='phone pending'),
        dict(name='Reason canopy settling',actors=['ReasonCanopy*'],trigger='revealed grove; normal motion; no modal sheet',loop=True,
             timingHz=.07,amplitudeTurns=.002,representation='local-pivot rigid yaw, staggered phases',reduced='still canopy',measuredCost='phone pending'),
        dict(name='Court evidence/gavel response',actors=['gavel','presented_exhibits'],trigger='both exhibits presented',loop=False,
             timingSeconds=.8,representation='bounded meaningful grip rotation, returns to rest; exhibits use existing presentation visibility',reduced='stable resting gavel and complete documents',measuredCost='phone pending')]

def emit_motion(emit,actor,ids):
    # 486/487 are cosmetic progress only; never change encounter/choice flags.
    for flag,progress,duration in ((150,486,2.4),(175,487,.8)):
        emit(f'{flag} read-mailbox 0 = if 0 {progress} write-mailbox else 108 read-mailbox 0 <> if 1 {progress} write-mailbox else '
             f'140 read-mailbox 0 = if {progress} read-mailbox 115 read-mailbox {duration} / + 1 min {progress} write-mailbox then then then\n')
    idx=actor('reason_grove');emit(f'486 read-mailbox .03 max INDEXOF_Z_SCALE {idx} write-actor-mailbox\n')
    for i,name in enumerate(n for n in ids if n.startswith('ReasonCanopy')):
        idx=actor(name)
        emit(f'0 INDEXOF_ROTATION_A {idx} write-actor-mailbox 0 INDEXOF_ROTATION_B {idx} write-actor-mailbox '
             f'108 read-mailbox 0 = 140 read-mailbox 0 = & if 110 read-mailbox .07 * {i*.13} + fy-sin .002 * else 0 then INDEXOF_ROTATION_C {idx} write-actor-mailbox\n')
        emit(f'{3.15} 486 read-mailbox .03 max * INDEXOF_Z_POS {idx} write-actor-mailbox '
             f'486 read-mailbox .03 max INDEXOF_Z_SCALE {idx} write-actor-mailbox\n')
    for i in range(3):
        idx=actor('ReasonRain'+str(i))
        emit(f'108 read-mailbox 0 = 140 read-mailbox 0 = & if 110 read-mailbox .35 * {i/3} + fy-wrap .28 * 1.37 swap - else {1.30-i*.08} then INDEXOF_Z_POS {idx} write-actor-mailbox\n')
    idx=actor('gavel')
    emit(f'0 INDEXOF_ROTATION_A {idx} write-actor-mailbox '
         f'.25 487 read-mailbox .5 < 487 read-mailbox 0 > & if .035 - then INDEXOF_ROTATION_B {idx} write-actor-mailbox '
         f'0 INDEXOF_ROTATION_C {idx} write-actor-mailbox\n')
    for name in SIGNS:
        idx=actor(name);emit(f'0 INDEXOF_ROTATION_A {idx} write-actor-mailbox 0 INDEXOF_ROTATION_B {idx} write-actor-mailbox '
                           f'114 read-mailbox .25 - INDEXOF_ROTATION_C {idx} write-actor-mailbox\n')
