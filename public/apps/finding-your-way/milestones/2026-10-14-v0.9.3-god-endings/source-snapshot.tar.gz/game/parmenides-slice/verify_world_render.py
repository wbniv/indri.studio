"""Offscreen captures for manual review of diagnosed winding and depth faults.

These fixtures inspect actual native rendering, not route correctness. A
capture manifest alone is not a visual acceptance result.
"""
import hashlib
import json
import re
import shutil
import subprocess
import sys
import time


def run(b,player,value,check,tap,position,out,evidence):
    rows=[]
    stills='--world-stills' in sys.argv
    ids=json.loads((out/'actors.json').read_text())['ids']
    for actor in (player,ids['Camera'],ids['FollowShot'],ids['CamTarget']):
        for mailbox in (3009,3010,3011):b.watch(actor,mailbox)
    fixtures=[
        ('temple-goddess',0,3,0,.25),
        ('temple-arches',0,0,3,.25),
        ('love-first-love',1,96,-1,.25),
        ('love-starlet',1,104,0,.25),
        ('reason-white-self',2,196,-2,.25),
        ('truth-court',3,300,1,.25),
        ('god-ascent',4,400,2,.25),
        ('god-shrine',4,400,29,.25),
        ('being-floor',5,500,0,.25),
        ('both-arch',6,600,0,.25),
        ('void-visage',7,700,1,.25),
        ('surgery-heads',8,800,0,.25),
    ]
    if '--world-only' in sys.argv:
        selected=sys.argv[sys.argv.index('--world-only')+1]
        fixtures=[row for row in fixtures if row[0]==selected]
        if not fixtures:raise ValueError('Unknown world fixture: '+selected)
    try:
        for mode in (0,1):
            if value(101)!=mode:tap(2)
            for name,realm,x,y,heading in fixtures:
                if '--world-only' in sys.argv and realm in (2, 3, 4) and value(102)!=realm:
                    # With scene9, these room assets are loaded by the Temple
                    # portal transition. A debug realm write alone leaves the
                    # Player in the Temple room and gives an invalid capture.
                    if realm==2:
                        for mailbox,answer in ((106,1),(107,1)):
                            b.set_mailbox(mailbox,answer,idx=player)
                        position(7,8)
                    elif realm==3:
                        for mailbox,answer in ((106,1),(107,1),(154,1),(155,1),(156,1)):
                            b.set_mailbox(mailbox,answer,idx=player)
                        position(-7,8)
                    else:
                        for mailbox in (106,154,176,107,155,177,156,178,195):
                            b.set_mailbox(mailbox,1,idx=player)
                        position(0,-8)
                    tap()
                    check('world fixture entered its scene room '+name,value(102)==realm)
                b.set_mailbox(140,0,idx=player)
                b.set_mailbox(102,realm,idx=player)
                b.set_mailbox(114,heading,idx=player)
                position(x,y)
                before=value(110) or 0
                deadline=time.monotonic()+25
                settled=False
                while time.monotonic()<deadline:
                    actual=[b.mailbox_values.get((ids['Camera'],m)) for m in (3009,3010,3011)]
                    shot=[b.mailbox_values.get((ids['FollowShot'],m)) for m in (3009,3010,3011)]
                    origin=[b.mailbox_values.get((ids['CamTarget'],m)) for m in (3009,3010,3011)]
                    actor=[value(m) for m in (3009,3010,3011)]
                    if all(v is not None for v in actual+shot+origin+actor):
                        expected=[s-o+p for s,o,p in zip(shot,origin,actor)]
                        if (value(110) or 0)>before+.5 and max(abs(a-e) for a,e in zip(actual,expected))<.04:
                            settled=True
                            break
                    time.sleep(.05)
                check('world camera reaches its requested pose '+name,settled)
                # The first presented frame after a realm switch can still
                # be the cleared buffer on a busy desktop GPU.
                time.sleep(3.0 if stills else .25)
                check('world fixture '+name+' mode '+str(mode)+' settled',
                      value(140)==0 and value(102)==realm and value(101)==mode)
                row=dict(file=name+'-view-'+str(mode)+'.png',realm=realm,camera=mode,wall_time=time.time(),
                         player_position=[value(m) for m in (3009,3010,3011)],
                         camera_position=[b.mailbox_values.get((ids['Camera'],m)) for m in (3009,3010,3011)])
                if stills:
                    from PIL import Image
                    from verify_panel_render import capture_presented
                    target=evidence/row['file']
                    # The bridge can acknowledge a cleared default framebuffer
                    # immediately after a room/camera transition. A uniform
                    # black still is not a valid visual acceptance capture.
                    for attempt in range(4):
                        capture_presented(target,b)
                        with Image.open(target) as frame:
                            has_pixels=frame.convert('RGB').getbbox() is not None
                        if has_pixels:
                            break
                        time.sleep(1.0)
                    check('world capture contains rendered pixels '+name+' mode '+str(mode),has_pixels)
                    row['sha256']=hashlib.sha256(target.read_bytes()).hexdigest()
                rows.append(row)
                time.sleep(.4)
    finally:
        receipt=out/('build-receipt.json' if (out/'build-receipt.json').exists() else 'level-receipt.json')
        (evidence/'requests.json').write_text(json.dumps({'build':json.loads(receipt.read_text()),'results':rows},indent=2)+'\n')


def finalize(out,evidence):
    requests=json.loads((evidence/'requests.json').read_text())
    if '--world-stills' in sys.argv:
        requests['visual_acceptance']='Pending manual review'
        (evidence/'capture-manifest.json').write_text(json.dumps(requests,indent=2)+'\n')
        return
    match=re.search(r'Duration: N/A, start:\s*([0-9.]+)',(evidence/'engine.log').read_text())
    if not match:raise RuntimeError('World recording start timestamp missing')
    epoch=float(match.group(1))
    movie=evidence/'world-render.mp4'
    shutil.copy2(out/'output.mp4',movie)
    for row in requests['results']:
        target=evidence/row['file']
        row['video_time']=row['wall_time']-epoch
        subprocess.run(['ffmpeg','-v','error','-y','-ss',str(row['video_time']),'-i',str(movie),'-frames:v','1',str(target)],check=True,timeout=15)
        row['sha256']=hashlib.sha256(target.read_bytes()).hexdigest()
    requests.update(video_sha256=hashlib.sha256(movie.read_bytes()).hexdigest(),visual_acceptance='Pending manual review')
    (evidence/'capture-manifest.json').write_text(json.dumps(requests,indent=2)+'\n')
