| Date | Change |
|------|--------|
| [2026-10-07](https://github.com/wbniv/finding-your-way/commit/37d77d5) | Shrink and lower the phone joystick |

<!--history-meta v1
37d77d5	author	Will Norris
37d77d5	added	24
37d77d5	deleted	0
37d77d5	files	1
-->
