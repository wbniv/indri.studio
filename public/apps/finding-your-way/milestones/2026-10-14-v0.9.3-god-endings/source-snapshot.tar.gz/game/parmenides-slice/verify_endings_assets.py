"""Audit E preparation geometry and preservation against frozen D Blender data."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import bpy

p=argparse.ArgumentParser();p.add_argument('--build-dir',type=Path,required=True)
p.add_argument('--baseline-build',type=Path,required=True);p.add_argument('--report',type=Path,required=True)
a=p.parse_args(sys.argv[sys.argv.index('--')+1:]);rows=[]
def check(label,condition):
    rows.append(dict(check=label,passed=bool(condition)))
    if not condition:raise AssertionError(label)
def snapshot(obj):
    return dict(vertices=[list(v.co) for v in obj.data.vertices] if obj.type=='MESH' else [],
        faces=[list(p.vertices) for p in obj.data.polygons] if obj.type=='MESH' else [],
        location=list(obj.location),rotation=list(obj.rotation_euler),scale=list(obj.scale),
        physical={k:(list(obj[k]) if hasattr(obj[k],'to_list') else obj[k]) for k in obj.keys() if k.startswith('wf_') and k not in ('wf_Moves Between Rooms',)})
bpy.ops.wm.open_mainfile(filepath=str(a.baseline_build.resolve()/'parmenides_slice.blend'))
baseline={o.name:snapshot(o) for o in bpy.context.scene.objects}
bpy.ops.wm.open_mainfile(filepath=str(a.build_dir.resolve()/'parmenides_slice.blend'))
objects=bpy.context.scene.objects;manifest_path=a.build_dir/'endings-preparation-manifest.json'
production=not manifest_path.exists()
manifest=json.loads((a.build_dir/('art-manifest.json' if production else 'endings-preparation-manifest.json')).read_text())
replaced=set(manifest['disposition']['replaced']);success=False;components=[]
try:
    check('actor roster unchanged',set(objects.keys())==set(baseline))
    for name,obj in objects.items():
        current=snapshot(obj)
        if name not in replaced:
            expected=baseline[name]
            if production and name=='Player':
                current['physical']=dict(current['physical']);expected=dict(expected);expected['physical']=dict(expected['physical'])
                current['physical'].pop('wf_Script',None);expected['physical'].pop('wf_Script',None)
            check(name+' existing geometry, frame and physical properties unchanged'+(' except E level Forth' if production and name=='Player' else ''),current==expected)
        else:
            for key in ('location','rotation','scale'):check(name+' actor '+key+' unchanged',current[key]==baseline[name][key])
            # Collision bounding boxes are inherited by replacement authoring;
            # this does not claim new statplat render triangles are identical.
            for key,value in baseline[name]['physical'].items():
                check(name+' preserves '+key,current['physical'].get(key)==value)
            check(name+' uses existing permanent residency',obj['wf_Moves Between Rooms']=='True')
            mesh=obj.data;uv=mesh.uv_layers.active
            check(name+' original image material and painted UVs present',bool(uv) and all(m.name.startswith('art_surfaces') for m in mesh.materials))
            check(name+' UVs remain inside ordinary texture coordinates',all(-.00001<=c<=1.00001 for loop in uv.data for c in loop.uv))
            # Weld coincident pole positions, then find independent closed
            # construction pieces. Signed volume detects inverted primitives.
            positions={};point=[]
            for v in mesh.vertices:
                coord=tuple(round(c,6) for c in v.co)
                point.append(positions.setdefault(coord,len(positions)))
            parent=list(range(len(positions)))
            def root(i):
                while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
                return i
            for face in mesh.polygons:
                verts=[point[i] for i in face.vertices]
                for j in verts[1:]:parent[root(j)]=root(verts[0])
            volumes={}
            for face in mesh.polygons:
                verts=[mesh.vertices[i].co for i in face.vertices]
                volume=sum(verts[0].dot(verts[j].cross(verts[j+1]))/6 for j in range(1,len(verts)-1))
                idx=root(point[face.vertices[0]]);volumes[idx]=volumes.get(idx,0)+volume
            for i,volume in enumerate(volumes.values()):check(name+' primitive '+str(i)+' outward signed volume',volume>1e-8)
            components.append(dict(actor=name,vertices=len(mesh.vertices),triangles=len(mesh.polygons),pieces=len(volumes)))
    for name in ('being_support','void_support'):
        check(name+' deliberate invisible physical support unchanged',snapshot(objects[name])==baseline[name] and objects[name]['wf_Model Type']=='None')
    check('voice-only Old Woman stays invisible',not any('oldwoman' in n.lower().replace('_','') for n in objects.keys()))
    motif=objects['both_triangles'];check('filled downward motif has approach-facing front',sum(p.normal.y<-.99 and min(motif.data.vertices[i].co.z for i in p.vertices)>-.03 for p in motif.data.polygons)>=1)
    for i in range(1,4):
        obj=objects['surgeon_'+str(i)]
        check(obj.name+' downward eye/mask faces remain above patient camera',min(v.co.z for v in obj.data.vertices)>2.5)
    for filename in ('content.json','art-textures.json'):
        check(filename+' byte-identical to D',hashlib.sha256((a.build_dir/filename).read_bytes()).digest()==hashlib.sha256((a.baseline_build/filename).read_bytes()).digest())
    success=True
finally:
    a.report.parent.mkdir(parents=True,exist_ok=True)
    a.report.write_text(json.dumps(dict(build=json.loads((a.build_dir/'build-receipt.json').read_text()) if production else None,stage='endings-surgery' if production else 'endings-surgery-preparation',passed=success,
        scope='Static asset preservation and outward-piece audits; native rendering/collision, motion, source-route and device acceptance remain pending.',
        results=rows,assets=components),indent=2)+'\n')
print('E asset checks',len(rows))
