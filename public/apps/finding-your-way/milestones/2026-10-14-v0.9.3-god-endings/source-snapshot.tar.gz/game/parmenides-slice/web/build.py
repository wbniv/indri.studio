#!/usr/bin/env python3
"""Build/freeze/stage a verified browser chapter without editing shared engine source."""
from pathlib import Path
import argparse, hashlib, json, os, shutil, subprocess, sys, zipfile, struct, tarfile
import web_deps
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
RELEASES = {
    '0.8': dict(engine='c3e0a5b3b428a40e89ccd122d71a439394abbb67',
                apk='1ee7d292dfb793b05087bd89485a8c7b730b5fe0c9cec213ebe20eeb0078dfe5',
                directory='2026-10-09-v0.8-optimization-compressed',
                snapshot_level='verified-export/parmenides_slice-standalone.iff'),
    '0.9': dict(engine='ba25f99bea241403c2865622c675711c7aaf0176',
                apk='3ef29dc87d55934a98d844e489f701c4d0c0893537ba6a5bd567ea609ddfb25b',
                directory='2026-10-14-v0.9-temple-goddess',
                snapshot_level=None),
    '0.9.1': dict(engine='ba25f99bea241403c2865622c675711c7aaf0176',
                  apk='c3ad1ffac1cc5ffe0f52873549aaa35d00ef4d4400518abdfccf098069baec54',
                  directory='2026-10-14-v0.9.1-love-street',
                  snapshot_level=None),
    '0.9.2': dict(engine='ba25f99bea241403c2865622c675711c7aaf0176',
                  apk='f704f5a2648cbb8e8c8f604b0d7ce9292e2b0dfb28e8066d7a2a9668f4b6bde0',
                  directory='2026-10-14-v0.9.2-reason-truth',
                  snapshot_level=None),
}
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def run(*args, **kwargs): subprocess.run([str(a) for a in args], check=True, **kwargs)
def validate(bundle):
    receipt=json.loads((bundle/'receipt.json').read_text())
    version=receipt.get('version')
    release=RELEASES.get(version)
    if not release or receipt['engineCommit'] != release['engine'] or receipt['apkSha256'] != release['apk']:
        raise ValueError('Unexpected release provenance')
    identity=hashlib.sha256(json.dumps(receipt['files'],sort_keys=True).encode()).hexdigest()[:16]
    if receipt['bundleId'] != 'v'+version+'-'+identity:
        raise ValueError('Bundle ID does not match content hashes')
    required={'wf_game.js','wf_game.wasm','wf_game.data','frame.html','player.js','player.css','config.json','title-preview.jpg'}
    if set(receipt['files']) != required:
        raise ValueError('Incomplete chapter player bundle')
    if set(p.name for p in bundle.iterdir()) != set(receipt['files'])|{'receipt.json'}:
        raise ValueError('Unexpected/missing bundle files')
    for name, info in receipt['files'].items():
        p=bundle/name
        if p.name != name or sha(p) != info['sha256'] or p.stat().st_size != info['bytes']:
            raise ValueError('Bundle mismatch: '+name)
    return receipt

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('command', choices=['build','stage','verify'])
    p.add_argument('--engine',type=Path,default=Path('/home/will/WorldFoundry-wbniv'))
    p.add_argument('--release',choices=RELEASES,default='0.8')
    p.add_argument('--sdk',type=Path,help='Pinned Emscripten SDK (default: discovered by web_deps.py; linked worktrees reuse the main checkout\'s)')
    p.add_argument('--out',type=Path)
    p.add_argument('--bundle',type=Path)
    p.add_argument('--site',type=Path)
    p.add_argument('--asan',action='store_true',help='Diagnostic build; cannot be staged')
    p.add_argument('--checks',action='store_true',help='Enable runtime and stack-overflow diagnostics')
    p.add_argument('--stack-size',type=int,default=65536,help='WASM stack bytes (default 64 KiB; original limit)')
    p.add_argument('--jobs',type=int,default=2)
    a=p.parse_args();a.out=(a.out or HERE.parent/'build'/('web-v'+a.release)).resolve()
    if a.command!='build':
        if not a.bundle: p.error('--bundle is required')
        bundle=a.bundle.resolve();receipt=validate(bundle)
        if a.command=='stage':
            if not a.site: p.error('--site is required')
            if receipt.get('addressSanitizer') or receipt.get('stackBytes') != 65536 or receipt.get('stackOverflowCheck') != 2: raise ValueError('Stage only non-ASAN bundles at the original checked 64 KiB stack limit')
            dest=a.site/'public/apps/finding-your-way/play/bundles'/receipt['bundleId']
            if dest.exists(): validate(dest)
            else: shutil.copytree(bundle,dest)
            validate(dest)
            (a.site/'public/apps/finding-your-way/play/manifest.json').write_text(json.dumps({'bundleId':receipt['bundleId']},indent=2)+'\n')
            print(dest)
        else: print('Verified',receipt['bundleId'])
        return
    engine=a.engine.resolve()
    release=RELEASES[a.release]
    release_dir=ROOT/'game/milestones'/release['directory']
    try: sdk=web_deps.locate(a.sdk,engine)
    except web_deps.LocateError as e: sys.exit(e.report(web_deps.load_manifest()))
    print('Emscripten SDK:',sdk)
    commit=subprocess.check_output(['git','-C',str(engine),'rev-parse','HEAD'],text=True).strip()
    if commit!=release['engine']: raise ValueError('Use the pinned engine commit '+release['engine'])
    if subprocess.check_output(['git','-C',str(engine),'status','--porcelain','--untracked-files=no'],text=True).strip():
        raise ValueError('Engine tracked source must be clean')
    apk=next(release_dir.glob('*.apk'))
    if sha(apk)!=release['apk']: raise ValueError('Frozen release APK hash differs')
    a.out.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(apk) as z: (a.out/'cd.iff').write_bytes(z.read('assets/cd.iff'))
    # The browser scheduler currently supports the standalone -L path, not the
    # packed-CD meta-script loop. Extract the identical L4 chunk from that CD.
    cd=(a.out/'cd.iff').read_bytes()
    if cd[:4]!=b'GAME' or cd[8:12]!=b'TOC\0': raise ValueError('Unexpected packed CD')
    toc_size=struct.unpack_from('<I',cd,12)[0]
    entries=[struct.unpack_from('<4sII',cd,16+i) for i in range(0,toc_size,12)]
    if len(entries)!=2 or not entries[1][0].startswith(b'L'): raise ValueError('Expected one full chapter')
    _,offset,size=entries[1]
    level=cd[offset:offset+size]
    if len(level)!=size or struct.unpack_from('<I',level,4)[0]+8!=size: raise ValueError('Level chunk size differs')
    with tarfile.open(release_dir/'source-snapshot.tar.gz') as archive:
        if release['snapshot_level']:
            frozen=archive.extractfile(release['snapshot_level']).read()
            if frozen!=level: raise ValueError('CD level differs from frozen standalone export')
        else:
            frozen_cd=archive.extractfile('build/cd.iff').read()
            if frozen_cd!=cd: raise ValueError('CD differs from frozen source snapshot')
    (a.out/'parmenides_slice-standalone.iff').write_bytes(level)
    source_receipt=json.loads((release_dir/'build-receipt.json').read_text())
    if sha(a.out/'cd.iff')!=source_receipt['levelSha256']: raise ValueError('Chapter payload differs')
    sdk_config=sdk/'.emscripten'
    if not sdk_config.exists(): run(sdk/'emsdk','activate','6.0.0')
    env=dict(os.environ,EM_CONFIG=str(sdk_config),EM_CACHE=str(a.out/'emscripten-cache'))
    env['PATH']=str(sdk/'upstream/emscripten')+os.pathsep+env['PATH']
    emcmake=sdk/'upstream/emscripten/emcmake'
    run(emcmake,'cmake','-S',engine,'-B',a.out/'cmake','-DCMAKE_BUILD_TYPE=Release',
        '-DCMAKE_PROJECT_INCLUDE='+str(HERE/'chapter.cmake'),'-DFYW_WEB_CD='+str(a.out/'parmenides_slice-standalone.iff'),
        '-DFYW_WEB_SHELL='+str(HERE/'link-shell.html'),'-DBUILD_TESTING=OFF','-DFYW_WEB_ASAN='+('ON' if a.asan else 'OFF'),'-DFYW_WEB_CHECKS='+('ON' if a.checks else 'OFF'),'-DFYW_WEB_STACK_SIZE='+str(a.stack_size),env=env)
    run('cmake','--build',a.out/'cmake','--target','wf_game','-j',a.jobs,env=env)
    temp=a.out/'bundle-staging';temp.mkdir(exist_ok=True)
    for name in ['wf_game.js','wf_game.wasm','wf_game.data']: shutil.copy2(a.out/'cmake'/name,temp/name)
    for name in ['frame.html','player.js','player.css']: shutil.copy2(HERE/name,temp/name)
    preview=HERE/('title-preview-v0.9.jpg' if a.release in ('0.9','0.9.1','0.9.2') else 'title-preview.jpg')
    shutil.copy2(preview,temp/'title-preview.jpg')
    (temp/'config.json').write_text(json.dumps({'version':a.release,'arguments':source_receipt['runtimeArguments']+['-L/parmenides_slice-standalone.iff']},indent=2)+'\n')
    files={f.name:{'bytes':f.stat().st_size,'sha256':sha(f)} for f in sorted(temp.iterdir()) if f.name!='receipt.json'}
    identity=hashlib.sha256(json.dumps(files,sort_keys=True).encode()).hexdigest()[:16]
    receipt={'addressSanitizer':a.asan,'runtimeChecks':a.checks,'stackBytes':a.stack_size,'stackOverflowCheck':2,'bundleId':'v'+a.release+'-'+identity,'version':a.release,'engineCommit':commit,'apkSha256':release['apk'],
      'levelSha256':source_receipt['levelSha256'],'standaloneSha256':sha(a.out/'parmenides_slice-standalone.iff'),'toolchain':subprocess.check_output([str(sdk/'upstream/emscripten/emcc'),'--version'],env=env,text=True).splitlines()[0],
      'runtimeArguments':source_receipt['runtimeArguments']+['-L/parmenides_slice-standalone.iff'],'files':files,'totalBytes':sum(f['bytes'] for f in files.values()),
      'buildConfiguration':'Release, single-threaded WebGL2; chapter-owned CMake preload/shell overrides; pinned approved text-storage remediation'}
    (temp/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    dest=a.out/'bundles'/receipt['bundleId']
    if dest.exists(): validate(dest);shutil.rmtree(temp)
    else: dest.parent.mkdir(exist_ok=True);temp.rename(dest)
    validate(dest);print('Frozen bundle:',dest)
if __name__=='__main__':main()
