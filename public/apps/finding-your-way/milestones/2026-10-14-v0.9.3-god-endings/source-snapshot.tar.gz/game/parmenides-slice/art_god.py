"""Iteration D: original God ascent and final Temple artwork.

The existing rising path and safe landings are painted in place, not reshaped.
Forest/shrine/canopies remain nonphysical dressing outside that corridor.
"""
import math
from art_temple_love import replace
from art_models import face, hand
from god_scene import height

STAGE='god-final'
TREES=[(400+side*(7+(i%3)*1.8),-4+i*3.3) for side in (-1,1) for i in range(12)]
SIGNS=('young_sign','holy_sign','god_poster_sign','god_icon_sign','question_sign','gbeing_sign','gnotbeing_sign','gback_sign','final_being_sign','final_both_sign','final_notbeing_sign')

def guide(M,holy=False):
    m=M();coat='cream' if holy else 'ink'
    for side in (-1,1):
        m.box((.08,side*.13,.08),(.34,.18,.16),'hair')
        m.loft([(.13,0,side*.13,.075,.08),(.49,0,side*.13,.09,.095),(.85,0,side*.13,.10,.11)],'brown',8)
    m.loft([(.83,0,0,.16,.20),(1.1,-.01,0,.13,.21),(1.32,-.025,0,.11,.26),(1.39,-.03,0,.09,.18)],coat,10)
    for side in (-1,1):
        # Unequal hands: one composed, one lightly extended to the route.
        end=(.18,side*.29,1.10 if side==1 else .94)
        m.beam((-.01,side*.24,1.27),(.04,side*.31,1.08),.14,coat)
        m.beam((.04,side*.31,1.08),end,.12,coat);hand(m,*end)
    face(m)
    if holy:
        m.loft([(.17,0,0,.24,.31),(.89,0,0,.18,.23)],'cream',10)
        for side in (-1,1):m.beam((.16,side*.16,1.34),(.20,side*.19,.25),.05,'gold')
        m.loft([(1.39,.10,0,.035,.075),(1.50,.15,0,.05,.08)],'stone',8)
        m.loft([(1.67,-.035,0,.14,.14),(1.77,-.05,0,.10,.11)],'cream',10)
        m.box((.13,0,1.36),(.06,.10,.15),'gold')
    else:
        m.box((.15,0,1.10),(.028,.16,.33),'purple')
        m.beam((.16,-.18,1.31),(.15,.19,.87),.055,'brown')
        m.box((-.02,.28,.93),(.16,.15,.23),'brown')
        # Handmade scarf and rolled jacket cuffs, no copied likeness.
        m.loft([(1.27,0,0,.13,.18),(1.34,-.01,0,.12,.16)],'red',10)
        m.blade([(-.12,1.29),(-.02,1.29),(.03,1.02),(-.06,.96)],.16,.045,'red')
    return m

def artwork(obj,mat,half):
    """Assign original front painting only; wood edges retain painted surfaces."""
    mesh=obj.data;mesh.materials.append(mat);index=len(mesh.materials)-1
    uv=mesh.uv_layers.active
    for poly in mesh.polygons:
        # The display face is its thin plaque at local y=-.105. Do not paint
        # frame sidewalls or rear faces with a mirrored image.
        if poly.normal.y<-.99 and all(abs(mesh.vertices[i].co.y+.105)<.0001 for i in poly.vertices):
            poly.material_index=index
            for loop in poly.loop_indices:
                p=mesh.vertices[mesh.loops[loop].vertex_index].co
                uv.data[loop].uv=((half*64+4+(p.x+.59)/1.18*56)/128,1-(4+(2.18-p.z)/1.80*56)/64)


def dress(M,scene,out,inspection_material):
    replaced=[];added=[]
    def put(name,m):
        obj=replace(scene,M,name,m);obj['art_stage']=STAGE;replaced.append(name);return obj
    def add(name,m,loc=(0,0,0),visibility=1):
        obj=m.object(name,loc,kind='platform',visibility=visibility);obj['art_stage']=STAGE;added.append(name);return obj
    for name,holy in (('YoungMan',False),('HolyMan',True)):
        obj=put(name,guide(M,holy));obj['art_role']='principal guide';obj['wf_Moves Between Rooms']='True'
    # Multi-layer trunks and branches end outside |x-400| < 3; foliage stays
    # above head height and is deliberately separate from navigation meshes.
    m=M()
    for i,(x,y) in enumerate(TREES):
        z=height(y)-1.5
        m.loft([(z,x,y,.32,.35),(z+1.3,x+.08,y-.05,.24,.26),(z+4.1,x-.09,y+.05,.15,.17)],'brown',8)
        for side in (-1,1):
            m.beam((x,y,z+2.5),(x+side*.85,y+.25,z+4.0),.16,'brown')
            m.beam((x,y,z+.1),(x+side*.7,y+.45,z-.1),.13,'brown')
        canopy=M();canopy.sphere((0,0,.55),(1.65,1.45,1.25),'green',8,4)
        canopy.sphere((-.70,.18,.1),(1.0,.90,.82),'green',8,4)
        obj=add('GodCanopy'+str(i),canopy,(x,y,z+3.7));obj['art_pivot']='branch crown';obj['art_role']='sparse moving forest canopy'
    put('god_forest',m)
    m=M();m.cone((0,0,0),8,12,'purple',.3,9)
    for i in range(3):
        a=(i+.25)*math.tau/3
        m.beam((7*math.cos(a),7*math.sin(a),1),(1.2*math.cos(a),1.2*math.sin(a),10.4),.28,'stone')
    put('god_distant_peak',m)
    # A quiet edge rhythm marks the existing gradual rise without adding
    # steps, changing its collision slope or fabricating a switchback.
    m=M()
    for side in (-1,1):
        for i in range(15):
            y=-4+i*2;z=height(y)
            m.box((400+side*2.88,y,z+.04),(.14,.85,.08),'cream')
    for x,y in ((397,6),(403,18),(397,24)):
        z=height(y)
        for dy in (-1.1,1.1):m.box((x,y+dy,z+.04),(3.1,.10,.08),'gold')
    add('GodRouteEdges',m)
    # Compact summit shrine sits behind the decision landing, clear of both
    # doors and their approach strip. No altar interaction or narrative gate.
    m=M();m.box((400,36,5.35),(5.6,2.8,.3),'stone')
    for x in (397.65,402.35):
        m.cone((x,36,5.5),.24,2.8,'cream',sides=10)
        m.box((x,36,5.58),(.62,.65,.16),'stone')
        m.box((x,36,8.22),(.62,.65,.16),'gold')
    m.box((400,36,8.38),(5.8,.85,.23),'stone')
    m.box((400,36,5.93),(1.9,.80,.85),'stone');m.box((400,36,6.42),(2.10,.95,.14),'gold')
    for side in (-1,1):m.beam((400,36,9.1),(400+side*2.7,36,8.51),.16,'cream')
    add('GodSummitShrine',m)
    # Poster/icon paintings exactly illustrate the delivered original accounts:
    # broken frames and empty centre / luminous figure above a rock.
    for name,half in (('god_poster',0),('god_icon',1)):
        m=M();m.box((0,0,1.3),(1.55,.18,2.35),'brown')
        m.box((0,-.095,1.28),(1.18,.02,1.80),'paper')
        for x in (-.68,.68):m.box((x,-.14,1.3),(.12,.13,2.2),'gold' if half else 'steel')
        for z in (.22,2.38):m.box((0,-.14,z),(1.48,.13,.12),'gold' if half else 'steel')
        obj=put(name,m);artwork(obj,inspection_material,half);obj['art_role']='original inspectable painting'
    # Source-correct aether appears only in the existing affirmed God history.
    # Sparse opaque beams are readable from within; no transparent shell cost.
    for shell,(radius,z,color) in enumerate(((4.7,7.2,'gold'),(3.7,8.0,'cream'),(2.7,8.7,'blue'))):
        m=M()
        for meridian in range(3):
            phi=meridian*math.pi/3
            for j in range(14):
                a=j*math.pi/14;b=(j+1)*math.pi/14
                points=[(radius*math.cos(t)*math.cos(phi),radius*math.cos(t)*math.sin(phi),radius*math.sin(t)*.55) for t in (a,b)]
                m.beam(*points,.075,color)
        for j in range(24):
            a=j*math.tau/24;b=(j+1)*math.tau/24
            m.beam((radius*math.cos(a),radius*math.sin(a),0),(radius*math.cos(b),radius*math.sin(b),0),.075,color)
        m.sphere((radius*.70,radius*.70,.25),(.20,.20,.20),('blue','red','gold')[shell],8,4)
        if shell==0:
            obj=put('aether_rings',m);obj.location=(0,0,z)
        else:obj=add('AetherShell'+str(shell),m,(0,0,z),visibility=212)
        obj['art_pivot']='overhead shell centre';obj['art_role']='crystal-aether shell and embedded planet'
    # Three final thresholds share no new state flag. Shape adds recognition to
    # the existing exact outgoing-source links and colour/label distinctions.
    for name,color in (('final_being','cream'),('final_both','purple'),('final_notbeing','ink')):
        m=M()
        for side in (-1,1):
            m.box((side*1.16,0,1.78),(.24,.38,3.56),color)
            m.box((side*1.16,0,.12),(.45,.55,.24),'stone')
        m.box((0,0,3.60),(2.60,.40,.20),color)
        if name=='final_both':
            for side in (-1,1):
                prism=M();prism.blade([(-.44*side,3.95),(.40*side,3.68),(.40*side,4.22)],.02,.08,'gold')
                # The generic blade is in YZ for +X-facing figures. Rotate its
                # coordinates into XZ so doorway approaches see both triangles.
                m.part([(y,-x,z) for x,y,z in prism.verts],prism.faces,'gold')
        elif name=='final_being':m.sphere((0,0,3.97),(.23,.12,.23),'gold',10,4)
        else:m.box((0,0,3.97),(.56,.15,.13),'stone')
        obj=scene.objects[name];logical={'final_being':214,'final_both':215,'final_notbeing':216}[name]
        add(name+'Crown',m,tuple(obj.location),logical)
    for name in SIGNS:
        obj=scene.objects[name];obj.location.x+=1.55;obj.location.z-=.45;obj.scale=(.72,.72,.72)
    return dict(stage=STAGE,replaced=replaced,added=added,
        reused=['unchanged navigation triangles, path actor transforms and safe landings','A–C original artwork and all source dialogue','sixteen exact final Temple histories and source-derived door links','unchanged pinned runtime and heap limits'],
        originality='Original closed geometry and original painted inspection atlas; no borrowed model, logo or likeness',
        collision='Existing path/landing render triangles unchanged. New dressing is mass-zero platform; inherited replacement boxes alone do not prove identical statplat collision.',
        pending=['Native/device review and phone budget','Complete ending/surgery iteration E','Final matching movie/catalog and Max feedback'])

MOTION=[dict(name='God canopy settling',actors=['GodCanopy*'],trigger='God realm; normal motion; no modal sheet',loop=True,timingHz=.045,amplitudeTurns=.0015,representation='24 independent local-pivot rigid yaw transforms',reduced='stable canopy',measuredCost='phone pending'),
        dict(name='Aether shell rotation',actors=['aether_rings','AetherShell1','AetherShell2'],trigger='source-affirmed God return; normal motion; no modal sheet',loop=True,timingHz=[.025,-.016,.009],representation='three sparse opaque crystal arcs and embedded planets',reduced='stable composed shells; visibility remains source-correct',measuredCost='phone pending')]

def emit_motion(emit,actor,ids):
    for i,name in enumerate(n for n in ids if n.startswith('GodCanopy')):
        idx=actor(name)
        emit(f'0 INDEXOF_ROTATION_A {idx} write-actor-mailbox 0 INDEXOF_ROTATION_B {idx} write-actor-mailbox '
             f'108 read-mailbox 0 = 140 read-mailbox 0 = & if 110 read-mailbox .045 * {i*.071} + fy-sin .0015 * else 0 then INDEXOF_ROTATION_C {idx} write-actor-mailbox\n')
    for name,speed in (('aether_rings',.025),('AetherShell1',-.016),('AetherShell2',.009)):
        idx=actor(name)
        emit(f'0 INDEXOF_ROTATION_A {idx} write-actor-mailbox 0 INDEXOF_ROTATION_B {idx} write-actor-mailbox '
             f'108 read-mailbox 0 = 140 read-mailbox 0 = & if 110 read-mailbox {speed} * fy-wrap else 0 then INDEXOF_ROTATION_C {idx} write-actor-mailbox\n')
    for name in SIGNS:
        idx=actor(name);emit(f'0 INDEXOF_ROTATION_A {idx} write-actor-mailbox 0 INDEXOF_ROTATION_B {idx} write-actor-mailbox '
                           f'114 read-mailbox .25 - INDEXOF_ROTATION_C {idx} write-actor-mailbox\n')
