#!/usr/bin/env python3
"""Freeze container-built font libraries into the unchanged Android shell APK."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p=argparse.ArgumentParser()
    for name in ('source','base_apk','arm64','armv7','ndk','output','desktop'):
        p.add_argument('--'+name.replace('_','-'),type=Path,required=True)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=a.source,text=True).strip()
    changed=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=a.source,text=True)
    if any(line.startswith(('wfsource/','engine/','CMakeLists.txt')) for line in changed.splitlines()):
        raise RuntimeError('Commit engine source before freezing its runtime')
    native={};libs={}
    for abi,src in (('arm64-v8a',a.arm64),('armeabi-v7a',a.armv7)):
        target=a.output/('libwf_game-'+abi+'.so');target.write_bytes(src.read_bytes())
        subprocess.run([str(a.ndk/'toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip'),'--strip-unneeded',str(target)],check=True)
        name='lib/'+abi+'/libwf_game.so';libs[name]=target.read_bytes();native[name]=sha(target)
    runtime=a.output/'font-runtime.apk'
    with zipfile.ZipFile(a.base_apk) as base,zipfile.ZipFile(runtime,'w') as frozen:
        original={info.filename for info in base.infolist()}
        if not set(libs)<=original:raise RuntimeError('Base APK must contain both expected native libraries')
        dex={}
        for info in base.infolist():
            if info.filename.startswith('META-INF/'):continue
            data=libs.get(info.filename,base.read(info.filename))
            frozen.writestr(info,data)
            if info.filename.endswith('.dex'):dex[info.filename]=hashlib.sha256(data).hexdigest()
    paths=subprocess.check_output(['git','diff','--name-only','99c2ac0c..HEAD'],cwd=a.source,text=True).splitlines()
    paths+=['CMakeLists.txt','wfsource/source/hal/android/native_app_entry.cc','wfsource/source/hal/android/gles_display.cc']
    sources={}
    for name in sorted(set(paths)):
        file=a.source/name
        if file.is_file():sources[name]=sha(file)
    receipt=dict(sourceCommit=commit,sourceFilesSha256=sources,runtimeApkSha256=sha(runtime),
                 nativeLibraries=native,desktopExecutableSha256=sha(a.desktop),
                 baseShellApkSha256=sha(a.base_apk),unchangedDexSha256=dex,
                 build=dict(container='wf-e3-merge-test:local',ndk='26.2.11394342',rust='1.97.1',api=26,
                            configuration='Release, Forth-only, Jolt, GL/GLES, no runtime font rasterizer'),
                 verification={'desktop':'See font-runtime-evidence/results.json; device validation pending'})
    (a.output/'runtime-provenance.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(dict(runtime=str(runtime),sha256=sha(runtime),sourceCommit=commit,nativeLibraries=native),indent=2))

if __name__=='__main__':main()
