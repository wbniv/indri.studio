#include <android/native_activity.h>
#include <android/window.h>
static_assert(AWINDOW_FLAG_KEEP_SCREEN_ON == 0x80, "Android visible-window flag ABI");
void keep_game_visible(ANativeActivity* activity) { ANativeActivity_setWindowFlags(activity, AWINDOW_FLAG_KEEP_SCREEN_ON, 0); }
