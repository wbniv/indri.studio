"""Check visible face margins in actual surgery frames, retaining manual review.

The provisional scene has three skin-colored heads. This detector checks the
diagnosed edge clipping, not anatomical correctness or final art quality.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

import numpy as np
from PIL import Image
from scipy import ndimage

ROOT=Path(__file__).resolve().parent
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def inspect(image):
    pixels=np.asarray(image.convert('RGB')).astype(np.int16)
    height,width=pixels.shape[:2]
    skin=(pixels[:,:,0]>pixels[:,:,1]*1.18)&(pixels[:,:,1]>pixels[:,:,2]*1.1)&(pixels[:,:,0]>80)
    labels,_=ndimage.label(skin)
    boxes=[]
    for i,region in enumerate(ndimage.find_objects(labels)):
        if region is None:continue
        y,x=region;area=int((labels[region]==i+1).sum())
        if area>width*height*.001 and x.stop-x.start>width*.035 and y.stop-y.start>height*.055:
            boxes.append([x.start,y.start,x.stop,y.stop])
    yy,xx=np.where(skin)
    margins=[int(xx.min()),int(yy.min()),width-1-int(xx.max()),height-1-int(yy.max())] if len(xx) else [0]*4
    passed=len(boxes)>=3 and min(margins[::2])>=width*.025 and min(margins[1::2])>=height*.025
    return dict(passed=bool(passed),skin_regions=boxes,visible_skin_margins=margins)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--evidence',type=Path,required=True)
    args=parser.parse_args();e=args.evidence.resolve()
    rows=[];frames=e/'framing-samples';frames.mkdir(exist_ok=True)
    for name in ('desktop/motion','desktop/reduced'):
        folder=e/name
        if not (folder/'render-review.json').exists():continue
        report=json.loads((folder/'render-review.json').read_text())
        assert report['build']['sha256']==json.loads((ROOT/'build/build-receipt.json').read_text())['sha256']
        for camera in (0,1):
            world=[r for r in report['results'] if r['kind']=='world' and r['camera']==camera]
            assert world
            start=min(r['video_time'] for r in world);end=max(r['video_time'] for r in world)
            for sample,stamp in enumerate(np.linspace(start,end,12 if 'motion' in name else 3)):
                target=frames/f'{name.replace("/","-")}-view-{camera}-{sample:02d}.png'
                subprocess.run(['ffmpeg','-v','error','-y','-ss',str(stamp),'-i',str(folder/'review.mp4'),'-frames:v','1',str(target)],check=True,timeout=20)
                rows.append(dict(file=str(target.relative_to(e)),sha256=digest(target),camera=camera,video_time=float(stamp),**inspect(Image.open(target))))
    assert rows
    old=e/'before/surgery-world-third.png'
    negative=inspect(Image.open(old))
    assert not negative['passed'],'Detector did not reject the previously cropped scene'
    result=dict(passed=all(r['passed'] for r in rows),build=json.loads((ROOT/'build/build-receipt.json').read_text()),results=rows,
                negative_control=dict(file=str(old.relative_to(e)),sha256=digest(old),**negative),
                scope='Skin-color head regions and viewport margins in targeted native footage; original cropped scene is a negative control. Faces/caps, clinical composition and text still require explicit visual review.')
    (e/'framing-audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print('Framing:',len(rows),'frames;',sum(not r['passed'] for r in rows),'failures')
    if not result['passed']:raise SystemExit('Patient face margins failed')

if __name__=='__main__':main()
