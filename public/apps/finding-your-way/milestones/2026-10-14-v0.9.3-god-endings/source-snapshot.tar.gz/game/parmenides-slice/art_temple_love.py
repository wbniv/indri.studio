"""Iteration B: original reusable Temple/street construction and Love roster.

All replacements retain actor names, narrative visibility and collision bounds.
No engine features, borrowed imagery or new narrative prerequisites are used.
"""
import math

STAGE = 'temple-love'
CROWD = [(94.8,-4,0),(105.2,0,1),(94.8,6,2),(105.2,9,3)]

def replace(scene, M, name, model):
    import bpy
    obj=scene.objects[name];old=obj.data
    # Art detail never silently enlarges an established collision footprint.
    if 'wf_original_bbox' not in obj:
        obj['wf_original_bbox']=tuple(min(v.co[i] for v in old.vertices) for i in range(3))+tuple(max(v.co[i] for v in old.vertices) for i in range(3))
        obj['wf_had_authored_bbox']=True
    temp=model.object('art_transfer');obj.data=temp.data
    bpy.data.objects.remove(temp,do_unlink=True)
    obj['art_stage']=STAGE
    return obj

def column(m,x,y,height=4):
    for z,r,h,color in [(0,.52,.16,'stone'),(.16,.43,.16,'cream'),(.32,.29,height-.62,'cream'),
                         (height-.30,.39,.13,'gold'),(height-.17,.52,.17,'cream')]:
        m.cone((x,y,z),r,h,color,sides=12)
    for i in range(8):
        a=i*math.tau/8
        m.beam((x+.29*math.cos(a),y+.29*math.sin(a),.4),
               (x+.29*math.cos(a),y+.29*math.sin(a),height-.4),.035,'stone')
    # Closed paired volutes give the capital an Ionic silhouette.
    for side in (-1,1):m.sphere((x+side*.40,y,height-.20),(.15,.18,.14),'cream',8,4)

def person(M,name,location,variant=0,seated=False,principal=False):
    from art_models import face,hand
    m=M();coat=('red','green','blue','purple')[variant%4]
    if seated:
        # Feet contact the pavement; horizontal thighs meet the bench at .55m.
        for side in (-1,1):
            m.box((.10,side*.13,.08),(.34,.18,.16),'hair')
            m.loft([(.15,.02,side*.13,.075,.08),(.48,.02,side*.13,.08,.085)],'brown',8)
            m.beam((-.30,side*.13,.53),(.02,side*.13,.49),.18,'brown')
        base=.53;shift=-.31
    else:
        for side in (-1,1):
            m.loft([(.11,0,side*.12,.075,.078),(.43,.012,side*.12,.087,.085),(.85,0,side*.12,.10,.1)],'brown',8)
            m.box((.08,side*.12,.075),(.34,.19,.15),'hair')
        base=.85;shift=0
    m.loft([(base,shift,0,.14,.19),(base+.22,shift,0,.13,.20),
            (base+.40,shift-.02,0,.12,.24),(base+.47,shift-.02,0,.10,.19)],coat,10)
    m.box((shift+.135,0,base+.22),(.025,.12,.32),'cream')
    for side in (-1,1):
        m.beam((shift,side*.24,base+.40),(shift+.08,side*.32,base+.07),.14,coat)
        hand(m,shift+.10,side*.32,base+.02)
    if principal:
        # Reuse the proven facial construction, translated for seated pose.
        start=len(m.verts);projection_start=len(m.projections);face(m,variant==1)
        for i in range(start,len(m.verts)):
            x,y,z=m.verts[i];m.verts[i]=(x+shift,y,z+base-.85)
        for j in range(projection_start,len(m.projections)):
            color,bounds=m.projections[j]
            m.projections[j]=(color,[(lo+delta,hi+delta) for (lo,hi),delta in zip(bounds,(shift,0,base-.85))])
    else:
        m.loft([(base+.45,shift,0,.06,.07),(base+.60,shift,0,.11,.12),
                (base+.78,shift-.02,0,.11,.12),(base+.85,shift-.03,0,.07,.08)],'skin',8)
        m.loft([(base+.76,shift-.04,0,.105,.125),(base+.88,shift-.04,0,.085,.105)],'hair',8)
        for side in (-1,1):m.box((shift+.11,side*.052,base+.72),(.028,.035,.027),'ink')
    if variant==0:
        m.beam((shift+.16,-.17,base+.02),(shift+.14,.18,base+.43),.045,'brown')
        m.box((shift,-.25,base+.02),(.16,.15,.25),'brown')
    elif variant==1:
        # Original pop-fashion scarf, earrings and oversized book-reading cuffs.
        m.loft([(base+.42,shift,0,.125,.17),(base+.48,shift,0,.115,.155)],'gold',10)
        m.blade([(-.05,base+.40),(.09,base+.40),(.07,base+.1),(-.03,base+.12)],shift+.16,.035,'purple')
        for side in (-1,1):m.sphere((shift,side*.15,base+.67),(.035,.027,.045),'gold',6,4)
    elif variant==2:m.box((shift+.145,0,base+.20),(.035,.22,.13),'brown')
    else:m.loft([(base+.81,shift-.03,0,.135,.14),(base+.91,shift-.04,0,.09,.10)],'purple',8)
    obj=m.object(name,location,kind='platform');obj['art_stage']=STAGE
    obj['art_role']='principal' if principal else 'background crowd'
    return obj

def dress(M,scene,out,tapestry_material):
    import bpy
    # Replace the corner overlays with a coherent kit across both scenes.
    for name in ('proof_temple_column','proof_temple_mosaic','proof_love_facade'):
        bpy.data.objects.remove(scene.objects[name],do_unlink=True)
    m=M()
    for x in (-10,10):
        for y in (-10,-5,0,5,10):column(m,x,y,5.15)
    # Broken thick shell segments; deliberately open crown and starless sky.
    for y in (-5,2,8):
        for i in range(16):
            if i in (6,7,8,9) or (y==2 and i==4):continue
            a=i*math.pi/16;b=(i+1)*math.pi/16
            verts=[(r*math.cos(t),y+d,5+r*math.sin(t))
                   for d in (-.30,.30) for r,t in ((9.55,a),(9.55,b),(9.80,b),(9.80,a))]
            # Same closed arch segment construction, with outward winding.
            m.part(verts,[(3,2,1,0),(4,5,6,7),(1,5,4,0),(2,6,5,1),(3,7,6,2),(0,4,7,3)],'stone')
            m.beam((9.52*math.cos(a),y-.34,5+9.52*math.sin(a)),
                   (9.52*math.cos(b),y-.34,5+9.52*math.sin(b)),.055,'gold')
    replace(scene,M,'temple_structure',m)
    m=M()
    for x in (-10,10):
        m.box((x,0,.6),(.8,27,1.2),'stone')
        for y in (-7,0,7):
            for dy in (-1.35,1.35):m.box((x,y+dy,2.65),(.22,.17,3),'cream')
            for z in (1.18,4.15):m.box((x,y,z),(.36,2.9,.20),'stone')
            # Empty window and a few closed irregular remnants, not a solid pane.
            for dy,z in ((-1.05,1.6),(1.02,3.75),(-.98,3.8)):
                m.blade([(dy-.18,z-.25),(dy+.16,z-.16),(dy+.08,z+.18)],x,.06,'glass')
    m.box((0,13,.6),(20,.8,1.2),'stone')
    replace(scene,M,'temple_walls',m)
    m=M()
    for x in (-9.9,9.9):
        for y in (-7,0,7):
            for i,color in enumerate(('red','gold','blue','green')):
                cy=y-.62+(i%2)*1.24;z=2.05+(i//2)*1.13
                m.box((x,cy,z),(.055,1.13,1.02),color)
                for dy in (-.59,.59):m.box((x,cy+dy,z),(.10,.06,1.1),'steel')
                for dz in (-.54,.54):m.box((x,cy,z+dz),(.10,1.24,.06),'steel')
    replace(scene,M,'stained_glass',m)
    for i in range(4):
        m=M();column(m,0,0);replace(scene,M,'pillar'+str(i),m)
        for variant in (0,1):
            name=f'cloth{i}v{variant}';m=M()
            # Uneven strips leave actual moth holes in the faded lower edge.
            for j in range(6):
                lo=1.1+(0.16 if not variant and j in (1,4) else 0)
                m.box((-.625+j*.25,-.43,(4+lo)/2),(.245,.055,4-lo),'cream')
            obj=replace(scene,M,name,m);obj.data.materials.append(tapestry_material)
            # Hub cloth stays resident with the player; use the existing native
            # permanent-asset route, keeping Room0's unchanged page budget.
            obj['wf_Moves Between Rooms']='True'
            uv=obj.data.uv_layers.active
            for poly in obj.data.polygons:
                if abs(poly.normal.y)>.9:
                    poly.material_index=1
                    for loop in poly.loop_indices:
                        p=obj.data.vertices[obj.data.loops[loop].vertex_index].co
                        uv.data[loop].uv=((i*64+4+(p.x+.75)/1.5*56)/256,
                                         1-(variant*64+4+(4-p.z)/2.9*56)/128)
    # Worn-path mosaic banding retains the visible foundation gate.
    m=M()
    for radius in (2.2,2.45,4.6,4.85):
        for i in range(32):
            a=i*math.tau/32;b=(i+1)*math.tau/32
            m.beam((radius*math.cos(a),radius*math.sin(a)-3,.035),
                   (radius*math.cos(b),radius*math.sin(b)-3,.035),.045,'gold')
    for i in range(16):
        a=i*math.tau/16
        m.box((3.4*math.cos(a),-3+3.4*math.sin(a),.031),(.18,.18,.024),('red','blue','green','cream')[i%4])
    m.object('temple_mosaic_courses',visibility=206)
    # Eight houses use a repeatable street kit. The west shop's door is a real
    # recess in this shell, rather than a proof facade laid on a solid wall.
    m=M()
    for side in (-1,1):
        for i in range(4):
            x=100+side*11;y=-7+i*6;front=x-side*2
            color=('plaster','stone','cream','plaster')[i]
            m.box((x+side*.20,y,3),(3.6,5,6),color)
            # Keep a 1.6m doorway aperture down to street level.
            for dy in (-1.64,1.64):m.box((front,y+dy,1.3),(.26,1.72,2.6),color)
            m.box((front,y,4.3),(.26,5,3.4),color)
            m.box((front-side*.10,y,.10),(.35,5,.20),'stone')
            for dy in (-.88,.88):m.box((front-side*.13,y+dy,1.2),(.30,.16,2.4),'stone')
            m.box((front-side*.13,y,2.46),(.30,1.92,.20),'stone')
            for z in (3.4,4.95):
                for dy in (-1.4,1.4):
                    m.box((front-side*.16,y+dy,z),(.055,1.02,.95),'glass')
                    for edge in (-.56,.56):m.box((front-side*.22,y+dy+edge,z),(.12,.08,1.10),'brown')
                    for edge in (-.52,.52):m.box((front-side*.22,y+dy,z+edge),(.12,1.2,.08),'brown')
                    m.box((front-side*.23,y+dy,z),(.12,.06,1.02),'brown')
            m.box((front,y,6),(.60,5.3,.18),'brown')
            # Hinged door leaf for every house; west #2 retains proof actor ID.
            if side==-1 and i==2:continue
            d=M();d.box((0,.70,1.13),(.13,1.4,2.26),('green','red','blue','brown')[i])
            for z in (.55,1.7):d.box((-.08*side,.70,z),(.035,1.12,.80),'brown')
            d.sphere((-.13*side,1.22,1.1),(.035,.055,.04),'gold',6,4)
            door=d.object(f'love_door_{side}_{i}',(front-side*.21,y-.70,.12),kind='platform')
            door['art_pivot']='door hinge'
    for x in (95,105):
        m.cone((x,-3,.12),.17,.25,'steel',sides=8)
        m.cone((x,-3,.37),.085,2.9,'steel',sides=8)
        m.box((x,-3,3.42),(.44,.44,.36),'gold')
        for dx in (-.25,.25):m.box((x+dx,-3,3.42),(.06,.50,.47),'steel')
        m.cone((x,-3,3.65),.39,.20,'steel',.04,8)
    replace(scene,M,'street_buildings',m)
    # Reuse the accepted door/newspaper construction and put the starlet bench
    # directly beneath the seated actor, outside the central eight-metre route.
    bench=scene.objects['proof_love_bench'];bench.location=(104.22,3.22,.12);bench.rotation_euler.z=-math.pi/4
    for name,variant,seated in (('FirstLove',0,False),('Starlet',1,True)):
        obj=scene.objects[name];temp=person(M,'roster_transfer',(0,0,0),variant,seated,True)
        replace(scene,M,name,_MeshTransfer(temp))
        bpy.data.objects.remove(temp,do_unlink=True)
        obj['wf_Visibility Mailbox']=480 if name=='FirstLove' else 481
        obj['art_role']='principal'
    m=M();m.box((0,0,0),(.32,.08,.4),'green');m.box((0,-.05,0),(.27,.015,.35),'paper')
    m.box((-.16,0,0),(.03,.09,.41),'gold')
    book=replace(scene,M,'biology_book',m);book.location=(104.10,3.10,.78);book.rotation_euler=(0,-math.pi/3,-3*math.pi/4);book['wf_Visibility Mailbox']=481
    book['wf_schema_path']=str(__import__('pathlib').Path(book['wf_schema_path']).with_name('platform.oad'))
    for x,y,i in CROWD:
        obj=person(M,f'LoveCrowd{i}',(x,y,.12),i)
        obj['wf_Visibility Mailbox']=482+i;obj.rotation_euler.z=-math.pi/4 if i%2==0 else -3*math.pi/4
    # Eye-height wayfinding, facing the approach in both views. No sign sits
    # across a threshold or uses the same geometry as modal reading sheets.
    for name in ('love_sign','reason_sign','truth_sign','being_sign','notbeing_sign','back_sign'):
        obj=scene.objects[name];obj.location.x+=1.85;obj.location.z=1.65
        obj.scale=(.70,.70,.70)
    return dict(stage=STAGE,scope='Temple and Love; later realms retain baseline art',
        replaced=['temple_structure','temple_walls','stained_glass',*[f'pillar{i}' for i in range(4)],
                  *[f'cloth{i}v{v}' for i in range(4) for v in (0,1)],'street_buildings','FirstLove','Starlet','biology_book'],
        reused=['Player','Goddess','GoddessWingL','GoddessWingR','proof_love_door','proof_love_bench','newspaper','proof_newspaper_leaf'],
        pending=['Pixel input/performance and Will style acceptance','Final aether/foundation history art in iteration D','Later realm/ending roster in iterations C–E'],
        collision='Existing replacement bounds and player footprint preserved; decorative crowd and kits are mass-zero',
        originality='Procedural original Blender geometry and painted diffuse; no celebrity likeness or external assets')

class _MeshTransfer:
    def __init__(self,obj):self.obj=obj
    def object(self,name):
        copy=self.obj.copy();copy.data=self.obj.data.copy();copy.name=name
        import bpy
        bpy.context.scene.collection.objects.link(copy)
        return copy
