#!/usr/bin/env python3
"""Make a --frame-profile variant of a frozen Parmenides APK.

The variant is byte-identical to the base APK except that ``assets/wf_args.txt``
gains ``--frame-profile`` (the engine's per-section CPU profiler, which prints to
``wf.log`` on Android). The native libraries, level, manifest and version code
are untouched, so the variant installs over the base milestone and measures the
same executable. It is re-aligned and re-signed with the stage's development key.

With ``--runtime RUNTIME.apk`` the variant also takes its ``lib/*/libwf_game.so``
from that engine build (same ABIs required), so the same level and chapter content
can be measured against a different engine build. The output is then named
``<base-stem>-<tag>-profile.apk`` (``--tag``, default ``rt``) and the receipt records
the runtime APK and the SHA-256 of every swapped library.

With ``--extra-flag FLAG`` (repeatable) each FLAG is appended to ``wf_args.txt``
after ``--frame-profile``: one APK, two variants that differ only in a run-time
switch, e.g. ``--extra-flag=--static-mesh=0`` for the E3 off side of an A/B.
Pair it with a distinct ``--tag`` so the two variants get different names.

Usage:
    make_profile_variant.py BASE.apk [BASE2.apk ...] [--out DIR] [--key P12]
                            [--runtime RUNTIME.apk [--tag TAG]] [--extra-flag FLAG ...]

Writes ``<out>/<base-stem>-profile.apk`` and ``<out>/<base-stem>-profile.json``
(base/variant SHA-256, version code, wf_args) for the evidence trail.
"""
import argparse
import hashlib
import json
import re
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TOOLS = Path('/home/will/android-sdk-local/build-tools/34.0.0')
FLAG = '--frame-profile'


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def version_code(apk):
    badging = subprocess.run([TOOLS / 'aapt', 'dump', 'badging', str(apk)], capture_output=True, text=True, check=True).stdout
    match = re.search(r"versionCode='(\d+)' versionName='([^']*)'", badging)
    return (int(match.group(1)), match.group(2)) if match else (None, None)


def runtime_libraries(runtime):
    with zipfile.ZipFile(runtime) as z:
        return {n: z.read(n) for n in z.namelist() if n.startswith('lib/') and n.endswith('/libwf_game.so')}


def make_variant(base, out_dir, key, runtime=None, tag='rt', extra_flags=()):
    base = base.resolve()
    stem = base.stem + (f'-{tag}' if runtime or extra_flags else '')
    swapped = runtime_libraries(runtime.resolve()) if runtime else {}
    unsigned = out_dir / f'{stem}-profile-unsigned.apk'
    aligned = out_dir / f'{stem}-profile-aligned.apk'
    variant = out_dir / f'{stem}-profile.apk'
    args_text = None
    replaced = {}
    with zipfile.ZipFile(base) as zin, zipfile.ZipFile(unsigned, 'w') as zout:
        base_libs = {i.filename for i in zin.infolist() if i.filename in swapped}
        if runtime and base_libs != set(swapped):
            raise SystemExit(f'{runtime} ABIs {sorted(swapped)} do not match {base} libraries {sorted(base_libs)}')
        for info in zin.infolist():
            if info.filename.startswith('META-INF/'):
                continue
            data = zin.read(info.filename)
            if info.filename in swapped:
                data = swapped[info.filename]
                replaced[info.filename] = hashlib.sha256(data).hexdigest()
            if info.filename == 'assets/wf_args.txt':
                text = data.decode()
                if FLAG in text.split():
                    raise SystemExit(f'{base} already carries {FLAG}')
                args_text = text.rstrip('\n') + '\n' + '\n'.join([FLAG, *extra_flags]) + '\n'
                data = args_text.encode()
            entry = zipfile.ZipInfo(info.filename, date_time=info.date_time)
            entry.compress_type = info.compress_type
            entry.external_attr = info.external_attr
            zout.writestr(entry, data)
    if args_text is None:
        raise SystemExit(f'{base} has no assets/wf_args.txt; not a Parmenides APK')
    subprocess.run([TOOLS / 'zipalign', '-f', '4', unsigned, aligned], check=True)
    subprocess.run([TOOLS / 'apksigner', 'sign', '--ks', key, '--ks-pass', 'pass:android', '--out', variant, aligned], check=True)
    subprocess.run([TOOLS / 'apksigner', 'verify', variant], check=True)
    unsigned.unlink()
    aligned.unlink()
    code, name = version_code(variant)
    receipt = dict(base=str(base), baseSha256=sha256(base), variant=str(variant), variantSha256=sha256(variant),
                   versionCode=code, versionName=name, wfArgs=args_text.split(), signingKey=str(key),
                   note='Identical native libraries, level and manifest; only assets/wf_args.txt and the signature differ.')
    if runtime:
        receipt.update(runtimeApk=str(runtime.resolve()), runtimeApkSha256=sha256(runtime.resolve()), swappedLibraries=replaced,
                       note='Level, manifest and version code from the base APK; lib/*/libwf_game.so from the runtime APK; '
                            'assets/wf_args.txt gains --frame-profile; re-signed.')
    (out_dir / f'{stem}-profile.json').write_text(json.dumps(receipt, indent=2) + '\n')
    return receipt


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.split('\n')[0])
    parser.add_argument('apks', nargs='+', type=Path)
    parser.add_argument('--out', type=Path, default=ROOT / 'build/profile-variants')
    parser.add_argument('--key', type=Path, default=ROOT / 'build/development-signing.p12')
    parser.add_argument('--runtime', type=Path, help='take lib/*/libwf_game.so from this runtime APK')
    parser.add_argument('--tag', default='rt', help='name suffix for --runtime / --extra-flag variants (default: rt)')
    parser.add_argument('--extra-flag', action='append', default=[],
                        help='append this flag to wf_args.txt after --frame-profile (repeatable)')
    args = parser.parse_args(argv)
    args.out.mkdir(parents=True, exist_ok=True)
    for apk in args.apks:
        receipt = make_variant(apk, args.out, args.key.resolve(), args.runtime, args.tag, args.extra_flag)
        print(f"{receipt['variant']}  code={receipt['versionCode']} {receipt['versionName']}  sha256={receipt['variantSha256'][:16]}")
    return 0


if __name__ == '__main__':
    sys.exit(main())
