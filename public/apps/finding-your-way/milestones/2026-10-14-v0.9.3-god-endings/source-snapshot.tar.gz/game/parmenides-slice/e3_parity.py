#!/usr/bin/env python3
"""E3 pixel-parity harness: capture fixed-step frames, then compare two runs exactly.

  capture  Render frame N of each fixture in a fresh wf_game process at the fixed
           1/14 s step and write <out>/<fixture>/<N>.png plus <out>/manifest.json
           (binary sha256, level sha256, argv, env, timings, exit status).
  compare  Byte- and pixel-compare two capture directories: differing pixels, max
           channel difference, bounding box, PASS/FAIL per capture, compare.json,
           and an amplified difference PNG for every mismatch.

The binary must carry the --capture-frame code: build with -DDESIGNER_CHEATS=1
(engine/build_game.sh does; a plain CMake Release does not). Each capture runs
`--frame-step-smoke=N+2 --cycles=1`, so the process exits by itself two frames
after the capture; a timeout kills it otherwise. Captures run one at a time.

Determinism (docs/diagnostics/parmenides/v0.8-optimization/e3/determinism/):
the same binary is byte-identical run to run on every fixture once two things
are kept out: the bottom-right fps counter (wall-clock; pass --extra=--no-fps)
and desktop keyboard input reaching the focused game window (the manifest's
x_input_events / no_human_input record it per capture). Both runs of a parity
check must use the same --extra flags. Flags that start with '-' go in as
--extra=--flag.

Off-screen by default: capture starts a private Xvfb display (ensure_xvfb.sh
provisions one without root) and runs every game process on it, so no window
opens on the desktop and the user's keyboard and mouse cannot reach the game.
The renderer there is Mesa llvmpipe (software), the same for both runs of a
parity check; the manifest records the display and the GL renderer, and compare
warns when A and B differ in either. --desktop opts out (a window per capture
on your own display, with the input watch as the only protection).

Examples:
  e3_parity.py capture --binary ~/wf/engine/wf_game --out runA --frames 20,200 --extra=--no-fps
  e3_parity.py capture --desktop --binary B --out runC --frames 20   # on the real desktop
  e3_parity.py capture --binary B --out runB --fixtures g0v0,smb_w1_1 --frames 20
  e3_parity.py compare --a runA --b runB [--json out.json] [--diff-dir DIR]
  e3_parity.py compare --a runA --b runA --frame-a 20 --frame-b 200   # sanity: must differ
  e3_parity.py list
"""
from __future__ import annotations

import argparse
import datetime as dt
import gzip
import hashlib
import json
import os
import platform
import re
import resource
import subprocess
import sys
import time
from pathlib import Path

HOME = Path.home()
SLICE = Path(__file__).resolve().parent
FIXTURE_ROOT = SLICE / "build" / "v0.7-polish" / "review-fixtures"
DEFAULT_WF_ROOT = HOME / "WorldFoundry-wbniv"
RATE = "-rate14"

CHAPTER_ARGS = ["-width=1280", "-height=720",
                "--vram-width=5120", "--vram-height=2048",
                "--vram-slot-width=1024", "--vram-slot-height=2048",
                "--vram-perm-width=2048", "--vram-perm-height=2048"]
# Same tour set as the cast1 profiles: view-0 of every group, view-1 of groups 1 and 3.
CHAPTER = {f"g{g}v{v}": (g, v) for g, v in
           [(0, 0), (1, 0), (1, 1), (2, 0), (3, 0), (3, 1), (4, 0)]}

_VRAM_4K = ["--vram-width=4096", "--vram-height=2048",
            "--vram-slot-width=1024", "--vram-slot-height=1024", "--vram-perm-width=1024"]
# The shipped standalone levels of tests/test_backface_cull_invariant.py (ACCEPTED),
# with its VRAM_FLAGS.
SHIPPED = {
    "condo_639_640": _VRAM_4K + ["--vram-perm-height=1024"],
    "condo_639_640_tour": _VRAM_4K + ["--vram-perm-height=1024"],
    "dome": [], "filelight": [], "filesys": [], "marble-madness": [],
    "marble-madness-2": [], "mm_practice": [], "mm_practice_blender": [],
    "mm_practice_blender_rt": [], "moon_site01": _VRAM_4K + ["--vram-perm-height=512"],
    "pilot_demo": [], "qbert_practice": [], "smb_w1_1": [], "smb_w1_2": [],
    "smb_w1_3": [], "smb_w1_4": [], "snowgoons": [], "snowgoons-blender": [],
}
CAPTURE_RE = re.compile(r"capture frame (\d+) -> .* \((\d+)x(\d+)\) (\S+), non-black pixels (\d+)/(\d+)")


def now() -> str:
    return dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def log(msg: str) -> None:
    print(f"{now()} {msg}", flush=True)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def fixture_spec(name: str, wf_root: Path) -> dict:
    """Level path, working directory and extra argv for one fixture name."""
    if name in CHAPTER:
        g, v = CHAPTER[name]
        d = FIXTURE_ROOT / f"group-{g}-view-{v}"
        return dict(level=d / "parmenides_slice-standalone.iff", cwd=d, args=CHAPTER_ARGS)
    if name in SHIPPED:
        return dict(level=wf_root / "wflevels" / f"{name}-standalone.iff",
                    cwd=wf_root / "wfsource" / "source" / "game", args=SHIPPED[name])
    raise SystemExit(f"unknown fixture {name!r}; see `{Path(__file__).name} list`")


def parse_list(text: str, all_names: list[str]) -> list[str]:
    out: list[str] = []
    for item in text.split(","):
        item = item.strip()
        if item == "chapter":
            out += list(CHAPTER)
        elif item == "shipped":
            out += list(SHIPPED)
        elif item == "all":
            out += all_names
        elif item:
            out.append(item)
    return list(dict.fromkeys(out))


class InputWatch:
    """Count the key/button/motion events the X server handles while a capture runs.

    wf_game's window takes keyboard focus on the shared desktop, and a key typed
    into it reaches the game (2026-10-08: Will's typing landed in run A and moved
    the condo_639_640 and marble-madness cameras). The engine logs only unmapped
    keys, so the harness listens with the X RECORD extension instead. Under
    XWayland this sees exactly the input routed to X clients, which is the input
    that can reach wf_game. `counts` stays None when RECORD is unavailable."""

    def __init__(self) -> None:
        self.counts: dict[str, int] | None = None
        self._ctx = None
        try:
            from Xlib import X, display
            from Xlib.ext import record
            from Xlib.protocol import rq
        except ImportError:
            return
        try:
            self._ctl, rec = display.Display(), display.Display()
            if not rec.has_extension("RECORD"):
                return
            self._ctx = rec.record_create_context(0, [record.AllClients], [dict(
                core_requests=(0, 0), core_replies=(0, 0, 0, 0), ext_requests=(0, 0, 0, 0),
                ext_replies=(0, 0, 0, 0), delivered_events=(0, 0),
                device_events=(X.KeyPress, X.MotionNotify), errors=(0, 0),
                client_started=False, client_died=False)])
        except Exception:  # no X server, or RECORD refused: run without the watch
            self._ctx = None
            return
        names = {X.KeyPress: "key_press", X.KeyRelease: "key_release", X.ButtonPress: "button_press",
                 X.ButtonRelease: "button_release", X.MotionNotify: "motion"}
        self.counts = dict.fromkeys(names.values(), 0)

        import threading
        started = threading.Event()

        def on_event(reply) -> None:
            if reply.category == record.StartOfData:
                started.set()
            if reply.category != record.FromServer or reply.client_swapped or not reply.data:
                return
            data = reply.data
            while data:
                ev, data = rq.EventField(None).parse_binary_value(data, rec.display, None, None)
                key = names.get(ev.type & 0x7F)
                if key and self.counts is not None:
                    self.counts[key] += 1

        self._thread = threading.Thread(target=rec.record_enable_context, args=(self._ctx, on_event), daemon=True)
        self._thread.start()
        self._rec = rec
        if not started.wait(timeout=3):  # recording is not live yet: say so rather than report 0
            self.counts = None

    def stop(self) -> dict[str, int] | None:
        if self._ctx is not None:
            time.sleep(0.2)  # let the last events drain
            self._ctl.record_disable_context(self._ctx)
            self._ctl.flush()
            self._thread.join(timeout=5)
            self._rec.record_free_context(self._ctx)
            self._ctl.close()
        return self.counts


def xvfb_path() -> str:
    out = subprocess.run([str(SLICE / "ensure_xvfb.sh")], capture_output=True, text=True)
    if out.returncode != 0:
        raise SystemExit(f"cannot provision Xvfb for an off-screen run (use --desktop to opt out):\n{out.stderr}")
    return out.stdout.strip().splitlines()[-1]


class PrivateDisplay:
    """A private Xvfb display: no real input devices, nothing on the user's desktop."""

    def __init__(self) -> None:
        self.number: int | None = None
        self._proc: subprocess.Popen | None = None

    def __enter__(self) -> "PrivateDisplay":
        rfd, wfd = os.pipe()
        self._proc = subprocess.Popen(
            [xvfb_path(), "-displayfd", str(wfd), "-screen", "0", "1920x1080x24", "-nolisten", "tcp", "-noreset"],
            pass_fds=(wfd,), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        os.close(wfd)
        with os.fdopen(rfd) as r:
            line = r.readline().strip()   # Xvfb writes the display number once it listens
        if not line.isdigit():
            self._proc.kill()
            raise SystemExit("Xvfb did not report a display number")
        self.number = int(line)
        return self

    @property
    def name(self) -> str:
        return f":{self.number}"

    def __exit__(self, *exc) -> None:
        if self._proc is not None:
            self._proc.terminate()
            try:
                self._proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self._proc.kill()


def gl_renderer(display: str) -> str | None:
    """The OpenGL renderer string of a display (recorded so A and B can be checked alike)."""
    try:
        out = subprocess.run(["glxinfo", "-B"], env=dict(os.environ, DISPLAY=display),
                             capture_output=True, text=True, timeout=30).stdout
    except (OSError, subprocess.TimeoutExpired):
        return None
    m = re.search(r"OpenGL renderer string: (.+)", out)
    return m.group(1).strip() if m else None


def limit_child() -> None:
    # No core dumps, bounded address space (house rule for batch engine runs).
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_AS, (4_000_000 * 1024, 4_000_000 * 1024))


def cmd_capture(a: argparse.Namespace) -> int:
    if a.desktop:
        return capture(a, isolated=False)
    with PrivateDisplay() as display:
        os.environ["DISPLAY"] = display.name   # the child env and the input watch both follow it
        log(f"off-screen: private Xvfb display {display.name}; no window opens on the desktop")
        return capture(a, isolated=True)


def capture(a: argparse.Namespace, isolated: bool) -> int:
    binary = Path(a.binary).expanduser().resolve()
    wf_root = Path(a.wf_root).expanduser().resolve()
    out = Path(a.out).expanduser().resolve()
    frames = [int(f) for f in a.frames.split(",") if f.strip()]
    names = parse_list(a.fixtures, list(CHAPTER) + list(SHIPPED))
    extra_env = dict(kv.split("=", 1) for kv in a.env)
    if not binary.exists():
        raise SystemExit(f"no binary at {binary}")
    # The option name alone is not enough: a build without DESIGNER_CHEATS parses
    # --capture-frame but never writes the file (the writer logs this message).
    if b"linux: capture frame" not in binary.read_bytes():
        raise SystemExit(f"{binary} has no --capture-frame writer; build with -DDESIGNER_CHEATS=1")
    out.mkdir(parents=True, exist_ok=True)
    manifest_path = out / "manifest.json"
    manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else {}
    manifest.update(dict(
        tool=str(Path(__file__).resolve()), started=manifest.get("started", now()),
        binary=str(binary), binary_sha256=sha256(binary), wf_root=str(wf_root),
        rate=RATE, host=platform.node(), display=os.environ.get("DISPLAY"),
        isolated_display=isolated, gl_renderer=gl_renderer(os.environ.get("DISPLAY", ":0")),
        extra_args=a.extra, extra_env=extra_env))
    caps = manifest.setdefault("captures", {})
    env = dict(os.environ, LD_LIBRARY_PATH=f"{wf_root / 'engine' / 'libs'}:{os.environ.get('LD_LIBRARY_PATH', '')}")
    env.setdefault("DISPLAY", ":0")
    env.update(extra_env)
    windows = 0
    failures = 0
    for name in names:
        spec = fixture_spec(name, wf_root)
        if not spec["level"].exists():
            log(f"SKIP {name}: missing {spec['level']}")
            failures += 1
            continue
        (out / name).mkdir(exist_ok=True)
        for frame in frames:
            png = out / name / f"{frame}.png"
            logf = out / name / f"{frame}.log"
            png.unlink(missing_ok=True)
            argv = [str(binary), f"-L{spec['level']}", f"--frame-step-smoke={frame + 2}", "--cycles=1",
                    RATE, *spec["args"], *a.extra, f"--capture-frame={frame}={png}"]
            t0 = time.monotonic()
            started = now()
            windows += 1
            timed_out = False
            watch = InputWatch()
            with open(logf, "w") as lf:
                proc = subprocess.Popen(argv, cwd=spec["cwd"], env=env, stdout=lf,
                                        stderr=subprocess.STDOUT, preexec_fn=limit_child)
                try:
                    rc = proc.wait(timeout=a.timeout)
                except subprocess.TimeoutExpired:
                    timed_out = True
                    proc.kill()
                    rc = proc.wait(timeout=10)
            secs = round(time.monotonic() - t0, 3)
            inputs = watch.stop()
            # Key/button input can steer the game; pointer motion alone cannot (the
            # window does not select MotionNotify, gfx/gl/mesa.cc XSelectInput).
            human = None if inputs is None else sum(v for k, v in inputs.items() if k != "motion")
            text = logf.read_text(errors="replace")
            m = CAPTURE_RE.search(text)
            ok = png.exists() and m is not None and m.group(4) == "written"
            # Keyboard events the window received ("unknown key" is only the unmapped ones).
            keys = [ln for ln in text.splitlines() if "key" in ln and ("pressed" in ln or "released" in ln)]
            # Engine logs reach several MB (jolt mesh dumps); keep them, compressed.
            with gzip.open(f"{logf}.gz", "wt") as gz:
                gz.write(text)
            logf.unlink()
            failures += 0 if ok else 1
            caps[f"{name}/{frame}"] = dict(
                fixture=name, frame=frame, png=f"{name}/{frame}.png" if png.exists() else None,
                png_sha256=sha256(png) if png.exists() else None,
                level=str(spec["level"]), level_sha256=sha256(spec["level"]), cwd=str(spec["cwd"]),
                argv=argv, started=started, seconds=secs, exit_code=rc, timed_out=timed_out,
                size=[int(m.group(2)), int(m.group(3))] if m else None,
                non_black=int(m.group(5)) if m else None, ok=ok,
                x_input_events=inputs, no_human_input=(human == 0) if human is not None else None,
                key_events_logged=keys)
            log(f"{'OK  ' if ok else 'FAIL'} {name} frame {frame}: rc={rc} {secs}s"
                f"{' TIMEOUT' if timed_out else ''}"
                f"{' input=unwatched' if human is None else (' INPUT=' + str(human) if human else ' input=0')}"
                f"{' KEYS=' + str(len(keys)) if keys else ''} "
                f"{png.name if ok else '(no capture, see ' + str(logf) + '.gz)'}")
            manifest["finished"] = now()
            manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    manifest["windows_opened_last_session"] = windows
    manifest["windows_on_user_desktop"] = 0 if isolated else windows
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    log(f"{windows} processes (windows) launched; {failures} failed; manifest {manifest_path}")
    return 1 if failures else 0


def load_rgb(path: Path):
    import numpy as np
    from PIL import Image
    return np.asarray(Image.open(path).convert("RGB")).astype(np.int16)


def diff_image(ia, ib, mask, path: Path) -> None:
    """Dimmed grey copy of A, differing pixels in magenta scaled by size of the difference."""
    import numpy as np
    from PIL import Image
    grey = (ia.mean(axis=2) * 0.35).astype(np.uint8)
    img = np.stack([grey, grey, grey], axis=2)
    mag = np.abs(ia - ib).max(axis=2)
    level = np.clip(128 + mag * 8, 0, 255).astype(np.uint8)
    img[mask, 0] = level[mask]
    img[mask, 1] = 0
    img[mask, 2] = level[mask]
    Image.fromarray(img).save(path)


def cmd_compare(a: argparse.Namespace) -> int:
    import numpy as np
    da, db = Path(a.a).expanduser().resolve(), Path(a.b).expanduser().resolve()
    ma = json.loads((da / "manifest.json").read_text())
    mb = json.loads((db / "manifest.json").read_text())
    diff_dir = Path(a.diff_dir).expanduser().resolve() if a.diff_dir else Path(a.json).expanduser().resolve().parent / "diffs" if a.json else db / "diffs"
    ca, cb = ma.get("captures", {}), mb.get("captures", {})
    fixtures = sorted({c["fixture"] for c in ca.values()} | {c["fixture"] for c in cb.values()})
    if a.fixtures:
        fixtures = [f for f in parse_list(a.fixtures, fixtures) if f in fixtures]
    rows = []
    for fx in fixtures:
        frames_a = sorted(c["frame"] for c in ca.values() if c["fixture"] == fx)
        pairs = [(a.frame_a, a.frame_b)] if a.frame_a is not None else [(f, f) for f in sorted(
            set(frames_a) | {c["frame"] for c in cb.values() if c["fixture"] == fx})]
        for fa, fb in pairs:
            ra, rb = ca.get(f"{fx}/{fa}"), cb.get(f"{fx}/{fb}")
            row = dict(fixture=fx, frame_a=fa, frame_b=fb)
            if not (ra and ra.get("png")) or not (rb and rb.get("png")):
                row.update(status="FAIL", reason="missing capture on side " + ("A" if not (ra and ra.get("png")) else "B"))
                rows.append(row)
                continue
            row.update(sha_a=ra["png_sha256"], sha_b=rb["png_sha256"],
                       level_same=ra.get("level_sha256") == rb.get("level_sha256"))
            ia, ib = load_rgb(da / ra["png"]), load_rgb(db / rb["png"])
            if ia.shape != ib.shape:
                row.update(status="FAIL", reason=f"size {ia.shape} vs {ib.shape}")
                rows.append(row)
                continue
            absd = np.abs(ia - ib)
            h, w = ia.shape[:2]
            masked = []
            for spec in a.mask:
                key, box = spec.split(":", 1)
                if key in ("*", fx, f"{w}x{h}"):
                    x0, y0, x1, y1 = (int(v) for v in box.split(","))
                    absd[y0:y1 + 1, x0:x1 + 1] = 0
                    masked.append([x0, y0, x1, y1])
            if masked:
                row["masked_boxes"] = masked
            mask = absd.max(axis=2) > 0
            n = int(mask.sum())
            row.update(byte_identical=ra["png_sha256"] == rb["png_sha256"], differing_pixels=n,
                       no_human_input=bool(ra.get("no_human_input") and rb.get("no_human_input")),
                       total_pixels=int(mask.size), max_channel_diff=int(absd.max()),
                       status="PASS" if n == 0 else "FAIL")
            if n:
                ys, xs = np.nonzero(mask)
                row["bbox"] = [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())]  # x0,y0,x1,y1 inclusive
                row["mean_channel_diff_in_diff"] = round(float(absd[mask].mean()), 3)
                diff_dir.mkdir(parents=True, exist_ok=True)
                out = diff_dir / f"{fx}--{fa}-vs-{fb}.png"
                diff_image(ia, ib, mask, out)
                row["diff_png"] = str(out)
            rows.append(row)
    env_a = (ma.get("isolated_display"), ma.get("gl_renderer"))
    env_b = (mb.get("isolated_display"), mb.get("gl_renderer"))
    result = dict(generated=now(), a=str(da), b=str(db), binary_a_sha256=ma.get("binary_sha256"),
                  binary_b_sha256=mb.get("binary_sha256"), rows=rows,
                  isolated_a=env_a[0], isolated_b=env_b[0], renderer_a=env_a[1], renderer_b=env_b[1],
                  passed=sum(r["status"] == "PASS" for r in rows), failed=sum(r["status"] != "PASS" for r in rows))
    if a.json:
        Path(a.json).expanduser().write_text(json.dumps(result, indent=2) + "\n")
    w = max([len(r["fixture"]) for r in rows] + [7])
    print(f"{'fixture':<{w}}  frames      result  diff px     max  bbox (x0,y0,x1,y1)")
    for r in rows:
        fr = f"{r['frame_a']}" if r["frame_a"] == r["frame_b"] else f"{r['frame_a']}v{r['frame_b']}"
        print(f"{r['fixture']:<{w}}  {fr:<10}  {r['status']:<6}  {r.get('differing_pixels', '-'):>7}  "
              f"{r.get('max_channel_diff', '-'):>5}  {r.get('bbox', r.get('reason', ''))}")
    dirty = [f"{r['fixture']}/{r['frame_a']}" for r in rows if "no_human_input" in r and not r["no_human_input"]]
    if dirty:
        log(f"WARNING: {len(dirty)} captures were not proven free of desktop key/button input "
            f"(input seen, or the watcher was unavailable): {' '.join(dirty)}")
    if env_a != env_b:
        log(f"WARNING: A and B were captured in different environments (A {env_a}, B {env_b}); "
            f"a difference may be the renderer, not the binary")
    log(f"{result['passed']} PASS, {result['failed']} FAIL"
        + (f"; json {a.json}" if a.json else ""))
    return 0 if result["failed"] == 0 else 1


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("capture", help="render frames from a binary into a directory")
    c.add_argument("--binary", required=True, help="wf_game built with -DDESIGNER_CHEATS=1")
    c.add_argument("--out", required=True, help="output directory (manifest.json is merged)")
    c.add_argument("--fixtures", default="all",
                   help="comma list of names, or chapter / shipped / all (default all)")
    c.add_argument("--frames", default="20", help="comma list of frame numbers (default 20)")
    c.add_argument("--wf-root", default=str(DEFAULT_WF_ROOT),
                   help=f"engine checkout for wflevels/ and engine/libs (default {DEFAULT_WF_ROOT})")
    c.add_argument("--extra", action="append", default=[], help="extra wf_game argument (repeatable)")
    c.add_argument("--env", action="append", default=[], help="KEY=VALUE for the child (repeatable)")
    c.add_argument("--timeout", type=float, default=180.0, help="seconds per capture before kill")
    c.add_argument("--desktop", action="store_true",
                   help="open the game windows on your own display instead of a private off-screen one "
                        "(your keyboard and mouse can then reach them)")
    k = sub.add_parser("compare", help="exact comparison of two capture directories")
    k.add_argument("--a", required=True)
    k.add_argument("--b", required=True)
    k.add_argument("--fixtures", default="", help="restrict to these fixtures")
    k.add_argument("--frame-a", type=int, help="compare this frame of A ...")
    k.add_argument("--frame-b", type=int, help="... against this frame of B")
    k.add_argument("--mask", action="append", default=[], metavar="KEY:x0,y0,x1,y1",
                   help="ignore an inclusive pixel box; KEY is a fixture name, WxH frame size, or * "
                        "(repeatable). Use only for a diagnosis; the E3 gate runs unmasked")
    k.add_argument("--json", help="write machine-readable result here")
    k.add_argument("--diff-dir", help="where amplified diff PNGs go (default beside --json, else B/diffs)")
    sub.add_parser("list", help="print the known fixture names")
    a = p.parse_args()
    if a.cmd == "list":
        print("chapter:", " ".join(CHAPTER))
        print("shipped:", " ".join(SHIPPED))
        return 0
    if a.cmd == "compare" and (a.frame_a is None) != (a.frame_b is None):
        p.error("--frame-a and --frame-b go together")
    return cmd_capture(a) if a.cmd == "capture" else cmd_compare(a)


if __name__ == "__main__":
    sys.exit(main())
