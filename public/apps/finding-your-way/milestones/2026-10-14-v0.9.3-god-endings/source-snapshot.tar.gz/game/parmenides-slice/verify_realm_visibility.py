"""Native render-only realm gates and real movement on a hidden static path."""
import json,time
from verify_god import movement_budget

def run(b,player,value,check,tap,position,out,evidence):
    gates=json.loads((out/'visual-gates.json').read_text())
    def wait(predicate):
        deadline=time.monotonic()+20
        while time.monotonic()<deadline and not predicate():time.sleep(.025)
        return bool(predicate())
    def setm(m,v):b.set_mailbox(m,v,idx=player)
    god=gates['1:4'];temple=gates['206:0']
    for mode in (0,1):
        if value(101)!=mode:tap(2)
        setm(102,4);setm(140,0)
        check(f'camera{mode} God art visible in its realm',wait(lambda:bool(value(god)) and not value(temple)))
        setm(102,0)
        check(f'camera{mode} God art hidden in Temple',wait(lambda:not value(god) and bool(value(temple))))
        # Wrong realm intentionally: rendering gate is false throughout actual
        # input ascent, while the underlying static triangles must support it.
        setm(102,3);setm(140,0);setm(114,.25);position(400,-7)
        check(f'camera{mode} hidden God path before walking',wait(lambda:not value(god)))
        b.inject_input('joystick1_raw',2048,2000);budget=movement_budget(value,22);samples=[];last=None
        while budget() and (value(3010) or -7)<29:
            t=value(110)
            if t!=last:
                samples.append(dict(clock=t,x=value(3009),y=value(3010),z=value(3011),visible=value(god),realm=value(102)));last=t
            time.sleep(.025)
        b.inject_input('joystick1_raw',0,1);b.wait_for_mailbox(player,111,0,timeout=3);time.sleep(.2)
        check(f'camera{mode} actual hidden-path ascent reaches upper landing',value(3010)>=29 and value(3011)>4.9)
        check(f'camera{mode} entire hidden ascent retains realm and suppressed render gate',bool(samples) and all(r['visible']==0 and r['realm']==3 for r in samples))
        (evidence/f'hidden-path-view-{mode}.json').write_text(json.dumps(samples,indent=2)+'\n')
        setm(102,4)
        check(f'camera{mode} visible path restores without transform changes',wait(lambda:bool(value(god))))
        setm(140,1)
        check(f'camera{mode} inherited modal suppresses world',wait(lambda:not value(god)))
        setm(140,0)
    (evidence/'realm-visibility-audit.json').write_text(json.dumps(dict(build=json.loads((out/'build-receipt.json').read_text()),passed=True,scope='Both native views: realm gates and actual input ascent on hidden God static triangles; inherited modal composition retained.'),indent=2)+'\n')
