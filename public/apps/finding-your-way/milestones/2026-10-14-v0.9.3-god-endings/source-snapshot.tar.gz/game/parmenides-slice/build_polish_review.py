"""Build F's full scene/history TV tours with only diagnostic Player Forth changed."""
import argparse
import json
from pathlib import Path

import build_review_fixtures as fixtures


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--build-dir', type=Path, required=True)
    parser.add_argument('--evidence', type=Path, required=True)
    parser.add_argument('--group', type=int, choices=range(5), required=True)
    parser.add_argument('--mode', type=int, choices=(0, 1), required=True)
    args = parser.parse_args()
    fixtures.BASE = args.build_dir.resolve()
    production = json.loads((fixtures.BASE / 'build-receipt.json').read_text())
    assert production['artStage'] == 'polish'
    # Independent fixtures start normal motion and restart E's visual clocks.
    fixtures.SCENES = [(name, realm, x, y, key, {108: 0, 488: 0, 489: 0, **history})
                       for name, realm, x, y, key, history in fixtures.SCENES]
    fixtures.make(args.group, args.mode)
    folder = fixtures.BASE / 'review-fixtures' / f'group-{args.group}-view-{args.mode}'
    path = folder / 'review-receipt.json'
    receipt = json.loads(path.read_text())
    receipt['phases'].insert(0, dict(scene='startup-intro', realm=0, camera=0,
        phase='initial-source-sheet', source_group='intro', start=0, end=5, optional=True))
    receipt['scope'] = ('F scene and changed-history rendering with scripted selection and native movement; '
                        'complete source and branch coverage is proved separately by native regression.')
    path.write_text(json.dumps(receipt, indent=2) + '\n')
    recipes = args.evidence.resolve() / 'recipes'
    recipes.mkdir(parents=True, exist_ok=True)
    (recipes / f'group-{args.group}-view-{args.mode}.json').write_text(json.dumps(dict(
        device='chromecast-test-01', app='parmenides', workflow='record', apk=receipt['apk'],
        warmup=0, runs=1, duration=65, trace='idle'), indent=2) + '\n')


if __name__ == '__main__':
    main()
