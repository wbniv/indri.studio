"""Actual native D artwork, source visibility and quiet-motion review."""
import json,time
from art_god import SIGNS

def run(b,player,value,check,tap,position,read_pages,groups,ids,out,evidence,capture):
    original_position=position
    def position(x,y,z=None,heading=.25):
        b.set_mailbox(114,heading,idx=player);original_position(x,y,z)
    def setm(m,v):b.set_mailbox(m,v,idx=player)
    actors=['GodCanopy0','GodCanopy13','aether_rings','AetherShell1','AetherShell2']
    for name in actors:
        for m in (3012,3013,3014):b.watch(ids[name],m)
    def av(name,m=3014):return b.mailbox_values.get((ids[name],m))
    def wait(label,predicate):
        deadline=time.monotonic()+25
        while time.monotonic()<deadline and not predicate():time.sleep(.025)
        if not predicate():print(dict(label=label,flags={m:value(m) for m in (102,140,190,194,195,201,202,212)}),flush=True)
        check(label,bool(predicate()))
    def sample(duration=.6):
        start=value(110);deadline=time.monotonic()+25;rows=[];previous=None
        while time.monotonic()<deadline:
            t=value(110)
            if t is not None and t!=previous:
                rows.append(dict(clock=t,**{n:av(n) for n in actors}));previous=t
                if t>=start+duration:break
            time.sleep(.02)
        check('D native clock advances',bool(rows) and rows[-1]['clock']>=start+duration)
        return rows
    samples=[]
    for mode in (0,1):
        if value(101)!=mode:tap(2)
        for m in (190,191,192,193,194,195,196):setm(m,0)
        setm(108,0);setm(102,4);setm(140,0)
        position(400,-4);capture(f'god-entry-view-{mode}')
        position(400,-2);capture(f'god-young-view-{mode}')
        position(400,1);tap();check('young guide keeps exact source account',value(140)==groups['young_man'][0])
        tap(16384);check('young cancellation preserves incompletion',value(190)==0)
        tap();read_pages('D young guide camera='+str(mode),groups['young_man']);wait('young completion retains both guides until question',lambda:value(190)==1 and bool(value(201)) and bool(value(202)))
        position(397,3);capture(f'god-poster-view-{mode}')
        position(397,6);tap();read_pages('D original poster inspection camera='+str(mode),groups['poster']);check('poster does not choose',value(192)==1 and value(195)==0)
        position(400,10);capture(f'god-holy-view-{mode}')
        position(400,13);tap();read_pages('D holy guide camera='+str(mode),groups['holy_man'])
        position(403,15);capture(f'god-icon-view-{mode}')
        position(403,18);tap();read_pages('D original icon inspection camera='+str(mode),groups['icon']);check('icon does not choose',value(193)==1 and value(195)==0)
        position(400,24);capture(f'god-upper-ascent-view-{mode}')
        s=sample(2);samples+=s
        check('forest canopies move asynchronously',all(max(r[n] for r in s)-min(r[n] for r in s)>.00001 for n in actors[:2]))
        position(397,24);tap();read_pages('D exact question camera='+str(mode),groups['god_question'])
        wait('question hides both completed guides without choosing',lambda:value(194)==1 and value(201)==0 and value(202)==0 and value(195)==0)
        position(400,29);capture(f'god-summit-view-{mode}')
        setm(108,1);wait('reduced canopy updates reach composed pose',lambda:all(av(n) is not None and abs(av(n))<.00001 for n in actors[:2]));s=sample(.5);samples+=s
        check('reduced canopies remain still',all(max(r[n] for r in s)-min(r[n] for r in s)<.00001 for n in actors[:2]))
        setm(102,0);setm(195,1);setm(196,1);setm(197,1);setm(188,1);position(0,-5,heading=.75)
        capture(f'final-thresholds-view-{mode}');position(0,5);capture(f'aether-still-view-{mode}')
        wait('affirmed source history reveals aether',lambda:bool(value(212)))
        s=sample(.5);samples+=s
        check('reduced aether remains composed',all(max(r[n] for r in s)-min(r[n] for r in s)<.00001 for n in actors[2:]))
        setm(108,0);s=sample(.7);samples+=s
        check('all three native aether shells rotate',all(max(r[n] for r in s)-min(r[n] for r in s)>.001 for n in actors[2:]))
        capture(f'aether-moving-view-{mode}')
        setm(140,groups['final_wait'][0]);wait('modal aether updates reach composed pose',lambda:all(av(n) is not None and abs(av(n))<.00001 for n in actors[2:]))
        s=sample(.5);samples+=s
        check('modal reading suspends aether at composed orientation',all(max(r[n] for r in s)-min(r[n] for r in s)<.00001 for n in actors[2:]))
        check('modal reading never mutates final completion',value(195)==1 and value(197)==1 and value(188)==1)
        setm(140,0);setm(196,-1);time.sleep(.2);wait('denied God history hides all aether shells through source gate',lambda:value(212)==0)
    report=dict(build=json.loads((out/'build-receipt.json').read_text()),passed=True,scope='Both native views; original God guide/inspection art, exact source sheets, source-neutral completion, canopy and aether normal/reduced/modal motion; final threshold views',samples=samples)
    (evidence/'god-art-audit.json').write_text(json.dumps(report,indent=2)+'\n')
