"""Compare target-compiler TU stack reservations; final LTO may differ."""
from pathlib import Path
import subprocess,shlex,re,json
here=Path(__file__).resolve().parent
root=here.parents[2]
engine=Path('/home/will/WorldFoundry-wbniv');build=here.parent/'build/web-v0.8/cmake'
out=build.parent/'stack-reports';out.mkdir(exist_ok=True)
flags=(build/'CMakeFiles/wfengine.dir/flags.make').read_text()
defs=next(line.split(' = ',1)[1] for line in flags.splitlines() if line.startswith('CXX_DEFINES = '))
includes=(build/'CMakeFiles/wfengine.dir/includes_CXX.rsp').read_text()
compiler=here.parent/'build/web-sdk/upstream/emscripten/em++'
args=[str(compiler),*shlex.split(defs),*shlex.split(includes),'-std=c++17','-fpermissive','-w','-Wno-register','-O3','-fno-rtti','-fno-exceptions','-S']
baseline='6459b76cbae73ef3141a55b8ca3134c84351f34c'
files=['gfx/glpipeline/backend_modern.cc','game/bitmap_presenter.cc','game/fps_overlay.cc','game/runtime_property_ui.cc','game/runtime_settings_ui.cc','game/plant_ui.cc']
report={'baseline':baseline,'engine':subprocess.check_output(['git','-C',str(engine),'rev-parse','HEAD'],text=True).strip(),'method':'Emscripten 6.0.0 -O3 assembly of each translation unit, without final thin LTO. Baseline source uses current consumer headers for this reservation comparison; separately recorded old/new object sizes. Only selected text symbols reported. Values are reservations, not measured whole-frame peaks.','consumers':{}}
for file in files:
 result={}
 for version in ['before','after']:
  source=out/(version+'-'+Path(file).name)
  source.write_bytes(subprocess.check_output(['git','-C',str(engine),'show',baseline+':wfsource/source/'+file]) if version=='before' else (engine/'wfsource/source'/file).read_bytes())
  assembly=source.with_suffix('.s');subprocess.run([*args,str(source),'-o',str(assembly)],check=True)
  frames={}
  for match in re.finditer(r'^([^\s:]+):[^\n]*\n(.*?)(?=^[ \t]*# -- End function)',assembly.read_text(),re.M|re.S):
   symbol,body=match.groups()
   if not any(word in symbol for word in ['DrawGlyphs','Presenter','Overlay5Build','propertyui5build','propertyui9buildHost','planted7buildUI']):continue
   reserve=re.search(r'global.get\s+__stack_pointer\s+i32.const\s+(\d+)\s+i32.sub',body)
   frames[symbol]=int(reserve[1]) if reserve else 0
  result[version]=frames
 report['consumers'][file]=result
path=root/'docs/diagnostics/browser-player-2026-10-10/text-stack-reservations.json'
path.write_text(json.dumps(report,indent=2)+'\n')
for file,versions in report['consumers'].items():
 print(file)
 for v,frames in versions.items():print(' ',v,list(frames.values()))
