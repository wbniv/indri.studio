# Browser chapter build

This packages the frozen Android chapter payload for the World Foundry WASM/WebGL2 runtime. The browser game runs at `/apps/finding-your-way/play/`. Publishing a new game release includes rebuilding and verifying this page against the same release payload.

The engine source stays unchanged. `chapter.cmake` is a chapter-owned `CMAKE_PROJECT_INCLUDE` configuration hook: it selects this chapter's preload data and shell instead of the generic demo bundle. No copied/patched engine source is used.

Build with the pinned Emscripten 6.0.0 SDK:

```sh
python3 game/parmenides-slice/web/build.py build --sdk game/parmenides-slice/build/web-sdk --checks --jobs 2
```

The command above reproduces v0.8. For v0.9, add `--release 0.9` and pass a clean engine checkout at the v0.9 engine commit with `--engine`. The resulting bundle has a `v0.9-` content ID and records the v0.9 APK hash, level hash, engine commit and launch arguments. The site play page displays the version from the verified bundle.

`--sdk` is optional: `web_deps.py` finds the pinned SDK in this worktree, the main checkout (so a fresh linked worktree reuses the existing 1.6 GiB install instead of downloading), `$FYW_WEB_SDK` or the engine's `engine/vendor/emsdk-6.0.0`, and rejects any other version. The build never downloads. With no SDK, `task web3d:sdk:install` builds one offline from the checksum-verified archive cache (`task web3d:sdk:fetch` fills it; 301.5 MB). Pins and checksums: `web-deps.json`; design: [web-build dependency mirror](../../../docs/plans/2026-10-10-web-build-dependency-mirror.md).

The engine checkout must be clean and at the commit pinned for the chosen release. Assets are extracted from that release's frozen APK and checked against its receipt and source snapshot. Generated compiler files, SDK and bundles live under the ignored chapter `build/` directory.

Each frozen bundle contains a SHA-256 receipt. Verify or stage it explicitly:

```sh
python3 game/parmenides-slice/web/build.py verify --bundle <bundle-directory>
python3 game/parmenides-slice/web/build.py stage --bundle <bundle-directory> --site ../indri.studio
```

Staging copies only verified player files into a content-addressed public directory. Staging selects the verified bundle in `public/apps/finding-your-way/play/manifest.json` with its `bundleId`. The Astro player route verifies all file hashes at build time.

The runtime starts only when the visitor chooses Play. A same-origin iframe contains the engine's window-wide input handlers. The chapter shell handles touch press/release/cancellation, keyboard focus release, fullscreen on desktop/phone Play, menu-first Escape, loading failure and confirmed restart. A static temple preview loads before Play, while game runtime downloads remain gesture-gated. The compact strip puts the joystick on the left and Select at the far right; Menu contains help, reduced motion and restart. The phone controls are experimental until real-device acceptance is recorded. A WebGL context loss requires restarting the chapter; no saved-progress restoration is promised.

AI-Assisted: Codex CLI 0.162.0; gpt-6.1-sol; reasoning effort medium; verified session `01a11e9e-a386-7462-b3f4-86364e106ee0`.

For production verification, `verify-site.mjs` exercises app navigation, the prominent play button, menu icons, iframe fullscreen and reader sizing (set `FYW_BROWSER=firefox` with Xvfb for Firefox). `verify-live.py --bundle <bundle-directory> --out <receipt.json> --release <site-tag>` verifies the deployed manifest, assets, cache/framing headers and retained APK links. It accounts explicitly for the Worker HTML nonce and Cloudflare Insights injection before comparing the frame source hash.

The reusable shell now lives in [browser-game-player](https://github.com/wbniv/browser-game-player). The chapter builder above remains the owner of the frozen engine/APK provenance. Its legacy shell files remain available for reproducing those original receipts. The three website previews use the shared component and its verified bundles instead.

In `../indri.studio`, `npm run sync-browser-player` freezes the installed component around the accepted source bundle selected in `browser-player.json`. Updating that source bundle, engine pin or chapter arguments is an explicit release change; Indri checks the shared bundle's runtime bytes and launch arguments against the original chapter receipt, including the 64 KiB stack. No compiler SDK is needed to refresh the component shell. A shared-component update does not replace the Android or text downloads.
