"""Level-owned rigid-part proof: no engine patch or unverified skinning.

Player gait responds to actual native speed; meaningful locomotion is retained
with reduced motion. Goddess wing settling freezes with reduced motion/modal.
"""
def emit_proof(emit, actor, temple_love=False):
    emit('\\ v0.6 original rigid-part motion: +X facing; native turns.\n')
    for side,suffix in ((-1,'L'),(1,'R')):
        for arm in (False,True):
            idx=actor('Player'+('Arm' if arm else 'Leg')+suffix)
            y=side*(.267 if arm else .112);z=1.25 if arm else .85
            for axis,term in (('X',f'114 read-mailbox fy-sin {y} * -'),
                              ('Y',f'114 read-mailbox fy-cos {y} * +'),('Z',f'{z} +')):
                emit(f'INDEXOF_{axis}_POS read-mailbox {term} INDEXOF_{axis}_POS {idx} write-actor-mailbox\n')
            emit(f'0 INDEXOF_ROTATION_A {idx} write-actor-mailbox\n')
            # Speed gating prevents idle feet from cycling and checks both axes.
            emit('INDEXOF_XSPEED read-mailbox dup * INDEXOF_YSPEED read-mailbox dup * + 0.01 > '
                 '140 read-mailbox 0 = & 102 read-mailbox 8 <> & if '
                 f'110 read-mailbox 0.9 * fy-sin {side*(.022 if arm else -.032)} * else 0 then '
                 f'INDEXOF_ROTATION_B {idx} write-actor-mailbox\n')
            # This pinned runtime commits its shared Euler scratch state on C.
            # Always write A/B/C together for each actor, with C last.
            emit(f'114 read-mailbox INDEXOF_ROTATION_C {idx} write-actor-mailbox\n')
    for side,suffix in ((-1,'L'),(1,'R')):
        idx=actor('GoddessWing'+suffix)
        emit(f'0 INDEXOF_ROTATION_A {idx} write-actor-mailbox\n')
        emit(f'108 read-mailbox 0 = 140 read-mailbox 0 = & if '
             f'110 read-mailbox 0.10 * {0.13 if side<0 else 0.31} + fy-sin {side*.006} * '
             f'else 0 then INDEXOF_ROTATION_B {idx} write-actor-mailbox\n')
        emit(f'-0.25 INDEXOF_ROTATION_C {idx} write-actor-mailbox\n')
    # First Love's departure opens the shop door; replay restores it. This
    # decorative response adds no interaction or progression prerequisite.
    idx=actor('proof_love_door')
    if temple_love:
        emit_temple_love(emit,actor)
        return
    emit('140 read-mailbox 0 = if 103 read-mailbox 0 <> if -0.22 else 0 then '
         '117 read-mailbox - 115 read-mailbox 0.35 * dup negate >r min r> max '
         '117 read-mailbox + 117 write-mailbox then\n')
    emit(f'0 INDEXOF_ROTATION_A {idx} write-actor-mailbox 0 INDEXOF_ROTATION_B {idx} write-actor-mailbox '
         f'117 read-mailbox INDEXOF_ROTATION_C {idx} write-actor-mailbox\n')

MOTION=[
    dict(name='player rigid-part gait',actors=['PlayerArmL','PlayerArmR','PlayerLegL','PlayerLegR'],
         trigger='native horizontal speed squared > 0.01; no modal dialogue/patient view',
         representation='level Forth actor position and rotation; editable pivot geometry',
         timingHz=.9,amplitudeTurns=dict(arm=.022,leg=.032),loop=True,
         reduced='meaningful locomotion retained; idle neutral',measuredCost='pending'),
    dict(name='goddess wing settling',actors=['GoddessWingL','GoddessWingR'],
         trigger='normal motion and no modal dialogue',representation='level Forth rigid transform',
         timingHz=.10,amplitudeTurns=.006,phaseTurns=[.13,.31],loop=True,
         reduced='neutral wing pose',measuredCost='pending'),
    dict(name='Love departure door',actors=['proof_love_door'],trigger='First Love encounter completion/replay reset; paused during modal dialogue',
         representation='level Forth hinge rotation',loop=False,amplitudeTurns=.22,timingSeconds=.63,
         reduced='short meaningful departure response retained',measuredCost='pending'),
]


TEMPLE_LOVE_MOTION=[
    dict(name='Love arrival dispersal',actors=[f'LoveCrowd{i}' for i in range(4)],
         trigger='enter Love; quiet while a modal sheet is open',loop=False,timingSeconds=3.2,
         representation='level rigid translation toward four distinct street doors; staggered starts',
         reduced='crowd immediately absent, doors closed',measuredCost='phone pending'),
    dict(name='First Love withdrawal and door closure',actors=['FirstLove','proof_love_door'],
         trigger='complete First Love account; replay restores pose',loop=False,timingSeconds=1.2,
         representation='level position interpolation into actual west doorway; door opens then closes',
         reduced='immediate final absent speaker/closed door; progression never waits',measuredCost='phone pending'),
    dict(name='Starlet withdrawal',actors=['Starlet','biology_book'],
         trigger='complete starlet account; replay restores seated pose',loop=False,timingSeconds=1.4,
         representation='level rigid withdrawal toward east doorway; book follows exact actor transform',
         reduced='immediate final absent speaker/book',measuredCost='phone pending'),
    dict(name='Readable street and Temple signs',actors=['love_sign','reason_sign','truth_sign','being_sign','notbeing_sign','back_sign'],
         trigger='player heading',loop=False,representation='eye-height billboard with unchanged sign pixels',
         reduced='same wayfinding response',measuredCost='phone pending'),
]

def emit_temple_love(emit,actor):
    # Mailboxes 133/134 store bounded departure progress, 135/136 arrival state.
    # The canonical complete/choice/visibility flags keep their original meaning.
    for flag,progress,duration in ((103,133,1.2),(104,134,1.4)):
        emit(f'{flag} read-mailbox 0 = if 0 {progress} write-mailbox else '
             f'108 read-mailbox 0 <> if 1 {progress} write-mailbox else '
             f'140 read-mailbox 0 = if {progress} read-mailbox 115 read-mailbox {duration} / + 1 min '
             f'{progress} write-mailbox then then then\n')
    for name,progress,logical,x,y,dx,dy in (
        ('FirstLove',133,480,96,2,-4.35,3),('Starlet',134,481,104,3,4.35,2),
        ('biology_book',134,481,104.10,3.10,4.35,2)):
        idx=actor(name)
        emit(f'{progress} read-mailbox 1 < {logical} write-mailbox\n')
        emit(f'{x} {progress} read-mailbox {dx} * + INDEXOF_X_POS {idx} write-actor-mailbox\n')
        emit(f'{y} {progress} read-mailbox {dy} * + INDEXOF_Y_POS {idx} write-actor-mailbox\n')
    # First Love leaves through the recess before closing the door behind them.
    idx=actor('proof_love_door')
    emit('133 read-mailbox 0 > 133 read-mailbox 1 < & if -0.22 else 0 then 117 write-mailbox\n')
    emit(f'0 INDEXOF_ROTATION_A {idx} write-actor-mailbox 0 INDEXOF_ROTATION_B {idx} write-actor-mailbox '
         f'117 read-mailbox INDEXOF_ROTATION_C {idx} write-actor-mailbox\n')
    idx=actor('love_door_1_2')
    emit(f'0 INDEXOF_ROTATION_A {idx} write-actor-mailbox 0 INDEXOF_ROTATION_B {idx} write-actor-mailbox '
         f'134 read-mailbox 0 > 134 read-mailbox 1 < & if 0.18 else 0 then INDEXOF_ROTATION_C {idx} write-actor-mailbox\n')
    emit('102 read-mailbox 1 = if 140 read-mailbox 0 = if '
         '135 read-mailbox 115 read-mailbox + 4 min 135 write-mailbox then '
         'else 0 135 write-mailbox then\n')
    from art_temple_love import CROWD
    for x,y,i in CROWD:
        idx=actor(f'LoveCrowd{i}');delay=i*.18;end=3.2+delay
        tx=91.65 if i%2==0 else 108.35;ty=(-7,-1,11,11)[i]
        emit(f'102 read-mailbox 1 = 108 read-mailbox 0 = & 135 read-mailbox {end} < & {482+i} write-mailbox\n')
        for axis,start,delta in (('X',x,tx-x),('Y',y,ty-y)):
            emit(f'{start} 135 read-mailbox {delay} - 0 max 3.2 / 1 min {delta} * + '
                 f'INDEXOF_{axis}_POS {idx} write-actor-mailbox\n')
        door=actor(f'love_door_{-1 if i%2==0 else 1}_{3 if i==2 else i}')
        emit(f'0 INDEXOF_ROTATION_A {door} write-actor-mailbox 0 INDEXOF_ROTATION_B {door} write-actor-mailbox '
             f'102 read-mailbox 1 = 108 read-mailbox 0 = & 135 read-mailbox {end} < & '
             f'135 read-mailbox {delay} > & if {-.18 if i%2==0 else .18} else 0 then '
             f'INDEXOF_ROTATION_C {door} write-actor-mailbox\n')
    for name in ('love_sign','reason_sign','truth_sign','being_sign','notbeing_sign','back_sign'):
        idx=actor(name)
        emit(f'0 INDEXOF_ROTATION_A {idx} write-actor-mailbox 0 INDEXOF_ROTATION_B {idx} write-actor-mailbox '
             f'114 read-mailbox 0.25 - INDEXOF_ROTATION_C {idx} write-actor-mailbox\n')
