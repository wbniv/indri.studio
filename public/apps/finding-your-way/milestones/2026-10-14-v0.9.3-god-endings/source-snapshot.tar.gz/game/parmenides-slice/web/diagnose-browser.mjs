import { chromium } from '/home/will/finding-your-way/node_modules/@playwright/test/index.mjs';
import {mkdirSync,writeFileSync,appendFileSync} from 'node:fs';
const [target,out]=process.argv.slice(2);mkdirSync(out,{recursive:true});
const browser=await chromium.launch({executablePath:'/usr/bin/google-chrome',headless:true,args:['--no-sandbox','--enable-unsafe-swiftshader']});
try {
 const page=await browser.newPage({viewport:{width:1280,height:900}});
 page.on('console',m=>appendFileSync(out+'/console.jsonl',JSON.stringify({type:m.type(),text:m.text()})+'\n'));
 page.on('pageerror',e=>appendFileSync(out+'/exceptions.jsonl',JSON.stringify({message:e.message,stack:e.stack})+'\n'));
 await page.goto(target);await page.locator('#play').click();
 await page.waitForFunction(()=>document.querySelector('#overlay').hidden || document.querySelector('#play').textContent==='Retry',null,{timeout:60000});
 async function snapshot(step){const state=await page.evaluate(()=>({active:document.activeElement?.id,overlay:document.querySelector('#overlay').hidden,status:document.querySelector('#status').textContent,focusDisabled:document.querySelector('#focus').disabled,pauseType:typeof Module.pauseMainLoop,resumeType:typeof Module.resumeMainLoop}));appendFileSync(out+'/states.jsonl',JSON.stringify({step,...state})+'\n');console.log(step,state);}
 await snapshot('started');await page.waitForTimeout(2000);await snapshot('after 2 seconds');
 await page.keyboard.press('Escape');await snapshot('after real Escape');
 await page.evaluate(()=>window.dispatchEvent(new KeyboardEvent('keydown',{code:'Escape',key:'Escape',bubbles:true,cancelable:true})));await snapshot('after synthetic Escape');
 await page.waitForTimeout(6000);await snapshot('after 6-second pause');
 await page.locator('#focus').click({force:true});await page.waitForTimeout(1000);await snapshot('after resume');
 await page.screenshot({path:out+'/after-resume.png'});
 writeFileSync(out+'/done.json',JSON.stringify({target,completed:true})+'\n');
}finally{await browser.close();}
