"""Certify the exact declared E artwork scope, retaining later polish/phone gates."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--build-dir',type=Path,required=True)
    p.add_argument('--evidence',type=Path,required=True)
    p.add_argument('--generator-source',type=Path);a=p.parse_args()
    out=a.build_dir.resolve();e=a.evidence.resolve();read=lambda path:json.loads(path.read_text())
    b=read(out/'build-receipt.json');sha=b['sha256'];desktop=b['engineProvenance']['desktopExecutableSha256']
    assert b['artStage']=='endings-surgery' and b['version']=='0.6-endings-surgery.1' and b['versionCode']==64
    assert digest(Path(b['apk']))==sha
    with zipfile.ZipFile(b['apk']) as apk:
        assert hashlib.sha256(apk.read('assets/cd.iff')).hexdigest()==b['levelSha256']
        for name,expected in b['nativeLibraries'].items():assert hashlib.sha256(apk.read(name)).hexdigest()==expected
    assert read(out/'art-manifest.json')==b['art']
    sources=a.generator_source.resolve() if a.generator_source else Path(__file__).resolve().parent
    for name,expected in b['art']['sources'].items():assert digest(sources/name)==expected,name
    assert digest(Path(b['engineProvenance']['desktopRebuild']['executable']))==desktop
    def matching(name):
        report=read(e/name);assert report['build']['sha256']==sha,name
        assert report['build']['levelSha256']==b['levelSha256'],name
        return report
    counts={}
    for name,expected in (('asset-audit.json',2026),('text-audit.json',358),('endings-asset-audit.json',896)):
        report=matching(name);assert len(report['results'])==expected and all(r['passed'] for r in report['results']),name
        counts[name]=expected
    mesh=matching('mesh-audit.json');uv=matching('art-uv-audit.json')
    assert mesh['passed'] and mesh['native_winding_matches'] and not mesh['inward_components'] and not mesh['inconsistent_edges'] and not mesh['mirrored_objects']
    assert uv['passed'] and all(r['passed'] for r in uv['models'])
    assert len(mesh['objects'])==426 and len(uv['models'])==172
    counts.update(mesh_objects=426,painted_models=172)
    cards=set();native_checks=0
    for folder,expected in (('desktop-endings',1629),('final-native',331)):
        state=read(e/folder/'run-state.json');assert state['status']=='completed' and state['apk_sha256']==sha and state['desktop_sha256']==desktop
        assert state['checks']==expected
        results=read(e/folder/'results.json');assert len(results)==expected and all(r['passed'] for r in results)
        assert read(e/folder/'build-receipt.json')['sha256']==sha
        for transcript in read(e/folder/'transcripts.json'):cards.update(int(c) for c in transcript['cards'])
        native_checks+=expected
    routes=read(e/'desktop-endings/results.json')
    assert sum('terminal completion matches chosen route' in r['check'] for r in routes)==66
    art=matching('final-native/endings-art-audit.json');assert art['passed'] and len(art['phases'])==42 and len(art['framing'])==16
    assert {row['camera'] for row in art['phases']}=={0,1}
    for pose in art['framing']:
        assert len(pose['features'])==12
        for feature in pose['features']:
            assert feature['minimum_depth']>1
            if feature['feature'] in ('masked-face','cap'):assert min(feature['margins'])>.025
    captures=matching('final-native/capture-manifest.json');assert len(captures['shots'])==42
    assert digest(e/'final-native/art-proof.mp4')==captures['movie_sha256']
    for row in captures['shots']:assert digest(e/'final-native'/row['file'])==row['sha256']
    manual=read(e/'native-visual-review.json');assert manual['passed'] and manual['apk_sha256']==sha
    for row in manual['captures']:assert digest(e/row['file'])==row['sha256']
    blender=matching('blender/manifest.json');assert len(blender['views'])==19
    gallery=matching('review-manifest.json');assert len(gallery['images'])==61
    for row in gallery['images']:assert digest(e/row['file'])==row['sha256']
    def device(folder,expected):
        receipt=read(folder/'receipt.json');assert receipt['result']=='completed' and receipt['cleanup_verified']
        assert receipt['job']['request']['device']=='chromecast-test-01' and receipt['job']['request']['apk']==expected+'.apk'
        return receipt
    tours=[]
    for group,mode in ((0,0),(0,1),(1,0),(1,1)):
        folder=e/f'cast1-group-{group}-view-{mode}';fixture=read(out/f'review-fixtures/group-{group}-view-{mode}/review-receipt.json')
        assert fixture['diagnostic_only'] and fixture['production_apk_sha256']==sha
        assert fixture['nativeLibraries']==b['nativeLibraries'] and digest(Path(fixture['apk']))==fixture['sha256']
        receipt=device(folder,fixture['sha256']);audit=read(folder/'sheet-audit.json')
        assert audit['passed'] and audit['device_job']==receipt['job']['id'] and audit['production_apk_sha256']==sha and audit['diagnostic_apk_sha256']==fixture['sha256']
        required={199,200,204,208} if group==0 else {201,202,203,204,208}
        assert set(audit['expected_cards'])==required and required<=set(audit['seen_cards'])<=required|{1} and set(audit['optional_cards'])=={1}
        assert digest(folder/'capture.mp4')==audit['video_sha256'] and audit['results'] and all(r['passed'] for r in audit['results'])
        for row in audit['results']:
            if row.get('file'):assert digest(folder/row['file'])==row['sha256']
        world=read(folder/'visual-review.json');assert world['passed'] and world['production_apk_sha256']==sha and world['device_job']==receipt['job']['id']
        for row in world['captures']:assert digest(folder/row['file'])==row['sha256']
        tours.append(dict(group=group,camera=mode,job=receipt['job']['id'],checked_sheet_frames=audit['sheet_frames'],video_sha256=audit['video_sha256']))
    receipt=device(e/'cast1-review',sha);visual=read(e/'cast1-review/visual-review.json')
    assert visual['passed'] and visual['apk_sha256']==sha and visual['device_job']==receipt['job']['id']
    for row in visual['captures']:assert digest(e/'cast1-review'/row['file'])==row['sha256']
    summary=dict(passed=True,iteration='E',art_stage='endings-surgery',apk_sha256=sha,level_sha256=b['levelSha256'],
        scope='Original ending/clinical artwork, paused visible effects, quiet reduced motion, both-view masked patient composition and complete four-account/66-edge native ending regression; four identity-bound TV rendering tours and exact production lifecycle.',
        runtime_checks=native_checks,native_art_checks=331,native_ending_checks=1629,eligible_edges=66,static_checks=counts,
        source_cards_static=208,native_distinct_cards=len(cards),native_cards=sorted(cards),gallery_images=61,
        fbo_shots=42,patient_poses=16,full_face_cap_margin=.025,tours=tours,production_device_job=receipt['job']['id'],
        final_endings_regression_complete=True,current_phone_verified=False,final_all_realm_regression_complete=False,
        generator_source=str(sources),experimental_realm_candidate_adopted=False,performance_optimization_deferred=True,
        next_milestones=dict(F='v0.7 polish',optimization='v0.8'),
        known_visual_issues=['Inherited distant God artwork can appear during the Being full-turn fixture; no realm culling experiment adopted.',
            'The combined passage full motif is visible in the ordinary follow view; its top can clip at close/first-person diagnostic approaches.',
            'Surgeon 3 gloves partly enter the bottom edge while all masked faces/caps retain strict margins; full hands were not the established patient contract.',
            'Earlier low Chromecast speed remains a recorded limitation; E does not claim new performance measurements or optimization.',
            'General camera collision remains deferred; unchanged support geometry does not certify every refined statplat fixture collider.'],
        pending_gates=['F/v0.7 polish and final all-realm regression with matching 44-chapter movie/103-shot catalog.',
            'Current-build Pixel interaction/readability acceptance; optimization and sustained measurement in v0.8.',
            'Max feedback after A–F; no intermediate Will style approval or implied delivery.'])
    (e/'verification-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print('E declared scope passed:',sha,native_checks,'native checks; 61 images;',sum(t['checked_sheet_frames'] for t in tours),'TV source frames')

if __name__=='__main__':main()
