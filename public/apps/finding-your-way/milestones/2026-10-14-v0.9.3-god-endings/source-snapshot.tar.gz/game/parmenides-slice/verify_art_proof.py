"""Freeze verification identities for an iteration-A review candidate.

Phone acceptance and final author feedback are explicitly pending; this cannot qualify final v0.6.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import zipfile

p=argparse.ArgumentParser();p.add_argument('--build-dir',type=Path,required=True);p.add_argument('--evidence',type=Path,required=True)
a=p.parse_args();out=a.build_dir.resolve();e=a.evidence.resolve()
read=lambda p:json.loads(p.read_text());digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
build=read(out/'build-receipt.json');assert build['artStage'] in ('proof','temple-love')
iteration='B' if build['artStage']=='temple-love' else 'A'
assert digest(Path(build['apk']))==build['sha256']
with zipfile.ZipFile(build['apk']) as apk:
    assert hashlib.sha256(apk.read('assets/cd.iff')).hexdigest()==build['levelSha256']
    for name,sha in build['nativeLibraries'].items():assert hashlib.sha256(apk.read(name)).hexdigest()==sha
def current(r):assert r['build']['sha256']==build['sha256'] and r['build']['levelSha256']==build['levelSha256']
for name in ('asset-audit','text-audit'):
    r=read(e/(name+'.json'));current(r);assert r['results'] and all(x['passed'] for x in r['results'])
for name in ('winding-audit','uv-audit','panel-render-audit','panel-transition-audit','rectification-audit'):
    r=read(e/(name+'.json'));current(r);assert r['passed']
assert len(read(e/'panel-render-audit.json')['results'])==420
checks=[];transcripts=[]
for name in ('realms','god','endings','final-native','supplemental'):
    current(dict(build=read(e/name/'build-receipt.json')))
    if iteration=='B':
        state=read(e/name/'run-state.json')
        assert state['status']=='completed' and state['apk_sha256']==build['sha256']
    rows=read(e/name/'results.json');assert rows and all(r['passed'] for r in rows);checks.extend(rows)
    transcripts.extend(read(e/name/'transcripts.json'))
seen={i for t in transcripts for i in t['cards']};assert seen==set(range(1,209))
edges=set()
for t in transcripts:
    m=re.match(r'Ending (9[a-p]) → (10[abc]) camera=([01]): complete (?:ending source|Both account)$',t['interaction'])
    if m:edges.add(m.groups())
assert len(edges)==66
for mode in (0,1):
    folder=e/f'cast1-tour-{mode}';r=read(folder/'sheet-audit.json');assert r['passed'] and r['production_apk_sha256']==build['sha256']
    receipt=read(folder/'receipt.json');assert receipt['result']=='completed' and receipt['cleanup_verified']
    assert digest(folder/'capture.mp4')==r['video_sha256'] and r['device_job']==receipt['job']['id']
folder=e/'cast1-review';r=read(folder/'visual-review.json');receipt=read(folder/'receipt.json')
assert r['passed'] and r['apk_sha256']==build['sha256'] and r['device_job']==receipt['job']['id']
assert receipt['result']=='completed' and receipt['cleanup_verified'] and receipt['job']['request']['apk']==build['sha256']+'.apk'
for capture in r['captures']:assert digest(folder/capture['file'])==capture['sha256']
captures=read(e/'final-native/capture-manifest.json');current(captures)
if 'movie_sha256' in captures:assert digest(e/'final-native/art-proof.mp4')==captures['movie_sha256']
else:raise AssertionError('Review gallery requires recorded native FBO frames; default-framebuffer screenshots are diagnostic only')
for capture in captures['shots']:assert digest(e/'final-native'/capture['file'])==capture['sha256']
if iteration=='B':
    launcher=read(e/'launcher-audit.json');assert launcher['passed'] and launcher['apk_sha256']==build['sha256']
    assert {row['device'] for row in launcher['devices']}=={'chromecast-test-01','chromecast-test-02'}
    for number,row in enumerate(launcher['devices'],1):
        assert row['passed']
        launcher_receipt=read(e/f'cast{number}-launcher/receipt.json')
        assert launcher_receipt['result']=='completed' and launcher_receipt['cleanup_verified'] and launcher_receipt['job']['id']==row['job']
        for capture in row['captures']:assert digest(e/capture['file'])==capture['sha256']
    r=read(e/'final-native/temple-love-audit.json');current(r);assert r['passed']
    r=read(e/'final-native/reading-capture-audit.json');current(r);assert r['passed'] and len(r['results'])==3
    for capture in r['results']:
        assert capture['comparison']['passed'] and digest(e/'final-native'/capture['file'])==capture['sha256']
summary=dict(passed=True,scope=f'Iteration {iteration} review candidate; native/source/rendering/Cast verification only, not final all-realm v0.6 or phone acceptance',
    apk_sha256=build['sha256'],level_sha256=build['levelSha256'],runtime_checks=len(checks),dialogue_sequences=len(transcripts),
    distinct_cards=len(seen),eligible_edges=len(edges),source_checks=len(read(e/'text-audit.json')['results']),
    asset_checks=len(read(e/'asset-audit.json')['results']),outward_meshes=len(read(e/'winding-audit.json')['objects']),
    art_uv_meshes=len(read(e/'uv-audit.json')['models']),rendered_panel_checks=420,
    transition_samples=len(read(e/'panel-transition-audit.json')['results']),rectified_transition_rechecks=len(read(e/'rectification-audit.json').get('frames',[])),
    deviceJob=receipt['job']['id'],engine_source_commit=build['engineSourceCommit'],
    pending_gates=['Max’s feedback after completing all production iterations','Current-build Pixel both perspectives and touch usability','Pixel sustained warm performance/thermal measurement','Approval/implementation of separate engine rotation fix'],
    known_visual_issues=['Camera obstruction/collision postponed','Corner-kit proof overlays remaining baseline architecture; full shop-recess integration and close world signs remain iteration B','Other NPCs, realms, endings and surgery retain baseline art until their scheduled production iterations','Temporary level full-axis safeguards remain pending engine fix'])
if iteration=='B':
    summary['launcher_devices']=[row['device'] for row in launcher['devices']]
    summary['known_visual_issues']=['Camera obstruction/collision postponed','Other realms, endings and final hub aether/foundation retain baseline art until their planned iterations','Temporary level full-axis safeguards remain pending engine fix']
    phone_folder=e/'phone-performance'
    if (phone_folder/'report.json').exists():
        phone=read(phone_folder/'report.json')
        phone_build=read(phone_folder/'production-build-receipt.json')
        assert phone_build['source_apk_sha256']==build['sha256']
        assert phone['production_apk_sha256']==phone_build['sha256']
        assert phone['production_level_sha256']==build['levelSha256']==phone_build['cd_sha256']
        campaign=read(phone_folder/'campaign/receipt.json')
        assert campaign['result']=='completed' and campaign['cleanup_verified']
        assert phone['job']==campaign['job']['id']
        assert {row['label'] for row in phone['measured_workloads']}=={'temple-view-0','temple-view-1','love-crowds-view-0','love-crowds-view-1'}
        for row in phone['measured_workloads']:
            folder=phone_folder/'campaign'/row['label']/'run-1'
            for name,sha in row['evidence_sha256'].items():assert digest(folder/name)==sha
        summary['phone_performance']={'job':phone['job'],'production_apk_sha256':phone_build['sha256'],
            'meets_mean_30_fps_target':phone['meets_mean_30_fps_target'],'scope':phone['scope'],
            'report_sha256':digest(phone_folder/'report.json')}
        if phone['meets_mean_30_fps_target']:
            summary['pending_gates'].remove('Pixel sustained warm performance/thermal measurement')
            summary['pending_gates'].append('Pixel later-realm sustained performance and full physical-input route checks')
(e/'verification-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
