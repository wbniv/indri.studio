| Date | Change |
|------|--------|
| [2026-10-10](https://github.com/wbniv/finding-your-way/commit/624882b) | Reuse one pinned Emscripten SDK across worktrees; checksum-verified offline install |
| [2026-10-10](https://github.com/wbniv/finding-your-way/commit/dfb4607) | Document completed reusable browser game player and consumer verification |
| [2026-10-10](https://github.com/wbniv/finding-your-way/commit/32d63eb) | Publish the refined fullscreen browser player with compact controls |
| [2026-10-10](https://github.com/wbniv/finding-your-way/commit/976d33d) | Build and verify the v0.8 browser player at a 64 KiB stack |

<!--history-meta v1
624882b	author	Will Norris
624882b	added	2
624882b	deleted	0
624882b	files	1
624882b	body	A fresh linked worktree had no SDK, because build.py's --sdk default was\nrelative to the worktree it ran from and build/ is ignored. web_deps.py now\ndiscovers the pinned SDK (--sdk, $FYW_WEB_SDK, this worktree, the main\ncheckout, the engine's vendor emsdk) and rejects any other version; the build\nnever downloads. web-deps.json pins the two upstream archives (301.5 MB) by\nSHA-256 and the installed tree by digest; `install` rebuilds a byte-identical\nSDK from the local cache with the network poisoned. The off-machine mirror is\ndesigned in the plan and awaits a decision.\n\nCo-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>\nClaude-Session: https://claude.ai/code/session_01FHCgJEKFj9n9X4Ju4vPgVR
dfb4607	author	Will Norris
dfb4607	added	4
dfb4607	deleted	0
dfb4607	files	1
dfb4607	body	AI-Assisted: Codex CLI 0.162.0; gpt-6.1-sol; reasoning effort medium.
32d63eb	author	Will Norris
32d63eb	added	5
32d63eb	deleted	3
32d63eb	files	1
32d63eb	body	Add a temple title preview, default desktop and phone Play to fullscreen, and keep one compact strip with a circular joystick, film-camera control and Select at the far right. Move help, reduced motion and confirmed restart into an icon menu. Record the prominent app-page play button, production iframe-policy fix and v0.1.189 publication.\n\nValidation: 19 Indri tests and 173-page build; Chrome/Firefox shell and Worker checks; 320 px multi-touch/cancellation/lost-capture checks; live desktop/phone navigation, fullscreen, menu icons and reader checks; all eight deployed asset hashes, CSP/cache headers and nine APK links verified. Existing engine, allocator implementations and game runtime are unchanged.\n\nAI-Assisted: Codex CLI 0.162.0; gpt-6.1-sol; reasoning effort medium.
976d33d	author	Will Norris
976d33d	added	26
976d33d	deleted	0
976d33d	files	1
976d33d	body	Add reproducible chapter browser tooling, Ubuntu 24.10 diagnostics, accepted fullscreen/lifecycle evidence, and plans with player component investigation diagrams. Preserve existing allocators and Android chapter provenance.\n\nValidation: Chrome and Firefox lifecycle checks, linked glyph batching and scratch balance, 3,120 reader fits, 17 Indri tests and built-page integration passed. Publication and full story/mobile acceptance remain pending.\n\nAI-Assisted: Codex CLI 0.162.0; gpt-6.1-sol; reasoning effort medium.
-->
