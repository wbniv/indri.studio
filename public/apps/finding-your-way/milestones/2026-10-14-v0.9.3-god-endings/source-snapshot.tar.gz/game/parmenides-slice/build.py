#!/usr/bin/env python3
"""Build the four Blender-authored realms and package the existing WF runtime."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import textwrap
import zipfile
from texture_slots import fit as fit_texture_slots, runtime_args

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[1]
WF = Path(os.environ.get('FYW_WF_ROOT', '/home/will/WorldFoundry-wbniv'))
OUT = ROOT / 'build'
ART_STAGE = 'baseline'
ROOM_LAYOUT = 'two'
DETAIL_SCALE = 1.0
VERSION = '0.5.5'
VERSION_CODE = 55
COMPRESS_LEVEL_DATA = False
LEVEL = 'parmenides_slice'
SDK = Path(os.environ.get('FYW_ANDROID_SDK', '/home/will/android-sdk-local'))
TOOLS = SDK / 'build-tools/34.0.0'
ANDROID = SDK / 'platforms/android-34/android.jar'
RUNTIME = Path(os.environ.get('FYW_RUNTIME_APK',str(WF / 'android/app/build/outputs/apk/condo/release/worldfoundry-condo-release.apk')))

def base_stage():
    return 'polish' if ART_STAGE in ('style-proof', 'chapter-art') else ART_STAGE

def release_runtime_args():
    args = runtime_args(OUT)
    if ART_STAGE in ('style-proof', 'chapter-art'):
        args += ['--static-mesh=1', '--static-mesh-shared-index=1']
    return args

def run(*args, **kwargs):
    subprocess.run([str(a) for a in args], check=True, **kwargs)

def source(slug):
    s = (PROJECT / 'src/content/pages' / (slug + '.md')).read_text().split('---', 2)[2]
    s = s.split('<details')[0]
    s = re.sub(r'!\[[^\]]*\]\([^)]*\)', '', s)
    return '\n\n'.join(re.sub(r'\s+', ' ', paragraph).strip() for paragraph in re.split(r'\n\s*\n', re.sub(r'[*_]', '', s)) if paragraph.strip())

def content(visual_fixes=True):
    OUT.mkdir(parents=True, exist_ok=True)
    labels={'love_sign':'LOVE','reason_sign':'REASON','goddess_sign':'THE GODDESS',
            'first_sign':'FIRST LOVE','starlet_sign':'THE STARLET','paper_sign':'ADVICE COLUMN',
            'being_sign':'BEING','notbeing_sign':'NOTBEING','back_sign':'TEMPLE',
            'truth_sign':'TRUTH','white_sign':'WHITE-CLAD SELF',
            'wild_sign':'WILD SELF','child_sign':'YOUNGER SELF','apparatus_sign':'WEATHER / WHY?',
            'rbeing_sign':'BEING','rnotbeing_sign':'NOTBEING','rback_sign':'TEMPLE',
            'prosecutor_sign':'PROSECUTOR','defence_sign':'DEFENCE ATTORNEY','student_sign':'THE STUDENT',
            'facts_sign':'EXHIBIT A / FACTS','interpretations_sign':'EXHIBIT B / ASSUMPTIONS',
            'judge_sign':'PRESENT EXHIBITS','tbeing_sign':'BEING / DEFENCE','tnotbeing_sign':'NOTBEING / PROSECUTOR',
            'tback_sign':'TEMPLE','god_sign':'GOD',
            'young_sign':'THE YOUNG MAN','holy_sign':'THE HOLY MAN',
            'god_poster_sign':'POSTER / MODELS','god_icon_sign':'ICON / FOUNDATION','question_sign':'YOUR QUESTION',
            'gbeing_sign':'BEING','gnotbeing_sign':'NOTBEING','gback_sign':'TEMPLE',
            'final_being_sign':'BEING','final_both_sign':'BOTH','final_notbeing_sign':'NOTBEING'}
    cards = []
    groups = {}
    runtime_beats = []
    def add(key, title, text, source_ids=(), atlas="permanent"):
        pages=[]
        page=[]
        for word in text.split():
            candidate=page+[word]
            if page and (len(candidate)>72 or len(textwrap.wrap(' '.join(candidate),54))>9):
                pages.append(page);page=[]
            page.append(word)
        if page:pages.append(page)
        ids = []
        for words in pages:
            ids.append(len(cards) + 1)
            cards.append(dict(id=len(cards) + 1, key=key, title=title,
                              text=' '.join(words), source=list(source_ids), atlas=atlas))
        groups[key] = ids
        runtime_beats.append(dict(id=ids[0], key=key, title=title, text=text, legacy_card_ids=ids))
    add('intro', 'THE TEMPLE', 'Four realms await: Love, Reason, Truth and God. Begin with Love. Walk toward the red portal and press Select. Directions move and turn. A short Select press interacts; hold Select to switch between third person and first person. The camera changes; your choices do not. Approach a speaker or object to interact. You can revisit the arguments before choosing a doorway.', ['intro', 'intro5'])
    add('first', 'FIRST LOVE', source('loveb'), ['loveb'])
    add('starlet', 'THE STARLET', source('lovec') + ' ' + source('loved'), ['lovec', 'loved'])
    add('paper', 'ADVICE COLUMN', 'One relationship taught me to care for someone even when it cost me. Another makes me wonder whether I only call it love when a bond answers my own needs. Should I trust love as a real force that exceeds advantage, or understand it as a response shaped by cooperation and survival? I do not want a slogan. I want to decide what this experience means. Which way holds my answer?', ['lovee'])
    add('affirm', 'ENTER THE WAY OF BEING?', 'Affirm Love as a real force that exceeds individual advantage. This is your interpretation, not a score. Press Select again to commit and return to the temple. Use Journal or move away after closing this sheet to reconsider.', ['lovebeing', '3a'])
    add('deny', 'ENTER THE WAY OF NOTBEING?', 'Understand Love as an evolved response to cooperation, vulnerability and survival rather than an independent force. This is your interpretation, not a score. Press Select again to commit and return to the temple. Use Journal or move away after closing this sheet to reconsider.', ['lovenotbeing', '3b'])
    add('locked', 'HEAR BOTH ACCOUNTS', 'Before choosing a doorway, hear First Love and the starlet and inspect the newspaper. Approach each of them and press Select. Finish their argument pages to complete an encounter. Ordinary walking never commits a choice.', ['loveb', 'lovec', 'loved', 'lovee'])
    add('return_being', 'RETURN TO THE TEMPLE', 'The tapestries glow with vibrance; their patterns weave and twist. The goddess smiles: "The weave of your love is fascinating." Reason is the next realm. Approach its purple portal and press Select. Explore the changed temple or begin a new interpretation at the Love portal.', ['3a'])
    add('return_notbeing', 'RETURN TO THE TEMPLE', 'The tapestries are gone; the four pillars stand bare. "They were worn out anyway. Out with the old," the goddess quips. The next portal glows blue: Reason awaits. Approach the blue portal and press Select, or revisit Love.', ['3b'])
    add('journal', 'JOURNAL', 'Love: First Love describes a force that can exceed selfish interests. The starlet describes an evolved response to cooperation and survival. The newspaper asks you to interpret a relationship. The two street thresholds represent your deliberate commitment. Select closes this sheet. With a gamepad or phone controller: B switches perspective, C opens/closes Journal, D toggles reduced motion. A long remote Select press switches perspective.', ['loveb', 'lovec', 'loved', 'lovee'])
    white,transformation=source('reasonba').split('You feel a vast crack',1)
    add('white','WHITE-CLAD SELF',source('reasonaa')+' '+white,['reasonaa','reasonab','reasonba','reasonbb'])
    add('grove','THE WHITE PLANE CHANGES','You feel a vast crack'+transformation,['reasonba','reasonbb'])
    add('apparatus_order','ORDERING APPARATUS','Press Select again to operate this model of rain. Warm water rises, cool clouds gather and rain falls. The apparatus can organize an explanation of how the weather works. The next question asks what this explanation can settle. Observe the pattern, then consider what kind of answer it provides. Neither doorway has a correct answer imposed by the apparatus.',['reasonba','reasonbb','reasonbeinga','reasonbeingb'])
    add('apparatus_limit','WHAT THE MODEL CANNOT CHOOSE','The model now shows a chain of causes: heat, vapor, cloud, rain. It can describe a pattern. It cannot choose why your survival matters, what you should value, or whether every question has a final answer. Neither doorway has been selected. Follow the roots, hear your Wild Self and meet the child at the edge of the grove.',['reasonbeinga','reasonbeingb'])
    add('wild','WILD SELF',source('reasonca'),['reasonca','reasoncb'])
    add('child','YOUNGER SELF',source('reasonda'),['reasonda','reasondb'])
    add('reason_affirm','ENTER REASON / BEING?','Take the bright threshold and question the scientific account down the Why Axis. Select continues that account; your commitment happens only after its final question. Left or Journal cancels the sheet. You can reconsider and choose the other threshold.',['reasonbeinga','reasonbeingb'])
    add('why_axis','THE WHY AXIS',source('reasonbeinga'),['reasonbeinga','reasonbeingb'])
    add('reason_deny','ENTER REASON / NOTBEING?','Take the dark threshold and hear the alternative answer to the child. Select continues that account; your commitment happens only after its final reply. Left or Journal cancels the sheet. You can reconsider and choose the other threshold.',['reasonnotbeinga','reasonnotbeingb'])
    add('rain_reply','ANOTHER ANSWER',source('reasonnotbeinga'),['reasonnotbeinga','reasonnotbeingb'])
    add('reason_locked','COMPLETE THE REASON ENCOUNTERS','Hear the White-Clad Self, operate the apparatus and consider its limits, follow the revealed roots to the Wild Self, then meet your Younger Self. Finish the encounter pages before entering either threshold. Walking never commits a choice.',['reasonaa','reasonab','reasonba','reasonbb','reasonca','reasoncb','reasonda','reasondb'])
    add('reason_wait','FOLLOW THE REVEALED ROOTS','Hear the White-Clad Self first. Completing that account reveals the grove and your Wild Self. Complete the apparatus encounter and the Wild Self account before meeting the child at the grove edge.',['reasonba','reasonbb','reasonda','reasondb'])
    add('reason_unavailable','LOVE COMES FIRST','Hear First Love and the starlet and inspect the newspaper, then choose the gold BEING or dark NOTBEING threshold. Select opens its confirmation; Select again commits and returns you to the Temple. The TEMPLE portal returns without choosing, so it does not unlock Reason. Your Love interpretation is kept while you explore Reason.',['3a','3b'])
    for slug in ('5a','5b','5c','5d'):
        add('return_'+slug,'RETURN TO THE TEMPLE',source(slug),[slug])
    from truth_content import add_truth
    add_truth(add, source)
    from god_content import add_god
    god_histories=add_god(add,source,PROJECT/'src/content/pages')
    from ending_content import add_endings
    ending_routes=add_endings(add,source,PROJECT/'src/content/pages')
    for card in cards:
        # DESIGNER_CHEATS reserves 420 for the engine's arcade game-over HUD.
        # Keep level-owned panel visibility out of that mailbox in v0.5.5.
        card['visibility_mailbox']=260+card['id']+(1 if visual_fixes and card['id']>=160 else 0)
    # Original advice wording replaces the source clipping; the arguments retain source prose.
    manifest = {'runtime_dialogue':True, 'runtime_beats':runtime_beats, 'labels':labels, 'visual_fixes':visual_fixes, 'chapter': 'Temple / Love / Temple / Reason / Temple / Truth / Temple / God / Final Temple / Endings / Surgery', 'cards': cards, 'groups': groups,
                'god_histories':god_histories, 'ending_routes':ending_routes,
                'reason_histories': {'5a':{'love':1,'reason':1},'5b':{'love':1,'reason':-1},'5c':{'love':-1,'reason':1},'5d':{'love':-1,'reason':-1}},
                'truth_histories': {'7'+chr(97+i):{'love':1 if i<4 else -1,'reason':1 if i%4<2 else -1,'truth':1 if i%2==0 else -1} for i in range(8)},
                'source_beats': ['intro','intro1','intro2','intro3','intro4','intro5','lovea','loveb','lovef','lovec','loved','lovee','lovebeing','lovenotbeing','3a','3b',
                                 'reasonaa','reasonab','reasonba','reasonbb','reasonca','reasoncb','reasonda','reasondb',
                                 'reasonbeinga','reasonbeingb','reasonnotbeinga','reasonnotbeingb','5a','5b','5c','5d']+
                                [prefix+suffix for prefix in ('truth1','trutha','truthb','truthc','truthd','truthbeing','truthnotbeing') for suffix in 'abcd']+
                                ['7'+suffix for suffix in 'abcdefgh']+
                                [prefix+suffix for prefix in ('god1','god2','goda','godb','godc','godbeing','godnotbeing') for suffix in 'abcdefgh']+
                                ['9'+suffix for suffix in 'abcdefghijklmnop']+['10a','10b','10c','101b'],
                'adaptation_notes': {'paper': 'Original advice-column replacement, not a transcription of the source photograph.',
                                    'first': 'Source loveb account remains approachable for replay; withdrawal is staged after the completed account.',
                                    'starlet': 'Original model and generic evolutionary-biology book replace the named celebrity/book portrait; both Love speakers withdraw after their accounts using provisional visibility changes.',
                                    'apparatus': 'Original causal-model interaction; completing it unlocks deliberation without selecting a philosophy.',
                                    'reason': 'Paired history pages share encounter prose; complete accounts and all four Temple returns are retained.',
                                    'truth': 'Complete source arguments and all eight returns; exhibits and hearing-bench presentation are authored adaptations, not new testimony.',
                                    '7h': 'Trailing authoring directions beginning Another Temple scene are omitted from the delivered return account.',
                                    'truth_aliases': 'Use canonical a-history spoken accounts; c-history prosecutor pages have minor apostrophe/quote-spacing edits, with unchanged argument content.',
                                    'god': 'Complete guide accounts, question, both answers and sixteen final returns. All eight NotBeing question repetitions are retained. Poster/icon inspection is authored adaptation with original geometry; complete endings and the sole surgery route are separate scenes.',
                                    'god_doors': 'Exact final-gate outgoing links are read from canonical frontmatter, not a majority vote.',
                                    'routing': 'The reasondb frontmatter points to a-terminals; explicit Love/Reason history uses the b-terminal routes to 5c/5d.'}}
    if base_stage() in ('temple-love','reason-truth','god-final','endings-surgery','polish'):
        manifest['adaptation_notes']['first']='Complete loveb account retained; bounded withdrawal into the west shop, then door closure; replay restores the encounter.'
        manifest['adaptation_notes']['starlet']='Original seated pop-fashion figure and generic biology book; exact lovec/loved text, bounded east-door withdrawal and replay restoration. No celebrity likeness.'
        manifest['adaptation_notes']['crowd']='Four original shared-body variants disperse toward street doors on arrival; no encounter or choice depends on the motion. Reduced motion starts at the quiet final state.'
    (OUT / 'content.json').write_text(json.dumps(manifest, indent=2) + '\n')
    from glyph_atlas import build
    build(manifest, OUT, ROOT/'fonts')

def native_build():
    if ART_STAGE!='baseline':
        from art_materials import generate
        generate(OUT, stage=base_stage())
    if ART_STAGE in ('style-proof', 'chapter-art'):
        from art_style_proof import generate_sources
        generate_sources(OUT)
    if ART_STAGE == 'chapter-art':
        from art_love_style import generate_sources as generate_love_sources
        generate_love_sources(OUT)
        from art_reason_truth_style import generate_sources as generate_reason_truth_sources
        generate_reason_truth_sources(OUT)
        from art_god_style import generate_sources as generate_god_sources
        generate_god_sources(OUT)
        from art_ending_style import generate_sources as generate_ending_sources
        generate_ending_sources(OUT)
    env = dict(os.environ, FYW_WF_ROOT=str(WF), FYW_SLICE_OUT=str(OUT),
               FYW_ART_STAGE=base_stage(), FYW_STYLE_PROOF='1' if ART_STAGE in ('style-proof', 'chapter-art') else '0',
               FYW_LOVE_STYLE='1' if ART_STAGE == 'chapter-art' else '0',
               FYW_REASON_TRUTH_STYLE='1' if ART_STAGE == 'chapter-art' else '0',
               FYW_GOD_STYLE='1' if ART_STAGE == 'chapter-art' else '0',
               FYW_ENDING_STYLE='1' if ART_STAGE == 'chapter-art' else '0',
               FYW_DETAIL_SCALE=repr(DETAIL_SCALE))
    run('blender', '--background', '--python-exit-code', '1', '--python', ROOT/'blender_scene.py', env=env)
    if ROOM_LAYOUT == 'scene9':
        from rooms_split import LAYOUTS, obj_name, patch, slot_map, split_objects
        # A room with only permanent actors has no RM chunk. The engine indexes
        # room chunks by room number, so keep one existing God prop local.
        layout = dict(LAYOUTS['scene9'], mbr_off=['young_sign'])
        _, _, problems, assertions = slot_map(layout['rooms'])
        if problems or assertions:
            raise RuntimeError('Invalid scene9 room slot map: ' + repr((problems, assertions)))
        source = OUT/(LEVEL+'.lev')
        revised, added = patch(source.read_text(), layout)
        source.write_text(revised)
        actors = OUT/'actors.json'
        manifest = json.loads(actors.read_text())
        _, sections = split_objects(revised)
        ids = {obj_name(section): index+1 for index, section in enumerate(sections)}
        if any(ids.get(name) != index for name, index in manifest['ids'].items()):
            raise RuntimeError('Scene9 changed an existing actor index')
        manifest['ids'] = ids
        actors.write_text(json.dumps(manifest, indent=2)+'\n')
        (OUT/'room-layout.json').write_text(json.dumps(dict(layout='scene9', rooms=layout['rooms'],
            added_objects=added, room_render_scope='all-active'), indent=2)+'\n')
    else:
        (OUT/'room-layout.json').write_text(json.dumps(dict(layout='two',
            room_render_scope='all-active'), indent=2)+'\n')
    tool = lambda name: WF / 'wftools' / (name + '-rs') / 'target/release' / name
    cwd = {'cwd': OUT}
    run(tool('iffcomp'), '-binary', '-o='+str(OUT/(LEVEL+'.lev.bin')), OUT/(LEVEL+'.lev'), **cwd)
    run(tool('levcomp'), LEVEL+'.lev.bin', WF/'wfsource/source/oas/objects.lc', LEVEL+'.lvl', WF/'wfsource/source/oas',
        '--mesh-dir', '.', '--iff-txt', LEVEL+'.iff.txt', '--textile-ini', LEVEL+'.ini', **cwd)
    if ROOM_LAYOUT == 'scene9':
        rooms = re.findall(r"'(RM\d+)'\s+\.offsetof", (OUT/(LEVEL+'.iff.txt')).read_text())
        if rooms != [f'RM{i}' for i in range(9)]:
            raise RuntimeError(f'Scene9 room chunks are incomplete: {rooms}')
    run(tool('textile'), '-ini='+LEVEL+'.ini', '-Tlinux', '-transparent=0,0,0', '-pagex=1024', '-pagey=2048',
        '-permpagex=2048', '-permpagey=2048', '-palx=256', '-paly=8', '-alignx=w', '-aligny=h', '-flipyout', **cwd)
    run(tool('iffcomp'), '-binary', '-o='+LEVEL+'.iff', LEVEL+'.iff.txt', **cwd)
    wrapper = "{ 'L4' { 'ALGN' .align( 2048 ) } { 'RAM' 'OBJD' 4194304l 'PERM' 16777216l 'ROOM' 8388608l 'FLAG' 1l 1l } { 'ALGN' .align( 2048 ) } [ \"parmenides_slice.iff\" ] }\n"
    (OUT/(LEVEL+'-standalone.iff.txt')).write_text(wrapper)
    run(tool('iffcomp'), '-binary', '-o='+LEVEL+'-standalone.iff', LEVEL+'-standalone.iff.txt', **cwd)
    from glyph_atlas import write_bundle, append_to_level
    manifest=json.loads((OUT/'content.json').read_text())
    write_bundle(manifest, OUT)
    append_to_level(OUT/(LEVEL+'-standalone.iff'), (OUT/'dialogue-glyphs.bin').read_bytes())
    from level_settings import attach
    attach(OUT/(LEVEL+'-standalone.iff'), OUT/'actors.json', OUT, WF, scope=0)
    run(tool('cdpack'), WF/'wfsource/source/game/shell.fth', LEVEL+'-standalone.iff', '-o', OUT/'cd.iff', **cwd)

def package():
    provenance=json.loads((OUT/'runtime-provenance.json').read_text())
    if json.loads((OUT/'content.json').read_text()).get('runtime_dialogue') and 'wfsource/source/game/bitmap_presenter.cc' not in provenance['sourceFilesSha256']:
        raise RuntimeError('Runtime glyph layout requires the matching font-system engine candidate; the legacy runtime is incompatible.')
    if provenance['runtimeApkSha256']!=hashlib.sha256(RUNTIME.read_bytes()).hexdigest():
        raise RuntimeError('Runtime changed since its verified provenance receipt')
    for path,digest in provenance['sourceFilesSha256'].items():
        committed=subprocess.check_output(['git','show',provenance['sourceCommit']+':'+path],cwd=WF)
        if hashlib.sha256(committed).hexdigest()!=digest:
            raise RuntimeError('Recorded engine source differs from its verified checkpoint: '+path)
    # Package the pinned, byte-verified runtime without rebuilding the engine.
    # Other work may edit the shared engine checkout; those edits do not belong
    # to this binary or its recorded source commit.
    # Android packaging is pinned by the APK and native-library hashes above.
    # The shared desktop output can be rebuilt independently by another task;
    # desktop verification checks its own exact executable before launching.
    assets = OUT / 'apk/assets'
    res = OUT / 'apk/res/drawable'
    assets.mkdir(parents=True, exist_ok=True)
    res.mkdir(parents=True, exist_ok=True)
    shutil.copy2(OUT/'cd.iff', assets/'cd.iff')
    (assets/'wf_args.txt').write_text('\n'.join(release_runtime_args())+'\n')
    with zipfile.ZipFile(RUNTIME) as runtime:
        for name in ('assets/controller.html',):
            (assets/Path(name).name).write_bytes(runtime.read(name))
    layout = {'app':'parmenides','title':'Finding Your Way','threshold':0.5,
              'stick':{'up':2048,'down':4096,'right':8192,'left':16384},
              'buttons':[dict(id='A',bit=1,label='interact',x=.87,y=.68,size=1),
                         dict(id='B',bit=2,label='perspective',x=.87,y=.3,size=1),
                         dict(id='C',bit=4,label='journal',x=.68,y=.68,size=.8),
                         dict(id='D',bit=8,label='reduce motion',x=.68,y=.3,size=.8)],
              'hint':'Move and turn with the stick. A interacts; B switches view; C opens Journal.'}
    (assets/'layout.json').write_text(json.dumps(layout))
    # Launcher artwork is original procedural geometry, not a crop of the concept sheets.
    banner = Image.new('RGB',(640,360),'#19262c');d=ImageDraw.Draw(banner)
    d.rectangle((230,65,410,310),fill='#bbad8c');d.rounded_rectangle((255,92,385,312),65,fill='#283839')
    d.rectangle((253,190,386,320),fill='#283839')
    d.text((320,205),'Π',anchor='mm',font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf',112),fill='#e3c879')
    d.text((28,22),'PARMENIDES',font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',30),fill='#e3c879')
    d.text((28,310),'Finding Your Way',font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',24),fill='#f2eee4')
    banner.save(res/'tv_banner.png')
    icon=Image.new('RGB',(256,256),'#19262c');draw=ImageDraw.Draw(icon)
    draw.rounded_rectangle((62,40,194,216),66,fill='#bbad8c')
    draw.rectangle((62,112,194,216),fill='#bbad8c')
    draw.rounded_rectangle((82,64,174,216),46,fill='#9e5250')
    draw.rectangle((82,112,174,216),fill='#9e5250')
    draw.rectangle((56,210,200,222),fill='#c7a45b')
    draw.text((128,142),'Π',anchor='mm',font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf',96),fill='#e3c879')
    icon.save(res/'icon.png')
    manifest = '''<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="org.worldfoundry.wf_game.parmenides" android:versionCode="VERSION_CODE" android:versionName="VERSION_NAME">
<uses-sdk android:minSdkVersion="MIN_SDK" android:targetSdkVersion="34"/><uses-permission android:name="android.permission.INTERNET"/>
<uses-feature android:name="android.hardware.touchscreen" android:required="false"/><uses-feature android:name="android.software.leanback" android:required="false"/>
<application android:label="Finding Your Way" android:icon="@drawable/icon" android:banner="@drawable/tv_banner" android:isGame="true" android:hasCode="false" android:extractNativeLibs="true">
<activity android:name="android.app.NativeActivity" android:exported="true" android:screenOrientation="landscape" android:configChanges="orientation|keyboardHidden|screenSize|uiMode" android:launchMode="singleTask"><meta-data android:name="android.app.lib_name" android:value="wf_game"/>
<intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/><category android:name="android.intent.category.LEANBACK_LAUNCHER"/></intent-filter></activity></application></manifest>'''
    (OUT/'apk/AndroidManifest.xml').write_text(manifest.replace('VERSION_CODE',str(VERSION_CODE)).replace('VERSION_NAME',VERSION).replace('MIN_SDK',str(provenance.get('build',{}).get('api',21))))
    # Room loads seek inside cd.iff; APK compression makes those seeks expensive.
    compression_args = [] if COMPRESS_LEVEL_DATA else ['-0', 'iff']
    run(TOOLS/'aapt','package','-f',*compression_args,'-M',OUT/'apk/AndroidManifest.xml','-S',OUT/'apk/res','-I',ANDROID,'-A',assets,'-F',OUT/'unsigned.apk')
    native = {}
    with zipfile.ZipFile(RUNTIME) as runtime, zipfile.ZipFile(OUT/'unsigned.apk','a') as bundle:
        expected_compression = zipfile.ZIP_DEFLATED if COMPRESS_LEVEL_DATA else zipfile.ZIP_STORED
        if bundle.getinfo('assets/cd.iff').compress_type != expected_compression:
            raise RuntimeError('Room-data ZIP compression differs from the requested packaging policy')
        for name in runtime.namelist():
            if name.startswith('lib/') and name.endswith('.so'):
                data = runtime.read(name);native[name]=hashlib.sha256(data).hexdigest()
                bundle.writestr(name,data,compress_type=zipfile.ZIP_STORED)
    if not any('armeabi-v7a' in n for n in native):
        raise RuntimeError('Missing Chromecast 32-bit runtime')
    if native!=provenance['nativeLibraries']:
        raise RuntimeError('Native libraries differ from the pinned engine receipt')
    key=OUT/'development-signing.p12'
    if not key.exists():
        run('keytool','-genkeypair','-keystore',key,'-storepass','android','-keypass','android','-alias','androiddebugkey','-keyalg','RSA','-keysize','2048','-validity','3650','-dname','CN=Finding Your Way Development')
    run(TOOLS/'zipalign','-f','4',OUT/'unsigned.apk',OUT/'aligned.apk')
    run(TOOLS/'apksigner','sign','--ks',key,'--ks-pass','pass:android','--out',OUT/'signed.apk',OUT/'aligned.apk')
    run(TOOLS/'apksigner','verify','--verbose',OUT/'signed.apk')
    digest=hashlib.sha256((OUT/'signed.apk').read_bytes()).hexdigest()
    frozen=OUT/('parmenides-'+digest[:16]+'.apk');shutil.copyfile(OUT/'signed.apk',frozen)
    receipt=dict(apk=str(frozen),sha256=digest,package='org.worldfoundry.wf_game.parmenides',nativeCode=True,
                 runtimeApk=str(RUNTIME),runtimeApkSha256=hashlib.sha256(RUNTIME.read_bytes()).hexdigest(),nativeLibraries=native,
                 levelSha256=hashlib.sha256((OUT/'cd.iff').read_bytes()).hexdigest(),engineSourceModified=True,
                 engineSourceCommit=provenance['sourceCommit'],engineProvenance=provenance)
    receipt.update(version=VERSION,versionCode=VERSION_CODE,artStage=ART_STAGE,roomLayout=ROOM_LAYOUT,detailScale=DETAIL_SCALE)
    receipt['levelDataCompression'] = 'deflate' if COMPRESS_LEVEL_DATA else 'stored'
    receipt['runtimeArguments']=release_runtime_args()
    if (OUT/'texture-slots.json').exists():
        receipt['textureSlots']=json.loads((OUT/'texture-slots.json').read_text())
    if ART_STAGE!='baseline':
        receipt['art']=json.loads((OUT/'art-manifest.json').read_text())
        receipt['artUVConvention']='Editable Blender bottom-up V; converted once to native top-down V at export. Shared native-pixel glyph atlas for dialogue/signs.'
        receipt['exporterSha256']=hashlib.sha256((WF/'wftools/wf_blender/export_level.py').read_bytes()).hexdigest()
    (OUT/'build-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))

if __name__ == '__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--package-only',action='store_true');parser.add_argument('--content-only',action='store_true');parser.add_argument('--visual-fixes',action='store_true',default=True,help='Retained command compatibility; v0.5.5 visual corrections are enabled by default.')
    parser.add_argument('--art-stage',choices=('baseline','proof','temple-love','reason-truth','god-final','endings-surgery','polish','style-proof','chapter-art'),default='baseline')
    parser.add_argument('--room-layout', choices=('two','scene9'), help='Engine Room layout; polish defaults to scene9.')
    parser.add_argument('--detail-scale',type=float,default=1.0,help='Temple and Goddess geometry density.')
    parser.add_argument('--build-dir',type=Path)
    parser.add_argument('--version',help='Explicit release version; requires --version-code.')
    parser.add_argument('--version-code',type=int,help='Monotonic Android release code; requires --version.')
    parser.add_argument('--compress-level-data',action='store_true',help='ZIP-compress level IFF data for a smaller download; room-data seeks may cost more.')
    parser.add_argument('--native-only',action='store_true',help='Export the level without packaging a runtime APK.')
    slots=parser.add_mutually_exclusive_group()
    slots.add_argument('--fit-texture-slots',action='store_true',help='Fit world texture slots to exported atlas dimensions (the default for runtime dialogue).')
    slots.add_argument('--legacy-texture-slots',action='store_true',help='Keep the original oversized slots for controlled comparisons.')
    args=parser.parse_args()
    COMPRESS_LEVEL_DATA=args.compress_level_data
    ART_STAGE=args.art_stage
    ROOM_LAYOUT=args.room_layout or ('scene9' if base_stage()=='polish' else 'two')
    if args.detail_scale!=1.0 and ART_STAGE not in ('style-proof','chapter-art'):parser.error('--detail-scale applies to the Temple/Goddess art stages only')
    if not .25<=args.detail_scale<=4:parser.error('--detail-scale must be between 0.25 and 4')
    DETAIL_SCALE=args.detail_scale
    if ART_STAGE=='proof':
        OUT=ROOT/'build/v0.6-proof'
        VERSION='0.6-proof.1';VERSION_CODE=60
    if ART_STAGE=='temple-love':
        OUT=ROOT/'build/v0.6-temple-love'
        VERSION='0.6-temple-love.1';VERSION_CODE=61
    if ART_STAGE=='reason-truth':
        OUT=ROOT/'build/v0.6-reason-truth'
        VERSION='0.6-reason-truth.1';VERSION_CODE=62
    if ART_STAGE=='god-final':
        OUT=ROOT/'build/v0.6-god-final'
        VERSION='0.6-god-final.1';VERSION_CODE=63
    if ART_STAGE=='endings-surgery':
        OUT=ROOT/'build/v0.6-endings-surgery'
        VERSION='0.6-endings-surgery.1';VERSION_CODE=64
    if ART_STAGE=='polish':
        OUT=ROOT/'build/v0.7-polish'
        VERSION='0.7-polish.2';VERSION_CODE=71
    if ART_STAGE=='style-proof':
        OUT=ROOT/'build/v0.9-temple'
        VERSION='0.9';VERSION_CODE=104
    if ART_STAGE=='chapter-art':
        OUT=ROOT/'build/v0.10-art'
        VERSION='0.10-art.2';VERSION_CODE=106
    if args.build_dir:OUT=args.build_dir.resolve()
    if os.environ.get('FYW_FONT_CANDIDATE')=='1':
        VERSION='0.9-dialogue-fonts.1';VERSION_CODE=91
    if (args.version is None) != (args.version_code is None):
        parser.error('--version and --version-code must be supplied together')
    if args.version is not None:
        if not re.fullmatch(r'[0-9]+(?:\.[0-9]+)+(?:-[a-zA-Z0-9.-]+)?',args.version) or not 1 <= args.version_code <= 2100000000:
            parser.error('Invalid Android release identity')
        VERSION=args.version;VERSION_CODE=args.version_code
    OUT.mkdir(parents=True,exist_ok=True)
    if OUT!=ROOT/'build' and not (args.content_only or args.native_only):
        # Keep the pinned runtime and application signing identity. A new key
        # would prevent updating the installed milestone in an ordinary session.
        for name in ('runtime-provenance.json','development-signing.p12'):
            target=OUT/name
            if not target.exists():shutil.copy2(ROOT/'build'/name,target)
    if args.package_only and (OUT/'build-receipt.json').exists():
        prior=json.loads((OUT/'build-receipt.json').read_text())
        if prior.get('artStage','baseline')!=ART_STAGE:raise SystemExit('Package stage differs from the exported build')
        if prior.get('roomLayout',ROOM_LAYOUT)!=ROOM_LAYOUT:raise SystemExit('Package room layout differs from the exported build')
    if args.package_only:
        manifest=OUT/'room-layout.json'
        if manifest.exists() and json.loads(manifest.read_text())['layout']!=ROOM_LAYOUT:
            raise SystemExit('Package room layout differs from the exported level')
        if ROOM_LAYOUT=='scene9' and not manifest.exists():
            raise SystemExit('Scene9 export has no room layout receipt')
    def configure_slots():
        if args.legacy_texture_slots:
            from texture_slots import image_sizes
            (OUT/'texture-slots.json').write_text(json.dumps(dict(permanent=[2048,2048],transient=[1024,2048],display=[5120,2048],exportedImages=image_sizes(OUT),rounding='legacy'),indent=2)+'\n')
        elif args.fit_texture_slots or json.loads((OUT/'content.json').read_text()).get('runtime_dialogue'):
            fit_texture_slots(OUT)
    if not args.package_only:
        content(args.visual_fixes)
        if args.content_only:raise SystemExit(0)
        native_build()
        configure_slots()
        if args.native_only:
            receipt={'artifact':'standalone level (no runtime APK)', 'artStage':ART_STAGE, 'roomLayout':ROOM_LAYOUT, 'detailScale':DETAIL_SCALE, 'sha256':hashlib.sha256((OUT/(LEVEL+'-standalone.iff')).read_bytes()).hexdigest(), 'glyphAtlasSha256':hashlib.sha256((OUT/'dialogue-glyphs.bin').read_bytes()).hexdigest()}
            (OUT/'level-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
            raise SystemExit(0)
    if args.package_only:configure_slots()
    package()
