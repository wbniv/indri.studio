#!/usr/bin/env python3
"""Compare the frozen desktop introductory reader with coordinator captures."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from PIL import Image

p = argparse.ArgumentParser()
p.add_argument('--reference', type=Path, required=True)
p.add_argument('--capture', type=Path, required=True)
p.add_argument('--report', type=Path, required=True)
a = p.parse_args()
reference = np.asarray(Image.open(a.reference).convert('RGB'), dtype=np.int16)
capture = np.asarray(Image.open(a.capture).convert('RGB'), dtype=np.int16)
if reference.shape != capture.shape:
    raise SystemExit('Desktop and device captures must have identical dimensions')
delta = np.abs(capture - reference)
# Coordinator APKs display the live FPS counter; the desktop reference omits it.
mask = np.ones(delta.shape[:2], dtype=bool)
mask[992:, 1792:] = False
report = dict(width=delta.shape[1], height=delta.shape[0],
              excluded='FPS stamp rectangle x >= 1792, y >= 992',
              referenceSha256=hashlib.sha256(a.reference.read_bytes()).hexdigest(),
              captureSha256=hashlib.sha256(a.capture.read_bytes()).hexdigest(),
              differentPixels=int(np.count_nonzero(np.any(delta > 0, axis=2) & mask)),
              maxChannelDifference=int(delta[mask].max()),
              passed=bool(delta[mask].max() <= 1))
a.report.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
raise SystemExit(0 if report['passed'] else 1)
