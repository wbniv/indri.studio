import { chromium, firefox } from '/home/will/finding-your-way/node_modules/@playwright/test/index.mjs';
import assert from 'node:assert/strict';
import { appendFileSync, mkdirSync, writeFileSync } from 'node:fs';
const [target,out] = process.argv.slice(2);assert(target&&out);mkdirSync(out,{recursive:true});
const engine=process.env.FYW_BROWSER || 'chromium';
const browser = engine === 'firefox' ? await firefox.launch({headless:false}) : await chromium.launch({executablePath:'/usr/bin/google-chrome',headless:true,args:['--no-sandbox','--enable-unsafe-swiftshader']});
const results=[];
try {
 const cases=engine === 'firefox' ? [['desktop',1280,900,false]] : [['desktop',1280,900,false],['phone',390,844,true]];
 for (const [name,width,height,touch] of cases) {
  const ctx=await browser.newContext({viewport:{width,height},hasTouch:touch});
  const page=await ctx.newPage();const requests=[],errors=[],logs=[],readerSizes=[];
  const consolePath=out+'/'+name+'-console.jsonl';writeFileSync(consolePath,'');
  page.on('request',r=>requests.push(r.url()));page.on('pageerror',e=>{errors.push(e.message);writeFileSync(out+'/'+name+'-exception.json',JSON.stringify({message:e.message,stack:e.stack,at:Date.now()},null,2)+'\n');});page.on('console',m=>{const entry={type:m.type(),text:m.text()};const reader=entry.text.match(/BITMAP_TEXT beat=1 .*body_px=(\d+)/);if(reader)readerSizes.push(Number(reader[1]));appendFileSync(consolePath,JSON.stringify(entry)+'\n');if(logs.length<500){logs.push(entry);writeFileSync(out+'/'+name+'-console.json',JSON.stringify(logs,null,2)+'\n');}});
  await page.goto(target,{waitUntil:'networkidle'});
  assert(!requests.some(u=>/wf_game\.(wasm|js|data)/.test(u)),'Game files fetched before Play');
  await page.evaluate(()=>{
   window.fywStackSamples=[];
   const original=WebGL2RenderingContext.prototype.bufferSubData;
   WebGL2RenderingContext.prototype.bufferSubData=function(...args){
    if(typeof _emscripten_stack_get_current==='function' && typeof _emscripten_stack_get_end==='function') {
     window.fywStackSamples.push({remaining:_emscripten_stack_get_current()-_emscripten_stack_get_end(),bytes:args[4]||args[2]?.byteLength});
    }
    return original.apply(this,args);
   };
  });
  await page.screenshot({path:out+'/'+name+'-title.png',fullPage:true});
  assert(await page.locator('#overlay').evaluate(e=>getComputedStyle(e).backgroundImage.includes('title-preview.jpg')));
  const begin=Date.now();await page.getByRole('button',{name:'Play',exact:true}).click();
  await page.waitForFunction(()=>document.querySelector('#overlay').hidden || document.querySelector('#play').textContent==='Retry',null,{timeout:60000});
  assert.equal(await page.locator('#overlay').evaluate(e=>e.hidden),true,await page.locator('#status').textContent());
  const startupMs=Date.now()-begin;
  await page.waitForFunction(()=>document.fullscreenElement?.id==='stage');
  await page.screenshot({path:out+'/'+name+'-fullscreen-intro.png',fullPage:true});
  await page.getByRole('button',{name:'Exit fullscreen',exact:true}).click();await page.waitForFunction(()=>!document.fullscreenElement);
  await page.waitForTimeout(1500);
  assert(requests.some(u=>u.endsWith('wf_game.wasm')));assert(requests.some(u=>u.endsWith('wf_game.data')));
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
  await page.screenshot({path:out+'/'+name+'-intro.png',fullPage:true});
  await page.locator('#canvas').focus();
  async function sizeKey(code, expected) {
   const next=page.waitForEvent('console',{predicate:m=>m.text().includes('body_px='+expected+' '),timeout:15000});
   await page.keyboard.down(code);try { await next; } finally { await page.keyboard.up(code); }
   await page.waitForTimeout(300);
  }
  await sizeKey('ArrowUp',42);await sizeKey('ArrowUp',56);
  await page.screenshot({path:out+'/'+name+'-reader-largest.png',fullPage:true});
  await sizeKey('ArrowDown',42);await sizeKey('ArrowDown',28);
  for(let i=0;i<3;i++){await page.keyboard.down('Space');await page.waitForTimeout(700);await page.keyboard.up('Space');await page.waitForTimeout(400);}
  await page.screenshot({path:out+'/'+name+'-after-select.png',fullPage:true});
  // Esc releases focus instead of invoking the engine shutdown key.
  await page.keyboard.press('Escape');
  await page.waitForFunction(()=>document.activeElement===document.querySelector('#focus'));
  await page.waitForTimeout(6000); // Exercise the engine's large wall-clock stall path on resume.
  await page.getByRole('button',{name:'Resume game'}).click();
  await page.getByRole('button',{name:'Game menu',exact:true}).click();
  await page.getByRole('button',{name:'Controls / help',exact:true}).click();assert.equal(await page.locator('#help').evaluate(e=>e.hidden),false);
  await page.getByRole('button',{name:'Controls / help',exact:true}).click();
  await page.screenshot({path:out+'/'+name+'-menu.png',fullPage:true});
  await page.keyboard.press('Escape');assert.equal(await page.locator('#menu').evaluate(e=>e.hidden),true);
  if(touch){
   assert.equal(await page.locator('#touch').evaluate(e=>e.hidden),false);
   const rect=await page.locator('[data-code="Space"]').boundingBox();const cdp=await ctx.newCDPSession(page);
   await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:rect.x+rect.width/2,y:rect.y+rect.height/2}]});
   await cdp.send('Input.dispatchTouchEvent',{type:'touchCancel',touchPoints:[]});
   assert.equal(await page.locator('[data-code="Space"]').getAttribute('aria-pressed'),'false');
  }
  await page.locator('#canvas').focus();
  // Input ownership: releasing the pointer must not release a held keyboard arrow.
  const pad=await page.locator('#joystick').boundingBox();const cx=pad.x+pad.width/2,cy=pad.y+pad.height/2;
  await page.mouse.move(cx,cy);await page.mouse.down();
  await page.mouse.move(cx,cy-30);
  assert.equal(await page.locator('[data-code=ArrowUp]').getAttribute('aria-pressed'),'true');
  await page.keyboard.down('ArrowUp');await page.mouse.move(cx,cy);await page.mouse.up();
  assert.equal(await page.locator('[data-code=ArrowUp]').getAttribute('aria-pressed'),'true');
  await page.keyboard.up('ArrowUp');assert.equal(await page.locator('[data-code=ArrowUp]').getAttribute('aria-pressed'),'false');
  await page.mouse.move(cx+26,cy-26);await page.mouse.down();
  assert.equal(await page.locator('[data-code=ArrowUp]').getAttribute('aria-pressed'),'true');
  assert.equal(await page.locator('[data-code=ArrowRight]').getAttribute('aria-pressed'),'true');
  await page.mouse.up();
  await page.keyboard.down('KeyI');assert.equal(await page.locator('[data-code=ArrowUp]').getAttribute('aria-pressed'),'true');await page.keyboard.up('KeyI');
  await page.getByRole('button',{name:'Game menu',exact:true}).click();
  await page.getByRole('button',{name:'Toggle reduced motion',exact:true}).click();assert.equal(await page.locator('#menu').evaluate(e=>e.hidden),true);
  await page.waitForTimeout(200);
  const layout=await page.evaluate(()=>{const rect=e=>{const r=e.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,right:r.right,bottom:r.bottom};};return {strip:rect(document.querySelector('#touch')),joystick:rect(document.querySelector('#joystick')),buttons:Array.from(document.querySelectorAll('#touch .round')).map(e=>({label:e.getAttribute('aria-label'),...rect(e)})),scene:rect(document.querySelector('#canvas'))};});
  assert.equal(layout.strip.height,layout.joystick.height+16);
  assert.equal(layout.buttons.at(-1).label,'Select');
  for(let i=0;i<layout.buttons.length;i++){const button=layout.buttons[i];assert(button.width>=44&&button.height>=44);if(i)assert(layout.buttons[i-1].right<=button.x);assert(button.right<=width);}
  assert.equal(await page.locator('#motion').evaluate(e=>e.closest('#menu')?.id),'menu');
  if(engine==='chromium'){for(const narrow of [320,390,844]){await page.setViewportSize({width:narrow,height:narrow===844?390:844});await page.waitForTimeout(250);const dims=await page.evaluate(()=>({strip:document.querySelector('#touch').getBoundingClientRect().height,pad:document.querySelector('#joystick').getBoundingClientRect().height,right:document.querySelector('[data-code=Space]').getBoundingClientRect().right,scroll:document.documentElement.scrollWidth,viewport:innerWidth}));assert.equal(dims.strip,dims.pad+16);assert(dims.right<=narrow&&dims.scroll<=narrow);}
   await page.setViewportSize({width,height});await page.waitForTimeout(500);}
  const stackSamples=await page.evaluate(()=>window.fywStackSamples);
  writeFileSync(out+'/'+name+'-stack-samples.json',JSON.stringify(stackSamples,null,2)+'\n');
  assert(stackSamples.length>0);assert(Math.min(...stackSamples.map(s=>s.remaining))>32768,'Sampled render stack headroom below 32 KiB');
  const measurement=await page.evaluate(()=>new Promise(resolve=>{
   const times=[];let previous=performance.now(),start=previous;
   function tick(now){times.push(now-previous);previous=now;if(now-start<3000)requestAnimationFrame(tick);else{times.sort((a,b)=>a-b);resolve({medianFrameMs:times[Math.floor(times.length/2)],p99FrameMs:times[Math.floor(times.length*.99)],observedRafFps:1000*times.length/(now-start),surface:[Module.canvas.width,Module.canvas.height],jsHeapBytes:performance.memory?.usedJSHeapSize||null});}}
   requestAnimationFrame(tick);
  }));
  assert.equal(errors.length,0,errors.join('\n'));
  if(logs.length<=500)writeFileSync(out+'/'+name+'-console.json',JSON.stringify(logs,null,2)+'\n');
  results.push({name,width,height,startupMs,readerSizes,minimumSampledStackHeadroom:Math.min(...stackSamples.map(s=>s.remaining)),noEagerGameDownloads:true,escapeDoesNotShutdown:true,playOpensFullscreen:true,compactControls:layout,joystickKeyboardOwnership:true,diagonalJoystick:true,menuAndMotion:true,readerInput:true,touchCancellation:touch,errors,measurement});
  // Fullscreen preserves a reader-safe logical canvas even on narrow screens.
  await page.getByRole('button',{name:'Fullscreen',exact:true}).click();
  {
   await page.waitForFunction(()=>document.fullscreenElement?.id==='stage');
   await page.getByRole('button',{name:'Exit fullscreen',exact:true}).click();await page.waitForFunction(()=>!document.fullscreenElement);
  }
  await page.getByRole('button',{name:'Game menu',exact:true}).click();
  page.once('dialog',dialog=>dialog.dismiss());await page.getByRole('button',{name:'Restart…',exact:true}).click();
  assert.equal(await page.locator('#overlay').evaluate(e=>e.hidden),true);
  page.once('dialog',dialog=>dialog.accept());await page.getByRole('button',{name:'Restart…',exact:true}).click();
  await page.getByRole('button',{name:'Play',exact:true}).waitFor();
  assert.equal(await page.locator('#overlay').evaluate(e=>e.hidden),false);
  assert.equal(errors.length,0,errors.join('\n'));
  await ctx.close();
 }
 // A rejected fullscreen request still starts inline, with identical controls.
 const fallbackCtx=await browser.newContext();const fallback=await fallbackCtx.newPage();
 await fallback.goto(target);await fallback.evaluate(()=>{document.querySelector('#stage').requestFullscreen=()=>Promise.reject(new Error('Test denial'));});
 await fallback.getByRole('button',{name:'Play',exact:true}).focus();await fallback.keyboard.press('Enter');
 await fallback.waitForFunction(()=>document.querySelector('#overlay').hidden,null,{timeout:60000});
 assert.equal(await fallback.evaluate(()=>!!document.fullscreenElement),false);assert.equal(await fallback.locator('#touch').evaluate(e=>e.hidden),false);await fallbackCtx.close();
 // Explicit load-failure test: block runtime JS and require useful retry UI.
 const ctx=await browser.newContext();const page=await ctx.newPage();await page.route('**/wf_game.js',r=>r.abort());await page.goto(target);await page.getByRole('button',{name:'Play',exact:true}).click();await page.getByRole('button',{name:'Retry',exact:true}).waitFor();assert((await page.locator('#status').textContent()).includes('download'));await ctx.close();
 writeFileSync(out+'/results.json',JSON.stringify({target,passed:true,browser:await browser.version(),results,interruptedDownloadRetry:true,allReaderSizes:true,fullscreenAndRestart:true,limits:'Headless Chrome with the local graphics backend; synthetic phone viewport/touch is not real mobile acceptance. RAF cadence is not instrumented engine FPS or GPU timing.'},null,2)+'\n');
 console.log('PASS browser startup, reader input, focus/Escape, loading failure, responsive layout');
} finally { await browser.close(); }
