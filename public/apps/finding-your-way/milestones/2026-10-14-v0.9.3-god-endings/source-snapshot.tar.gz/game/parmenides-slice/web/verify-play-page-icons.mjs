// Verify the animated icons on the in-frame Play button of /apps/finding-your-way/play/.
// Usage: node verify-play-page-icons.mjs BASE_URL OUT_DIR
//   BASE_URL  built indri.studio site (e.g. pnpm preview), OUT_DIR receives screenshots + results.json.
//   BEFORE_BUNDLE=<bgp1-id> also captures before-normal.png from that earlier frozen frame.
//   FYW_START=0 skips the real game start (menu toggle + key 4 mirror checks).
import { chromium } from '/home/will/finding-your-way/node_modules/@playwright/test/index.mjs';
import assert from 'node:assert/strict';
import { mkdirSync, writeFileSync } from 'node:fs';

const [base, out] = process.argv.slice(2);
if (!base || !out || base === '-h' || base === '--help') {
  console.log('Usage: node verify-play-page-icons.mjs BASE_URL OUT_DIR'); process.exit(base ? 0 : 2);
}
mkdirSync(out, { recursive: true });
const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', headless: true, args: ['--no-sandbox', '--enable-unsafe-swiftshader'] });
const results = { base, browser: await browser.version() };
const slots = [[1000, 'play'], [3000, 'temple'], [5000, 'play'], [7000, 'controller'], [9000, 'play'], [11000, 'cube'], [13000, 'play']];
const iconState = button => button.evaluate(el => {
  const icons = [...el.querySelectorAll('.play-icons svg')];
  return {
    visible: icons.filter(icon => Number(getComputedStyle(icon).opacity) > .99).map(icon => icon.dataset.icon),
    animationCount: icons.reduce((n, icon) => n + icon.getAnimations().length, 0),
  };
});
// Crop to the Play button and status line rather than the whole poster overlay.
async function shot(page, scope, path) {
  const play = await scope.locator('#play').boundingBox(), status = await scope.locator('#status').boundingBox();
  const x = Math.max(0, play.x + play.width / 2 - 260), y = Math.max(0, play.y - 24);
  await page.screenshot({ path, clip: { x, y, width: 520, height: status.y + status.height + 16 - y } });
}
async function openPlayPage(context) {
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.goto(base + '/apps/finding-your-way/play/', { waitUntil: 'networkidle' });
  const frame = page.frames().find(f => new URL(f.url()).pathname.endsWith('/frame.html'));
  assert(frame, 'player frame present');
  await frame.waitForSelector('#play');
  return { page, frame, errors, button: frame.getByRole('button', { name: 'Play', exact: true }) };
}
try {
  if (process.env.BEFORE_BUNDLE) {
    const context = await browser.newContext({ viewport: { width: 1280, height: 900 }, reducedMotion: 'no-preference' });
    const page = await context.newPage();
    await page.goto(`${base}/apps/finding-your-way/play/bundles/${process.env.BEFORE_BUNDLE}/frame.html`, { waitUntil: 'networkidle' });
    await shot(page, page, out + '/before-normal.png');
    await context.close();
  }

  // 1. Normal motion: accessible name, hidden icons, six-slot cycle, stable size.
  let context = await browser.newContext({ viewport: { width: 1280, height: 900 }, reducedMotion: 'no-preference' });
  let { page, frame, errors, button } = await openPlayPage(context);
  assert.equal(await button.locator('.play-icons').getAttribute('aria-hidden'), 'true');
  assert.equal(await button.locator('.play-label').textContent(), 'Play');
  const samples = [];
  for (const [time, expected] of slots) {
    const sample = await button.evaluate((el, time) => {
      for (const icon of el.querySelectorAll('.play-icons svg')) for (const a of icon.getAnimations()) { a.pause(); a.currentTime = time; }
      const r = el.getBoundingClientRect();
      return { visible: [...el.querySelectorAll('.play-icons svg')].filter(i => Number(getComputedStyle(i).opacity) > .99).map(i => i.dataset.icon), width: r.width, height: r.height };
    }, time);
    assert.deepEqual(sample.visible, [expected], `slot at ${time} ms shows ${expected}`);
    if (samples.length) assert.deepEqual([sample.width, sample.height], [samples[0].width, samples[0].height], 'icon changes do not resize the button');
    samples.push({ time, ...sample });
    if (time < 12000 && expected !== 'play' || time === 1000) await shot(page, frame, `${out}/after-normal-${expected}.png`);
  }
  results.cycle = samples;

  // 2. OS reduced motion: static temple, no animations; cycling resumes when cleared.
  await page.emulateMedia({ reducedMotion: 'reduce' });
  const reduced = await iconState(button);
  assert.deepEqual(reduced, { visible: ['temple'], animationCount: 0 }, 'OS reduced motion shows the static temple');
  await shot(page, frame, out + '/after-reduced-motion.png');
  await page.emulateMedia({ reducedMotion: 'no-preference' });
  await frame.waitForFunction(() => document.querySelectorAll('#play .play-icons svg').length === 4 && [...document.querySelectorAll('#play .play-icons svg')].every(i => i.getAnimations().length === 1));
  results.osReducedMotion = reduced;

  // 3. In-game reduced-motion mirror attribute (CSS hook) stops the cycle.
  await frame.evaluate(() => document.documentElement.setAttribute('data-reduced-motion', 'true'));
  const gameReduced = await iconState(button);
  assert.deepEqual(gameReduced, { visible: ['temple'], animationCount: 0 }, 'in-game reduced motion shows the static temple');
  await shot(page, frame, out + '/after-game-reduced-motion.png');
  await frame.evaluate(() => document.documentElement.setAttribute('data-reduced-motion', 'false'));
  assert.equal((await iconState(button)).animationCount, 4);
  results.gameReducedMotionAttribute = gameReduced;
  assert.deepEqual(errors, []);
  await context.close();

  // 4. Phone layout of the whole page.
  context = await browser.newContext({ viewport: { width: 390, height: 844 }, reducedMotion: 'no-preference', hasTouch: true });
  ({ page, frame, button } = await openPlayPage(context));
  await button.scrollIntoViewIfNeeded();
  await page.screenshot({ path: out + '/play-page-phone.png' });
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true, 'no horizontal scroll at 390 px');
  await context.close();

  // 5. Retry after a failed load keeps the icons and reads "Retry".
  context = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  await context.route('**/wf_game.wasm', route => route.abort());
  ({ page, frame, button } = await openPlayPage(context));
  await button.click();
  const retry = frame.getByRole('button', { name: 'Retry', exact: true });
  await retry.waitFor({ timeout: 60000 });
  assert.equal(await frame.locator('#play').textContent(), 'Retry', 'legacy textContent check still sees Retry');
  assert.equal(await frame.locator('#play .play-icons svg').count(), 4);
  await shot(page, frame, out + '/after-retry.png');
  results.retry = { name: 'Retry', icons: 4 };
  await context.close();

  // 6. Loading (disabled) shows the static icon, then the real menu toggle and key 4 flip the mirror.
  if (process.env.FYW_START !== '0') {
    context = await browser.newContext({ viewport: { width: 1280, height: 900 }, reducedMotion: 'no-preference' });
    ({ page, frame, errors, button } = await openPlayPage(context));
    await context.route('**/wf_game.data', async route => { await new Promise(r => setTimeout(r, 1500)); await route.continue(); });
    await button.click();
    await frame.waitForFunction(() => document.querySelector('#play').disabled);
    const loading = await iconState(frame.locator('#play'));
    assert.deepEqual(loading, { visible: ['temple'], animationCount: 0 }, 'disabled/loading shows the static temple');
    assert.equal(await frame.locator('#play').getAttribute('disabled'), '');
    await shot(page, frame, out + '/after-loading-disabled.png');
    await frame.waitForFunction(() => document.querySelector('#overlay').hidden || document.querySelector('#play').textContent === 'Retry', null, { timeout: 90000 });
    assert.equal(await frame.locator('#overlay').evaluate(e => e.hidden), true, await frame.locator('#status').textContent());
    const mirror = () => frame.evaluate(() => document.documentElement.getAttribute('data-reduced-motion'));
    assert.equal(await mirror(), null);
    await frame.getByRole('button', { name: 'Game menu', exact: true }).click();
    await frame.getByRole('button', { name: 'Toggle reduced motion', exact: true }).click();
    assert.equal(await mirror(), 'true', 'menu toggle mirrors reduced motion on');
    await frame.locator('#canvas').focus();
    await page.keyboard.press('Digit4');
    assert.equal(await mirror(), 'false', 'key 4 mirrors reduced motion off');
    results.loading = loading;
    results.inGameToggleMirror = ['true', 'false'];
    assert.deepEqual(errors, []);
    await context.close();
  }

  // 7. SNES consumers keep the plain Play button.
  const snesManifest = await (await fetch(base + '/apps/llvm-mos-65816/play/component/manifest.json')).json();
  const snesFrame = await (await fetch(`${base}/apps/llvm-mos-65816/play/component/bundles/${snesManifest.bundleId}/frame.html`)).text();
  assert(snesFrame.includes('<button id="play">Play</button>') && !snesFrame.includes('play-icons'), 'SNES frame unchanged');
  results.snes = { bundleId: snesManifest.bundleId, plainPlay: true };

  writeFileSync(out + '/results.json', JSON.stringify({ ...results, timing: 'CSS animations seeked to each two-second slot; not a wall-clock playback measurement.' }, null, 2) + '\n');
  console.log(JSON.stringify({ passed: true, checks: Object.keys(results).filter(k => !['base', 'browser'].includes(k)), browser: results.browser }));
} finally {
  await browser.close();
}
