"""Check actual coordinator movies against the diagnostic tour's source pages.

This is sampled rendering evidence, not proof of remote-driven Android routes.
World and deliberately hidden transition frames need separate visual review.
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

import numpy as np
from PIL import Image, ImageDraw
from build_review_fixtures import SCENES
from verify_panel_render import inspect_frame, locate_sheet

ROOT=Path(__file__).resolve().parent
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())

def run(folder,fixture,group,base=ROOT/'build'):
    device=read(folder/'receipt.json');review=read(fixture/'review-receipt.json')
    production=read(base/'build-receipt.json')
    assert device['result']=='completed' and device['cleanup_verified']
    assert device['job']['request']['apk']==review['sha256']+'.apk'
    assert review['diagnostic_only'] and review['production_apk_sha256']==production['sha256']
    assert review['nativeLibraries']==production['nativeLibraries']
    shutil.copy2(fixture/'review-receipt.json',folder/'diagnostic-build-receipt.json')
    shutil.copy2(fixture/'chapter.fth',folder/'diagnostic-script.fth')
    content=read(base/'content.json')
    expected=set()
    captured_scenes={p['scene'] for p in review['phases']}
    selected=set()
    for phase in review['phases']:
        if 'source_group' not in phase or phase.get('optional'):continue
        key=phase['source_group'];canonical=content['groups'][key]
        pages=phase.get('source_page_ids',canonical)
        # A fixture may start at a later canonical page (for example the third
        # NotBeing sheet). Reject invented or reordered source-page metadata.
        assert pages and any(pages==canonical[start:start+len(pages)] for start in range(len(canonical)))
        selected.add((phase['scene'],phase['realm'],key,tuple(pages)))
    optional={card for phase in review['phases'] if phase.get('optional') and 'source_group' in phase for card in content['groups'][phase['source_group']][:2]}
    if not selected:selected={(name,realm,key,tuple(content['groups'][key])) for name,realm,_,_,key,_ in SCENES[group*3:group*3+3] if name in captured_scenes}
    for name,realm,key,pages in selected:
        expected.update(pages[:2])
        if len(pages)==1 and realm in (5,7,8):expected.add(content['groups']['ending_complete'][0])
        if len(pages)==1 and realm==6:expected.add(content['groups']['ending_101b'][0])
    allowed=expected|optional
    templates={n:Image.open(base/f'card_{n:02d}.tga') for n in allowed}
    movie=folder/'capture.mp4'
    probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-of','json',str(movie)]))
    stream=next(s for s in probe['streams'] if s['codec_type']=='video');w,h=stream['width'],stream['height']
    proc=subprocess.Popen(['ffmpeg','-v','error','-i',str(movie),'-vf','fps=4','-f','rawvideo','-pix_fmt','rgb24','pipe:1'],stdout=subprocess.PIPE)
    samples=folder/'checked-sheets';samples.mkdir(exist_ok=True)
    world_samples=folder/'samples';world_samples.mkdir(exist_ok=True)
    contact=Image.new('RGB',(1280,1680));contact_index=0
    rows=[];seen=set();frame_index=0;excluded=[]
    exclusion_path=folder/'candidate-exclusions.json'
    exclusions=read(exclusion_path) if exclusion_path.exists() else []
    try:
        while True:
            data=proc.stdout.read(w*h*3)
            if not data:break
            if len(data)!=w*h*3:raise RuntimeError('Incomplete decoded frame')
            frame=Image.frombytes('RGB',(w,h),data);pixels=np.asarray(frame)
            if frame_index%12==0 and contact_index<32:
                target=world_samples/f'frame-{contact_index+1:02d}.png';frame.save(target)
                thumb=Image.new('RGB',(320,210));thumb.paste(frame.resize((320,180)),(0,30))
                ImageDraw.Draw(thumb).text((4,4),f'{frame_index/4:.1f}s',fill='white')
                contact.paste(thumb,((contact_index%4)*320,(contact_index//4)*210));contact_index+=1
            # Ordinary world signs share the sheet's base color. A modal
            # reading frame has a predominantly black suppressed world.
            quiet=float((pixels[:-40:4,::4].max(axis=2)<20).mean())
            if quiet<.7:
                frame_index+=1
                continue
            mask=np.max(np.abs(pixels.astype(np.int16)-np.array([32,41,49],dtype=np.int16)),axis=2)<=10
            # Recognize a broad modal plate. Opaque world/void backgrounds are
            # excluded; their rendering is judged in the separate world review.
            yy=np.where(mask.sum(axis=1)>w*.2)[0]
            if len(yy)>=50 and .02<float(mask.mean())<.7:
                location=locate_sheet(frame)
                matches=[(n,inspect_frame(frame,t,location)) for n,t in templates.items()]
                accepted=[(n,r) for n,r in matches if r['passed']]
                if accepted:
                    n,result=max(accepted,key=lambda pair:pair[1]['body_similarity'])
                    if n not in seen:
                        target=samples/f'card-{n:03d}.png';frame.save(target)
                        result=dict(result,file=str(target.relative_to(folder)),sha256=digest(target))
                    seen.add(n)
                    rows.append(dict(video_time=frame_index/4,card=n,**result))
                else:
                    target=samples/f'failed-{frame_index:04d}.png';frame.save(target)
                    candidate=dict(video_time=frame_index/4,passed=False,file=str(target.relative_to(folder)),sha256=digest(target),candidate_results=dict(matches))
                    exemption=next((r for r in exclusions if r['sha256']==candidate['sha256'] and r['video_time']==candidate['video_time']),None)
                    if exemption:
                        assert exemption['classification']=='world sign' and exemption['reason']
                        excluded.append(dict(candidate=candidate,manual_review=exemption))
                    else:
                        rows.append(candidate)
            frame_index+=1
    finally:
        proc.stdout.close()
        if proc.wait(timeout=30)!=0:raise RuntimeError('Movie decode failed')
    report=dict(passed=bool(rows) and all(r['passed'] for r in rows) and expected<=seen and seen<=allowed,
                device_job=device['job']['id'],diagnostic_apk_sha256=review['sha256'],
                production_apk_sha256=production['sha256'],video_sha256=digest(movie),
                sample_rate=4,frames_sampled=frame_index,sheet_frames=len(rows),
                expected_cards=sorted(expected),optional_cards=sorted(optional),seen_cards=sorted(seen),results=rows,
                manual_world_exclusions=excluded,
                scope='4 Hz samples with recognizable sheet plates; exact expected source templates; world/hidden intervals require visual review; diagnostic scene selection is scripted')
    (folder/'sheet-audit.json').write_text(json.dumps(report,indent=2)+'\n')
    contact.save(folder/'contact.png')
    print(folder.name,'sheet frames',len(rows),'failed',sum(not r['passed'] for r in rows),'missing',sorted(expected-seen),'passed',report['passed'],flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--folder',type=Path,required=True);p.add_argument('--fixture',type=Path,required=True);p.add_argument('--group',type=int,required=True);p.add_argument('--build-dir',type=Path,default=ROOT/'build')
    args=p.parse_args();run(args.folder,args.fixture,args.group,args.build_dir.resolve())
