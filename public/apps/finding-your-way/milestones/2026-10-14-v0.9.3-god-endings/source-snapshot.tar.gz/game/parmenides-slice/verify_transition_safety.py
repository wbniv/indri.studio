"""Actual input must not skip unseen coda pages during the native camera slew."""
import time

def run(b,player,value,check,tap,position,read_pages,groups):
    b.watch(player,138)
    for mode in (0,1):
        b.set_mailbox(140,0,idx=player)
        if value(101)!=mode:tap(2)
        for mb,val in ((102,6),(189,2),(222,1),(223,0),(224,0),(225,0)):
            b.set_mailbox(mb,val,idx=player)
        position(600,0)
        b.set_mailbox(140,groups['ending_10b'][-1],idx=player)
        deadline=time.monotonic()+25
        while not value(129) and time.monotonic()<deadline:time.sleep(.03)
        check('Both account readable before coda '+str(mode),bool(value(129)))
        tap()
        check('Both advances only into source coda '+str(mode),value(102)==8 and value(140)==groups['ending_101b'][0])
        check('coda transition initially hides sheet '+str(mode),not value(129))
        with b._lock:start=len(b._inbox)
        tap()
        with b._lock:messages=[m for m in b._inbox[start:] if m.get('op')=='mailbox' and m.get('idx')==player and m.get('mailbox') in (111,129,138,140,224,225)]
        print({'early_press_trace':messages,'card':value(140),'ready':value(129),'press_card':value(138),'coda_done':value(224),'done':value(225)},flush=True)
        # The view may finish slewing during the press/release observation.
        # Readiness at its end is allowed; skipping/crediting the unseen source
        # from that early press is the behavior this regression must reject.
        check('unseen Select cannot advance or complete coda '+str(mode),
              value(140)==groups['ending_101b'][0] and value(224)==0 and value(225)==0)
        tap(16384)
        check('unseen sheet can be cancelled safely '+str(mode),value(140)==0 and value(224)==0 and value(225)==0)
        tap(4)
        check('cancelled coda resumes from its source start '+str(mode),value(140)==groups['ending_101b'][0])
        read_pages('visible coda after transition '+str(mode),groups['ending_101b'],groups['ending_complete'][0])
        check('coda completes only after visible pages '+str(mode),value(224)==1 and value(225)==1)
        read_pages('coda review returns '+str(mode),groups['ending_complete'])
        check('review restores Temple and camera preference '+str(mode),value(102)==0 and value(101)==mode)
