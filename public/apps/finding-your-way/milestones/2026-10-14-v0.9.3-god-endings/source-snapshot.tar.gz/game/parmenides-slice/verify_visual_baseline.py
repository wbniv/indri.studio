"""Record native moving-world and unsheltered dialogue transition intervals.

Fixture setup is debug-assisted; movement, paging, toggling and closing use the
same observed native input cycle as route verification. Pixel failures remain
in the receipt rather than aborting capture of the other scenes.
"""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

from PIL import Image, ImageDraw
from verify_panel_render import inspect_frame

FIXTURES=[
    ('temple',0,3,0,'intro'),('love',1,96,-1,'first'),
    ('reason',2,196,-2,'white'),('truth',3,294,-2,'prosecutor'),
    ('god',4,400,-1,'young_man'),('being',5,500,0,'ending_10a'),
    ('both',6,600,0,'ending_10b'),('notbeing',7,700,1,'ending_10c'),
    ('surgery',8,800,0,'ending_101b'),
]

def history_fixtures():
    """Distinct Temple visibility histories plus previously unsampled approaches."""
    rows=[]
    for phase,letters in ((1,'ab'),(2,'abcd'),(3,'abcdefgh'),(4,'abcdefghijklmnop')):
        for index,letter in enumerate(letters):
            choices=[1 if not (index & (1 << (phase-1-i))) else -1 for i in range(phase)]
            state={106:1,107:choices[0]}
            if phase>=2:state.update({154:1,155:choices[1],156:index//(2**(phase-2))+1})
            if phase>=3:state.update({176:1,177:choices[2],178:index//(2**(phase-3))+1})
            if phase>=4:state.update({195:1,196:choices[3],197:index+1,188:1})
            rows.append((f'temple-phase-{phase}-{letter}',0,3,0,None,state))
    rows.extend([
        ('reason-transformed',2,204,5,None,{150:1,151:1,152:1,157:1}),
        ('god-summit',4,400,30,None,{190:1,191:1,192:1,193:1}),
        ('love-starlet',1,104,1,None,{}),
        ('love-temple-sign',1,100,-2,None,{}),
        ('truth-hearing-complete',3,300,9,None,{170:1,171:1,172:1,173:1,174:1,175:1}),
    ])
    return rows

def run(b,player,value,check,tap,position,out,evidence):
    ids=json.loads((out/'actors.json').read_text())['ids']
    content=json.loads((out/'content.json').read_text())
    rows=[];events=[]
    for actor in (ids['Camera'],ids['FollowShot'],ids['CamTarget']):
        for mb in (3009,3010,3011):b.watch(actor,mb)
    def state():
        return dict(card=value(140),realm=value(102),mode=value(101),
                    player=[value(m) for m in (3009,3010,3011)],
                    camera=[b.mailbox_values.get((ids['Camera'],m)) for m in (3009,3010,3011)])
    def event(label):
        row=dict(label=label,wall_time=time.time(),**state());events.append(row);return row
    def settle():
        deadline=time.monotonic()+25
        while time.monotonic()<deadline:
            vectors=[[b.mailbox_values.get((a,m)) for m in (3009,3010,3011)] for a in (ids['Camera'],ids['FollowShot'],ids['CamTarget'],player)]
            if all(v is not None for vector in vectors for v in vector):
                actual,shot,origin,actor=vectors
                if max(abs(a-(s-o+p)) for a,s,o,p in zip(actual,shot,origin,actor))<.12:return
            time.sleep(.03)
        raise AssertionError('Fixture camera did not settle: '+str(vectors))
    def reading():
        deadline=time.monotonic()+25
        while not value(129) and time.monotonic()<deadline:time.sleep(.03)
        check('reading view becomes ready',bool(value(129)))
        time.sleep(.15)
    try:
        if '--reduced-motion' in sys.argv:b.set_mailbox(108,1,idx=player)
        for mode in (0,1):
            fixtures=history_fixtures() if '--visual-states' in sys.argv else [(*row,{}) for row in FIXTURES]
            if '--scene-only' in sys.argv:
                fixtures=[row for row in fixtures if row[0]==sys.argv[sys.argv.index('--scene-only')+1]]
                if not fixtures:raise ValueError('Unknown scene fixture')
            if '--history-only' in sys.argv:
                fixtures=[row for row in fixtures if row[0]==sys.argv[sys.argv.index('--history-only')+1]]
                if not fixtures:raise ValueError('Unknown history fixture')
            for name,realm,x,y,key,history in fixtures:
                b.set_mailbox(140,0,idx=player)
                # Independent fixtures must not inherit completion or NPC state.
                for mb in (103,104,105,106,107,150,151,152,153,154,155,156,157,
                           *range(170,180),*range(188,201),222,223,224,225,253):
                    b.set_mailbox(mb,history.get(mb,0),idx=player)
                if value(101)!=mode:tap(2)
                heading=.75 if name in ('god-summit','love-temple-sign') else .25
                b.set_mailbox(102,realm,idx=player);b.set_mailbox(114,heading,idx=player)
                position(x,y);settle()
                if realm==8:time.sleep(1)
                start=event(name+' world start')
                if realm==8 and '--world-hold' in sys.argv:
                    time.sleep(float(sys.argv[sys.argv.index('--world-hold')+1]))
                if realm!=8:
                    for bit in (2048,8192,4096,16384):
                        tap(bit,10)
                        event(name+' move '+str(bit))
                end=event(name+' world end')
                rows.append(dict(kind='world',name=name,camera=mode,history=history,realm=realm,player_xy=[x,y],heading_turns=heading,start=start['wall_time'],end=end['wall_time']))
                if key is None:
                    print('recorded history/approach interval '+name+' view '+str(mode),flush=True)
                    continue
                # Open the intended account through actual native interact.
                if realm<=4:
                    b.set_mailbox(114,.25,idx=player);position(x,y+1);settle();tap()
                else:
                    tap()
                card=int(value(140) or 0)
                check(name+' interaction opens its exact source sheet',card==content['groups'][key][0])
                begin=event(name+' sheet opened');time.sleep(.8);reading()
                rows.append(dict(kind='sheet',name=name,camera=mode,card=card,start=begin['wall_time'],end=time.time()))
                tap();card=int(value(140) or 0)
                pages=content['groups'][key]
                expected=pages[1] if len(pages)>1 else content['groups']['ending_complete'][0] if realm in (5,7,8) else content['groups']['ending_101b'][0] if realm==6 else 0
                check(name+' next page is intended',card==expected)
                if card:
                    begin=event(name+' page advanced');time.sleep(.7);reading()
                    rows.append(dict(kind='sheet',name=name+' next page',camera=mode,card=card,start=begin['wall_time'],end=time.time()))
                tap(16384);event(name+' sheet cancelled');check(name+' cancellation closes sheet',value(140)==0)
                time.sleep(.3)
                print('recorded moving and transition interval '+name+' view '+str(mode),flush=True)
    finally:
        (evidence/'requests.json').write_text(json.dumps(dict(build=json.loads((out/'build-receipt.json').read_text()),results=rows,events=events),indent=2)+'\n')

def finalize(out,evidence):
    requests=json.loads((evidence/'requests.json').read_text())
    match=re.search(r'Duration: N/A, start:\s*([0-9.]+)',(evidence/'engine.log').read_text())
    if not match:raise RuntimeError('Recording start missing')
    recording=evidence if '--isolated-recording' in sys.argv else out
    epoch=float(match.group(1));movie=evidence/'review.mp4';shutil.copy2(recording/'output.mp4',movie)
    frames=evidence/'frames';frames.mkdir(exist_ok=True)
    rows=[];thumbs=[]
    for n,request in enumerate(requests['results']):
        # Sample inside the recorded interval. Its exact wall-clock endpoint
        # can be later than the final encoded frame when the runtime stops.
        duration=request['end']-request['start']
        offsets=(0,.10,.25,.50,max(.50,duration-.05)) if request['kind']=='sheet' else (0,duration/2,max(0,duration-.10))
        for i,offset in enumerate(offsets):
            target=frames/f'{n:03d}-{request["name"].replace(" ","-")}-view-{request["camera"]}-{i}.png'
            stamp=max(0,request['start']+offset-epoch)
            subprocess.run(['ffmpeg','-v','error','-y','-ss',str(stamp),'-i',str(movie),'-frames:v','1',str(target)],check=True,timeout=20)
            row=dict(request,video_time=stamp,file=str(target.relative_to(evidence)),sha256=hashlib.sha256(target.read_bytes()).hexdigest())
            frame=Image.open(target)
            if request['kind']=='sheet':
                row.update(inspect_frame(frame,Image.open(out/f'card_{request["card"]:02d}.tga')))
                if not row['passed']:
                    # A deliberate transition displays neither sheet nor world.
                    # Exclude only the small bottom-right FPS plate.
                    import numpy as np
                    pixels=np.asarray(frame.convert('RGB'))[:-40]
                    quiet=float((pixels.max(axis=2)<20).mean())
                    if quiet>.995 and i<len(offsets)-1:
                        row.update(passed=True,presentation='hidden transition; no world or sheet',black_fraction=quiet)
            else:row['manual_review']='pending'
            rows.append(row)
            thumb=frame.convert('RGB').resize((320,180));panel=Image.new('RGB',(320,210));panel.paste(thumb,(0,30))
            ImageDraw.Draw(panel).text((4,4),f'{n} {request["name"]} v{request["camera"]} +{offset:.2f}',fill='white')
            thumbs.append(panel)
    for page in range((len(thumbs)+23)//24):
        sheet=Image.new('RGB',(1280,1260))
        for i,t in enumerate(thumbs[page*24:(page+1)*24]):sheet.paste(t,((i%4)*320,(i//4)*210))
        sheet.save(evidence/f'contact-{page:02d}.png')
    report=dict(build=requests['build'],video_sha256=hashlib.sha256(movie.read_bytes()).hexdigest(),results=rows,
                sheet_frames=sum(r['kind']=='sheet' for r in rows),
                failed_sheet_frames=sum(r['kind']=='sheet' and not r['passed'] for r in rows),
                world_review='pending manual review',scope='Scene/history cases listed in results; actual native movement/input after debug-assisted fixture setup; opening and next-page samples require exact source IDs')
    report['hidden_transition_frames']=sum('presentation' in r for r in rows)
    (evidence/'render-review.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Transition sheet frames:',report['sheet_frames'],'failures:',report['failed_sheet_frames'],flush=True)
