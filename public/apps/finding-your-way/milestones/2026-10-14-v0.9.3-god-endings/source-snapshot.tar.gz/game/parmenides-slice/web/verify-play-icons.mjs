import { chromium, firefox } from '/home/will/finding-your-way/node_modules/@playwright/test/index.mjs';
import assert from 'node:assert/strict';
import { mkdirSync, writeFileSync } from 'node:fs';

const [base, out] = process.argv.slice(2);
mkdirSync(out, { recursive: true });
const engine = process.env.FYW_BROWSER || 'chromium';
const browser = engine === 'firefox'
  ? await firefox.launch({ headless: false })
  : await chromium.launch({ executablePath: '/usr/bin/google-chrome', headless: true, args: ['--no-sandbox'] });
const results = [];
try {
  for (const [name, width, height] of [['desktop', 1280, 900], ['phone', 390, 844]]) {
    const context = await browser.newContext({ viewport: { width, height: 500 }, reducedMotion: 'no-preference' });
    const page = await context.newPage();
    const errors = [], requests = [];
    page.on('pageerror', error => errors.push(error.message));
    page.on('request', request => requests.push(request.url()));
    await page.goto(base + '/apps/finding-your-way/', { waitUntil: 'networkidle' });
    const paused = await page.locator('.web-play-icon svg').evaluateAll(icons => icons.every(icon => getComputedStyle(icon).animationPlayState === 'paused'));
    assert(paused, 'cycle pauses while disclosure is closed');
    await page.locator('#web-3d-play summary strong').scrollIntoViewIfNeeded();
    await page.waitForFunction(() => document.querySelector('#web-3d-play').open);
    await page.waitForTimeout(550);
    await page.setViewportSize({ width, height });
    const button = page.getByRole('link', { name: 'Play 3D in browser', exact: true });
    await button.scrollIntoViewIfNeeded();
    assert.equal(await button.getAttribute('href'), '/apps/finding-your-way/play/');
    assert.equal(await button.locator('.web-play-icon').getAttribute('aria-hidden'), 'true');
    const samples = [];
    for (const [time, expected] of [[1000, 'play'], [3000, 'temple'], [5000, 'play'], [7000, 'controller'], [9000, 'play'], [11000, 'cube'], [13000, 'play']]) {
      const sample = await button.evaluate((el, time) => {
        for (const icon of el.querySelectorAll('.web-play-icon svg')) {
          for (const animation of icon.getAnimations()) {
            animation.pause();
            animation.currentTime = time;
          }
        }
        const bounds = el.getBoundingClientRect();
        return {
          visible: [...el.querySelectorAll('.web-play-icon svg')].filter(icon => Number(getComputedStyle(icon).opacity) > .99).map(icon => icon.dataset.icon),
          width: bounds.width, height: bounds.height,
        };
      }, time);
      assert.deepEqual(sample.visible, [expected], 'exactly one requested icon at each cycle slot');
      if (samples.length) assert.deepEqual([sample.width, sample.height], [samples[0].width, samples[0].height], 'icon changes do not shift the button');
      samples.push({ time, ...sample });
      if (['temple', 'controller', 'cube'].includes(expected) && time < 12000) await button.screenshot({ path: `${out}/${name}-${expected}.png` });
    }
    await page.emulateMedia({ reducedMotion: 'reduce' });
    const staticTemple = await button.locator('.web-play-icon svg').evaluateAll(icons => ({
      visible: icons.filter(icon => Number(getComputedStyle(icon).opacity) > .99).map(icon => icon.dataset.icon),
      animationCount: icons.reduce((count, icon) => count + icon.getAnimations().length, 0),
    }));
    assert.deepEqual(staticTemple, { visible: ['temple'], animationCount: 0 }, 'changing reduced motion immediately stops cycling on temple');
    await page.emulateMedia({ reducedMotion: 'no-preference' });
    await page.waitForFunction(() => document.querySelector('.web-play-icon .icon-temple').getAnimations().length === 1);
    assert.equal(requests.some(url => /play\/bundles|wf_game\.(js|wasm|data)/.test(url)), false);
    assert.deepEqual(errors, []);
    results.push({ name, samples, staticTemple, cycleRestartsWhenMotionEnabled: true, noEagerGameDownload: true, errors });
    await context.close();
  }
  const context = await browser.newContext({ javaScriptEnabled: false, reducedMotion: 'reduce' });
  const page = await context.newPage();
  await page.goto(base + '/apps/finding-your-way/');
  assert.deepEqual(await page.locator('.web-play-icon svg').evaluateAll(icons => icons.filter(icon => Number(getComputedStyle(icon).opacity) > .99).map(icon => icon.dataset.icon)), ['temple']);
  results.push({ javaScript: false, reducedMotion: true, visible: ['temple'] });
  await context.close();
  writeFileSync(out + '/results.json', JSON.stringify({ base, engine, results, timing: 'CSS animations seeked to each two-second slot in the browser; not a wall-clock playback measurement.' }, null, 2) + '\n');
  console.log(JSON.stringify({ engine, passed: results.length, base }));
} finally {
  await browser.close();
}
