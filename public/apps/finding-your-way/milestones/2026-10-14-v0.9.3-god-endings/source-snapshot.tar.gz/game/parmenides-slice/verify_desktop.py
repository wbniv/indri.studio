"""Exercise the actual native chapter on desktop; no Chromecast access.

Debug transforms arrange encounter fixtures; real native input advances every
argument and confirms the choices. This is not proof of Android gameplay.
"""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from texture_slots import runtime_args

READING_TIMEOUT=float(sys.argv[sys.argv.index('--reading-timeout')+1]) if '--reading-timeout' in sys.argv else 25
INPUT_FRAME_TIMEOUT=float(sys.argv[sys.argv.index('--input-frame-timeout')+1]) if '--input-frame-timeout' in sys.argv else 1.5
if INPUT_FRAME_TIMEOUT<=0:raise ValueError('--input-frame-timeout must be positive')
INPUT_TIMEOUT=float(sys.argv[sys.argv.index('--input-timeout')+1]) if '--input-timeout' in sys.argv else 12
if INPUT_TIMEOUT<=0:raise ValueError('--input-timeout must be positive')
PORT=int(sys.argv[sys.argv.index('--debug-port')+1]) if '--debug-port' in sys.argv else 7814
TAP_FRAMES=int(sys.argv[sys.argv.index('--tap-frames')+1]) if '--tap-frames' in sys.argv else 5
if TAP_FRAMES<1:raise ValueError('--tap-frames must be positive')
RECORDING=any(flag in sys.argv for flag in ('--render-panels','--render-worlds','--visual-baseline','--art-proof')) and not any(flag in sys.argv for flag in ('--art-stills','--world-stills'))
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'build'
if '--build-dir' in sys.argv:OUT=Path(sys.argv[sys.argv.index('--build-dir')+1]).resolve()
EVIDENCE=ROOT.parents[1]/'docs/diagnostics/parmenides/endings/desktop'
if '--visual-baseline' in sys.argv:EVIDENCE=ROOT.parents[1]/'docs/diagnostics/parmenides/visual-baseline-review/desktop'
if '--visual-states' in sys.argv:EVIDENCE=EVIDENCE/'history-states'
if '--history-only' in sys.argv:EVIDENCE=EVIDENCE/sys.argv[sys.argv.index('--history-only')+1]
if '--fixture-probe' in sys.argv:EVIDENCE=ROOT.parents[1]/'docs/diagnostics/parmenides/visual-baseline-review/fixture-probes'/OUT.name
if '--transition-safety' in sys.argv:EVIDENCE=ROOT.parents[1]/'docs/diagnostics/parmenides/visual-baseline-review/transition-safety'
if '--endings-only' in sys.argv:EVIDENCE=EVIDENCE/'ending-routes'
if '--ending-smoke' in sys.argv:EVIDENCE=EVIDENCE/'ending-smoke'
if '--render-panels' in sys.argv:EVIDENCE=EVIDENCE/'panel-render'
if '--render-worlds' in sys.argv:EVIDENCE=EVIDENCE/'world-render'
if '--render-worlds' in sys.argv and '--world-only' in sys.argv:EVIDENCE=EVIDENCE/sys.argv[sys.argv.index('--world-only')+1]
if '--ending-visual' in sys.argv:EVIDENCE=EVIDENCE/'ending-visual'
if '--god-only' in sys.argv:EVIDENCE=EVIDENCE/'god-routes'
if '--supplemental-text' in sys.argv:EVIDENCE=EVIDENCE/'supplemental-text'
if '--evidence' in sys.argv:EVIDENCE=Path(sys.argv[sys.argv.index('--evidence')+1]).resolve()
EVIDENCE.mkdir(parents=True,exist_ok=True)
RECORDING_CWD=EVIDENCE if "--isolated-recording" in sys.argv else OUT
WF=Path(os.environ.get('FYW_WF_ROOT','/home/will/WorldFoundry-wbniv'))
sys.path.insert(0,str(WF/'tests'))
from debug_bridge_client import BridgeClient

ids=json.loads((OUT/'actors.json').read_text())['ids']
content=json.loads((OUT/'content.json').read_text())
groups=content['groups']
cards={card['id']:card for card in content['cards']}
BUILD_RECEIPT=json.loads((OUT/('build-receipt.json' if (OUT/'build-receipt.json').exists() else 'level-receipt.json')).read_text())
(EVIDENCE/'build-receipt.json').write_text(json.dumps(BUILD_RECEIPT,indent=2)+'\n')
player=ids['Player']
results=[]
transcripts=[]
art_captures=[]
env=dict(os.environ,DISPLAY=os.environ.get('DISPLAY',':0'),LD_LIBRARY_PATH=str(WF/'engine/libs'))
log=(EVIDENCE/'engine.log').open('w')
runtime=Path(sys.argv[sys.argv.index('--desktop-runtime')+1]).resolve() if '--desktop-runtime' in sys.argv else WF/'engine/wf_game'
import hashlib
provenance=json.loads((OUT/'runtime-provenance.json').read_text()) if (OUT/'runtime-provenance.json').exists() else {'desktopExecutableSha256':None}
# --unpinned-runtime lets an engine proposal (e.g. the v0.8 release-defines build) run the same
# harness; the executable hash is then recorded in run-state.json with pinned=false.
PINNED=hashlib.sha256(runtime.read_bytes()).hexdigest()==provenance['desktopExecutableSha256']
SCRIPTED_POSITION='--scripted-position' in sys.argv
if SCRIPTED_POSITION:
    hook=json.loads((OUT/'verifier-hook-receipt.json').read_text())
    if hashlib.sha256((OUT/'parmenides_slice-standalone.iff').read_bytes()).hexdigest()!=hook['levelSha256']:
        raise RuntimeError('Scripted verifier fixture differs from its compiled level receipt')
if not PINNED and '--unpinned-runtime' not in sys.argv:
    raise RuntimeError('Desktop executable differs from this build provenance; use the isolated pinned runtime')
proc=subprocess.Popen([str(runtime),'-L'+str(OUT/'parmenides_slice-standalone.iff'),*(['-record_video'] if RECORDING else []),
    '--debug-port',str(PORT),'--debug-bind','127.0.0.1','--debug-print-actors','-width=1280','-height=720',
    *runtime_args(OUT)],cwd=RECORDING_CWD,env=env,stdout=log,stderr=subprocess.STDOUT)
b=None
run_state=dict(status='running',harness_pid=os.getpid(),runtime_pid=proc.pid,
    apk_sha256=BUILD_RECEIPT['sha256'],
    desktop_sha256=hashlib.sha256(runtime.read_bytes()).hexdigest(),pinned=PINNED,arguments=sys.argv[1:])
(EVIDENCE/'run-state.json').write_text(json.dumps(run_state,indent=2)+'\n')
def value(m):return b.mailbox_values.get((player,m))
def check(label,condition):
    results.append({'check':label,'passed':bool(condition)})
    print(label,condition,flush=True)
    if not condition:raise AssertionError(label)
def tap(bit=1,frames=TAP_FRAMES):
    # Select advances on release. A wall-clock delay can expire before five
    # native frames when the desktop stalls; wait for the actual input cycle.
    # Older events are skipped by this input cycle and mailbox_values already
    # retains their latest state. Discard them between cycles, never mid-wait,
    # so long story runs do not accumulate every watched mailbox broadcast.
    with b._lock:
        b._inbox.clear()
        start=0
    b.inject_input('joystick1_raw',bit,frames)
    # Rendering can temporarily run at one frame per second on this desktop.
    # A movement hold needs its full frame count before release is observable.
    deadline=time.monotonic()+max(INPUT_TIMEOUT,frames*INPUT_FRAME_TIMEOUT)
    pressed=False
    while time.monotonic()<deadline:
        with b._lock:
            messages=b._inbox[start:]
            start=len(b._inbox)
        for message in messages:
            if message.get('op')=='mailbox' and message.get('idx')==player and message.get('mailbox')==111:
                if int(message['value']) & bit:pressed=True
                elif pressed:
                    # Visibility broadcasts follow the released-input update.
                    time.sleep(.1)
                    return
        time.sleep(.01)
    check('native input press/release observed '+str(bit),False)
def snap(name):
    target=EVIDENCE/(name+'.png')
    target.unlink(missing_ok=True)
    b.send({'op':'screenshot','filename':str(target)});time.sleep(.4)
def capture_window(name,warmup=False):
    target=(EVIDENCE if '--art-proof' in sys.argv or '--evidence' in sys.argv else ROOT.parents[1]/'docs/diagnostics/parmenides/endings/rendered')/(name+'.png')
    target.parent.mkdir(parents=True,exist_ok=True)
    before=value(110) or 0
    deadline=time.monotonic()+8
    while (value(110) or 0)<before+.2 and time.monotonic()<deadline:time.sleep(.05)
    time.sleep(.4)
    if '--art-proof' in sys.argv:
        deadline=time.monotonic()+READING_TIMEOUT
        while time.monotonic()<deadline:
            actual=[b.mailbox_values.get((ids['Camera'],m)) for m in (3009,3010,3011)]
            shot=[b.mailbox_values.get((ids['FollowShot'],m)) for m in (3009,3010,3011)]
            origin=[b.mailbox_values.get((ids['CamTarget'],m)) for m in (3009,3010,3011)]
            pos=[value(m) for m in (3009,3010,3011)]
            if all(x is not None for x in actual+shot+origin+pos) and max(abs(a-s+o-p) for a,s,o,p in zip(actual,shot,origin,pos))<.04:break
            time.sleep(.04)
        else:raise AssertionError('Art capture camera did not settle')
        time.sleep(.2)
        if '--art-stills' in sys.argv:
            from verify_panel_render import capture_presented
            if warmup:
                scratch=target.with_name(target.stem+'-warmup.png')
                capture_presented(scratch,b,timeout=READING_TIMEOUT)
                scratch.unlink()
            capture_presented(target,b,timeout=READING_TIMEOUT)
            art_captures.append(dict(file=name+'.png',camera=value(101),realm=value(102),sha256=hashlib.sha256(target.read_bytes()).hexdigest(),player_position=[value(m) for m in (3009,3010,3011)]))
            return
        # Recording renders to an FBO; screenshot_done reads a stale default
        # framebuffer. Extract this settled pose from the recorded FBO instead.
        art_captures.append(dict(file=name+'.png',wall_time=time.time(),camera=value(101),realm=value(102),
                                 player_position=[value(m) for m in (3009,3010,3011)]))
        before=value(110);deadline=time.monotonic()+8
        while value(110)<before+.3 and time.monotonic()<deadline:time.sleep(.04)
        return
    from verify_panel_render import capture_presented
    if '--ending-visual' in sys.argv:
        from PIL import Image
        for attempt in range(4):
            capture_presented(target,b)
            with Image.open(target) as frame:
                if frame.convert('RGB').getbbox() is not None:
                    break
            time.sleep(1.0)
        else:
            raise AssertionError('Ending visual capture contains no rendered pixels: '+name)
    else:
        capture_presented(target,b)
def position(x,y,z=None):
    if z is None:
        z=.16
        if 360<x<450:
            from god_scene import height
            z=height(y)+.16
    if SCRIPTED_POSITION:
        position.sequence=getattr(position,'sequence',0)+1
        for mailbox,coordinate in ((477,x),(478,y),(479,z)):
            b.set_mailbox(mailbox,coordinate,idx=player)
        b.set_mailbox(476,position.sequence,idx=player)
        deadline=time.monotonic()+30
        while value(475)!=position.sequence and time.monotonic()<deadline:
            time.sleep(.02)
        if value(475)!=position.sequence:
            raise AssertionError(f'Level-script teleport {position.sequence} to {(x,y,z)} was not acknowledged')
        time.sleep(.1)
        return
    b.send({'op':'scene:set_transform','idx':player,'pos':[x,y,z]});time.sleep(.4)
def read_pages(label,expected,terminal=0):
    if content.get('runtime_dialogue'):
        beats={beat['id']:beat for beat in content['runtime_beats']}
        owner={legacy:beat['id'] for beat in beats.values() for legacy in beat['legacy_card_ids']}
        semantic=[]
        for legacy in expected:
            beat=owner[legacy]
            if not semantic or semantic[-1]!=beat:semantic.append(beat)
        observed=[];display_pages=[]
        for beat in semantic:
            wait_readable(label+' rendered semantic beat '+str(beat),beat)
            pages=int(value(630));check(label+' bounded display pagination '+str(beat),pages>0 and value(629)==0)
            for page in range(pages):
                deadline=time.monotonic()+READING_TIMEOUT
                while (value(140)!=beat or value(629)!=page or value(632)!=beat) and time.monotonic()<deadline:time.sleep(.02)
                check(label+' exact display page '+str(beat)+':'+str(page),value(140)==beat and value(629)==page and value(632)==beat)
                check(label+' scene suppressed during reading',not any(value(m)!=0 for m in json.loads((OUT/'visual-gates.json').read_text()).values()))
                display_pages.append({'beat':beat,'page':page,'pages':pages});tap()
            observed.append(beat)
        deadline=time.monotonic()+READING_TIMEOUT
        while value(140)!=terminal and time.monotonic()<deadline:time.sleep(.02)
        check(label+' exact semantic order and correct stop',observed==semantic and value(140)==terminal)
        transcripts.append({'interaction':label,'camera':value(101),'beats':observed,'display_pages':display_pages,
                            'text':[beats[beat]['text'] for beat in observed]})
        if terminal:wait_readable(label+' terminal becomes readable',terminal)
        return
    observed=[]
    for expected_id in expected:
        if content.get('visual_fixes') and value(140):
            deadline=time.monotonic()+READING_TIMEOUT
            stable=None
            while time.monotonic()<deadline:
                active_now=[index for index in cards if bool(value(cards[index].get('visibility_mailbox',260+index)))]
                if value(129) and active_now==[expected_id]:
                    if stable is None:stable=time.monotonic()
                    if time.monotonic()-stable>=.25:break
                else:stable=None
                time.sleep(.02)
            if stable is None:
                print('Reading diagnostic:',dict(clock=value(110),ready=value(129),active=active_now,player=[value(m) for m in (3009,3010,3011)],actors={name:[b.mailbox_values.get((ids[name],m)) for m in (3009,3010,3011)] for name in ('Camera','FollowShot','CamTarget','LookAt')}),flush=True)
            check(label+' reading view ready for page '+str(expected_id),stable is not None and time.monotonic()-stable>=.25)
        actual=value(140)
        observed.append(actual)
        active=[index for index in cards if bool(value(cards[index].get('visibility_mailbox',260+index)))]
        if actual and any(value(m)!=0 for m in json.loads((OUT/'visual-gates.json').read_text()).values()):
            check(label+' world meshes suppressed during reading',False)
        if active!=[expected_id]:
            print({'expected':expected_id,'dialogue':actual,'visible_panels':active,'raw_input':value(111)},flush=True)
            check(label+' only the intended rendered panel',False)
        if actual!=expected_id:
            check(label+' exact page order',False)
        tap()
    transcripts.append({'interaction':label,'camera':value(101),'cards':observed,
                        'text':[cards[index]['text'] for index in observed],
                        'sources':[cards[index]['source'] for index in observed]})
    if terminal and value(140)==terminal and content.get('visual_fixes'):
        deadline=time.monotonic()+READING_TIMEOUT
        while not value(129) and time.monotonic()<deadline:time.sleep(.03)
        check(label+' terminal reading view becomes ready',bool(value(129)))
    # Mailbox notifications arrive separately. A released-input notification
    # is not a barrier for the page and visibility updates later in that frame.
    initial_terminal=dict(card=value(140),active=[index for index in cards if bool(value(cards[index].get('visibility_mailbox',260+index)))])
    wanted=[terminal] if terminal else []
    deadline=time.monotonic()+5
    while (value(140)!=terminal or [index for index in cards if bool(value(cards[index].get('visibility_mailbox',260+index)))]!=wanted) and time.monotonic()<deadline:
        time.sleep(.02)
    transcripts[-1]['initial_terminal_notifications']=initial_terminal
    transcripts[-1]['final_terminal_notifications']=dict(card=value(140),active=[index for index in cards if bool(value(cards[index].get('visibility_mailbox',260+index)))])
    if value(140)!=terminal:print({'terminal_expected':terminal,'initial':initial_terminal,'actual':value(140),'ready':value(129)},flush=True)
    check(label+' intended text only, correct stop',observed==expected and value(140)==terminal and [index for index in cards if bool(value(cards[index].get('visibility_mailbox',260+index)))]==([terminal] if terminal else []))
def read_argument(x,y,key,flag,following=()):
    position(x,y);tap();check('argument opens',value(140)>0)
    read_pages(key,groups[key]+[index for extra in following for index in groups[extra]])
    check('complete encounter '+str(flag),value(flag)==1)
def advance_partial():
    # A single runtime page delivers the complete passage on Continue.
    # Cancel before that input; otherwise advance into a later display page.
    if not content.get('runtime_dialogue') or int(value(630))>1:tap()

def wait_readable(label,card):
    # Cancel/reopen intentionally starts a hidden presentation interval.
    # A test intending to read/advance must observe that page before Select.
    deadline=time.monotonic()+READING_TIMEOUT
    stable=None
    while time.monotonic()<deadline:
        active=[index for index in cards if bool(value(cards[index].get('visibility_mailbox',260+index)))]
        if value(140)==card and value(129) and ((value(632)==card and value(630)>0) if content.get('runtime_dialogue') else active==[card]):
            if stable is None:stable=time.monotonic()
            if time.monotonic()-stable>=.25:break
        else:stable=None
        time.sleep(.02)
    check(label,stable is not None and time.monotonic()-stable>=.25)
try:
    startup_timeout=float(sys.argv[sys.argv.index('--startup-timeout')+1]) if '--startup-timeout' in sys.argv else 12
    b=BridgeClient(port=PORT,timeout=startup_timeout)
    for m in [100,101,102,103,104,105,106,107,108,110,111,112,114,130,140,150,151,152,153,154,155,156,157,475,
              129,629,630,631,632,160,161,162,163,164,226,228,229,230,234,242,243,244,245,247,248,250,251,252,3009,3010,3011,3014]:b.watch(player,m)
    for m in list(range(170,180))+[180,181,182,184,185,186,187,206,208,209,210,211]+[cards[index].get('visibility_mailbox',260+index) for index in cards]:b.watch(player,m)
    b.watch(player,420)
    for m in range(188,226):b.watch(player,m)
    for m in range(253,260):b.watch(player,m)
    for m in json.loads((OUT/'visual-gates.json').read_text()).values():b.watch(player,m)
    for name in ('Camera','FollowShot','CamTarget','LookAt'):
        for m in (3009,3010,3011):b.watch(ids[name],m)
    deadline=time.monotonic()+20
    while value(100)!=1 and time.monotonic()<deadline and proc.poll() is None:time.sleep(.1)
    time.sleep(.3)
    check('chapter initializes',value(100)==1)
    if '--fixture-probe' in sys.argv:
        time.sleep(.5)
        check('diagnostic tour compiles without runtime failure',proc.poll() is None and 'zforth compile error' not in (EVIDENCE/'engine.log').read_text())
        raise SystemExit(0)
    snap('intro');read_pages('intro',groups['intro']);check('intro dismisses',value(140)==0)
    if '--truth-counsel-safety' in sys.argv:
        for mode in (0,1):
            for mailbox,answer in [(101,mode),(102,3),(107,1),(155,1),(156,1),
                                   *[(m,1) for m in range(170,176)],(176,0),(177,0),(178,0),(187,1)]:
                b.set_mailbox(mailbox,answer,idx=player)
            position(293,16);tap()
            confirmation=groups['truth_affirm'][0]
            check('counsel fixture confirmation opens view '+str(mode),value(140)==confirmation)
            tap(16384);check('counsel fixture cancellation does not commit',value(140)==0 and value(176)==0)
            tap()
            wait_readable('reopened confirmation becomes readable view '+str(mode),confirmation)
            tap();check('Being counsel starts before commitment view '+str(mode),value(140)==groups['truth_counsel_being'][0] and value(176)==0)
            wait_readable('counsel becomes readable view '+str(mode),groups['truth_counsel_being'][0])
            advance_partial();tap(16384)
            check('mid-counsel cancellation is safe view '+str(mode),value(140)==0 and value(176)==0 and value(177)==0)
        raise SystemExit(0)
    if '--realm-visibility' in sys.argv:
        from verify_realm_visibility import run
        run(b,player,value,check,tap,position,OUT,EVIDENCE)
        raise SystemExit(0)
    if '--art-proof' in sys.argv:
        if '--polish-art' in sys.argv:
            from verify_polish_art import run
        elif '--endings-art' in sys.argv:
            from verify_endings_art import run
        elif '--aether-camera' in sys.argv:
            from verify_aether_camera import run
        elif '--god-art' in sys.argv:
            from verify_god_art import run
        elif '--reason-truth-art' in sys.argv:
            from verify_reason_truth import run
        else:
            from verify_art_motion import run
        run(b,player,value,check,tap,position,read_pages,groups,ids,OUT,EVIDENCE,capture_window)
        check('art proof native process alive',proc.poll() is None)
        raise SystemExit(0)
    if '--dialogue-camera-regression' in sys.argv:
        from verify_dialogue_camera import run
        run(b,player,value,check,tap,position,ids,OUT,EVIDENCE)
        raise SystemExit(0)
    if '--transition-safety' in sys.argv:
        from verify_transition_safety import run
        run(b,player,value,check,tap,position,read_pages,groups)
        raise SystemExit(0)
    if '--supplemental-text' in sys.argv:
        position(3,3);tap();read_pages('goddess before Love',groups['intro'])
        tap(4);read_pages('journal',groups['journal'])
        tap(4);check('journal can reopen',value(140)==groups['journal'][0]);tap(4)
        check('journal closes without other text',value(140)==0)
        from verify_god import run_safety
        run_safety(b,player,value,check,tap,position,read_pages,groups)
        check('native process alive',proc.poll() is None)
        raise SystemExit(0)
    if '--render-panels' in sys.argv:
        from verify_panel_render import run
        run(b,player,value,check,tap,position,cards,content,ids,OUT,EVIDENCE)
        raise SystemExit(0)
    if '--render-worlds' in sys.argv:
        from verify_world_render import run
        run(b,player,value,check,tap,position,OUT,EVIDENCE)
        raise SystemExit(0)
    if '--visual-baseline' in sys.argv:
        from verify_visual_baseline import run
        run(b,player,value,check,tap,position,OUT,EVIDENCE)
        raise SystemExit(0)
    if '--ending-visual' in sys.argv:
        from verify_ending_visual import run
        run(b,player,value,check,tap,position,read_pages,groups,ids,capture_window)
        raise SystemExit(0)
    if '--endings-only' in sys.argv or '--ending-smoke' in sys.argv:
        from verify_endings import run
        run(b,player,value,check,tap,position,read_pages,groups,content,ids,proc,smoke='--ending-smoke' in sys.argv,capture=capture_window if '--ending-smoke' in sys.argv else None)
        raise SystemExit(0)
    if '--god-only' in sys.argv:
        from verify_god import run
        history=sys.argv[sys.argv.index('--god-history')+1] if '--god-history' in sys.argv else None
        if history is not None and (len(history)!=1 or history not in 'abcdefghijklmnop'):
            raise ValueError('--god-history must be a single letter a through p')
        camera=int(sys.argv[sys.argv.index('--god-camera')+1]) if '--god-camera' in sys.argv else None
        if camera is not None and camera not in (0,1):
            raise ValueError('--god-camera must be 0 or 1')
        run(b,player,value,check,tap,position,read_pages,read_argument,groups,content,proc,history,camera)
        raise SystemExit(0)
    snap('temple-third-person')
    position(7,8);tap();check('Reason gated before Love',value(140)==groups['reason_unavailable'][0]);read_pages('Reason prerequisite',groups['reason_unavailable'])
    tap(2);check('first person',value(101)==1);snap('temple-first-person')
    tap(2);check('third person',value(101)==0)
    start=value(3010);tap(2048,60);time.sleep(.9)
    check('native forward movement',value(3010)>start+.2)
    position(0,8);tap();check('physical Love portal',value(102)==1)
    snap('love-street')
    position(94,11);tap();check('choice gated before encounters',value(140)==16);read_pages('Love early choice gate',groups['locked'])
    read_argument(96,1,'first',103)
    check('First Love departs with label',value(251)==0 and value(247)==0)
    read_argument(104,2,'starlet',104)
    check('starlet departs with label',value(252)==0 and value(248)==0)
    position(100,6);tap();snap('newspaper');read_pages('newspaper',groups['paper']);check('paper completes',value(105)==1)
    position(100,-8);tap();check('Temple return does not commit Love',value(102)==0 and value(106)==0)
    position(7,8);tap();check('Reason requires commitment after all encounters',value(140)==groups['reason_unavailable'][0]);read_pages('Reason after uncommitted Love',groups['reason_unavailable'])
    position(0,8);tap();check('unfinished Love retains all encounters',value(102)==1 and all(value(m)==1 for m in (103,104,105)))
    position(94,11);tap();check('Being confirmation',value(140)==14);read_pages('Love Being confirmation',groups['affirm'],groups['return_being'][0])
    check('Being committed',value(107)==1 and value(106)==1 and value(102)==0)
    snap('temple-return-being');read_pages('Love Being return',groups['return_being'])
    position(3,3);tap();read_pages('goddess after Love Being',groups['return_being'])
    position(0,8);tap();check('Love replay resets encounters',value(103)==0 and value(104)==0 and value(105)==0)
    check('Love replay clears prior commitment',value(106)==0 and value(107)==0)
    check('Love replay restores both speakers and labels',all(value(m)!=0 for m in (251,252,247,248)))
    read_argument(96,1,'first',103);read_argument(104,2,'starlet',104);position(100,6);tap();read_pages('newspaper replay',groups['paper'])
    position(106,11);tap();check('NotBeing confirmation',value(140)==15);read_pages('Love NotBeing confirmation',groups['deny'],groups['return_notbeing'][0])
    check('NotBeing committed',value(107)==-1 and value(102)==0)
    snap('temple-return-notbeing');read_pages('Love NotBeing return',groups['return_notbeing'])
    position(3,3);tap();read_pages('goddess after Love NotBeing',groups['return_notbeing'])
    tap(8);check('reduced motion',value(108)==1)
    tap(4);check('journal',value(140)==19);tap(4);check('journal closes without choice',value(140)==0)
    tap(1,50);time.sleep(.8);check('remote held Select switches perspective',value(101)==1)
    for mode in (0,1):
        if value(101)!=mode:tap(2)
        for love,reason,history in ((1,1,'5a'),(1,-1,'5b'),(-1,1,'5c'),(-1,-1,'5d')):
            prefix=f'{history} camera={mode}: '
            # Both Love choices were played above. These fixtures select the prior history.
            b.set_mailbox(107,love,idx=player);time.sleep(.2)
            position(7,8);tap();check(prefix+'Reason portal',value(102)==2)
            check(prefix+'replay resets encounters',all(value(m)==0 for m in (150,151,152,153,154,155,156,157)))
            position(193,13);tap();check(prefix+'early commitment gated',value(140)==groups['reason_locked'][0]);read_pages(prefix+'early gate',groups['reason_locked'])
            position(200,10);tap();check(prefix+'child waits for both accounts',value(140)==groups['reason_wait'][0]);read_pages(prefix+'child waiting',groups['reason_wait'])
            position(196,1);tap();check(prefix+'White opens',value(140)==groups['white'][0])
            check(prefix+'world labels hidden under dialogue',all(value(m)==0 for m in (242,243,244,245)))
            read_pages(prefix+'White and grove',groups['white']+groups['grove'])
            check(prefix+'White and grove completed',value(150)==1 and value(140)==0 and value(163)!=0 and value(160)==0)
            if mode==0 and history=='5a':
                position(200,-8);tap();check('Reason return does not commit',value(102)==0 and value(154)==0)
                position(7,8);tap();check('unfinished Reason retains White and grove',value(102)==2 and value(150)==1 and value(163)!=0)
            read_argument(204,7,'wild',151)
            position(200,10);tap();check(prefix+'child still waits for apparatus',value(140)==groups['reason_wait'][0]);read_pages(prefix+'child still waiting',groups['reason_wait'])
            read_argument(200,3,'apparatus_order',152,('apparatus_limit',))
            check(prefix+'apparatus changes without choosing',value(157)==1 and value(164)!=0 and value(154)==0 and value(155)==0)
            read_argument(200,11,'child',153)
            position(193 if reason==1 else 207,13);tap()
            confirmation=groups['reason_affirm' if reason==1 else 'reason_deny'][0]
            check(prefix+'explicit confirmation',value(140)==confirmation)
            tap(16384);check(prefix+'Left cancels without committing',value(140)==0 and value(154)==0)
            tap();check(prefix+'confirmation reopens',value(140)==confirmation)
            read_pages(prefix+'chosen conclusion',groups['reason_affirm' if reason==1 else 'reason_deny']+
                       groups['why_axis' if reason==1 else 'rain_reply'],groups['return_'+history][0])
            check(prefix+'correct Temple history',value(102)==0 and value(154)==1 and value(155)==reason and
                  value(156)==int(history[-1],36)-9 and value(140)==groups['return_'+history][0])
            check(prefix+'source-correct walls and windows',bool(value(228))==(reason==1) and bool(value(229))==(reason==1))
            check(prefix+'Love tapestries retained',bool(value(234))==(love==1) and value(230)==0)
            check(prefix+'Truth portal enabled',value(226)!=0)
            check(prefix+'return labels hidden',value(242)==0)
            read_pages(prefix+'Temple return',groups['return_'+history])
            check(prefix+'labels restore after overlay',value(140)==0 and value(242)!=0)
            position(3,3);tap();read_pages(prefix+'goddess return replay',groups['return_'+history])
            position(-7,8);tap();check(prefix+'Truth opens courtroom',value(102)==3 and value(140)==groups['truth_intro'][0]);read_pages(prefix+'courtroom intro',groups['truth_intro']);position(300,-8);tap();check(prefix+'uncommitted Truth returns',value(102)==0 and value(176)==0)
    for mode in (0,1):
        if value(101)!=mode:tap(2)
        for index,suffix in enumerate('abcdefgh'):
            love=1 if index<4 else -1
            reason=1 if index%4<2 else -1
            truth=1 if index%2==0 else -1
            history='7'+suffix
            prefix=f'{history} camera={mode}: '
            # Prior Love/Reason routes were played above; choose their state fixture.
            for mailbox,answer in ((107,love),(155,reason),(156,index//2+1)):
                b.set_mailbox(mailbox,answer,idx=player)
            time.sleep(.2)
            position(-7,8);tap();check(prefix+'Truth portal',value(102)==3)
            check(prefix+'fresh encounter/result state',all(value(m)==0 for m in range(170,179)))
            if value(140):read_pages(prefix+'courtroom intro',groups['truth_intro'])
            position(293,16);tap();read_pages(prefix+'early choice gate',groups['truth_locked'])
            position(306,1);tap();read_pages(prefix+'defence waits for prosecutor',groups['truth_wait'])
            position(300,5);tap();read_pages(prefix+'student waits for both lawyers',groups['truth_wait'])
            position(294,6);tap();read_pages(prefix+'exhibit waits for student',groups['truth_wait'])
            read_argument(294,1,'prosecutor',170)
            check(prefix+'prosecution does not complete defence',value(171)==0 and value(176)==0)
            if mode==0 and index==0:
                position(300,-8);tap();check('Truth return without verdict',value(102)==0 and value(176)==0)
                position(-7,8);tap();check('unfinished Truth preserves prosecution and intro',value(170)==1 and value(171)==0 and value(140)==0)
            read_argument(306,1,'defence',171)
            read_argument(300,5,'student',172)
            check(prefix+'lawyers leave when student scene completes',value(180)==0 and value(181)==0 and value(185)==0 and value(186)==0 and value(182)!=0)
            read_argument(294,6,'facts',173)
            position(300,10);tap();read_pages(prefix+'presentation needs both exhibits',groups['truth_locked'])
            read_argument(306,6,'interpretations',174)
            check(prefix+'exhibits do not choose a philosophy',value(175)==0 and value(176)==0 and value(177)==0)
            position(307,16);tap();read_pages(prefix+'choice still needs presentation',groups['truth_locked'])
            read_argument(300,10,'present',175)
            check(prefix+'presentation token and no auto-verdict',value(187)!=0 and value(176)==0 and value(177)==0)
            position(293 if truth==1 else 307,16);tap()
            confirmation=groups['truth_affirm' if truth==1 else 'truth_deny']
            counsel=groups['truth_counsel_being' if truth==1 else 'truth_counsel_notbeing']
            check(prefix+'correct threshold confirmation',value(140)==confirmation[0])
            check(prefix+'all labels hidden under modal',all(value(m)==0 for m in (242,184,185,186,209)))
            tap(16384);check(prefix+'cancel does not commit',value(140)==0 and value(176)==0)
            tap()
            if mode==0 and index==0:
                wait_readable('reopened Truth confirmation becomes readable',confirmation[0])
                tap();check('Being counsel starts before commitment',value(140)==counsel[0] and value(176)==0)
                wait_readable('Being counsel becomes readable before cancellation probe',counsel[0])
                advance_partial();tap(16384);check('mid-counsel cancellation is safe',value(140)==0 and value(176)==0 and value(177)==0)
                tap()
            read_pages(prefix+'selected counsel',confirmation+counsel,groups['return_'+history][0])
            check(prefix+'correct eight-way Temple history',value(102)==0 and value(176)==1 and value(177)==truth and value(178)==index+1)
            check(prefix+'earlier interpretations preserved',value(107)==love and value(155)==reason)
            check(prefix+'foundation and mosaic follow source',bool(value(206))==(truth==1) and
                  bool(value(210))==(truth==1 and reason==1) and bool(value(211))==(truth==1 and reason==-1))
            check(prefix+'walls/windows and tapestries retain history',bool(value(228))==(reason==1) and bool(value(229))==(reason==1) and bool(value(234))==(love==1))
            check(prefix+'God portal enabled',value(208)!=0)
            read_pages(prefix+'Temple return',groups['return_'+history])
            position(3,3);tap();read_pages(prefix+'goddess exact history response',groups['return_'+history])
            start=value(3010);tap(2048,15);time.sleep(.35)
            check(prefix+'Temple remains traversable',value(3010)>start+.1 and value(3011)>-.2)
            position(0,-8);tap();check(prefix+'God opens hill',value(102)==4)
            read_pages(prefix+'God onboarding',groups['god_intro'])
            position(400,-8);tap();check(prefix+'God return without choice',value(102)==0 and value(195)==0)
    position(7,8);tap()
    check('Reason replay clears all downstream Truth progress',value(102)==2 and all(value(m)==0 for m in range(170,180)))
    position(200,-8);tap()
    position(-7,8);tap();read_pages('Truth locked again after Reason replay',groups['truth_unavailable'])
    position(0,8);tap()
    check('Love replay clears all downstream Reason progress',value(102)==1 and all(value(m)==0 for m in (150,151,152,153,154,155,156,157)))
    check('Love replay clears all downstream Truth progress',all(value(m)==0 for m in range(170,180)))
    if '--realms-only' in sys.argv:
        check('Love/Reason/Truth native process alive',proc.poll() is None)
        raise SystemExit(0)
    from verify_god import run
    run(b,player,value,check,tap,position,read_pages,read_argument,groups,content,proc)
    from verify_endings import run
    run(b,player,value,check,tap,position,read_pages,groups,content,ids,proc)
    if not content.get('visual_fixes'):
        check('v0.5 known clipping and obscuring issues retained for v0.5.5',not json.loads((OUT/'visual-gates.json').read_text()))
    elif content.get('runtime_dialogue'):
        check('runtime chapter exports glyphs instead of panel actors',not any(name.startswith('card_') for name in ids))
    elif '--reuse-panel-render' not in sys.argv:
        inherited=(['--unpinned-runtime'] if '--unpinned-runtime' in sys.argv else [])+(
            ['--evidence',str(EVIDENCE/'panel-render')] if '--evidence' in sys.argv else [])
        subprocess.run([sys.executable,str(ROOT/'verify_desktop.py'),'--render-panels','--debug-port',str(PORT+1),
                        '--build-dir',str(OUT),'--desktop-runtime',str(runtime),*inherited],check=True)
    else:
        rendered=json.loads((EVIDENCE.parent/'panel-render-audit.json').read_text())
        check('matching completed pixel audit reused',rendered['passed'] and rendered['build']['sha256']==json.loads((OUT/'build-receipt.json').read_text())['sha256'])
    check('native process alive',proc.poll() is None)
finally:
    run_exception=sys.exc_info()[1]
    if b:b.close()
    proc.terminate()
    try:proc.wait(timeout=20 if RECORDING else 5)
    except subprocess.TimeoutExpired:
        proc.kill();proc.wait(timeout=5)
    log.close()
    try:
        if '--render-panels' in sys.argv:
            from verify_panel_render import finalize
            finalize(OUT,EVIDENCE,check,recording_cwd=RECORDING_CWD)
        if '--render-worlds' in sys.argv:
            from verify_world_render import finalize
            finalize(OUT,EVIDENCE)
        if '--visual-baseline' in sys.argv:
            from verify_visual_baseline import finalize
            finalize(OUT,EVIDENCE)
        if '--art-proof' in sys.argv and art_captures and '--art-stills' in sys.argv:
            (EVIDENCE/'capture-manifest.json').write_text(json.dumps(dict(build=BUILD_RECEIPT,shots=art_captures,method='Settled actual native default-framebuffer captures; each acknowledged through the debug bridge; fixture transforms plus real source/movement input'),indent=2)+'\n')
        if '--art-proof' in sys.argv and art_captures and '--art-stills' not in sys.argv:
            import shutil,re
            movie=EVIDENCE/'art-proof.mp4';shutil.copy2(RECORDING_CWD/'output.mp4',movie)
            match=re.search(r'Duration: N/A, start:\s*([0-9.]+)',(EVIDENCE/'engine.log').read_text())
            if not match:raise RuntimeError('Art recording start timestamp missing')
            epoch=float(match.group(1))
            for row in art_captures:
                row['video_time']=row['wall_time']-epoch
                target=EVIDENCE/row['file']
                subprocess.run(['ffmpeg','-v','error','-y','-ss',str(row['video_time']),'-i',str(movie),'-frames:v','1',str(target)],check=True,timeout=15)
                row['sha256']=hashlib.sha256(target.read_bytes()).hexdigest()
            (EVIDENCE/'capture-manifest.json').write_text(json.dumps(dict(build=BUILD_RECEIPT,
                movie_sha256=hashlib.sha256(movie.read_bytes()).hexdigest(),shots=art_captures,
                method='Settled native FBO frames extracted from the recording; fixture transforms plus real source/movement input'),indent=2)+'\n')
    finally:
        (EVIDENCE/'results.json').write_text(json.dumps(results,indent=2)+'\n')
        if '--render-panels' in sys.argv:
            controls=[row for row in results if row['check'].startswith('pixel detector ')]
            audit_path=EVIDENCE.parent/'panel-render-audit.json'
            if len(controls)==5 and audit_path.exists():
                audit=json.loads(audit_path.read_text())
                negative=dict(build=BUILD_RECEIPT,passed=audit['passed'] and all(row['passed'] for row in controls),
                    method='Actual detector controls from the completed native panel finalizer.',results=controls,
                    source_results='panel-run/results.json',
                    source_results_sha256=hashlib.sha256((EVIDENCE/'results.json').read_bytes()).hexdigest(),
                    video_sha256=audit['video_sha256'])
                (EVIDENCE.parent/'body-detector-negative-controls.json').write_text(json.dumps(negative,indent=2)+'\n')
        (EVIDENCE/'transcripts.json').write_text(json.dumps(transcripts,indent=2)+'\n')
        final_exception=sys.exc_info()[1]
        clean_exit=run_exception is None or isinstance(run_exception,SystemExit) and run_exception.code in (None,0)
        passed=clean_exit and final_exception is run_exception and bool(results) and all(row['passed'] for row in results)
        run_state.update(status='completed' if passed else 'failed',checks=len(results),
            error=None if passed else repr(final_exception or run_exception))
        (EVIDENCE/'run-state.json').write_text(json.dumps(run_state,indent=2)+'\n')
