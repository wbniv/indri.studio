"""Matched C/D held-camera workloads; only Player Forth/package version differ.

All native libraries, production mesh and texture inputs remain exact. A common
version code avoids an Android downgrade during coordinator-owned comparisons.
"""
import argparse,hashlib,json,zipfile
from pathlib import Path
import build_review_fixtures as fixtures

def main():
 p=argparse.ArgumentParser();p.add_argument('--source-build',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--label',required=True);a=p.parse_args()
 fixtures.BASE=a.source_build.resolve();production=json.loads((fixtures.BASE/'build-receipt.json').read_text())
 def tour(original,scenes,mode,content):
  scene,realm,x,y,key,history=scenes[0]
  from god_scene import height
  z=height(y)+.16 if realm==4 else .15
  setters=''.join(f'{v} {m} write-mailbox ' for m,v in history.items())
  tail=original.splitlines(keepends=True)[-1];assert tail.startswith('fy-init fy-input ')
  setup=(f': fy-matched-hold 470 read-mailbox 0 = if 1 470 write-mailbox {x} {y} fy-teleport {z} INDEXOF_Z_POS write-mailbox {realm} 102 write-mailbox {mode} 101 write-mailbox .25 114 write-mailbox 0 108 write-mailbox {setters}then fy-stop 0 140 write-mailbox 0 INDEXOF_INPUT write-mailbox ;\n')
  revised=original[:-len(tail)]+setup+tail.replace('fy-input ','fy-input fy-matched-hold ',1)
  return revised,[dict(scene=scene,realm=realm,camera=mode,player_position=[x,y,z],heading=.25,history=history,reduced_motion=False,reading_modal=False,phase='held north-facing camera and player; production decorative motion; no modal/input')]
 fixtures.tour=tour
 common={106:1,107:1,154:1,155:1,156:1,176:1,177:1,178:1,190:1,191:1,192:1,193:1,194:0,188:1}
 variants=[]
 for scene,realm,x,y,extra in [('god-held',4,400,-2,{195:0,196:0,197:0}),('temple-final-held',0,0,-5,{195:1,196:1,197:1})]:
  history={**common,**extra};name=scene+'-comparison'
  for mode in (0,1):
   fixtures.SCENES=[(name,realm,x,y,'intro',history)];fixtures.make(0,mode,scene_only=name,diagnostic_version_code=63)
   source=fixtures.BASE/'review-fixtures'/f'group-0-view-{mode}-{name}'
   r=json.loads((source/'review-receipt.json').read_text());inputs={}
   for path in fixtures.BASE.glob('*'):
    if path.is_file() and (path.suffix=='.tga' or path.suffix=='.iff' and path.name not in ('cd.iff','parmenides_slice.iff','parmenides_slice-standalone.iff')):
     assert (source/path.name).read_bytes()==path.read_bytes(),path.name
     inputs[path.name]=hashlib.sha256(path.read_bytes()).hexdigest()
   with zipfile.ZipFile(r['apk']) as diag,zipfile.ZipFile(production['apk']) as prod:
    assert all(diag.read(n)==prod.read(n) for n in production['nativeLibraries'])
   r.update(duration=None,changed_level_source='Only Player Forth holds matching north-facing no-modal scene; Android versionCode63 for both baseline stages',unchanged_mesh_texture_inputs=inputs,scope='Matched native rendering workload; fixture-selected state, not route or touch proof')
   (source/'comparison-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
   variants.append(dict(label=f'{a.label}-{scene}-view-{mode}',apk=r['apk'],sha256=r['sha256'],production_apk_sha256=production['sha256'],warmup=30,runs=1,receipt=str(source/'comparison-receipt.json')))
 a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(dict(source_build=production,variants=variants),indent=2)+'\n')
if __name__=='__main__':main()
