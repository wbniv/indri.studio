# Proposed visible-game screen hold

- [x] Inspect the current native entry and Android window/policy APIs.
- [x] Prepare the exact engine patch and current-source precondition hash without editing the engine.
- [x] Compile the NDK API shim for arm64 and ARMv7 with API 26 / NDK 26.2.11394342.
- [x] Will explicitly approved the prepared engine change on 2026-10-07.
- [x] Match shared-source precondition and apply the exact patch; preserve existing unrelated engine edits.
- [ ] Rebuild and record new native-library/APK hashes.
- [ ] Verify the visible-game hold, Home/resume and manual lock behavior through owned coordinator sessions.

The proposed change is in `wfsource/source/hal/android/native_app_entry.cc`, function `android_main(struct android_app* app)`, immediately after assigning `gApp`. Add the Android native-activity/window headers and call `ANativeActivity_setWindowFlags(app->activity, AWINDOW_FLAG_KEEP_SCREEN_ON, 0)`. The flag is `0x00000080`; clear-mask zero preserves all existing window flags.

Android holds the screen on and bright while this game window is visible. When the game is hidden, destroyed or closed, window visibility/lifecycle removes that hold; no global timeout or security setting is changed and no secure keyguard is dismissed. Pressing Home returns screen-timeout behavior to the prior app/system. Manual power-button lock must remain effective and must invalidate an active measurement. This covers an idle visible game, including passive reading; it does not protect installation while no game window is visible. The coordinator’s wake requests should therefore remain labeled requests, not proof that idle timeout was reset.

The current engine file already includes runtime diagnostics, property text input and the previously authorized smaller/lower phone joystick. The patch preserves those changes and existing activity entrypoints. Preconditions record the current whole-file SHA-256; apply only after it matches or review any drift. Existing phone touch build/provenance is in `game/parmenides-slice/runtime-fixes/android-touch/source-layout-review.json`; this proposal is a separate delta and requires a new native-library build identity. Archived A/B/C TV APKs and art/CD hashes remain immutable. Package updated native libraries into a separately identified phone build and verify that the source production CD is byte-identical.

The shim verifies NDK declarations and the flag ABI for both shipped architectures. It does not establish a successful modified engine build or actual-device behavior. After authorization, run the existing touch controls checks; build the affected Android native objects and package a new immutable phone APK with its exact source/native provenance. Use owned checks to observe the visible window flag/power state across more than the device’s unchanged idle timeout, prove the app stays foreground and presents frames, then exercise Home/resume and manual screen lock. Retry sustained timing only on a valid, unlocked owned session and preserve failed samples/cleanup proof. Do not classify a SurfaceFlinger or screencap timeout as lock without state evidence.

Primary references: [Android window flag](https://developer.android.com/reference/android/view/WindowManager.LayoutParams#FLAG_KEEP_SCREEN_ON), [AOSP PhoneWindowManager wake-key handling](https://android.googlesource.com/platform/frameworks/base/+/android16-release/services/core/java/com/android/server/policy/PhoneWindowManager.java), and [AOSP input user-activity gating](https://android.googlesource.com/platform/frameworks/native/+/refs/heads/main/services/inputflinger/dispatcher/InputDispatcher.cpp). KEYCODE_WAKEUP clears PASS_TO_USER; the input path gates ordinary user-activity updates on that flag. These source observations do not substitute for checking the Pixel’s actual power state.

The applicable [engine AGENTS.md](/home/will/WorldFoundry-wbniv/AGENTS.md) explicitly requires: “prepare a concrete proposal describing the required engine changes and obtain permission before editing engine code.” Will explicitly approved this prepared delta on 2026-10-07. The shared source precondition matched and the exact patch is now applied; runtime build and device proof remain pending.

Authored with Codex; unavailable model/tool/effort metadata is not inferred.
