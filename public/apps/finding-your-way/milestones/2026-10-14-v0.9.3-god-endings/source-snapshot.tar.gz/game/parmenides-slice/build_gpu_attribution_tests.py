"""Freeze GPU diagnostics without replacing any completed policy-test APK."""
from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile,sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
EVID=ROOT/'docs/diagnostics/parmenides/current-baseline-2026-10-09/gpu-attribution'
OUT=Path('/tmp/wf-gpu-attribution-tests')
WF=Path('/tmp/wf-current-baseline')
TOOLS=Path('/home/will/android-sdk-local/build-tools/34.0.0')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(args):subprocess.run([str(x) for x in args],check=True)
def main():
    OUT.mkdir(exist_ok=True);EVID.mkdir(exist_ok=True)
    lib=OUT/'libwf_game.so';shutil.copyfile(WF/'build-android/libwf_game.so',lib)
    run(['/home/will/android-sdk-local/ndk/26.2.11394342/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip','--strip-unneeded',lib])
    extra=len(sys.argv)>1 and sys.argv[1] in ['materials','solids']
    extra_modes=['no-world-solid'] if extra and sys.argv[1]=='solids' else ['no-world-textured']
    variants=json.loads((EVID/'build-receipt.json').read_text())['variants'] if extra else []
    for fixture,scope,mode in [(f,'current-only',m) for f in ['g2','g3','g4'] for m in (extra_modes if extra else ['native','no-world','no-overlay'])]:
        label=f'{fixture}-{scope}-{mode}'
        if any(v['label']==label for v in variants):continue
        source=json.loads((EVID.parent/'current-room'/f'{fixture}-{scope}-variant.json').read_text())
        path=OUT/label;path.mkdir(exist_ok=True)
        unsigned,aligned,signed=[path/(n+'.apk') for n in ['unsigned','aligned','signed']]
        with zipfile.ZipFile(source['apk']) as zin,zipfile.ZipFile(unsigned,'w') as zout:
            for info in zin.infolist():
                if info.filename.startswith('META-INF/'):continue
                data=zin.read(info.filename)
                if info.filename=='lib/armeabi-v7a/libwf_game.so':data=lib.read_bytes()
                if info.filename=='assets/wf_args.txt':
                    flags=['--gpu-profile']
                    if mode.startswith('no-'):flags+=['--gpu-profile-omit='+mode[3:]]
                    if mode=='half':flags+=['--gpu-profile-scale=0.5']
                    data=(data.decode().strip()+' '+' '.join(flags)+'\n').encode()
                    arguments=data.decode().split()
                zout.writestr(info,data)
        run([TOOLS/'zipalign','-f','4',unsigned,aligned])
        run([TOOLS/'apksigner','sign','--ks',HERE/'build/development-signing.p12','--ks-pass','pass:android','--out',signed,aligned])
        run([TOOLS/'apksigner','verify',signed])
        frozen=path/(label+'-'+sha(signed)[:16]+'.apk');signed.rename(frozen)
        unsigned.unlink();aligned.unlink()
        with zipfile.ZipFile(source['apk']) as a,zipfile.ZipFile(frozen) as b:
            assert a.read('assets/cd.iff')==b.read('assets/cd.iff')
            assert b.getinfo('assets/cd.iff').compress_type==zipfile.ZIP_STORED
            for name in b.namelist():
                if not name.startswith('META-INF/') and name not in ['lib/armeabi-v7a/libwf_game.so','assets/wf_args.txt']:assert a.read(name)==b.read(name)
        v=dict(label=label,fixture=fixture,scope=scope,mode=mode,apk=str(frozen),apk_sha256=sha(frozen),native_sha256=sha(lib),source_apk_sha256=source['apk_sha256'],level_payload_unchanged=True,arguments=arguments)
        variants.append(v);(EVID/(label+'-variant.json')).write_text(json.dumps(v,indent=2)+'\n')
        print(label,frozen,flush=True)
    files=['wfsource/source/gfx/glpipeline/backend_modern.cc','CMakeLists.txt','engine/gpu_profile.hpp','engine/gpu_profile_android.hpp','engine/room_render_settings.hpp','tests/room_render_settings_test.cc','tests/fixtures/room-render-settings','wfsource/source/game/level.cc','wfsource/source/game/level.hp','wfsource/source/game/main.cc','wfsource/source/game/game.cc','wfsource/source/gfx/gl/display.cc','wfsource/source/gfx/gl/android_window.cc']
    run(['git','-C',WF,'add','-N','engine/gpu_profile.hpp','engine/gpu_profile_android.hpp'])
    patch=subprocess.check_output(['git','-C',str(WF),'diff','--binary','HEAD','--',*files])
    (EVID/'engine.patch').write_bytes(patch)
    (EVID/'build-receipt.json').write_text(json.dumps(dict(base_engine_commit=subprocess.check_output(['git','-C',str(WF),'rev-parse','HEAD'],text=True).strip(),native_sha256=sha(lib),engine_patch_sha256=hashlib.sha256(patch).hexdigest(),source_sha256={f:sha(WF/f) for f in files if (WF/f).is_file()},variants=variants),indent=2)+'\n')
if __name__=='__main__':main()
