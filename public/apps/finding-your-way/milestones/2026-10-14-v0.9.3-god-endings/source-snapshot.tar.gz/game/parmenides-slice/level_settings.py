"""Attach authored load-time settings through the existing OAD/RPRP cooker."""
from pathlib import Path
import importlib.util
import json
import shutil
import subprocess

HERE = Path(__file__).resolve().parent

def attach(level, actors, output, engine, scope=None):
    if scope is not None and (type(scope) is not int or scope not in (0, 1)):
        raise ValueError("Room Render Scope must be 0 or 1")
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    engine = Path(engine)
    # prep writes beside its types file; isolate those temporary files per build.
    types = output / 'oas-types'
    types.mkdir(exist_ok=True)
    for name in ['types3ds.s', 'types.h']:
        shutil.copyfile(engine / 'wfsource/source/oas' / name, types / name)
    oad = output / 'settings.oad'
    subprocess.run([str(engine / 'wftools/oas2oad-rs/target/release/oas2oad'),
                    '--types=' + str(types / 'types3ds.s'),
                    '--prep=' + str(engine / 'wftools/prep/prep'),
                    '-o', str(oad), str(HERE / 'settings.oas')], check=True)
    spec = importlib.util.spec_from_file_location('level_catalog', engine / 'scripts/build-object-properties.py')
    cooker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(cooker)
    bindings = json.loads((HERE / 'settings-bindings.json').read_text())
    if scope is not None:
        bindings['fields']['Room Render Scope']['initial'] = str(scope)
    ids = json.loads(Path(actors).read_text())['ids']
    actor = ids[bindings['owner']]
    payload = cooker.catalog(oad, bindings, actor)
    (output / 'settings-bindings.json').write_text(json.dumps(bindings, indent=2) + '\n')
    (output / 'settings.rprp').write_bytes(payload)
    level = Path(level)
    level.write_bytes(cooker.attach(level.read_bytes(), payload))
    receipt=readback(level)
    import hashlib
    receipt.update(owner=bindings['owner'],oasSha256=hashlib.sha256((HERE/'settings.oas').read_bytes()).hexdigest(),oadSha256=hashlib.sha256(oad.read_bytes()).hexdigest(),bindingsSha256=hashlib.sha256((output/'settings-bindings.json').read_bytes()).hexdigest())
    (output/'level-settings-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    return receipt


def readback(level):
    """Validate the packaged catalog and read the authored load-time enum.

    This checks bytes in the final level, not the nearby schema or bindings.
    Observed engine readback is a separate runtime acceptance check.
    """
    import struct
    data=Path(level).read_bytes()
    if len(data)<4096 or data[2048:2052]!=b'RAM\0':
        raise ValueError('Expected standalone level RAM at sector one')
    ram_size=struct.unpack_from('<I',data,2052)[0]
    locator=2056+ram_size-12
    if ram_size<48 or locator+12>len(data) or data[locator:locator+4]!=b'RPRP':
        raise ValueError('Level has no RPRP catalog locator')
    offset,size=struct.unpack_from('<II',data,locator+4)
    start=2048+offset
    if offset<2048 or offset%2048 or size<8 or size%2048 or start+size>len(data) or data[start:start+4]!=b'RPRP':
        raise ValueError('Invalid RPRP locator')
    length=struct.unpack_from('<I',data,start+4)[0]
    if length>size-8:raise ValueError('Invalid catalog length')
    payload=data[start+8:start+8+length]
    if payload[:4]!=b'RP01':raise ValueError('Unsupported property catalog')
    position=4
    def take(n):
        nonlocal position
        if n<0 or position+n>len(payload):raise ValueError('Truncated property catalog')
        result=payload[position:position+n];position+=n;return result
    def integer():return struct.unpack('<I',take(4))[0]
    def text():
        n=integer()
        if n>65536:raise ValueError('Oversized property text')
        return take(n).decode('utf-8')
    count=integer()
    if count>4096:raise ValueError('Too many catalog owners')
    matches=[]
    for _ in range(count):
        actor=integer();schema=text();title=text();field_count=integer()
        if field_count>16384:raise ValueError('Too many catalog fields')
        for _ in range(field_count):
            field,kind,show,readonly,rule,lo,hi,scale,width,max_length=struct.unpack('<IBBBBiiIII',take(28))
            key,label,help,group,choices,value=[text() for _ in range(6)]
            if schema=='LevelRenderSettings' and field==1:
                if key!='Room Render Scope' or kind!=2 or readonly!=1 or lo!=0 or hi!=1 or value not in ('0','1'):
                    raise ValueError('Invalid read-only Room Render Scope enum')
                matches.append(dict(schema=schema,actor=actor,field=field,scope=int(value),readonly=True))
    if position!=len(payload) or len(matches)!=1:raise ValueError('Expected exactly one LevelRenderSettings scope')
    import hashlib
    return dict(matches[0],catalogSha256=hashlib.sha256(payload).hexdigest(),levelSha256=hashlib.sha256(data).hexdigest())
