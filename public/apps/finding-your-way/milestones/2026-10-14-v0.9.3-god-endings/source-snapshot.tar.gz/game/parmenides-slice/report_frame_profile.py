#!/usr/bin/env python3
"""Join coordinator presented-frame evidence with the engine's --frame-profile output.

Each evidence directory is one coordinator profile job (``task chromecast:evidence
JOB=... OUT=<dir>``): ``summary.json`` or ``run-1/summary.json`` holds the
deduplicated SurfaceFlinger presentation statistics for the whole measurement,
``wf.log`` holds the engine log whose ``frame-window:`` / ``frame-profile:`` /
``frame-count:`` blocks are printed every 5 s by
``wfsource/source/game/runtime_profile.hp`` (main-thread CPU time per section,
mean per frame, plus per-frame counters), ``receipt.json`` identifies the job,
device and APK, and ``run-1/meminfo.txt`` / ``run-1/thermal.txt`` give PSS and
thermal status.

``wf.log`` accumulates across launches, so only the last launch segment is read.
A tour alternates reading sheets with world scenes, so windows are classified by
triangle count: *world* windows carry at least half of the launch's maximum
triangles per frame, *sheet* windows the rest. Each class is reported from its
median window, with the engine-side frame rate of that window (frames divided by
the window span) beside the SurfaceFlinger statistics of the whole run.

Usage:
    report_frame_profile.py DIR [DIR ...] [--json OUT.json] [--markdown OUT.md]

Verdict per class: total main-thread CPU per frame against the window's frame
interval. At or above 90 % the frame is CPU-bound; at or below 60 % the GPU or
the swap chain is the limit; between, mixed. Thread CPU time also counts a
driver busy-wait, so a CPU-bound verdict names the section, not the function.
"""
import argparse
import json
import re
import statistics
import sys
from pathlib import Path

WINDOW_RE = re.compile(r'^frame-window: start-ns=(\d+) end-ns=(\d+)')
PROFILE_RE = re.compile(r'^frame-profile: (\w+) frames=(\d+) mean=([\d.]+) p50=([\d.]+) p95=([\d.]+) max=([\d.]+) cpu-ms')
COUNT_RE = re.compile(r'^frame-count: ([\w-]+) frames=(\d+) mean=([\d.]+)')
LAUNCH_MARK = 'wf_game android_main'
SECTIONS = ('update', 'actors', 'director', 'render', 'total')
COUNTERS = ('level-objects', 'render-actors', 'draws', 'triangles', 'actor-mailbox-writes')


def parse_windows(log_text):
    """Profile windows of the last launch in the log, oldest first."""
    segment = log_text.rsplit(LAUNCH_MARK, 1)[-1] if LAUNCH_MARK in log_text else log_text
    windows, current = [], None
    for line in segment.splitlines():
        m = WINDOW_RE.match(line)
        if m:
            current = dict(span_s=(int(m.group(2)) - int(m.group(1))) / 1e9, sections={}, counters={})
            windows.append(current)
            continue
        if current is None:
            continue
        m = PROFILE_RE.match(line)
        if m:
            current['sections'][m.group(1)] = dict(frames=int(m.group(2)), mean=float(m.group(3)), p50=float(m.group(4)),
                                                   p95=float(m.group(5)), max=float(m.group(6)))
            continue
        m = COUNT_RE.match(line)
        if m:
            current['counters'][m.group(1)] = float(m.group(3))
    complete = []
    for w in windows:
        total = w['sections'].get('total')
        if not total or w['span_s'] <= 0:
            continue
        w['frames'] = total['frames']
        w['fps'] = w['frames'] / w['span_s']
        complete.append(w)
    return complete


def classify(windows):
    if not windows:
        return {}
    peak = max(w['counters'].get('triangles', 0) for w in windows)
    world = [w for w in windows if peak > 0 and w['counters'].get('triangles', 0) >= 0.5 * peak]
    sheet = [w for w in windows if w not in world]
    return {name: group for name, group in (('world', world), ('sheet', sheet)) if group}


def summarize(group):
    def med(values):
        return statistics.median(values) if values else None
    fps = med([w['fps'] for w in group])
    out = dict(windows=len(group), fps=fps,
               cpu_ms={k: med([w['sections'][k]['mean'] for w in group if k in w['sections']]) for k in SECTIONS},
               cpu_p95_ms={k: med([w['sections'][k]['p95'] for w in group if k in w['sections']]) for k in SECTIONS},
               counters={k: med([w['counters'][k] for w in group if k in w['counters']]) for k in COUNTERS})
    total = out['cpu_ms'].get('total')
    if fps and total:
        interval = 1000 / fps
        ratio = total / interval
        out['frame_interval_ms'] = interval
        out['cpu_share_of_frame'] = round(ratio, 3)
        out['verdict'] = 'CPU-bound' if ratio >= 0.9 else ('GPU-or-swap-bound' if ratio <= 0.6 else 'mixed')
    render, tris, draws = out['cpu_ms'].get('render'), out['counters'].get('triangles'), out['counters'].get('draws')
    if render and tris:
        out['render_us_per_triangle'] = round(1000 * render / tris, 3)
    if render and draws:
        out['render_ms_per_draw'] = round(render / draws, 3)
    return out


def first_existing(folder, *names):
    for name in names:
        path = folder / name
        if path.exists():
            return path
    return None


def thermal_status(path):
    if not path:
        return None
    m = re.search(r'^Thermal Status: (\d+)', path.read_text(), re.M)
    return int(m.group(1)) if m else None


def pss_mib(path):
    if not path:
        return None
    text = path.read_text()
    m = re.search(r'^\s*TOTAL PSS:\s*(\d+)', text, re.M) or re.search(r'^\s*TOTAL\s+(\d+)', text, re.M)
    return int(m.group(1)) / 1024 if m else None


def report_dir(folder):
    folder = Path(folder)
    receipt = json.loads((folder / 'receipt.json').read_text()) if (folder / 'receipt.json').exists() else {}
    # Coordinator receipts nest the job record under "job" and keep the device
    # record at the top level; older receipts were flat.
    job = receipt.get('job') if isinstance(receipt.get('job'), dict) else receipt
    device = receipt.get('device') if isinstance(receipt.get('device'), dict) else {}
    request = job.get('request', {}) if isinstance(job.get('request'), dict) else {}
    summary_path = first_existing(folder, 'run-1/summary.json', 'summary.json')
    summary = json.loads(summary_path.read_text()) if summary_path else {}
    if 'runs' in summary:
        summary = summary['runs'][0]
    log_path = first_existing(folder, 'run-1/wf.log', 'wf.log')
    windows = parse_windows(log_path.read_text(errors='replace')) if log_path else []
    state = job.get('state')
    if summary and state == 'running':
        state = 'completed'   # the evidence snapshot was taken while the coordinator was still restoring
    row = dict(label=folder.name, job=job.get('id'), state=state, error=job.get('error'),
               device=dict(id=device.get('id'), model=device.get('model'), android=device.get('android'), abis=device.get('abis')),
               apk=request.get('apk'), warmup=request.get('warmup'), duration=request.get('duration'),
               presented=dict(fps=summary.get('fps'), frames=summary.get('frames') or summary.get('interval_count'),
                              p50_ms=summary.get('p50_ms'), p90_ms=summary.get('p90_ms'), p95_ms=summary.get('p95_ms'),
                              p99_ms=summary.get('p99_ms'), worst_ms=summary.get('worst_ms'), refresh_ms=summary.get('refresh_ms')),
               pss_mib=pss_mib(first_existing(folder, 'run-1/meminfo.txt', 'meminfo.txt')),
               thermal_status=thermal_status(first_existing(folder, 'run-1/thermal.txt', 'thermal.txt')),
               profile_windows=len(windows),
               classes={name: summarize(group) for name, group in classify(windows).items()})
    return row


def fmt(value, digits=1):
    return '—' if value is None else f'{value:.{digits}f}'


def markdown(rows):
    lines = ['| Job | Device | Workload | Phase | Windows | Window fps | update / render / total CPU ms | Actors | Draws | Triangles | CPU share | Verdict | Run presented fps, p50 / p95 ms |',
             '| --- | --- | --- | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | --- | --- |']
    for r in rows:
        p = r['presented']
        run = f"{fmt(p['fps'], 2)}, {fmt(p['p50_ms'])} / {fmt(p['p95_ms'])}"
        if r['state'] not in ('completed',) or not r['classes']:
            lines.append(f"| `{r['job']}` | {r['device']['model']} | {r['label']} | {r['state']} | — | — | {(r['error'] or 'no profile windows')[:70]} | — | — | — | — | — | {run} |")
            continue
        for phase, s in r['classes'].items():
            c, k = s['cpu_ms'], s['counters']
            lines.append(f"| `{r['job']}` | {r['device']['model']} | {r['label']} | {phase} | {s['windows']} | {fmt(s['fps'])} | "
                         f"{fmt(c.get('update'))} / {fmt(c.get('render'))} / {fmt(c.get('total'))} | "
                         f"{fmt(k.get('render-actors'), 0)} | {fmt(k.get('draws'), 0)} | {fmt(k.get('triangles'), 0)} | "
                         f"{fmt(s.get('cpu_share_of_frame'), 2)} | {s.get('verdict', '—')} | {run} |")
    return '\n'.join(lines) + '\n'


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.split('\n')[0])
    parser.add_argument('dirs', nargs='+', type=Path)
    parser.add_argument('--json', type=Path)
    parser.add_argument('--markdown', type=Path)
    args = parser.parse_args(argv)
    rows = [report_dir(d) for d in args.dirs]
    text = markdown(rows)
    if args.json:
        args.json.write_text(json.dumps(rows, indent=2) + '\n')
    if args.markdown:
        args.markdown.write_text(text)
    sys.stdout.write(text)
    return 0


if __name__ == '__main__':
    sys.exit(main())
