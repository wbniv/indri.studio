"""Verify the shareable movie, catalog and pinned comparison recipe.

Checks actual encoded dialogue at the beginning, middle and end of each hold,
not just the source screenshots. Reuse after the graphics upgrade.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

from PIL import Image, ImageDraw
from verify_panel_render import inspect_frame

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[1]
read = lambda path: json.loads(path.read_text())
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--folder', type=Path, required=True)
    parser.add_argument('--build-dir', type=Path, default=ROOT / 'build')
    parser.add_argument('--shot-list', type=Path)
    args = parser.parse_args()
    folder = args.folder.resolve()
    manifest = read(folder / 'capture-manifest.json')
    recipe = read(folder / 'author-shot-list.json')
    catalog = read(folder / 'screenshot-catalog.json')
    build_dir = args.build_dir.resolve()
    build = read(build_dir / 'build-receipt.json')
    assert manifest['build']['sha256'] == catalog['build']['sha256'] == build['sha256']
    assert digest(folder / 'screenshot-catalog.json') == manifest['screenshot_catalog_sha256']
    assert digest(folder / 'author-shot-list.json') == manifest['shot_list_sha256']
    movie = folder / manifest['mp4']
    assert digest(movie) == manifest['sha256']
    for source, expected in manifest['source_videos'].items():
        assert digest(PROJECT / source) == expected, source
    ids = [row['id'] for row in catalog['shots']]
    assert len(ids) == len(set(ids))
    assert {row['id'] for row in recipe['catalog_shots']} == set(ids)
    if args.shot_list:
        pinned = read(args.shot_list)
        assert recipe['shots'] == pinned['shots'], 'Movie recipe changed'
        assert recipe['catalog_shots'] == pinned['catalog_shots'], 'Catalog recipe changed'
    for row in catalog['shots']:
        assert digest(folder / row['file']) == row['sha256'], row['id']
    probe = json.loads(subprocess.check_output([
        'ffprobe', '-v', 'error', '-show_streams', '-show_chapters', '-of', 'json', str(movie)]))
    stream = next(s for s in probe['streams'] if s['codec_type'] == 'video')
    assert (stream['codec_name'], stream['width'], stream['height'], stream['pix_fmt']) == ('h264', 1280, 720, 'yuv420p')
    assert abs(float(stream['duration']) - manifest['duration']) < .1
    assert len(probe['chapters']) == len(manifest['chapters'])
    for actual, expected in zip(probe['chapters'], manifest['chapters']):
        assert actual['tags']['title'] == expected['id']
        assert abs(float(actual['start_time']) - expected['start']) < .1
        assert abs(float(actual['end_time']) - expected['start'] - expected['duration']) < .1
    # Decode every frame: a usable container/header cannot prove intact footage.
    subprocess.run(['ffmpeg', '-v', 'error', '-i', str(movie), '-f', 'null', '-'], check=True, timeout=180)
    content = read(build_dir / 'content.json')
    cards = {row['id']: row for row in content['cards']}
    rows = []
    contact = Image.new('RGB', (1280, ((len(manifest['chapters']) + 3) // 4) * 210))
    frames = folder / 'movie-check-frames'
    frames.mkdir(exist_ok=True)
    for index, chapter in enumerate(manifest['chapters']):
        matching = next((row for row in catalog['shots'] if row['id'] == chapter['id']), None)
        offsets = (.25, chapter['duration'] / 2, chapter['duration'] - .25) if matching and matching['kind'] == 'dialogue' else (chapter['duration'] / 2,)
        for sample, offset in enumerate(offsets):
            target = frames / f'{index:02d}-{sample}.png'
            subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', str(chapter['start'] + offset),
                            '-i', str(movie), '-frames:v', '1', str(target)], check=True, timeout=30)
            image = Image.open(target)
            row = dict(id=chapter['id'], time=chapter['start'] + offset,
                       file=str(target.relative_to(folder)), sha256=digest(target))
            if matching and matching['kind'] == 'dialogue':
                number = content['groups'][matching['page_key']][matching['page_index']]
                assert hashlib.sha256(cards[number]['text'].encode()).hexdigest() == matching['source_text_sha256']
                row.update(card=number, **inspect_frame(image, Image.open(build_dir / f'card_{number:02d}.tga')))
                assert row['passed'], (chapter['id'], offset, row)
            rows.append(row)
            if offset == chapter['duration'] / 2:
                thumb = Image.new('RGB', (320, 210))
                thumb.paste(image.resize((320, 180)), (0, 30))
                ImageDraw.Draw(thumb).text((4, 4), chapter['id'], fill='white')
                contact.paste(thumb, ((index % 4) * 320, (index // 4) * 210))
    for key in ('ending_10a', 'ending_10b', 'ending_10c', 'ending_101b'):
        actual = {row['page_index'] for row in catalog['shots'] if row.get('page_key') == key}
        assert actual == set(range(len(content['groups'][key]))), key
    contact.save(folder / 'movie-contact.png')
    result = dict(passed=True, apk_sha256=build['sha256'], movie_sha256=manifest['sha256'],
                  comparison_recipe_sha256=digest(args.shot_list.resolve()) if args.shot_list else None,
                  duration=manifest['duration'], chapters=len(manifest['chapters']), screenshots=len(ids),
                  dialogue_samples=sum('card' in row for row in rows), results=rows,
                  scope='Full video decode, matching source/catalog hashes, embedded chapter timings and exact source text checks at three points of every dialogue hold. World composition needs manual review.')
    (folder / 'media-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print({key: value for key, value in result.items() if key != 'results'}, flush=True)


if __name__ == '__main__':
    main()
