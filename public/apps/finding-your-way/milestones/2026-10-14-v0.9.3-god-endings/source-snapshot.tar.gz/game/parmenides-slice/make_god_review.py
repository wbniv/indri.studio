"""Generate an iteration-D gallery from matching exported native evidence."""
import argparse
import hashlib
import html
import json
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('--build-dir',type=Path,required=True);p.add_argument('--evidence',type=Path,required=True);p.add_argument('--native-folder',default='final-native');p.add_argument('--aether-folder')
a=p.parse_args();out=a.build_dir.resolve();e=a.evidence.resolve()
b=json.loads((out/'build-receipt.json').read_text());assert b['artStage']=='god-final'
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
assert digest(Path(b['apk']))==b['sha256']
rows=[]
for folder,filename in (('blender','turnaround-manifest.json'),(a.native_folder,'capture-manifest.json')):
    source=json.loads((e/folder/filename).read_text());assert source['build']['sha256']==b['sha256']
    for row in source.get('shots',source.get('images',source.get('views',[]))):
        rel=folder+'/'+row['file'];target=e/rel
        assert target.is_file()
        if 'sha256' in row:assert digest(target)==row['sha256']
        rows.append(dict(file=rel,sha256=digest(target),method='Blender editable mesh turnaround' if folder=='blender' else 'Actual native FBO recording frame'))
if a.aether_folder:
    folder=a.aether_folder
    source=json.loads((e/folder/'capture-manifest.json').read_text())
    audit=json.loads((e/folder/'aether-camera-audit.json').read_text())
    assert audit['passed'] and audit['diagnostic_receipt']['production_apk_sha256']==b['sha256']
    for row in source.get('shots',source.get('images',source.get('views',[]))):
        target=e/folder/row['file']
        assert digest(target)==row['sha256']
        rows.append(dict(file=folder+'/'+row['file'],sha256=digest(target),method='Actual native FBO; explicitly diagnostic upward camera, unchanged production mesh/native bytes'))
assert len(rows)>=20,'Missing D turnarounds/native views'
manifest=dict(build=b,images=rows,feedback='Max after all production iterations; no intermediate Will style approval',scope='D intermediate art review; phone cost, full production regression and immutable archive tracked separately')
(e/'review-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
css='body{font:16px sans-serif;background:#20272b;color:#e6dcc4;margin:2rem}a{color:#c7b578}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:1rem}figure{margin:0;background:#303b45;padding:.8rem}img{width:100%;max-height:540px;object-fit:contain}figcaption{margin-top:.5rem}video{width:100%;max-width:1000px}code{overflow-wrap:anywhere}'
parts=['<!doctype html><meta charset="utf-8"><title>Iteration D — God and final Temple</title><style>'+css+'</style><h1>Iteration D — God and final Temple</h1>',
       '<p>Original Blender models and actual exported native frames. Max provides feedback after all iterations; this gallery is an intermediate progress record.</p>',
       '<p>APK <code>'+b['sha256']+'</code>. <a href="README.md">Verification scope and caveats</a>.</p>',
       '<video controls preload="metadata" src="'+html.escape(a.native_folder,quote=True)+'/art-proof.mp4"></video><div class="grid">']
for row in rows:
    path=html.escape(row['file'],quote=True);parts.append(f'<figure><a href="{path}"><img loading="lazy" src="{path}"></a><figcaption>{path}<br>{row["method"]}</figcaption></figure>')
parts.append('</div>');(e/'review.html').write_text('\n'.join(parts)+'\n');print('Verified gallery images',len(rows))
