"""Love-street overlay on the shipped Temple/Goddess style stage.

The sky and paving are original painted sources. Balconies, shutters, lanterns,
planters and vines are reproducible Blender geometry. Existing encounters,
doors, route colliders, actor names and narrative visibility remain in place.
"""

import json
import math
import random

STAGE = 'chapter-art'
LOVE_SKY_MAILBOX = 492
LOVE_SKY_FORTH = f'102 read-mailbox 1 = {LOVE_SKY_MAILBOX} write-mailbox\n'
PAVING_SIZE = 512
PAVING_X = (90.0, 110.0)
PAVING_Y = (-10.0, 18.0)


def generate_sources(out):
    """Paint a warm daytime sky and staggered, worn street stones."""
    from PIL import Image, ImageDraw

    sky = Image.new('RGB', (256, 128))
    pixels = sky.load()
    for y in range(128):
        t = y / 127
        # The Love street should feel open and inhabited against the Temple's
        # darker stone. Broad colour changes survive TV minification.
        top = (117, 171, 207)
        horizon = (239, 209, 174)
        blend = min(1.0, max(0.0, (t - .16) / .84)) ** 1.25
        for x in range(256):
            sun = max(0.0, 1.0 - math.hypot((x - 170) / 105, (y - 96) / 85)) * .20
            pixels[x, y] = tuple(min(255, round(top[k] * (1 - blend) + horizon[k] * blend + sun * (255 - horizon[k]))) for k in range(3))
    d = ImageDraw.Draw(sky)
    for x, y, w in ((20, 52, 46), (113, 33, 62), (200, 58, 44)):
        d.ellipse((x - w / 2, y, x + w / 2, y + 11), fill=(208, 216, 212))
        d.ellipse((x - w / 3, y - 5, x + w / 3, y + 9), fill=(231, 229, 218))
    sky.save(out / 'art_love_sky.tga')

    # The narrow gaps should read as warm mortar after minification. The
    # image's implicit black background made them dominate the native view.
    paving = Image.new('RGB', (PAVING_SIZE, PAVING_SIZE), (123, 111, 98))
    d = ImageDraw.Draw(paving)
    rng = random.Random(9117)
    scale_x = PAVING_SIZE / (PAVING_X[1] - PAVING_X[0])
    scale_y = PAVING_SIZE / (PAVING_Y[1] - PAVING_Y[0])
    for row in range(37):
        y0 = row * 14
        y1 = min(PAVING_SIZE, y0 + 14)
        offset = 0 if row % 2 else -12
        for col in range(25):
            x0 = col * 25 + offset
            x1 = x0 + 25
            if x1 <= 0 or x0 >= PAVING_SIZE:
                continue
            wx = PAVING_X[0] + (x0 + x1) / 2 / scale_x
            road = 96.0 <= wx <= 104.0
            base = (149, 135, 117) if road else (194, 177, 151)
            variation = rng.randrange(-13, 14)
            warm = int(11 * math.sin((row + col) * .36))
            color = tuple(max(0, min(255, c + variation + (warm if k == 0 else 0))) for k, c in enumerate(base))
            d.rectangle((x0 + 1, y0 + 1, x1 - 1, y1 - 1), fill=color)
            d.line((x0 + 2, y1 - 3, x1 - 2, y1 - 3), fill=tuple(max(0, c - 9) for c in color), width=1)
    for world_x in (96.0, 104.0):
        x = round((world_x - PAVING_X[0]) * scale_x)
        d.rectangle((x - 3, 0, x + 3, PAVING_SIZE), fill=(201, 188, 159))
        d.line((x - 3, 0, x - 3, PAVING_SIZE), fill=(98, 92, 83), width=2)
    # Restrained leaf litter reads as life without speckling the whole frame.
    for _ in range(130):
        x = rng.randrange(PAVING_SIZE)
        y = rng.randrange(PAVING_SIZE)
        if 153 < x < 359 and rng.random() < .8:
            continue
        d.polygon(((x, y), (x + 4, y + 1), (x + 1, y + 5)), fill=rng.choice(((170, 111, 66), (188, 147, 67), (108, 111, 65))))
    paving.save(out / 'art_love_paving.tga')
    (out / 'love-style-sources.json').write_text(json.dumps({
        'art_love_sky.tga': list(sky.size),
        'art_love_paving.tga': list(paving.size),
        'method': 'deterministic original painted sources',
    }, indent=2) + '\n')


def dress(M, scene, out, setup_material):
    import bpy
    from art_style_proof import _explicit, kit_type, sky_dome

    Base = M.__bases__[0]
    sky_kit = sky_dome(kit_type(Base))
    sky = sky_kit.object('love_sky', (100, 4, 0), kind='platform', visibility=LOVE_SKY_MAILBOX)
    sky['art_stage'] = STAGE
    sky['art_role'] = 'warm sky above the Love street'
    sky['wf_original_bbox'] = (-.05, -.05, 30.0, .05, .05, 30.1)
    sky['wf_had_authored_bbox'] = True
    sky.data.uv_layers.new(name='Painted diffuse')
    _explicit(sky, sky_kit.uvfns)
    sky.data.materials.clear()
    sky_mat = setup_material(out, 'art_love_sky.tga')
    sky_mat['wf_prelit'] = True
    sky.data.materials.append(sky_mat)
    if 'style_regions' in sky:
        del sky['style_regions']

    paving_mat = setup_material(out, 'art_love_paving.tga')
    paving_mat['wf_prelit'] = True
    painted = {}
    for name in ('love_road', 'pavement94', 'pavement106'):
        obj = scene.objects[name]
        mesh = obj.data
        slot = len(mesh.materials)
        mesh.materials.append(paving_mat)
        layer = mesh.uv_layers.active.data
        indices = []
        for face in mesh.polygons:
            if face.normal.z < .9:
                continue
            face.material_index = slot
            indices.append(face.index)
            for loop in face.loop_indices:
                p = obj.matrix_world @ mesh.vertices[mesh.loops[loop].vertex_index].co
                u = (p.x - PAVING_X[0]) / (PAVING_X[1] - PAVING_X[0])
                v = (p.y - PAVING_Y[0]) / (PAVING_Y[1] - PAVING_Y[0])
                layer[loop].uv = (u, v)
        obj['art_stage_overlay'] = STAGE
        painted[name] = indices

    # Geometry is local to the room's centre. This keeps its room ownership
    # explicit in the nine-room export while making every ornament share one
    # tiny, unreachable platform collision box high above the playable street.
    m = M()
    rng = random.Random(1307)
    for side in (-1, 1):
        front = side * 9.0
        toward = -side
        for i in range(4):
            y = -11 + i * 6
            # Each house gets a shaded cornice and a projecting balcony. Open
            # railings leave the painted window visible from the street.
            m.box((front + toward * .20, y, 5.98), (.54, 5.24, .22), 'brown')
            m.box((front + toward * .38, y, 2.90), (.80, 2.70, .14), 'stone')
            rail_x = front + toward * .76
            for yy in (y - 1.22, y - .61, y, y + .61, y + 1.22):
                m.beam((rail_x, yy, 2.98), (rail_x, yy, 3.54), .075, 'steel')
            m.beam((rail_x, y - 1.34, 3.55), (rail_x, y + 1.34, 3.55), .11, 'brown')
            for yy in (y - 1.36, y + 1.36):
                m.beam((front, yy, 3.54), (rail_x, yy, 3.54), .09, 'brown')
            # Folded timber shutters frame the two upper windows.
            for center in (y - 1.4, y + 1.4):
                for edge in (-.67, .67):
                    m.box((front + toward * .24, center + edge, 4.94), (.10, .30, 1.06), 'green' if i % 2 else 'brown')
                    for z in (4.60, 4.84, 5.08, 5.32):
                        m.beam((front + toward * .30, center + edge - .12, z),
                               (front + toward * .30, center + edge + .12, z + .05), .035, 'gold')
            # Planter boxes and uneven leaf clusters soften the rectilinear kit.
            for yy in (y - 1.02, y + .94):
                m.box((rail_x + side * .10, yy, 3.55), (.32, .62, .29), 'brown')
                for j in range(5):
                    jitter = (rng.random() - .5) * .45
                    leaf_x = rail_x + toward * (.08 + .18 * rng.random())
                    leaf_y = yy + jitter
                    leaf_z = 3.76 + .27 * rng.random()
                    m.sphere((leaf_x, leaf_y, leaf_z), (.18, .21, .15), 'green', 7, 4)
                    if (j + i) % 3 == 0:
                        m.sphere((leaf_x + toward * .11, leaf_y + .03, leaf_z + .04), (.08, .10, .08), 'red', 6, 3)
            # An iron wall lantern with an opaque warm core: no transparency.
            lamp_y = y + (2.0 if side < 0 else -2.0)
            lamp_x = front + toward * .38
            m.beam((front, lamp_y, 2.83), (lamp_x, lamp_y, 2.83), .08, 'steel')
            m.box((lamp_x, lamp_y, 2.66), (.28, .25, .40), 'gold')
            m.box((lamp_x, lamp_y, 2.90), (.36, .32, .09), 'ink')
            m.box((lamp_x, lamp_y, 2.43), (.32, .29, .07), 'ink')
            # Street-level terracotta pots stay against facades, outside the
            # central road and the speakers' routes.
            pot_y = y + (2.05 if i % 2 else -2.03)
            pot_x = front + toward * .55
            m.cone((pot_x, pot_y, .12), .22, .37, 'red', .29, 8)
            m.sphere((pot_x, pot_y, .64), (.34, .35, .31), 'green', 8, 5)
            m.sphere((pot_x + toward * .21, pot_y + .17, .73), (.22, .23, .20), 'green', 7, 4)
    # A low row beyond the walkable street gives the two portals a distant
    # setting. It belongs to the Love room and has no reachable collider.
    # Extend a visual-only apron under it so its bases meet the horizon.
    m.box((0, 19.0, -.08), (20, 11.0, .08), 'stone')
    for x, width, height in ((-8.0, 3.2, 4.4), (-3.8, 3.6, 3.1),
                             (3.8, 3.7, 3.8), (8.0, 3.1, 4.8)):
        m.box((x, 22.5, height * .5), (width, .65, height), 'stone')
        m.box((x, 22.5, height + .10), (width + .28, .86, .20), 'brown')
        for window_x in (x - width * .22, x + width * .22):
            m.box((window_x, 22.12, height * .64), (.36, .06, .70), 'ink')
    dressing = m.object('love_street_dressing', (100, 4, 0), kind='platform', visibility=LOVE_SKY_MAILBOX)
    dressing['art_stage'] = STAGE
    dressing['art_role'] = 'balconies, shutters, lanterns, planters and foliage'
    dressing['wf_original_bbox'] = (-.05, -.05, 13.0, .05, .05, 13.1)
    dressing['wf_had_authored_bbox'] = True

    # Scene labels are still present and readable, but no longer cover the
    # entire street when the player approaches a speaker.
    for name, scale in (('first_sign', .44), ('starlet_sign', .46), ('paper_sign', .58)):
        obj = scene.objects[name]
        obj.scale = (scale, scale, scale)
        obj['art_stage_overlay'] = STAGE

    (out / 'love-style-sheets.json').write_text(json.dumps({
        'sky': {'size': [256, 128], 'prelit': True, 'mesh': sky.name},
        'paving': {'size': [PAVING_SIZE, PAVING_SIZE], 'prelit': True, 'meshes': list(painted), 'faces': painted},
        'dressing': {'mesh': dressing.name, 'triangles': len(dressing.data.polygons)},
    }, indent=2) + '\n')
    return {
        'stage': STAGE,
        'area': 'Love street',
        'added': [sky.name, dressing.name],
        'painted': painted,
        'labels_scaled': ['first_sign', 'starlet_sign', 'paper_sign'],
        'sky_visibility': {'mailbox': LOVE_SKY_MAILBOX, 'forth': LOVE_SKY_FORTH.strip()},
        'collision': 'new visual dressing uses explicit unreachable platform bounds; existing street and encounter colliders unchanged',
        'sources': ['art_love_sky.tga', 'art_love_paving.tga', 'art_surfaces.tga'],
    }
