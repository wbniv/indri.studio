"""Build a repeatable screenshot catalog and author MP4 from actual captures.

Use --shot-list from the v0.5.5 baseline after v0.6; semantic scene/page keys,
chapter order and reading durations are retained. This edits captured footage,
not the game's graphics. The movie is an illustrated review, not a continuous
remote-driven playthrough or complete dialogue transcript of all four realms.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import textwrap

from PIL import Image, ImageDraw, ImageFont
from verify_visual_baseline import FIXTURES, history_fixtures

ROOT=Path(__file__).resolve().parent
PROJECT=ROOT.parents[1]
read=lambda p:json.loads(p.read_text())
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
NAMES={'temple':'Temple hub','love':'Love street','reason':'Reason','truth':'Truth courtroom','god':'God ascent',
       'being':'10a — Being','both':'10b — Both','notbeing':'10c — NotBeing','surgery':'101b — Surgery coda'}
KEYS={'temple':'intro','love':'first','reason':'white','truth':'prosecutor','god':'young_man',
      'being':'ending_10a','both':'ending_10b','notbeing':'ending_10c','surgery':'ending_101b'}

def slate(path,title,lines):
    image=Image.new('RGB',(1280,720),(24,34,41));draw=ImageDraw.Draw(image)
    font=lambda size:ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',size)
    draw.text((70,65),'PARMENIDES: FINDING YOUR WAY',font=font(24),fill=(195,177,120))
    y=135
    for line in textwrap.wrap(title,43):
        draw.text((70,y),line,font=font(40),fill=(241,230,207));y+=55
    y+=25
    for paragraph in lines:
        for line in textwrap.wrap(paragraph,70):
            draw.text((70,y),line,font=font(25),fill=(215,221,223));y+=37
        y+=17
    image.save(path)

def main():
    p=argparse.ArgumentParser();p.add_argument('--version',default='0.5.5');p.add_argument('--evidence',type=Path,default=PROJECT/'docs/diagnostics/parmenides/visual-baseline-review')
    p.add_argument('--shot-list',type=Path);p.add_argument('--render',action='store_true')
    p.add_argument('--build-dir',type=Path,default=ROOT/'build')
    p.add_argument('--output',type=Path)
    p.add_argument('--panel-root',type=Path)
    p.add_argument('--progression-doc',type=Path)
    a=p.parse_args();build_dir=a.build_dir.resolve()
    evidence=a.evidence.resolve();native=evidence/'desktop';report=read(native/'render-review.json')
    if report['failed_sheet_frames']:raise SystemExit('Cannot use failed sheet captures.')
    build=report['build'];out=a.output.resolve() if a.output else evidence/'share'/('v'+a.version)
    panel_root=a.panel_root.resolve() if a.panel_root else evidence
    if (out/'capture-manifest.json').exists() and read(out/'capture-manifest.json').get('frozen'):
        raise SystemExit('This comparison baseline is frozen. Capture the next version in its own directory.')
    out.mkdir(parents=True,exist_ok=True)
    screens=out/'screenshots';screens.mkdir(exist_ok=True)
    content=read(build_dir/'content.json');cards={c['id']:c for c in content['cards']}
    fixtures={row[0]:row for row in FIXTURES}
    if read(build_dir/'build-receipt.json')['sha256']!=build['sha256']:
        raise SystemExit('Capture and current content/build must match.')
    shots=[];catalog=[];sources={}
    for name,title in NAMES.items():
        for mode,view in ((0,'third'),(1,'first')):
            rows=[r for r in report['results'] if r['kind']=='world' and r['name']==name and r['camera']==mode]
            row=rows[len(rows)//2];target=screens/f'{name}-world-{view}.png';shutil.copy2(native/row['file'],target)
            identity=f'{name}.world.{view}'
            fixture=dict(realm=fixtures[name][1],player_xy=list(fixtures[name][2:4]),heading_turns=.25,
                         history=row.get('history',{}),input_bits=[] if name=='surgery' else [2048,8192,4096,16384],frames_each=10)
            catalog.append(dict(id=identity,scene=name,kind='world',camera=mode,file=str(target.relative_to(out)),
                                source_video=str((native/'review.mp4').relative_to(PROJECT)),video_time=row['video_time'],sha256=digest(target),fixture=fixture))
            sources[identity]=dict(type='world',movie=native/'review.mp4',start=min(r['video_time'] for r in rows),duration=row['end']-row['start'],image=target)
            shots.append(dict(id=identity,scene=name,camera=mode,kind='world',duration=6,
                              fixture=fixture))
        key=KEYS[name]
        pages=content['groups'][key] if name in ('being','both','notbeing','surgery') else content['groups'][key][:2]
        for index,number in enumerate(pages):
            row_candidates=[r for r in report['results'] if r['kind']=='sheet' and r['card']==number and r['camera']==0 and r.get('passed') and not r.get('presentation')]
            if row_candidates:
                row=max(row_candidates,key=lambda r:r['video_time']);source=native/row['file'];video=native/'review.mp4';stamp=row['video_time']
            else:
                audit=read(panel_root/'panel-render-audit.json')
                if not audit['passed'] or audit['build']['sha256']!=build['sha256']:raise SystemExit('Matching complete panel capture required for '+str(number))
                row=next(r for r in audit['results'] if r['card']==number and r['camera']==0 and not r['patient'])
                source=panel_root/'rendered-panels'/row['file'];video=source.parent/'panel-render.mp4';stamp=row['video_time']
            target=screens/f'{name}-dialogue-{index+1:02d}.png';shutil.copy2(source,target)
            identity=f'{name}.dialogue.{index+1}'
            catalog.append(dict(id=identity,scene=name,kind='dialogue',camera=0,page_key=key,page_index=index,
                                source_text_sha256=hashlib.sha256(cards[number]['text'].encode()).hexdigest(),file=str(target.relative_to(out)),
                                source_video=str(video.relative_to(PROJECT)),video_time=stamp,sha256=digest(target)))
            sources[identity]=dict(type='still',image=target)
            shots.append(dict(id=identity,scene=name,kind='dialogue',page_key=key,page_index=index,
                              duration=max(6,round(len(cards[number]['text'].split())/2.8+3)),reading_pause=True))
    # The screenshot catalog also covers the changed-history review matrix.
    history_report=read(native/'history-states/render-review.json')
    if history_report['build']['sha256']!=build['sha256']:
        raise SystemExit('Changed-history captures must match the baseline candidate.')
    for name,realm,x,y,key,history in history_fixtures():
        for mode,view in ((0,'third'),(1,'first')):
            rows=[r for r in history_report['results'] if r['kind']=='world' and r['name']==name and r['camera']==mode]
            row=rows[len(rows)//2];target=screens/f'{name}-world-{view}.png'
            shutil.copy2(native/'history-states'/row['file'],target)
            catalog.append(dict(id=f'history.{name}.world.{view}',scene=name,kind='history',camera=mode,
                file=str(target.relative_to(out)),source_video=str((native/'history-states'/row.get('source_video','review.mp4')).relative_to(PROJECT)),
                video_time=row['video_time'],sha256=digest(target),fixture=dict(realm=realm,player_xy=[x,y],heading_turns=.75 if name in ('god-summit','love-temple-sign') else .25,
                history=history,input_bits=[2048,8192,4096,16384],frames_each=10)))
    # JSON object keys are strings on disk; normalize mailbox keys before
    # comparing with the frozen recipe, preserving every value and fixture.
    catalog_recipe=json.loads(json.dumps([{k:v for k,v in row.items() if k in ('id','scene','kind','camera','fixture','page_key','page_index','source_text_sha256')} for row in catalog]))
    # Persist semantic shot identities and durations so the v0.6 edit repeats
    # this exact chapter structure rather than silently choosing new pages.
    if a.shot_list:
        pinned=read(a.shot_list)
        if {r['id'] for r in pinned['shots']}!={r['id'] for r in shots}:raise SystemExit('Shot coverage changed; document the difference before comparison.')
        previous={row['id']:row for row in pinned['shots']}
        for shot in shots:
            old=previous[shot['id']]
            for field in ('scene','camera','kind','fixture','page_key','page_index'):
                if old.get(field)!=shot.get(field):
                    raise SystemExit('Comparison setup changed for '+shot['id']+' field '+field+'; document an explicit comparison exception first.')
        shots=pinned['shots']
        if pinned.get('catalog_shots')!=catalog_recipe:
            raise SystemExit('Screenshot catalog setup/source coverage changed; document the difference before comparison.')
    recipe=dict(format=1,version=a.version,shots=shots,catalog_shots=catalog_recipe,world_capture_command='python3 game/parmenides-slice/verify_desktop.py --visual-baseline --tap-frames 1',
                history_capture_command='python3 game/parmenides-slice/verify_desktop.py --visual-baseline --visual-states --tap-frames 1',
                panel_capture_command='python3 game/parmenides-slice/verify_desktop.py --render-panels',
                scope='Both viewpoints; representative realm pages; complete 10a/10b/10c/101b source accounts; actual movement intervals retimed to six seconds; still reading pauses',
                comparison='After v0.6, pass --shot-list pointing to the immutable v0.5.5 author-shot-list.json; retain semantic IDs, setup, views, page keys and durations. Record changes in capture-manifest.json.')
    (out/'author-shot-list.json').write_text(json.dumps(recipe,indent=2)+'\n')
    (out/'screenshot-catalog.json').write_text(json.dumps(dict(version=a.version,build=build,shots=catalog,repeat_after=('v0.6 with matching semantic shot IDs' if a.version=='0.5.5' else 'next authorized review with matching semantic shot IDs')),indent=2)+'\n')
    # The illustrated document links the actual images, never imagined passes.
    link=lambda file:Path(os.path.relpath(out/file,PROJECT/'docs/plans')).as_posix()
    doc=a.progression_doc.resolve() if a.progression_doc else PROJECT/'docs/plans'/('2026-10-06-v'+a.version+'-visual-baseline-review-ladder.md')
    lines=[f'# v{a.version} screenshot ladder and author review catalog','',
           'Companion to the [visual baseline review plan](2026-10-06-v0.5.5-visual-baseline-review.md). Screenshots come from actual World Foundry recordings. Build identity: `'+build['sha256']+'`. Camera collision and patient composition remain postponed; production graphics and phone acceptance are separate gates.','',
           'The nine scene families are shown in both perspectives. Realm dialogue is representative; the three ending accounts and the sole surgery coda are complete. Reading pauses in the movie hold actual captured frames. Scene setup uses debug fixtures; this is an edited review, not a continuous phone/remote playthrough.','',
           '```mermaid','flowchart TD','    A[Frozen baseline] --> B[Reproduce defect]','    B --> C[Correct transition presentation]','    C --> D[Review moving world in both views]','    D --> E[Review full source and completion]','    E --> F[Chromecast captures and lifecycle]','    F --> G[Matching regression summary]','    G --> H[Archive and commit/push]','    H --> I[Will and original author review]','```','',
           '## Completion ladder','',
           '| Step | Evidence and current gate | Screenshot |','| --- | --- | --- |',
           '| 1. Frozen baseline | The original v0.5.5 archive remains immutable; this image is from its earlier text/winding review. The new catalog pins the corrected candidate separately. | ![Original Temple baseline](../diagnostics/parmenides/visual-baseline-review/step-screenshots/original-temple.png) |',
           '| 2. Reproduce clipping | The earlier Truth opening frame crosses the top safe margin; retain the failed clip. | ![Truth opening before correction](../diagnostics/parmenides/visual-baseline-review/step-screenshots/truth-opening-before.png) |',
           '| 3. Correct presentation | Show sheets only when the reading view is ready; hidden input cannot skip source text. Regression must remain passing. | ![Corrected Truth sheet]('+link('screenshots/truth-dialogue-01.png')+') |',
           '| 4. Moving-world review | Both camera modes and changed histories need explicit visual judgments; a capture alone is not acceptance. | ![Love first-person view]('+link('screenshots/love-world-first.png')+') |',
           '| 5. Endings and coda | Verify complete source, exclusive 10b → 101b, cancellation and completion. | ![Surgery source sheet]('+link('screenshots/surgery-dialogue-01.png')+') |',
           '| 6. Device review | Coordinator-owned Chromecast1 clips cover every scene family; diagnostic scene selection is scripted. Restore/recheck the production APK. | ![Being device sheet](../diagnostics/parmenides/visual-baseline-review/final-device/group-1-view-0/samples/frame-16.png) |',
           '| 7. Final regression | Require matching source/asset/route, 420 settled/transition views and device receipts. Open until the final summary passes. | ![Being source sheet]('+link('screenshots/being-dialogue-01.png')+') |',
           '| 8. Freeze and commit/push | Open until the corrected revision has its own archive and matching source checkpoint; keep the original archive unchanged. | ![Final ending view]('+link('screenshots/notbeing-world-third.png')+') |',
           '| 9. Author feedback | Review this movie/catalog with timestamps and shot IDs; Will retains the completion decision. | ![Both passage]('+link('screenshots/both-world-third.png')+') |','',
           'Steps 7–8 must be updated with exact receipts/checkpoint links when completed. A screenshot illustrates each checkpoint; it does not replace its verification receipt.','',
           '## Shareable movie','',f'[Author review MP4]({link("author-review-v"+a.version+".mp4")}) · [Pinned shot list]({link("author-shot-list.json")}) · [Screenshot catalog manifest]({link("screenshot-catalog.json")})','',
           'Feedback should identify the movie timestamp or screenshot shot ID, the expected narrative/visual meaning, what appears wrong and any proposed wording or composition change. Known provisional effects: graybox models, visibility-based dissolution/portal closure, captioned voices and cropped upward surgery composition.','',
           '## Matched screenshot catalog','']
    for name,title in NAMES.items():
        lines += ['### '+title,'', '| Third-person follow | First-person free movement |','| --- | --- |',
                  f'| ![{name}.world.third]({link("screenshots/"+name+"-world-third.png")}) | ![{name}.world.first]({link("screenshots/"+name+"-world-first.png")}) |','']
        for row in (r for r in catalog if r['scene']==name and r['kind']=='dialogue'):
            lines += [f'**Shot `{row["id"]}`** — source group `{row["page_key"]}`, page {row["page_index"]+1}.','',f'![{row["id"]}]({link(row["file"])})','']
    lines += ['## Changed histories and additional approaches','',
              'These matching screenshots extend the catalog beyond the movie chapters: 30 Temple histories and five additional encounter approaches, each in both views. Source state and exact fixture setup are pinned in the manifest.','',
              '| State / approach | Third-person follow | First-person free movement |','| --- | --- | --- |']
    for name,*_ in history_fixtures():
        lines += [f'| `{name}` | ![history.{name}.world.third]({link("screenshots/"+name+"-world-third.png")}) | ![history.{name}.world.first]({link("screenshots/"+name+"-world-first.png")}) |']
    lines += ['']
    lines += ['## Repeat after the v0.6 graphics upgrade','',
              '- [ ] Rerun the same native fixture and source-page captures using the v0.6 candidate.','- [ ] Run `make_review_media.py --version 0.6 --shot-list <v0.5.5 author-shot-list.json> --render`; keep the same scene order, views, histories, dialogue keys and reading durations.','- [ ] Recapture the screenshot catalog with the same semantic shot IDs and record the new APK, frame and video hashes. Preserve this baseline catalog/movie.','- [ ] Compare matching shots side by side. Explicitly describe any necessary camera/layout changes rather than silently replacing a shot.','- [ ] Give the original author the v0.6 movie and catalog with the same chapter/shot IDs for a second feedback pass.','',
              'Authored with Codex. Exact model version and reasoning-effort metadata were unavailable for verification in this session.','']
    if a.version != '0.5.5':
        catalog_start=lines.index('## Matched screenshot catalog')
        repeat_start=lines.index('## Repeat after the v0.6 graphics upgrade')
        lines=[f'# v{a.version} matched author review catalog','',
            'Companion to the [v0.7 polish plan](2026-10-07-v0.7-polish.md). Current-build native captures retain the corrected v0.5.5 semantic shot recipe. APK SHA-256: `'+build['sha256']+'`.','',
            'Nine scene families, both camera preferences, all ending/coda source pages and the complete changed-history comparison matrix. Reading pauses hold real captured frames; this edited fixture-based movie is not a continuous remote or touch playthrough.','',
            '## Review status','',
            '- [x] Generate the matching catalog from identity-bound current-build captures.',
            '- [ ] Verify the full movie decode, chapter timings, source text and capture provenance.',
            '- [ ] Record current-build native/device regression, archive and final installation results.',
            '- [ ] Obtain Max’s feedback after authorized delivery of the combined A–F package.','',
            'General camera collision and phone acceptance remain separate gates. Speed optimization is v0.8. Patient composition and ending effects have current artwork; their actual limits are recorded in the polish evidence.','',
            '## Review movie','',f'[MP4]({link("author-review-v"+a.version+".mp4")}) · [Shot recipe]({link("author-shot-list.json")}) · [Catalog manifest]({link("screenshot-catalog.json")})','',
            'Feedback should identify a timestamp or semantic shot ID, the intended meaning and the observed issue. This package remains private until delivery is explicitly authorized.','',
            *lines[catalog_start:repeat_start],
            '## Comparison provenance','',
            'The prior patient-framing baseline remains unchanged. Retain the same semantic IDs, fixture/history setup, page keys and reading durations. Document intentional framing changes in the current evidence rather than substituting another scene.','']
    doc.write_text('\n'.join(lines))
    print('Catalog and ladder:',doc,flush=True)
    if not a.render:
        manifest_path=out/'capture-manifest.json'
        if manifest_path.exists():
            manifest=read(manifest_path)
            if manifest['build']['sha256']!=build['sha256'] or digest(out/manifest['mp4'])!=manifest['sha256']:
                raise SystemExit('Existing movie does not match this candidate; rerender it.')
            if any(digest(PROJECT/name)!=sha for name,sha in manifest['source_videos'].items()):
                raise SystemExit('Movie source recording changed; rerender it.')
            movie_ids={r['id'] for r in manifest['chapters'] if r['id'] in sources}
            if movie_ids!={r['id'] for r in shots}:raise SystemExit('Movie shot coverage changed; rerender it.')
            manifest.update(source_videos={row['source_video']:digest(PROJECT/row['source_video']) for row in catalog},
                screenshot_catalog_sha256=digest(out/'screenshot-catalog.json'),shot_list_sha256=digest(out/'author-shot-list.json'))
            manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
        return
    chapters=[];time=0
    with tempfile.TemporaryDirectory(prefix='fyw-movie-',dir='/tmp') as temp:
        temp=Path(temp);clips=[]
        def encode(source,duration,identity):
            nonlocal time
            target=temp/f'{len(clips):03d}.mp4'
            cmd=['ffmpeg','-v','error','-y','-threads','2']
            raw=source.get('duration',0)
            if source['type']=='world' and raw>.1:
                cmd += ['-ss',str(source['start']),'-t',str(raw),'-i',str(source['movie'])]
                vf=f'setpts={(duration/raw):.8f}*(PTS-STARTPTS),fps=30,scale=1280:720'
            else:
                cmd += ['-loop','1','-i',str(source['image'])];vf='fps=30,scale=1280:720'
            cmd += ['-vf',vf,'-t',str(duration),'-an','-c:v','libx264','-threads','2','-preset','fast','-crf','20','-pix_fmt','yuv420p',str(target)]
            subprocess.run(cmd,check=True,timeout=180)
            clips.append(target);chapters.append(dict(id=identity,start=time,duration=duration));time+=duration
        intro=temp/'intro.png';slate(intro,'Author review — v'+a.version,[
            'Actual World Foundry prototype footage. Scene setup uses review fixtures; ordinary movement is driven by native input.',
            'Representative realm dialogue, all three ending accounts and only Both → surgery. Reading pauses hold real captures.',
            'A–F artwork and polish for author review. General camera collision and phone acceptance remain open; optimization is v0.8.' if a.version != '0.5.5' else 'Models and effects are provisional. Camera collision and surgery framing remain open. Phone acceptance is separate.'])
        encode(dict(type='still',image=intro),12,'review.introduction')
        last_scene=None
        for shot in shots:
            name=shot['scene']
            if name!=last_scene:
                title=temp/(name+'.png');slate(title,NAMES[name],[
                    'Third-person follow, then first-person free movement. Actual movement intervals are retimed to six seconds.',
                    'Dialogue follows as a reading pause. Realm samples are representative; ending/coda source accounts are complete.'])
                encode(dict(type='still',image=title),5,name+'.chapter');last_scene=name
            encode(sources[shot['id']],shot['duration'],shot['id'])
        closing=temp/'closing.png';slate(closing,'Feedback and matched comparison' if a.version != '0.5.5' else 'Feedback and v0.6 comparison',[
            'Please identify a timestamp or screenshot shot ID, what should be conveyed and what needs correction.',
            'The chapter timings and semantic shot IDs match the preserved patient-framing baseline.' if a.version != '0.5.5' else 'After the v0.6 graphics upgrade, repeat this shot list and screenshot catalog. Keep this baseline for comparison.',
            'Max provides feedback on the combined A–F package. Phone acceptance and performance optimization remain separate.' if a.version != '0.5.5' else 'These scenes retain provisional models/effects and known camera limitations.'])
        encode(dict(type='still',image=closing),12,'review.feedback')
        concat=temp/'concat.txt';concat.write_text(''.join("file '"+str(clip)+"'\n" for clip in clips))
        movie=out/f'author-review-v{a.version}.mp4'
        metadata=temp/'chapters.ffmetadata'
        metadata.write_text(';FFMETADATA1\n'+''.join(
            '[CHAPTER]\nTIMEBASE=1/1000\nSTART='+str(int(row['start']*1000))+
            '\nEND='+str(int((row['start']+row['duration'])*1000))+'\ntitle='+row['id']+'\n'
            for row in chapters))
        subprocess.run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(concat),
                        '-i',str(metadata),'-map_metadata','1','-map_chapters','1','-c','copy','-movflags','+faststart',str(movie)],check=True,timeout=120)
    manifest=dict(version=a.version,build=build,mp4=movie.name,sha256=digest(movie),duration=time,chapters=chapters,
                  source_videos={row['source_video']:digest(PROJECT/row['source_video']) for row in catalog},
                  screenshot_catalog_sha256=digest(out/'screenshot-catalog.json'),shot_list_sha256=digest(out/'author-shot-list.json'))
    (out/'capture-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (out/'author-feedback.md').write_text('# Author feedback\n\nMovie: '+movie.name+'\n\n| Timestamp or shot ID | Expected meaning | Observed issue | Suggested change |\n| --- | --- | --- | --- |\n| | | | |\n\nRetain semantic shot IDs when recording Max’s feedback. Delivery remains separately authorized.\n')
    print('Shareable movie:',movie,'duration',time,'seconds',flush=True)

if __name__=='__main__':main()
