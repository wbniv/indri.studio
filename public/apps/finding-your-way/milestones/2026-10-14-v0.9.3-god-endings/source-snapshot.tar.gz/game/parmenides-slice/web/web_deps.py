#!/usr/bin/env python3
"""Locate, verify and offline-install the pinned Emscripten 6.0.0 SDK for the browser chapter.

The pins (manager commit, release archives, SHA-256, installed tree digest) live in
web-deps.json beside this file. Nothing here downloads unless `fetch` is run.

SDK discovery order, first valid one wins:
  1. --sdk PATH
  2. $FYW_WEB_SDK
  3. this worktree's   game/parmenides-slice/build/web-sdk
  4. the main checkout's game/parmenides-slice/build/web-sdk  (so linked worktrees reuse it)
  5. the engine's engine/vendor/emsdk-6.0.0, in the --engine checkout, then its main checkout

Archive cache: $FYW_WEB_DEPS_CACHE, default ~/.cache/finding-your-way/web-deps.
See docs/plans/2026-10-10-web-build-dependency-mirror.md.
"""
from pathlib import Path
import argparse, hashlib, json, os, platform, shutil, subprocess, sys, tempfile, urllib.request

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MANIFEST = HERE / 'web-deps.json'
CHAPTER_SDK = Path('game/parmenides-slice/build/web-sdk')
ENGINE_SDK = Path('engine/vendor/emsdk-6.0.0')
DEFAULT_ENGINE = Path(os.environ.get('FYW_WF_ROOT', str(Path.home() / 'WorldFoundry-wbniv')))
DEAD_PROXY = 'http://127.0.0.1:9'


class SdkInvalid(Exception):
    pass


class LocateError(Exception):
    def __init__(self, tried):
        self.tried = tried
        super().__init__('No pinned Emscripten SDK found')

    def report(self, manifest):
        lines = [f"No pinned Emscripten {manifest['emscripten']} SDK found. Tried:"]
        lines += [f'  {label}: {path}: {reason}' for label, path, reason in self.tried]
        lines += ['Install it offline from the verified archive cache (no download):',
                  '  python3 game/parmenides-slice/web/web_deps.py install',
                  'or fill the cache first: python3 game/parmenides-slice/web/web_deps.py fetch']
        return '\n'.join(lines)


def load_manifest(path=MANIFEST):
    return json.loads(Path(path).read_text())


def platform_key():
    system, machine = platform.system().lower(), platform.machine().lower()
    if system == 'linux' and machine in ('x86_64', 'amd64'):
        return 'linux-x86_64'
    raise SystemExit(f'web-deps.json pins only linux-x86_64; this host is {system}-{machine}')


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def tree_digest(sdk):
    """SHA-256 of the `sha256sum` listing of upstream/ and node/, sorted by path.

    Equivalent to: cd SDK && find upstream node \\( -path upstream/emscripten/cache -o -name __pycache__ \\)
    -prune -o \\( -type f -o -type l \\) -print0 | LC_ALL=C sort -z | xargs -0 sha256sum | sha256sum
    The excluded cache is generated/updated by emcc; __pycache__ by Python.
    """
    sdk = Path(sdk)
    entries = []
    for top in ('upstream', 'node'):
        for dirpath, dirnames, filenames in os.walk(sdk / top):
            rel_dir = Path(dirpath).relative_to(sdk)
            keep = []
            for d in dirnames:
                rel = (rel_dir / d).as_posix()
                if d == '__pycache__' or rel == 'upstream/emscripten/cache':
                    continue
                if (Path(dirpath) / d).is_symlink():
                    entries.append(rel)  # find -type l lists it; hashing a directory fails below, as in sha256sum
                else:
                    keep.append(d)
            dirnames[:] = keep
            entries += [(rel_dir / f).as_posix() for f in filenames]
    entries.sort(key=lambda p: p.encode())
    listing = hashlib.sha256()
    for rel in entries:
        if '\\' in rel or '\n' in rel:
            raise SdkInvalid(f'unsupported file name {rel!r}')
        target = sdk / rel
        if target.is_dir():
            raise SdkInvalid(f'{rel} is a symlink to a directory')
        listing.update(f'{sha256_file(target)}  {rel}\n'.encode())
    return listing.hexdigest(), len(entries)


def check_sdk(sdk, manifest=None, tree=False):
    """Raise SdkInvalid unless SDK is the pinned installation. Cheap unless tree=True."""
    manifest = manifest or load_manifest()
    pins = manifest['platforms'][platform_key()]['installed']
    sdk = Path(sdk)
    if not sdk.is_dir():
        raise SdkInvalid('missing')
    version_file = sdk / 'upstream/.emsdk_version'
    if not version_file.is_file():
        raise SdkInvalid('no upstream/.emsdk_version (not installed)')
    version = version_file.read_text().strip()
    if version != pins['emsdkVersion']:
        raise SdkInvalid(f"upstream/.emsdk_version is {version!r}, expected {pins['emsdkVersion']!r}")
    if not (sdk / 'node' / pins['node'] / 'bin/node').is_file():
        raise SdkInvalid(f"no node/{pins['node']}/bin/node")
    emcc = sdk / 'upstream/emscripten/emcc'
    if not os.access(emcc, os.X_OK):
        raise SdkInvalid('upstream/emscripten/emcc is not executable')
    if not (sdk / 'emsdk').is_file():
        raise SdkInvalid('no emsdk manager script')
    if tree:
        digest, count = tree_digest(sdk)
        if (digest, count) != (pins['treeSha256'], pins['treeFiles']):
            raise SdkInvalid(f"tree digest {digest} over {count} files, expected {pins['treeSha256']} over {pins['treeFiles']}")


def main_checkout(path):
    """The main working tree of the repository containing PATH, or None."""
    try:
        common = subprocess.run(['git', '-C', str(path), 'rev-parse', '--path-format=absolute', '--git-common-dir'],
                                check=True, capture_output=True, text=True).stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError, NotADirectoryError):
        return None
    common = Path(common)
    return common.parent if common.name == '.git' else None


def candidates(explicit=None, engine=None, root=ROOT, env=os.environ):
    """Ordered (label, path) list; duplicates removed, first label kept."""
    out = []
    if explicit:
        out.append(('--sdk', Path(explicit)))
    if env.get('FYW_WEB_SDK'):
        out.append(('$FYW_WEB_SDK', Path(env['FYW_WEB_SDK'])))
    root = Path(root)
    out.append(('this worktree', root / CHAPTER_SDK))
    main = main_checkout(root)
    if main:
        out.append(('main checkout', main / CHAPTER_SDK))
    if engine:
        engine = Path(engine)
        out.append(('engine checkout', engine / ENGINE_SDK))
        engine_main = main_checkout(engine)
        if engine_main:
            out.append(('engine main checkout', engine_main / ENGINE_SDK))
    seen, unique = set(), []
    for label, path in out:
        key = os.path.abspath(path)
        if key not in seen:
            seen.add(key)
            unique.append((label, Path(key)))
    return unique


def locate(explicit=None, engine=None, root=ROOT, env=os.environ, manifest=None):
    """First valid pinned SDK. An explicit --sdk that is invalid is an error, not skipped."""
    manifest = manifest or load_manifest()
    tried = []
    for label, path in candidates(explicit, engine, root, env):
        try:
            check_sdk(path, manifest)
            return path
        except SdkInvalid as e:
            tried.append((label, path, str(e)))
            if label == '--sdk':
                break
    raise LocateError(tried)


def default_cache(env=os.environ):
    if env.get('FYW_WEB_DEPS_CACHE'):
        return Path(env['FYW_WEB_DEPS_CACHE'])
    return Path(env.get('XDG_CACHE_HOME') or Path.home() / '.cache') / 'finding-your-way/web-deps'


def bundle_has_commit(bundle, commit):
    try:
        heads = subprocess.run(['git', 'bundle', 'list-heads', str(bundle)], check=True,
                               capture_output=True, text=True).stdout
    except subprocess.CalledProcessError:
        return False
    return any(line.split()[0] == commit for line in heads.splitlines() if line.strip())


def verify_cache(cache, manifest=None):
    """List of problems with the archive cache; empty means every pinned file is present and matches."""
    manifest = manifest or load_manifest()
    cache, problems = Path(cache), []
    for a in manifest['platforms'][platform_key()]['archives']:
        p = cache / a['file']
        if not p.is_file():
            problems.append(f"{a['file']}: missing")
        elif p.stat().st_size != a['bytes']:
            problems.append(f"{a['file']}: {p.stat().st_size} bytes, expected {a['bytes']}")
        elif sha256_file(p) != a['sha256']:
            problems.append(f"{a['file']}: SHA-256 mismatch")
    m = manifest['manager']
    if not (cache / m['bundle']).is_file():
        problems.append(f"{m['bundle']}: missing")
    elif not bundle_has_commit(cache / m['bundle'], m['commit']):
        problems.append(f"{m['bundle']}: does not contain {m['commit']}")
    return problems


def fetch(cache, base_url=None, manifest=None):
    """Fill the cache from upstream (or a mirror at BASE_URL/<file>), verifying every byte."""
    manifest = manifest or load_manifest()
    cache = Path(cache)
    cache.mkdir(parents=True, exist_ok=True)
    for a in manifest['platforms'][platform_key()]['archives']:
        dest = cache / a['file']
        if dest.is_file() and dest.stat().st_size == a['bytes'] and sha256_file(dest) == a['sha256']:
            print(f"ok      {a['file']}")
            continue
        url = f"{base_url.rstrip('/')}/{a['file']}" if base_url else a['url']
        part = dest.with_name(dest.name + '.part')
        print(f"fetch   {url}")
        with urllib.request.urlopen(url, timeout=60) as r, open(part, 'wb') as f:
            shutil.copyfileobj(r, f, 1 << 20)
        got = (part.stat().st_size, sha256_file(part))
        if got != (a['bytes'], a['sha256']):
            part.unlink()
            raise SystemExit(f"{url}: got {got[0]} bytes sha256 {got[1]}, expected {a['bytes']} {a['sha256']}")
        part.replace(dest)
    m = manifest['manager']
    bundle = cache / m['bundle']
    if bundle.is_file() and bundle_has_commit(bundle, m['commit']):
        print(f"ok      {m['bundle']}")
    elif base_url:
        url = f"{base_url.rstrip('/')}/{m['bundle']}"
        print(f"fetch   {url}")
        with urllib.request.urlopen(url, timeout=60) as r, open(bundle, 'wb') as f:
            shutil.copyfileobj(r, f)
        if not bundle_has_commit(bundle, m['commit']):
            bundle.unlink()
            raise SystemExit(f"{url}: bundle does not contain {m['commit']}")
    else:
        print(f"fetch   {m['repo']} @ {m['commit']}")
        with tempfile.TemporaryDirectory() as tmp:
            git = ['git', '-C', tmp]
            subprocess.run(['git', 'init', '-q', tmp], check=True)
            subprocess.run(git + ['fetch', '-q', '--depth', '1', m['repo'], m['commit']], check=True)
            subprocess.run(git + ['checkout', '-q', '--detach', m['commit']], check=True)
            subprocess.run(git + ['bundle', 'create', '-q', str(bundle), 'HEAD'], check=True)
    problems = verify_cache(cache, manifest)
    if problems:
        raise SystemExit('cache still invalid:\n  ' + '\n  '.join(problems))
    print(f'cache verified: {cache}')


def offline_env(env=os.environ):
    """Environment that makes any HTTP(S) fetch fail fast instead of silently downloading."""
    env = dict(env, EMSDK_KEEP_DOWNLOADS='1')
    for k in ('http_proxy', 'https_proxy', 'HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'all_proxy'):
        env[k] = DEAD_PROXY
    for k in ('no_proxy', 'NO_PROXY'):
        env.pop(k, None)
    return env


def install(cache, dest, manifest=None):
    """Build DEST from the verified cache with the network poisoned; verify the tree digest."""
    manifest = manifest or load_manifest()
    cache, dest = Path(cache), Path(dest)
    problems = verify_cache(cache, manifest)
    if problems:
        raise SystemExit('archive cache invalid (run `web_deps.py fetch`):\n  ' + '\n  '.join(problems))
    if dest.exists() and any(dest.iterdir()):
        raise SystemExit(f'{dest} exists and is not empty; remove it or choose another --dest')
    m = manifest['manager']
    dest.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(['git', '-c', 'advice.detachedHead=false', 'clone', '-q', str(cache / m['bundle']), str(dest)], check=True)
    subprocess.run(['git', '-C', str(dest), 'remote', 'set-url', 'origin', m['repo']], check=True)
    head = subprocess.run(['git', '-C', str(dest), 'rev-parse', 'HEAD'], check=True, capture_output=True, text=True).stdout.strip()
    if head != m['commit']:
        raise SystemExit(f"manager HEAD {head}, expected {m['commit']}")
    downloads = dest / 'downloads'
    downloads.mkdir(exist_ok=True)
    seeded = []
    for a in manifest['platforms'][platform_key()]['archives']:
        target = downloads / a['file']
        try:
            os.link(cache / a['file'], target)
        except OSError:
            shutil.copy2(cache / a['file'], target)
        seeded.append(target)
    env = offline_env()
    subprocess.run(['./emsdk', 'install', manifest['emscripten']], cwd=dest, env=env, check=True)
    subprocess.run(['./emsdk', 'activate', manifest['emscripten']], cwd=dest, env=env, check=True, stdout=subprocess.DEVNULL)
    for p in seeded:
        p.unlink()
    check_sdk(dest, manifest, tree=True)
    print(f'installed and verified: {dest}')


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest='command', required=True)
    s = sub.add_parser('locate', help='print the first valid pinned SDK (exit 1 if none)')
    s.add_argument('--sdk', type=Path)
    s.add_argument('--engine', type=Path, default=DEFAULT_ENGINE)
    s = sub.add_parser('check', help='verify an SDK against the pins, including the tree digest')
    s.add_argument('sdk', type=Path, nargs='?')
    s.add_argument('--engine', type=Path, default=DEFAULT_ENGINE)
    s.add_argument('--quick', action='store_true', help='skip the tree digest')
    s = sub.add_parser('digest', help='print the tree digest and file count of an SDK')
    s.add_argument('sdk', type=Path)
    s = sub.add_parser('fetch', help='download the pinned archives into the cache (network)')
    s.add_argument('--cache', type=Path, default=default_cache())
    s.add_argument('--base-url', help='mirror holding <file> for each archive and the manager bundle')
    s = sub.add_parser('verify-cache', help='verify sizes and SHA-256 of the cached archives')
    s.add_argument('--cache', type=Path, default=default_cache())
    s = sub.add_parser('install', help='install the SDK from the cache with the network poisoned')
    s.add_argument('--cache', type=Path, default=default_cache())
    s.add_argument('--dest', type=Path, help='default: the main checkout\'s game/parmenides-slice/build/web-sdk')
    a = p.parse_args(argv)
    manifest = load_manifest()
    if a.command == 'locate':
        try:
            print(locate(a.sdk, a.engine, manifest=manifest))
        except LocateError as e:
            print(e.report(manifest), file=sys.stderr)
            return 1
    elif a.command == 'check':
        try:
            sdk = a.sdk or locate(engine=a.engine, manifest=manifest)
            check_sdk(sdk, manifest, tree=not a.quick)
        except LocateError as e:
            print(e.report(manifest), file=sys.stderr)
            return 1
        except SdkInvalid as e:
            print(f'{sdk}: {e}', file=sys.stderr)
            return 1
        print(f"{sdk}: pinned Emscripten {manifest['emscripten']}" + ('' if a.quick else ', tree digest verified'))
    elif a.command == 'digest':
        digest, count = tree_digest(a.sdk)
        print(f'{digest}  {count} files')
    elif a.command == 'fetch':
        fetch(a.cache, a.base_url, manifest)
    elif a.command == 'verify-cache':
        problems = verify_cache(a.cache, manifest)
        if problems:
            print('\n'.join(problems), file=sys.stderr)
            return 1
        print(f'cache verified: {a.cache}')
    elif a.command == 'install':
        install(a.cache, a.dest or (main_checkout(ROOT) or ROOT) / CHAPTER_SDK, manifest)
    return 0


if __name__ == '__main__':
    sys.exit(main())
