"""Painted finishing pass for the three endings and the surgery coda.

The stage only changes diffuse surfaces and adds visual dressing. The existing
support, doors, surgeons, camera, mailboxes and story routes stay authoritative.
"""

import json
import math
import random

STAGE = 'chapter-art'


def generate_sources(out):
    from PIL import Image, ImageDraw

    sky = Image.new('RGB', (256, 128))
    pixels = sky.load()
    for y in range(128):
        blend = (y / 127) ** 1.6
        high, low = (181, 191, 196), (252, 234, 184)
        for x in range(256):
            pixels[x, y] = tuple(round(high[k] * (1 - blend) + low[k] * blend)
                                 for k in range(3))
    sky.save(out / 'art_being_sky.tga')

    marble = Image.new('RGB', (512, 512), (224, 214, 190))
    draw = ImageDraw.Draw(marble)
    rng = random.Random(51021)
    for row in range(16):
        for col in range(16):
            x, y = col * 32, row * 32
            variation = rng.randrange(-9, 10)
            tone = (min(255, 233 + variation), min(255, 225 + variation),
                    min(255, 202 + variation))
            draw.rectangle((x + 1, y + 1, x + 30, y + 30), fill=tone)
            if (row + col) % 5 == 0:
                draw.line((x + 7, y + 22, x + 20, y + 9), fill=(209, 202, 182))
    for radius in (63, 126, 204):
        draw.ellipse((256 - radius, 256 - radius, 256 + radius, 256 + radius),
                     outline=(185, 151, 76), width=2)
    marble.save(out / 'art_being_marble.tga')

    both = Image.new('RGB', (512, 512), (58, 64, 72))
    draw = ImageDraw.Draw(both)
    rng = random.Random(61022)
    for row in range(16):
        for col in range(16):
            x, y = col * 32, row * 32
            light = col < 8
            n = rng.randrange(-8, 9)
            color = ((215 + n, 209 + n, 190 + n) if light
                     else (75 + n, 82 + n, 91 + n))
            draw.rectangle((x + 1, y + 1, x + 30, y + 30), fill=color)
    draw.line((255, 0, 255, 511), fill=(181, 146, 78), width=4)
    both.save(out / 'art_both_floor.tga')

    clinical = Image.new('RGB', (512, 512), (176, 195, 199))
    draw = ImageDraw.Draw(clinical)
    rng = random.Random(81023)
    for row in range(8):
        for col in range(8):
            x, y = col * 64, row * 64
            n = rng.randrange(-5, 6)
            draw.rectangle((x + 2, y + 2, x + 61, y + 61),
                           fill=(202 + n, 216 + n, 215 + n))
            draw.line((x + 4, y + 4, x + 59, y + 4),
                      fill=(230, 236, 227), width=2)
    clinical.save(out / 'art_surgery_tile.tga')
    (out / 'ending-style-sources.json').write_text(json.dumps({
        'art_being_sky.tga': list(sky.size),
        'art_being_marble.tga': list(marble.size),
        'art_both_floor.tga': list(both.size),
        'art_surgery_tile.tga': list(clinical.size),
        'method': 'deterministic original painted sources',
    }, indent=2) + '\n')


def _paint_horizontal(scene, name, material, bounds):
    obj = scene.objects[name]
    mesh = obj.data
    slot = len(mesh.materials)
    mesh.materials.append(material)
    if mesh.uv_layers.active is None:
        mesh.uv_layers.new(name='Painted diffuse')
    uv = mesh.uv_layers.active.data
    x0, x1, y0, y1 = bounds
    faces = []
    for face in mesh.polygons:
        if abs(face.normal.z) < .9:
            continue
        face.material_index = slot
        faces.append(face.index)
        for loop in face.loop_indices:
            p = obj.matrix_world @ mesh.vertices[mesh.loops[loop].vertex_index].co
            uv[loop].uv = ((p.x - x0) / (x1 - x0), (p.y - y0) / (y1 - y0))
    obj['art_stage_overlay'] = STAGE
    return faces


def _visual(model, name, position, visibility, role, top=12):
    obj = model.object(name, position, kind='platform', visibility=visibility)
    obj['art_stage'] = STAGE
    obj['art_role'] = role
    # Deliberately unreachable collider; the chapter's existing floors and
    # thresholds keep every navigation and encounter contact unchanged.
    obj['wf_original_bbox'] = (-.05, -.05, top, .05, .05, top + .1)
    obj['wf_had_authored_bbox'] = True
    return obj


def dress(M, scene, out, setup_material):
    from art_style_proof import _explicit, kit_type, sky_dome

    materials = {}
    for key, filename in (
        ('being', 'art_being_marble.tga'),
        ('both', 'art_both_floor.tga'),
        ('surgery', 'art_surgery_tile.tga'),
    ):
        materials[key] = setup_material(out, filename)
        materials[key]['wf_prelit'] = True
    painted = {
        'being_ocean': _paint_horizontal(scene, 'being_ocean', materials['being'],
                                         (485, 515, -15, 15)),
        'both_floor': _paint_horizontal(scene, 'both_floor', materials['both'],
                                        (591, 609, -11, 11)),
        'surgery_ceiling': _paint_horizontal(scene, 'surgery_ceiling',
                                             materials['surgery'], (792, 808, -9, 9)),
    }

    sky_kit = sky_dome(kit_type(M.__bases__[0]))
    sky = sky_kit.object('being_sky', (500, 0, 0), kind='platform', visibility=255)
    sky['art_stage'] = STAGE
    sky['art_role'] = 'warm luminous horizon behind the Being threshold'
    sky['wf_original_bbox'] = (-.05, -.05, 49, .05, .05, 49.1)
    sky['wf_had_authored_bbox'] = True
    sky.data.uv_layers.new(name='Painted diffuse')
    _explicit(sky, sky_kit.uvfns)
    sky.data.materials.clear()
    sky_mat = setup_material(out, 'art_being_sky.tga')
    sky_mat['wf_prelit'] = True
    sky.data.materials.append(sky_mat)
    if 'style_regions' in sky:
        del sky['style_regions']

    being = M()
    # Three shallow bays frame the existing opening without touching it.
    for x in (-9, 9):
        for y in (-8, 2, 12):
            being.box((x, y, 3.5), (.65, .65, 7), 'cream')
            being.box((x, y, 7.05), (1.0, .9, .22), 'gold')
        being.box((x, 2, 7.25), (.45, 20.6, .3), 'cream')
    for y in (-8, 2, 12):
        being.box((0, y, 7.25), (18.8, .42, .33), 'cream')
        being.box((0, y, 7.08), (18.4, .15, .06), 'gold')
    for x in (-6.5, 6.5):
        for y in (-5, 5):
            being.box((x, y, .08), (.8, .8, .16), 'gold')
    being_obj = _visual(being, 'being_hall_dressing', (500, 0, 0), 255,
                        'pale colonnade and gold courses around the bright ending')

    both = M()
    # The split passage follows the existing arch and floor, so its left and
    # right halves read separately in the player approach view.
    for side, color in ((-1, 'cream'), (1, 'ink')):
        x = side * 5.6
        both.box((x, 7, 3.4), (.45, 18, 6.8), color)
        for y in (-1, 3, 7, 11, 15):
            both.box((x - side * .10, y, 4.0), (.20, .22, 4.6),
                     'gold' if side < 0 else 'purple')
        both.box((side * 2.9, 16, 4.0), (5.5, .38, 8), color)
        for step in range(5):
            y = 4 + step * 2.4
            both.box((side * 2.5, y, .08 + step * .11),
                     (4.6, .16, .16), 'gold' if side < 0 else 'purple')
    both.box((0, 16, 7.7), (11.2, .55, .38), 'gold')
    both_obj = _visual(both, 'both_hall_dressing', (600, 0, 0), 256,
                       'paired light and dark stone walls around the combined passage')

    void = M()
    rng = random.Random(71024)
    for index in range(72):
        y = rng.uniform(-10, 13)
        side = -1 if index % 2 else 1
        x = side * rng.uniform(2.5, 14)
        z = rng.uniform(.8, 7)
        size = rng.uniform(.10, .30)
        void.box((x, y, z), (size, size * .75, size * 1.3),
                 'purple' if index % 7 == 0 else 'stone')
    for side in (-1, 1):
        void.beam((side * 1.8, 8, .2), (side * 1.8, 8, 6.8), .045, 'purple')
    void_obj = _visual(void, 'void_shards_dressing', (700, 0, 0), 258,
                       'restrained suspended fragments and distant portal edges')

    surgery = M()
    for x in range(-6, 7, 3):
        surgery.box((x, 0, 4.82), (.10, 17, .08), 'steel')
    for y in range(-6, 7, 3):
        surgery.box((0, y, 4.82), (15, .10, .08), 'steel')
    for side in (-1, 1):
        x = side * 7.2
        surgery.box((x, 0, 2.8), (.14, 16.5, 4.2), 'steel')
        surgery.box((x - side * .18, 0, 3.0), (.08, 13.5, 2.0), 'blue')
        surgery.box((x - side * .21, 0, 3.0), (.09, 13.7, .09), 'cream')
    # The monitor sits behind the physicians and remains off the patient bed.
    surgery.box((5.1, 5.0, 3.25), (2.15, .16, 1.35), 'ink')
    surgery.box((5.1, 4.90, 3.25), (1.90, .06, 1.08), 'blue')
    for i in range(8):
        x = 4.35 + i * .20
        z = 3.1 + (.23 if i in (2, 3, 4) else .03)
        surgery.beam((x, 4.85, z), (x + .19, 4.85, 3.1 + (.23 if i in (3, 4) else .03)),
                     .035, 'green')
    surgery_obj = _visual(surgery, 'surgery_room_dressing', (800, 0, 0), 159,
                          'tiled operating room ceiling, wall panels and monitor', top=8)

    added = [sky.name, being_obj.name, both_obj.name, void_obj.name, surgery_obj.name]
    (out / 'ending-style-sheets.json').write_text(json.dumps({
        'sky': {'size': [256, 128], 'prelit': True, 'mesh': sky.name},
        'painted': painted,
        'dressing': added[1:],
    }, indent=2) + '\n')
    return {
        'stage': STAGE,
        'areas': ['Being', 'Both', 'NotBeing', 'surgery'],
        'added': added,
        'painted': painted,
        'visibility': {'being': 255, 'both': 256, 'void': 258, 'surgery': 159},
        'collision': 'new visual meshes have unreachable bounds; existing support, doors and encounters unchanged',
        'sources': ['art_being_sky.tga', 'art_being_marble.tga',
                    'art_both_floor.tga', 'art_surgery_tile.tga'],
    }
