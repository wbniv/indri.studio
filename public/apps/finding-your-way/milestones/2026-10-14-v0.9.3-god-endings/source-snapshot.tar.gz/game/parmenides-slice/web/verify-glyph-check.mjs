import { chromium } from '/home/will/finding-your-way/node_modules/@playwright/test/index.mjs';
import assert from 'node:assert/strict';
import { mkdirSync, writeFileSync } from 'node:fs';
const [target,out]=process.argv.slice(2);mkdirSync(out,{recursive:true});
const browser=await chromium.launch({executablePath:'/usr/bin/google-chrome',headless:true,args:['--no-sandbox','--enable-unsafe-swiftshader']});
try {
 const page=await browser.newPage();const errors=[],console=[];
 page.on('pageerror',e=>errors.push(e.stack));page.on('console',m=>console.push(m.text()));
 await page.goto(target);await page.waitForFunction(()=>window.glyphDone,null,{timeout:60000});
 const cases=await page.evaluate(()=>window.glyphResults);
 assert.equal(errors.length,0,errors.join('\n'));assert.deepEqual(cases.map(c=>c.count),[1,255,256,257,769]);
 function packed(index){
  const x=index*.125,y=index*.0625,g=Math.fround((index&255)/255);
  return [[x,y,0,0],[x+8,y,1,0],[x+8,y+8,1,1],[x,y,0,0],[x+8,y+8,1,1],[x,y+8,0,1]].flatMap(([px,py,u,v])=>[px,py,0,u,v,1,g,0,1]);
 }
 for (const c of cases) {
  const batches=[];for(let left=c.count;left>0;left-=256)batches.push(Math.min(left,256));
  assert.deepEqual(c.draws,batches.map(n=>n*6));assert.deepEqual(c.uploads.map(u=>u.bytes),batches.map(n=>n*6*9*4));
  assert.equal(c.freeBefore,c.freeAfter);
  for(let i=0;i<c.uploads.length;i++){
   const u=c.uploads[i];assert.deepEqual(u.first,packed(i*256));assert.deepEqual(u.last,packed(i*256+batches[i]-1));
   assert.equal(c.freeBefore-u.freeDuring,Math.min(c.count,256)*6*9*4);
  }
 }
 writeFileSync(out+'/glyph-results.json',JSON.stringify({passed:true,browser:await browser.version(),cases,errors,console},null,2)+'\n');
 process.stdout.write('PASS actual linked renderer: batch counts/upload lengths/vertex packing/arena balance/GL restoration/surface loss\n');
} finally {await browser.close();}
