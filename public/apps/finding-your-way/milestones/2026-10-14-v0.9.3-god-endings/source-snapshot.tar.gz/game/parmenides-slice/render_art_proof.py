"""Render actual proof meshes and diffuse sources as Blender turnarounds.

Lighting/camera are review fixtures, never changes to the exported level.
Run: blender --background --python this.py -- --build-dir PATH --out PATH.
"""
import argparse
import json
import math
from pathlib import Path
import sys
import bpy
from mathutils import Vector

parser=argparse.ArgumentParser();parser.add_argument('--build-dir',type=Path,required=True)
parser.add_argument('--out',type=Path,required=True);parser.add_argument('--iteration-c-only',action='store_true');parser.add_argument('--iteration-d-only',action='store_true')
args=parser.parse_args(sys.argv[sys.argv.index('--')+1:]);args.build_dir=args.build_dir.resolve();args.out=args.out.resolve()
args.out.mkdir(parents=True,exist_ok=True)
receipt=json.loads((args.build_dir/'build-receipt.json').read_text())
bpy.ops.wm.open_mainfile(filepath=str(args.build_dir/'parmenides_slice.blend'))
families=[('player',['Player','PlayerArmL','PlayerArmR','PlayerLegL','PlayerLegR']),('goddess',['Goddess','GoddessWingL','GoddessWingR'])]
if 'LoveCrowd0' in bpy.data.objects:
    families += [('first-love',['FirstLove']),('starlet',['Starlet']),*[(f'crowd-{i}',[f'LoveCrowd{i}']) for i in range(4)]]
if receipt['artStage']=='reason-truth':
    c_families=[(name.lower(),[name]) for name in ('WhiteSelf','WildSelf','YoungerSelf','Prosecutor','DefenceAttorney','Student','Judge','OldLady')]
    families=c_families if args.iteration_c_only else families+c_families
elif args.iteration_c_only:raise ValueError('--iteration-c-only requires reason-truth build')
if receipt['artStage']=='god-final':
    d_families=[('young-guide',['YoungMan']),('holy-guide',['HolyMan'])]
    families=d_families if args.iteration_d_only else families+d_families
elif args.iteration_d_only:raise ValueError('--iteration-d-only requires god-final build')
parts={name:bpy.data.objects[name].copy() for _,names in families for name in names}
for obj in list(bpy.data.objects):
    if obj.name not in {o.name for o in parts.values()}:bpy.data.objects.remove(obj,do_unlink=True)
# Unlinked copies survive removing the original scene objects; replace the
# scene's actor transforms with a neutral review pose around the floor contact.
for obj in list(bpy.context.scene.objects):bpy.data.objects.remove(obj,do_unlink=True)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=4;scene.render.threads_mode="FIXED";scene.render.threads=2
scene.render.resolution_x=400;scene.render.resolution_y=600;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='Standard'
scene.world=bpy.data.worlds.new('Proof neutral world');scene.world.use_nodes=True
scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.70,.67,.60,1)
scene.world.node_tree.nodes['Background'].inputs[1].default_value=.65
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.008));ground=bpy.context.object
mat=bpy.data.materials.new('Review floor');mat.diffuse_color=(.56,.54,.49,1);ground.data.materials.append(mat)
for location,power,size in [((3,-4,5),350,4),((-3,-1,3),180,3)]:
    light=bpy.data.lights.new('Review softbox','AREA');light.energy=power;light.shape='DISK';light.size=size
    obj=bpy.data.objects.new('Review softbox',light);scene.collection.objects.link(obj);obj.location=location
    obj.rotation_euler=(Vector((0,0,1))-obj.location).to_track_quat('-Z','Y').to_euler()
camera=bpy.data.cameras.new('Review orthographic');camera.type='ORTHO';camera.ortho_scale=2.75
obj=bpy.data.objects.new('Review orthographic',camera);scene.collection.objects.link(obj);scene.camera=obj
obj.location=(4,-.01,1.60);obj.rotation_euler=(Vector((0,0,1.02))-obj.location).to_track_quat('-Z','Y').to_euler()
rows=[]
for family,names in families:
    camera.ortho_scale=3.7 if family=='goddess' else 2.75
    parent=bpy.data.objects.new('Review floor pivot',None);scene.collection.objects.link(parent)
    for name in names:
        part=parts[name];scene.collection.objects.link(part);part.parent=parent;part.rotation_euler=(0,0,0);part.scale=(1,1,1)
        if 'PlayerArm' in name:part.location=(0,-.267 if name.endswith('L') else .267,1.25)
        elif 'PlayerLeg' in name:part.location=(0,-.112 if name.endswith('L') else .112,.85)
        elif 'Wing' in name:part.location=(-.08,-.2 if name.endswith('L') else .2,1.23)
        else:part.location=(0,0,0)
    for name,angle in [('front',0),('side',math.pi/2),('back',math.pi)]:
        parent.rotation_euler.z=angle;scene.render.filepath=str(args.out/f'{family}-{name}.png')
        bpy.ops.render.render(write_still=True);rows.append(dict(asset=family,view=name,file=f'{family}-{name}.png'))
    for name in names:scene.collection.objects.unlink(parts[name]);parts[name].parent=None
    bpy.data.objects.remove(parent,do_unlink=True)
(args.out/'turnaround-manifest.json').write_text(json.dumps(dict(build=receipt,
    representation='Actual exported Blender meshes and generated diffuse sources; neutral review camera/lighting',views=rows),indent=2)+'\n')
