"""Iteration F: localized, source-preserving presentation corrections.

No camera/runtime changes, render optimization or experimental realm culling.
The Being-only inherited-background mask is a deliberate scene-composition decision;
all authored collision fields, narrative visibility and non-Being presentation remain.
"""
from art_temple_love import replace
from art_endings import surgeon

STAGE='polish'
BEING_BACKGROUND=490


def dress(M,scene,out):
    replaced=[]
    class PatientHands(M):
        def part(self,verts,faces,color):
            # Pull only low, forward sleeves/gloves toward the fixed patient
            # view. Mask/head bounds never meet both the lateral/forward test.
            # Recompute projection bounds through M.part after deforming, so
            # no translated vertices retain stale painted-UV projection bounds.
            shifted=[]
            for x,y,z in verts:
                amount=max(0,min(1,(3.30-z)/.62)) if abs(x)>.10 and y>.25 else 0
                shifted.append((x,y-.25*amount,z+.12*amount))
            super().part(shifted,faces,color)
    for i in range(3):
        name='surgeon_'+str(i+1)
        obj=replace(scene,M,name,surgeon(PatientHands,i))
        obj['art_stage']=STAGE;obj['art_role']='patient-readable glove and sleeve pose'
        replaced.append(name)
    # Keep the filled-down/outlined-up motif and its actor pivot; compress and
    # lower local geometry rather than moving the reachable source threshold.
    obj=scene.objects['both_triangles'];mesh=obj.data.copy();obj.data=mesh
    for vertex in mesh.vertices:
        vertex.co.x*=.48
        vertex.co.z=vertex.co.z*.48-1.50
    mesh.update();obj['art_stage']=STAGE
    obj['art_role']='combined motif lowered into normal close approach framing'
    replaced.append(obj.name)
    # The two resident rooms can draw distant God and court dressing behind
    # Being. Isolate only this ending from inherited world art and signage, including conditional court props.
    # Their original logical conditions are retained
    # outside Being; ending art has its own source-specific 254/255 mailboxes.
    masked=[]
    for obj in scene.objects:
        logical=int(obj.get('wf_Visibility Mailbox',1))
        if obj.get('wf_Model Type')=='Mesh' and logical not in (250,254,255) and not obj.name.startswith('Player') and not (obj.parent and obj.parent.name.startswith('Player')):
            if logical in (1,242):obj['wf_Visibility Mailbox']=490 if logical==1 else 491
            obj['art_polish']='Hide inherited ordinary background only during Being'
            masked.append(obj.name)
    return dict(stage=STAGE,replaced=replaced,added=[],
        presentationMasked=masked,maskMailbox=BEING_BACKGROUND,signMaskMailbox=491,
        reused=['A–E painted materials, faces, architecture and exact source signage',
                'all actor transforms, authored collision fields and exact invisible support triangles',
                'fixed patient camera, lateral lamp and bounded E rigid motion',
                'canonical filled downward / outlined upward Both motif'],
        intentionallyInvisible=['being_support','void_support','voice-only Old Woman'],
        limits=['Extremely close or inside a threshold can still crop its geometry; camera collision is deferred',
                'Changed surgeon/Both render triangles may also change native statplat mesh collision; unchanged fields alone do not prove identical colliders',
                'No performance improvement or sustained measurement claimed'],
        pending=['Actual native glove/motif framing and Being turn review',
                 'Full both-view regression, matched media, device review and immutable archive'])


def emit_presentation(emit):
    # Forth true is -1. The ordinary modal render gates apply this mailbox too.
    emit('102 read-mailbox 5 <> 1 read-mailbox & 490 write-mailbox\n')
    emit('102 read-mailbox 5 <> 242 read-mailbox & 491 write-mailbox\n')
