#!/usr/bin/env python3
"""Build-only Atkinson rasterization; runtime consumes WFGA pixels + metrics.

Codex CLI 0.160.1, gpt-6.1-sol, effort high.
"""
import hashlib
import json
from pathlib import Path
import struct

from PIL import Image, ImageDraw, ImageFont

CONTROLS = 'SELECT: continue   LEFT / C: close   UP / DOWN: text size'
VARIANTS = ((0, (24, 28, 36, 42, 48, 54, 56, 63, 72, 84)),
            (1, (18, 24, 36, 48, 54, 72, 81, 108)))
BINDINGS = (140, 129, 629, 630, 631, 632, 102)  # beat, ready, page, count, size, rendered beat


def cmap(path):
    """Read the font's Unicode coverage without adding a runtime dependency."""
    data = path.read_bytes()
    u16 = lambda off: struct.unpack_from('>H', data, off)[0]
    u32 = lambda off: struct.unpack_from('>I', data, off)[0]
    tables = {data[off:off+4]: u32(off+8)
              for off in range(12, 12+16*u16(4), 16)}
    base = tables[b'cmap']
    result = set()
    for off in range(base+4, base+4+8*u16(base+2), 8):
        if u16(off) not in (0, 3):
            continue
        sub = base + u32(off+4)
        fmt = u16(sub)
        if fmt == 12:
            for group in range(sub+16, sub+16+12*u32(sub+12), 12):
                first, last, glyph = struct.unpack_from('>III', data, group)
                result.update(range(first+(glyph == 0), last+1))
        elif fmt == 4:
            count = u16(sub+6)//2
            ends = sub+14
            starts = ends+2*count+2
            deltas = starts+2*count
            ranges = deltas+2*count
            for i in range(count):
                for cp in range(u16(starts+2*i), u16(ends+2*i)+1):
                    distance = u16(ranges+2*i)
                    glyph = u16(ranges+2*i+distance+2*(cp-u16(starts+2*i))) if distance else cp
                    if glyph and (glyph+u16(deltas+2*i)) % 65536:
                        result.add(cp)
    return result


def build(manifest, out, fonts):
    labels = manifest['labels']
    strings = [(f"beat {card['id']} title", card['title']) for card in manifest['cards']]
    strings += [(f"beat {card['id']} body", card['text']) for card in manifest['cards']]
    strings += [(f'label {name}', text) for name, text in labels.items()]
    strings += [(f"runtime beat {beat['id']}", beat['title']+beat['text']) for beat in manifest['runtime_beats']]
    strings += [('controls/progress', CONTROLS+'0123456789 /')]
    inventory = sorted({ord(char) for _, text in strings for char in text if char != '\n'})
    pairs = sorted({(ord(a), ord(b)) for _, text in strings for a, b in zip(text, text[1:])
                    if a != '\n' and b != '\n'} | {(ord(a), ord(b)) for a in '0123456789' for b in '0123456789'})
    files = [fonts/'AtkinsonHyperlegibleNext-Regular.ttf', fonts/'AtkinsonHyperlegibleNext-SemiBold.ttf']
    for path in files:
        coverage = cmap(path)
        for source, text in strings:
            missing = {f'U+{ord(c):04X}' for c in text if c != '\n' and ord(c) not in coverage}
            if missing:
                raise ValueError(f'{path.name}: missing {sorted(missing)} in {source}')
    # Shelf packing with two transparent texels between neighboring glyphs.
    width = 2048
    canvas = Image.new('L', (width, 4096), 0)
    # Reserved solid texel for native-pixel sign backdrops (not a font glyph).
    canvas.putpixel((0, 0), 255)
    variants, glyphs, kerns = [], [], []
    x, y, shelf = 1, 1, 0
    for face, sizes in VARIANTS:
        for px in sizes:
            index = len(variants)
            font = ImageFont.truetype(str(files[face]), px)
            ascent, descent = font.getmetrics()
            variants.append((index, face, px, ascent, descent, max(ascent+descent, round(px*1.5))))
            advances = {cp: round(font.getlength(chr(cp))*64) for cp in inventory}
            for cp in inventory:
                bx, by, right, bottom = font.getbbox(chr(cp), anchor='ls')
                w, h = right-bx, bottom-by
                if x+w+1 > width:
                    x, y, shelf = 1, y+shelf+2, 0
                if y+h+1 > canvas.height:
                    raise ValueError('Complete glyph inventory exceeds bounded atlas')
                if w and h:
                    tile = Image.new('L', (w, h))
                    ImageDraw.Draw(tile).text((-bx, -by), chr(cp), font=font, anchor='ls', fill=255)
                    canvas.paste(tile, (x, y))
                glyphs.append((index, cp, x, y, w, h, bx, by, advances[cp]))
                x += w+2
                shelf = max(shelf, h)
            for left, right in pairs:
                value = round(font.getlength(chr(left)+chr(right))*64)-advances[left]-advances[right]
                if value:
                    kerns.append((index, left, right, value))
    height = y+shelf+1
    if height > canvas.height:
        raise ValueError('Atlas height exceeds 4096')
    canvas = canvas.crop((0, 0, width, height))
    canvas.save(out/'glyph-atlas.png')
    metrics = dict(format='WFGA', version=1, width=width, height=height,
                   inventory=[f'U+{cp:04X}' for cp in inventory], variants=variants,
                   glyphs=glyphs, kerning=kerns, bindings=BINDINGS, controls=CONTROLS,
                   fontSha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in files})
    (out/'glyph-atlas.json').write_text(json.dumps(metrics, indent=2)+'\n')
    write_bundle(manifest, out, metrics, canvas.tobytes(), [])
    return metrics


def write_bundle(manifest, out, metrics=None, pixels=None, labels=None):
    if metrics is None:
        metrics = json.loads((out/'glyph-atlas.json').read_text())
        pixels = Image.open(out/'glyph-atlas.png').tobytes()
    if labels is None:
        actors = json.loads((out/'actors.json').read_text())['ids']
        exported = json.loads((out/'font-labels.json').read_text())
        labels = sorted([(actors[name], row['visibility'], row['realm'], row['text']) for name, row in exported.items()])
    header = b'WFGA' + struct.pack('<15i', 1, metrics['width'], metrics['height'],
                                 len(metrics['variants']), len(metrics['glyphs']), len(metrics['kerning']),
                                 len(manifest['cards']), len(labels), *BINDINGS)
    data = bytearray(header)
    for fmt, key in (('<6i', 'variants'), ('<9i', 'glyphs'), ('<4i', 'kerning')):
        for record in metrics[key]:
            data.extend(struct.pack(fmt, *record))
    runtime = {beat['id']:beat for beat in manifest['runtime_beats']}
    for legacy in manifest['cards']:
        card = runtime.get(legacy['id'], legacy)
        title, body = card['title'].encode(), card['text'].encode()
        data.extend(struct.pack('<3i', card['id'], len(title), len(body))+title+body)
    for actor, visibility, realm, text in labels:
        encoded = text.encode()
        data.extend(struct.pack('<4i', actor, visibility, realm, len(encoded))+encoded)
    data.extend(pixels)
    (out/'dialogue-glyphs.bin').write_bytes(data)


def append_to_level(path, payload):
    """Attach the glyph bundle while retaining RAM padding and RPRP locators."""
    data = bytearray(path.read_bytes())
    if len(data) < 4096 or data[:2] != b'L4' or data[2048:2052] != b'RAM\0':
        raise ValueError('Unexpected standalone L4/RAM structure')
    ram_bytes = struct.unpack_from('<I', data, 2052)[0]
    end = 2056 + ram_bytes
    if ram_bytes < 36 or end+8 > 4096 or data[end:end+4] != b'ALGN':
        raise ValueError('Glyph attachment requires valid RAM alignment padding')
    padding = struct.unpack_from('<I', data, end+4)[0]
    if end+8+padding != 4096:
        raise ValueError('RAM alignment does not end at the next sector')
    body = bytearray(data[2056:end])
    existing = [off for off in range(36, len(body)-11, 4) if body[off:off+4] == b'DLOG']
    if len(existing) > 1:
        raise ValueError('Duplicate glyph locators')
    if existing:
        insert = existing[0]
        relative, size = struct.unpack_from('<II', body, insert+4)
        start = 2048+relative
        if relative < 2048 or relative%2048 or size < 8 or size%2048 or start+size > len(data) or data[start:start+4] != b'DLOG':
            raise ValueError('Invalid existing glyph locator')
        length = struct.unpack_from('<I',data,start+4)[0]
        if length > size-8:
            raise ValueError('Invalid existing glyph payload')
        if data[start+8:start+8+length] == payload:
            return
    else:
        if padding < 12:
            raise ValueError('RAM header has no glyph locator padding')
        insert = len(body)-12 if body[-12:-8] == b'RPRP' else len(body)
        body[insert:insert] = bytes(12)
        padding -= 12
    offset = (len(data)+2047)//2048*2048
    chunk = b'DLOG'+struct.pack('<I',len(payload))+payload
    size = (len(chunk)+2047)//2048*2048
    struct.pack_into('<4sII',body,insert,b'DLOG',offset-2048,size)
    # Catalog replacement truncates at its locator, so keep its chunk last.
    catalog = b''
    if body[-12:-8] == b'RPRP':
        relative, catalog_size = struct.unpack_from('<II', body, len(body)-8)
        start = 2048+relative
        if relative < 2048 or relative%2048 or catalog_size < 8 or catalog_size%2048 or start+catalog_size > len(data) or data[start:start+4] != b'RPRP':
            raise ValueError('Invalid existing property locator')
        catalog = bytes(data[start:start+catalog_size])
        struct.pack_into('<I', body, len(body)-8, offset+size-2048)
    sector = b'RAM\0'+struct.pack('<I',len(body))+body+b'ALGN'+struct.pack('<I',padding)+bytes(padding)
    if len(sector) != 2048:
        raise ValueError('Invalid RAM sector size')
    data[2048:4096] = sector
    data.extend(bytes(offset-len(data))+chunk+bytes(size-len(chunk))+catalog)
    struct.pack_into('<I',data,4,len(data)-8)
    path.write_bytes(data)
