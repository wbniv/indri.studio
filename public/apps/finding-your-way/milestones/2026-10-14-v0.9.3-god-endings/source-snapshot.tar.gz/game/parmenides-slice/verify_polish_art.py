"""F live patient margins, close Both framing and complete Being turn review."""
import json
import time
import math
import itertools
import sys
from art_polish import BEING_BACKGROUND


def run(b,player,value,check,tap,position,read_pages,groups,ids,out,evidence,capture):
    from verify_endings_art import run as ending_art
    features={'masked-face':((-.34,-.30,2.79),(.34,.30,3.40)),
              'cap':((-.30,-.30,3.27),(.30,.35,3.56)),
              'left-glove':((-.40,.03,2.68),(-.11,.28,2.93)),
              'right-glove':((.11,.03,2.68),(.40,.28,2.93))}
    if '--polish-framing-only' not in sys.argv:
        ending_art(b,player,value,check,tap,position,read_pages,groups,ids,out,evidence,capture,
               features=features,require_full_gloves=True)
    manifest=json.loads((out/'art-manifest.json').read_text())
    masked=manifest['disposition']['presentationMasked']
    gates=json.loads((out/'visual-gates.json').read_text())
    actual=gates[str(BEING_BACKGROUND)];signs=gates['491'];b.watch(player,BEING_BACKGROUND);b.watch(player,actual);b.watch(player,signs)
    b.watch(ids['both_triangles'],3011)
    inventory=json.loads((evidence.parent/'asset-dispositions.json').read_text())['inventory']
    motif=next(row for row in inventory if row['actor']=='both_triangles')
    bounds=motif['local_bounds'];origin=motif['actor_location']
    world_ranges=[(bounds[i]+origin[i],bounds[i+3]+origin[i]) for i in range(3)]
    frames=[];projections=[];restoration=[]
    b.watch(player,1);b.watch(player,242)
    def setm(m,v):b.set_mailbox(m,v,idx=player)
    def wait(predicate):
        deadline=time.monotonic()+40
        while time.monotonic()<deadline and not predicate():time.sleep(.03)
        return bool(predicate())
    for mode in (0,1):
        if value(101)!=mode:tap(2)
        for mb,v in ((102,5),(140,0),(189,1),(222,1),(223,0),(224,0),(225,0),(488,4.2),(108,1)):
            setm(mb,v)
        position(500,0)
        check('Being-specific God background is hidden',wait(lambda:value(actual)==0 and value(signs)==0 and value(BEING_BACKGROUND)==0))
        for heading in range(8):
            setm(114,heading/8);time.sleep(.4)
            name=f'being-full-turn-{heading}-view-{mode}';capture(name)
            frames.append(dict(file=name+'.png',scene='Being',mode=mode,heading=heading/8,masked=masked))
        setm(140,groups['ending_10a'][0]);check('Being source reading preserves modal background mask',wait(lambda:value(actual)==0))
        tap(16384);setm(102,4);position(400,-2)
        check('God background restored on leaving Being',wait(lambda:bool(value(actual)) and bool(value(signs)) and bool(value(BEING_BACKGROUND))))
        name=f'god-background-restored-view-{mode}';capture(name);frames.append(dict(file=name+'.png',scene='God',mode=mode))
        for realm in (0,1,2,3,4,6,7,8):
            setm(102,realm)
            for reading in (0,groups['intro'][0]):
                setm(140,reading)
                predicate=lambda:value(actual)==(value(1) if reading==0 else 0) and value(signs)==(value(242) if reading==0 else 0)
                check(f'Being-only masks preserve original outside realm {realm} modal {bool(reading)} view {mode}',wait(predicate))
                restoration.append(dict(realm=realm,mode=mode,reading=reading,original_world=value(1),original_signs=value(242),derived_world=value(actual),derived_signs=value(signs)))
        setm(140,0)
        setm(102,6);setm(114,.25)
        for approach in (-1,0,1):
            position(600,approach);time.sleep(.3)
            name=f'both-close-{approach}-view-{mode}';capture(name)
            frames.append(dict(file=name+'.png',scene='Both',mode=mode,approach_y=approach))
            # Use the actual live camera and look target rather than a nominal
            # preview camera. The cube contains all lowered motif surfaces.
            av=lambda n,m:b.mailbox_values.get((ids[n],m))
            camera=[av('Camera',3009+i) for i in range(3)]
            aim=[av('LookAt',3009+i)+value(3009+i)-av('CamTarget',3009+i) for i in range(3)]
            dot=lambda a,c:sum(x*y for x,y in zip(a,c))
            norm=lambda a:[x/math.sqrt(dot(a,a)) for x in a]
            cross=lambda a,c:[a[1]*c[2]-a[2]*c[1],a[2]*c[0]-a[0]*c[2],a[0]*c[1]-a[1]*c[0]]
            forward=norm([aim[i]-camera[i] for i in range(3)]);right=norm(cross(forward,[0,0,1]));up=cross(right,forward)
            points=[];depths=[]
            for x,y,z in itertools.product(*world_ranges):
                delta=[x-camera[0],y-camera[1],z-camera[2]];depth=dot(delta,forward);depths.append(depth)
                points.append((.5+dot(delta,right)/(depth*math.tan(math.pi/6)*(1280/720)*2),.5-dot(delta,up)/(depth*math.tan(math.pi/6)*2)))
            margins=[min(p[0] for p in points),min(p[1] for p in points),1-max(p[0] for p in points),1-max(p[1] for p in points)]
            projections.append(dict(mode=mode,approach_y=approach,camera=camera,aim=aim,margins=margins,minimum_depth=min(depths),verified_mesh_world_bounds=world_ranges))
            (evidence/'both-projections.json').write_text(json.dumps(projections,indent=2)+'\n')
            check(f'Both motif complete at approach {approach} view {mode}',min(depths)>.1 and min(margins)>.025)
    (evidence/'polish-art-audit.json').write_text(json.dumps(dict(passed=True,build=json.loads((out/'build-receipt.json').read_text()),
        scope=('Framing-only probe; patient motion is not checked' if '--polish-framing-only' in sys.argv else 'Live bounded E motion with complete patient glove/face/cap margins, close Both approach framing, eight-heading Being review and God restoration. Recorded images require visual inspection.'),
        frames=frames,both_projection=projections,background_mask=masked,outside_Being_visibility_checks=restoration),indent=2)+'\n')
