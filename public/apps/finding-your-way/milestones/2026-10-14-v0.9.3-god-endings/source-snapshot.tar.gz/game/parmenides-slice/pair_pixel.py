"""Private terminal QR enrollment; all ADB pairing belongs to a coordinator job.

Never prints/persists the pairing password or calls ADB. mDNS identifies the
scanning phone; the reviewed admin step adds one TLS device, preserving state.
"""
import argparse
import fcntl
import hashlib
import importlib.util
import ipaddress
import json
import os
from pathlib import Path
import pty
import re
import secrets
import select
import shutil
import socket
import sqlite3
import struct
import subprocess
import sys
import tempfile
import time

ROOT=Path(__file__).resolve().parent
WF=Path('/home/will/WorldFoundry-wbniv')
DEVICE='phone-pixel-8-pro'
TYPES=('_adb-tls-pairing._tcp.local.','_adb-tls-connect._tcp.local.')

def wait_for_lock(lock, timeout=300):
    """Serialize protected setup without interrupting another deployment."""
    deadline=time.monotonic()+timeout;next_notice=0
    while True:
        try:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            return
        except BlockingIOError:
            now=time.monotonic()
            if now>=deadline:
                raise TimeoutError('Coordinator setup is still busy; retry after its current deployment finishes')
            if now>=next_notice:
                print('Waiting for the coordinator setup lock; existing sessions remain protected.',flush=True)
                next_notice=now+20
            time.sleep(min(.5,deadline-now))

def check_enrollment(config, device):
    if device['id']!=DEVICE or device['transport']!='tls':
        raise ValueError('Unexpected enrollment identity or transport')
    host=device['endpoint'].rsplit(':',1)[0];address=ipaddress.ip_address(host)
    networks=config.get('discovery_networks') or [str(ipaddress.ip_network(
        d['endpoint'].rsplit(':',1)[0]+'/24',strict=False)) for d in config['devices']]
    if not networks or not any(address in ipaddress.ip_network(n) for n in networks):
        raise ValueError('Phone is outside registered discovery networks; review enrollment network first')
    existing=[d for d in config['devices'] if d['id']==DEVICE or d['serial']==device['serial']]
    if existing:
        if (len(existing)==1 and existing[0]['id']==DEVICE and existing[0]['serial']==device['serial']
                and existing[0]['transport']=='tls'):
            return True
        raise ValueError('Device identity conflicts with existing enrollment')
    return False

def dns_name(data, offset, visited=None):
    visited=set() if visited is None else visited
    start=offset;labels=[];resume=None
    while True:
        if offset>=len(data):raise ValueError('Truncated DNS name')
        count=data[offset]
        if count&0xc0==0xc0:
            if offset+1>=len(data):raise ValueError('Truncated DNS pointer')
            pointer=((count&63)<<8)|data[offset+1]
            if pointer in visited:raise ValueError('DNS pointer cycle')
            visited.add(pointer)
            tail,_=dns_name(data,pointer,visited)
            labels.extend(tail.rstrip('.').split('.'));resume=offset+2;break
        if count&0xc0 or count>63:raise ValueError('Invalid DNS label')
        offset+=1
        if count==0:break
        if offset+count>len(data):raise ValueError('Truncated DNS label')
        labels.append(data[offset:offset+count].decode('ascii'));offset+=count
    return '.'.join(labels)+'.',resume if resume is not None else offset

def records(data):
    if len(data)<12:raise ValueError('Truncated DNS packet')
    _,flags,questions,answers,authority,additional=struct.unpack_from('!6H',data)
    if not flags&0x8000:return []
    offset=12;result=[]
    for _ in range(questions):
        _,offset=dns_name(data,offset);offset+=4
    for _ in range(answers+authority+additional):
        name,offset=dns_name(data,offset)
        if offset+10>len(data):raise ValueError('Truncated DNS record')
        kind,cls,ttl,size=struct.unpack_from('!HHIH',data,offset);offset+=10
        end=offset+size
        if end>len(data):raise ValueError('Truncated DNS data')
        if kind==1 and size==4:result.append((name,'address',socket.inet_ntoa(data[offset:end])))
        if kind==33 and size>=7:
            _,_,port=struct.unpack_from('!HHH',data,offset);host,_=dns_name(data,offset+6)
            result.append((name,'service',(host,port)))
        offset=end
    return result

def discover(service, timeout=900):
    # mDNS queries/discovery are observational, with no ADB connection/control.
    sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM,socket.IPPROTO_UDP)
    sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
    sock.bind(('',5353));sock.setsockopt(socket.IPPROTO_IP,socket.IP_ADD_MEMBERSHIP,
        socket.inet_aton('224.0.0.251')+socket.inet_aton('0.0.0.0'))
    sock.settimeout(.5);found={};deadline=time.monotonic()+timeout;next_query=0
    def query(name):
        encoded=b''.join(bytes([len(x)])+x.encode() for x in name.rstrip('.').split('.'))+b'\0'
        return struct.pack('!6H',0,0,1,0,0,0)+encoded+struct.pack('!HH',12,1)
    try:
        while time.monotonic()<deadline:
            if time.monotonic()>=next_query:
                for name in TYPES:sock.sendto(query(name),('224.0.0.251',5353))
                next_query=time.monotonic()+1
            try:data,peer=sock.recvfrom(65535)
            except socket.timeout:continue
            try:
                for name,kind,value in records(data):found[(name,kind)]=(value,peer[0],time.monotonic())
            except (ValueError,UnicodeError,struct.error):continue
            pairing=found.get((service+'.'+TYPES[0],'service'))
            if not pairing:continue
            host,port=pairing[0];address=found.get((host,'address'))
            if not address:continue
            ip=address[0]
            if ip!=pairing[1]:continue
            candidates=[]
            for (name,kind),(value,source,seen) in found.items():
                if kind!='service' or not name.endswith('.'+TYPES[1]) or source!=ip:continue
                serial_service=name[:-len('.'+TYPES[1])]
                if not serial_service.startswith('adb-'):continue
                serial=serial_service[4:].rsplit('-',1)[0]
                if re.fullmatch(r'[A-Za-z0-9_]{5,40}',serial):candidates.append((serial,value[1]))
            if len(set(candidates))==1:
                serial,connect_port=candidates[0]
                return dict(id=DEVICE,serial=serial,endpoint=f'{ip}:{connect_port}',transport='tls',
                            model='Pixel 8 Pro (pending verification)',pools=['phone-review'],health='offline'),f'{ip}:{port}'
        raise TimeoutError('QR session expired; retry with Wireless debugging enabled on the same Wi-Fi')
    finally:sock.close()

def admit(path):
    if os.geteuid()!=0:raise SystemExit('Only the reviewed enrollment step needs sudo')
    device=json.loads(path.read_text())
    required={'id','serial','endpoint','transport','model','pools','health'}
    if set(device)!=required or device['id']!=DEVICE or device['transport']!='tls' or device['health']!='offline' or device['pools']!=['phone-review']:
        raise SystemExit('Unexpected enrollment fields')
    if not re.fullmatch(r'[A-Za-z0-9_]{5,40}',device['serial']):raise SystemExit('Invalid serial')
    host,port=device['endpoint'].rsplit(':',1);address=ipaddress.ip_address(host)
    if not address.is_private or not port.isdigit() or not 1<=int(port)<=65535:raise SystemExit('Invalid private endpoint')
    config_path=Path('/etc/wf-device-coordinator/devices.json')
    # Protected deployment helper owns maintenance, complete-session drain,
    # SQLite/config backup, restart/readiness. No service code is replaced.
    helper=Path('/opt/wf-device-coordinator/deploy/upgrade.py')
    spec=importlib.util.spec_from_file_location('wf_reviewed_enrollment',helper)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    with (module.STATE/'locks/deployment.lock').open('a') as lock:
        wait_for_lock(lock)
        # Read only after acquiring the lock: another enrollment may have
        # finished while this attempt waited. Do not drain/restart twice.
        original=config_path.read_bytes();config=json.loads(original)
        if check_enrollment(config,device):
            print('Phone already enrolled; retaining registry and state.',flush=True);return
        module.wait_and_stop(timeout=300)
        backup=module.backup_state()
        try:
            if config_path.read_bytes()!=original:raise RuntimeError('Registry changed after enrollment review')
            config['devices'].append(device)
            temp=config_path.with_suffix('.pixel-enrollment');temp.write_text(json.dumps(config,indent=2)+'\n')
            shutil.copystat(config_path,temp);os.chown(temp,0,0);os.replace(temp,config_path)
            subprocess.run(['systemctl','start',module.UNIT],check=True,timeout=30)
            module.verify_service()
            with sqlite3.connect(module.STATE/'coordinator.sqlite3') as db:module.maintenance(db,False)
            print('Enrolled phone-pixel-8-pro; existing jobs/reservations/ADB keys retained.')
        except BaseException:
            # Keep maintenance visible if restart/readiness fails. Do not claim
            # a rolled-back device or bypass ownership with direct commands.
            config_path.write_bytes(original)
            print('Enrollment failed; original registry restored; maintenance retained.',file=sys.stderr)
            raise

def registered_phone(device, listing):
    """Inspect the supported Task listing; fail closed on conflicting identity."""
    rows=[]
    for line in listing.splitlines():
        match=re.fullmatch(r'([^: ]+): [^;]+; [^;]*; serial ([A-Za-z0-9_]+); Android [^;]*; ABI [^;]*; endpoint [^;]*; pools ([^;]*)',line)
        if not match:
            if line.strip():raise ValueError('Unexpected coordinator device listing; refusing enrollment fallback')
            continue
        rows.append(match.groups())
    matches=[row for row in rows if row[0]==DEVICE or row[1]==device['serial']]
    if not matches:return False
    if (len(matches)!=1 or matches[0][0]!=DEVICE or matches[0][1]!=device['serial']
            or matches[0][2].split(',')!=['phone-review']):
        raise ValueError('Scanning phone conflicts with coordinator registration')
    return True

def ensure_enrolled(device):
    # Coordinator access failures stop this attempt; never reinterpret them
    # as missing registration or bypass the service with administrator setup.
    listing=subprocess.run(['task','chromecast:devices'],cwd=WF,
                           check=True,capture_output=True,text=True,timeout=30)
    if registered_phone(device,listing.stdout):
        print('Phone already registered; pairing directly through the coordinator. No sudo needed.',flush=True)
        return
    print('First enrollment requires your Linux sudo password in this terminal.',flush=True)
    with tempfile.TemporaryDirectory(prefix='fyw-pixel-') as directory:
        path=Path(directory)/'device.json';path.write_text(json.dumps(device));path.chmod(0o600)
        subprocess.run(['sudo',sys.executable,str(Path(__file__).resolve()),'--admit',str(path)],check=True)

def pair_task(endpoint, password):
    pid,fd=pty.fork()
    if pid==0:
        os.chdir(WF)
        os.execlp('task','task','chromecast:readd',f'DEVICE={DEVICE}',f'PAIRING_ENDPOINT={endpoint}')
    sent=False;buffer=b''
    try:
        while True:
            ready,_,_=select.select([fd],[],[],1)
            if not ready:continue
            try:chunk=os.read(fd,4096)
            except OSError:break
            if not chunk:break
            buffer=(buffer+chunk)[-4096:]
            if not sent and b'pairing code:' in buffer:
                os.write(fd,(password+'\n').encode());sent=True
            # Never echo the secret even if a future getpass implementation
            # unexpectedly enables terminal echo.
            sys.stdout.write(chunk.decode(errors='replace').replace(password,'[private]'));sys.stdout.flush()
    finally:os.close(fd)
    _,status=os.waitpid(pid,0)
    if not sent or os.waitstatus_to_exitcode(status):raise RuntimeError('Coordinator pairing did not complete')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--admit',type=Path);args=parser.parse_args()
    if args.admit:return admit(args.admit.resolve())
    if os.geteuid()==0:raise SystemExit('Run normally; only enrollment requests sudo')
    if not sys.stdout.isatty():raise SystemExit('QR credentials are displayed only in a private terminal, never logs')
    session_dir=ROOT/'build';session_dir.mkdir(exist_ok=True)
    with (session_dir/'pixel-pairing.lock').open('a') as session_lock:
        try:fcntl.flock(session_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            raise SystemExit('A Pixel QR session is already active. Use its terminal, or close it before retrying.')
        run_session()

def run_session():
    import qrcode
    service='studio-'+secrets.token_hex(5);password=f'{secrets.randbelow(1000000):06d}'
    qr=qrcode.QRCode(border=4,error_correction=qrcode.constants.ERROR_CORRECT_M)
    qr.add_data(f'WIFI:T:ADB;S:{service};P:{password};;');qr.make(fit=True)
    print('On Pixel: Settings → System → Developer options → Wireless debugging → Pair device with QR code.\n')
    qr.print_ascii(invert=True)
    print('\nScan this QR. Registered phones pair without sudo; first enrollment needs administrator authentication. Pairing remains coordinator-owned.',flush=True)
    device,endpoint=discover(service)
    print('Discovered scanning phone. Checking coordinator registration.',flush=True)
    ensure_enrolled(device)
    pair_task(endpoint,password)
    password='';print('Paired through the coordinator. Pixel development connection is ready.',flush=True)

if __name__=='__main__':
    try:main()
    except (TimeoutError,RuntimeError,ValueError,subprocess.CalledProcessError,subprocess.TimeoutExpired) as error:
        print('Pixel pairing: '+str(error),file=sys.stderr)
        raise SystemExit(1)
