#!/usr/bin/env python3
"""Make a profileable copy of a frozen Parmenides APK for simpleperf.

The manifest is compiled into the APK, so ``<profileable android:shell="true"/>`` cannot be
added in place. The manifest is rebuilt from the same text ``build.py`` writes (version code and
name read from the base APK, ``<profileable>`` added inside ``<application>``) and the APK is
reassembled around the base's own assets, drawable resources and native libraries. Assets and
libraries are byte-identical to the base; only the manifest and the signature differ. The version
code is unchanged, so it installs over the base. Run it on a variant that already carries the
libraries and ``--frame-profile`` flag you want measured (``make_profile_variant.py``).

Usage:
    make_profileable_variant.py BASE.apk [BASE2.apk ...] [--out DIR] [--key P12]

Writes ``<out>/<base-stem>-profileable.apk`` and ``<out>/<base-stem>-profileable.json``.
"""
import argparse
import hashlib
import json
import re
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SDK = Path('/home/will/android-sdk-local')
TOOLS = SDK / 'build-tools/34.0.0'
ANDROID = SDK / 'platforms/android-34/android.jar'

MANIFEST = '''<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="org.worldfoundry.wf_game.parmenides" android:versionCode="VERSION_CODE" android:versionName="VERSION_NAME">
<uses-sdk android:minSdkVersion="21" android:targetSdkVersion="34"/><uses-permission android:name="android.permission.INTERNET"/>
<uses-feature android:name="android.hardware.touchscreen" android:required="false"/><uses-feature android:name="android.software.leanback" android:required="false"/>
<application android:label="Finding Your Way" android:icon="@drawable/icon" android:banner="@drawable/tv_banner" android:isGame="true" android:hasCode="false" android:extractNativeLibs="true">
<profileable android:shell="true"/>
<activity android:name="android.app.NativeActivity" android:exported="true" android:screenOrientation="landscape" android:configChanges="orientation|keyboardHidden|screenSize|uiMode" android:launchMode="singleTask"><meta-data android:name="android.app.lib_name" android:value="wf_game"/>
<intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/><category android:name="android.intent.category.LEANBACK_LAUNCHER"/></intent-filter></activity></application></manifest>'''


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def badging(apk):
    text = subprocess.run([TOOLS / 'aapt', 'dump', 'badging', str(apk)], capture_output=True, text=True, check=True).stdout
    match = re.search(r"package: name='([^']*)' versionCode='(\d+)' versionName='([^']*)'", text)
    if not match or match.group(1) != 'org.worldfoundry.wf_game.parmenides':
        raise SystemExit(f'{apk} is not a Parmenides APK')
    return int(match.group(2)), match.group(3)


def make(base, out_dir, key):
    base = base.resolve()
    code, name = badging(base)
    stem = base.stem
    result = out_dir / f'{stem}-profileable.apk'
    with tempfile.TemporaryDirectory(prefix='profileable-') as scratch:
        scratch = Path(scratch)
        assets, res = scratch / 'assets', scratch / 'res/drawable'
        assets.mkdir(); res.mkdir(parents=True)
        libs = []
        with zipfile.ZipFile(base) as z:
            for info in z.infolist():
                n = info.filename
                if n.startswith('assets/') and not n.endswith('/'):
                    (assets / n[len('assets/'):]).write_bytes(z.read(n))
                elif n.startswith('res/drawable/') and n.endswith('.png'):
                    (res / Path(n).name).write_bytes(z.read(n))
                elif n.startswith('lib/') and n.endswith('.so'):
                    libs.append((n, z.read(n)))
        if not libs or not (res / 'icon.png').exists() or not (res / 'tv_banner.png').exists():
            raise SystemExit(f'{base} is missing libraries or drawable resources')
        manifest = scratch / 'AndroidManifest.xml'
        manifest.write_text(MANIFEST.replace('VERSION_CODE', str(code)).replace('VERSION_NAME', name))
        unsigned, aligned = scratch / 'unsigned.apk', scratch / 'aligned.apk'
        subprocess.run([TOOLS / 'aapt', 'package', '-f', '-M', manifest, '-S', scratch / 'res', '-I', ANDROID,
                        '-A', assets, '-F', unsigned], check=True)
        with zipfile.ZipFile(unsigned, 'a') as bundle:
            for n, data in libs:
                bundle.writestr(n, data, compress_type=zipfile.ZIP_STORED)
        subprocess.run([TOOLS / 'zipalign', '-f', '4', unsigned, aligned], check=True)
        subprocess.run([TOOLS / 'apksigner', 'sign', '--ks', key, '--ks-pass', 'pass:android', '--out', result, aligned], check=True)
    subprocess.run([TOOLS / 'apksigner', 'verify', result], check=True)
    tree = subprocess.run([TOOLS / 'aapt', 'dump', 'xmltree', str(result), 'AndroidManifest.xml'], capture_output=True, text=True, check=True).stdout
    if 'E: profileable' not in tree or 'android:shell' not in tree:
        raise SystemExit('built manifest lacks <profileable android:shell="true"/>')
    new_code, _ = badging(result)
    if new_code != code:
        raise SystemExit('version code changed')
    with zipfile.ZipFile(base) as zb, zipfile.ZipFile(result) as zr:
        same = all(zb.read(n) == zr.read(n) for n in zb.namelist() if n.startswith(('assets/', 'lib/')))
        if not same:
            raise SystemExit('assets or libraries differ from the base')
        libs_sha = {n: hashlib.sha256(zr.read(n)).hexdigest() for n in zr.namelist() if n.startswith('lib/')}
    receipt = dict(base=str(base), baseSha256=sha256(base), apk=str(result), apkSha256=sha256(result),
                   versionCode=code, versionName=name, nativeLibraries=libs_sha,
                   note='Assets and native libraries byte-identical to the base; manifest gains '
                        '<profileable android:shell="true"/>; re-signed. For simpleperf only; not a milestone.')
    (out_dir / f'{stem}-profileable.json').write_text(json.dumps(receipt, indent=2) + '\n')
    return receipt


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.split('\n')[0])
    parser.add_argument('apks', nargs='+', type=Path)
    parser.add_argument('--out', type=Path, default=ROOT / 'build/profileable-variants')
    parser.add_argument('--key', type=Path, default=ROOT / 'build/development-signing.p12')
    args = parser.parse_args(argv)
    args.out.mkdir(parents=True, exist_ok=True)
    for apk in args.apks:
        r = make(apk, args.out, args.key.resolve())
        print(f"{r['apk']}  code={r['versionCode']} {r['versionName']}  sha256={r['apkSha256'][:16]}")
    return 0


if __name__ == '__main__':
    sys.exit(main())
