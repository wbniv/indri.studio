"""Exercise exported rigid parts through the unchanged native game runtime.

Transforms select review fixtures; movement and source dialogue use real input.
This verifies level safeguards while the independent engine proposal is reviewed.
"""
import json
import time
import sys


def run(b,player,value,check,tap,position,read_pages,groups,ids,out,evidence,capture):
    parts=['PlayerArmL','PlayerArmR','PlayerLegL','PlayerLegR','GoddessWingL','GoddessWingR','proof_love_door']
    for name in parts:
        for mailbox in (3009,3010,3011,3012,3013,3014):b.watch(ids[name],mailbox)
    for m in (117,3018,3019,3020):b.watch(player,m)
    rows=[]
    signed=lambda a:(a+.5)%1-.5
    timeout=float(sys.argv[sys.argv.index('--motion-timeout')+1]) if '--motion-timeout' in sys.argv else 45
    if timeout<=0:raise ValueError('--motion-timeout must be positive')
    def sample(seconds=.7):
        start=value(110);deadline=time.monotonic()+timeout;seen=[];last=None
        while time.monotonic()<deadline:
            clock=value(110)
            if clock!=last and clock is not None:
                state={name:[b.mailbox_values.get((ids[name],m)) for m in (3012,3013,3014)] for name in parts}
                if all(v is not None for angles in state.values() for v in angles):
                    seen.append(dict(clock=clock,angles=state));last=clock
            if clock is not None and clock>=start+seconds:break
            time.sleep(.015)
        if not seen or seen[-1]['clock']<start+seconds:
            print(dict(motion_start=start,motion_clock=value(110),sample_count=len(seen),
                missing=[(name,m) for name in parts for m in (3012,3013,3014)
                    if b.mailbox_values.get((ids[name],m)) is None]),flush=True)
        check('native clock advances for motion sample',bool(seen) and seen[-1]['clock']>=start+seconds)
        rows.extend(seen);return seen
    def angles(samples,name,axis):return [signed(r['angles'][name][axis]) for r in samples]
    def bounds(samples):
        for name in parts:
            if 'Wing' in name:limit=.0063
            elif 'Arm' in name:limit=.0224
            elif 'Leg' in name:limit=.0324
            else:continue
            check(name+' bounded native pitch',max(abs(a) for a in angles(samples,name,1))<=limit)
            check(name+' no inherited native roll',max(abs(a) for a in angles(samples,name,0))<.0001)
    position(3,0);samples=sample(1.5);bounds(samples)
    check('wings actually animate in native runtime',max(angles(samples,'GoddessWingL',1))-min(angles(samples,'GoddessWingL',1))>.0004)
    for name in parts[:4]:check(name+' neutral while standing',max(abs(a) for a in angles(samples,name,1))<.0001)
    capture('temple-goddess-follow')
    start=value(3010)
    b.inject_input('joystick1_raw',2048,40)
    samples=sample(1.0);bounds(samples)
    check('player traverses with rigid limbs present',value(3010)>start+.15)
    check('gait actually changes native limb pitch',any(max(angles(samples,n,1))-min(angles(samples,n,1))>.001 for n in parts[:4]))
    b.inject_input('joystick1_raw',0,1);sample(1.0)
    for clock in (10,100,1000,10000):
        b.set_mailbox(110,clock,idx=player);time.sleep(.25)
        samples=sample(.4);bounds(samples)
    b.set_mailbox(110,1,idx=player)
    tap(8);check('reduced motion enabled',value(108)==1)
    samples=sample(.5)
    for name in parts[4:6]:check(name+' reduced motion neutral',max(abs(a) for a in angles(samples,name,1))<.0001)
    tap(8);check('normal motion restored',value(108)==0)
    for mode in (0,1):
        if value(101)!=mode:tap(2)
        position(3,0);capture('temple-goddess-view-'+str(mode))
        check('body and limbs follow perspective visibility',bool(value(250))==(mode==0))
        position(-3.8,-1);capture('temple-column-view-'+str(mode))
        position(0,8);tap();check('art does not change Love portal',value(102)==1)
        position(96,-1);capture('love-corner-view-'+str(mode))
        position(106,3);capture('love-bench-view-'+str(mode))
        position(100,5);capture('love-newspaper-view-'+str(mode))
        tap();check('canonical newspaper opens',value(140)==groups['paper'][0]);capture('newspaper-reading-view-'+str(mode))
        read_pages('art newspaper mode '+str(mode),groups['paper'])
        position(100,-8);tap();check('return to Temple unchanged',value(102)==0)
    position(0,8);tap();position(96,1);tap()
    check('First Love exact source opens',value(140)==groups['first'][0])
    samples=sample(.5)
    for name in parts[4:6]:check(name+' modal motion neutral',max(abs(a) for a in angles(samples,name,1))<.0001)
    capture('first-love-reading')
    read_pages('art First Love',groups['first']);check('First Love completes and departs',value(103)==1 and value(251)==0)
    samples=sample(1.6 if 'LoveCrowd0' in ids else 1.0)
    expected=0 if 'LoveCrowd0' in ids else -.22
    check('door reaches source-correct departure state',abs(signed(samples[-1]['angles']['proof_love_door'][2])-expected)<.001)
    position(96,5);b.set_mailbox(114,.5,idx=player);capture('love-door-open')
    b.set_mailbox(103,0,idx=player);sample(1.0)
    check('door restores after replay state reset',abs(signed(b.mailbox_values[(ids['proof_love_door'],3014)]))<.001)
    capture('love-door-closed')
    if 'LoveCrowd0' in ids:
        from verify_temple_love import run as run_temple_love
        run_temple_love(b,player,value,check,tap,position,read_pages,groups,ids,out,evidence,capture)
    receipt=out/('build-receipt.json' if (out/'build-receipt.json').exists() else 'level-receipt.json')
    (evidence/'motion-samples.json').write_text(json.dumps(dict(build=json.loads(receipt.read_text()),
        scope='Unchanged native runtime; level-owned full-axis safeguards; actual movement and source input; explicit late-clock fixtures',samples=rows),indent=2)+'\n')
