"""Audit exact E→F deltas and disposition every current actor/prop."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import bpy

p=argparse.ArgumentParser();p.add_argument('--build-dir',type=Path,required=True)
p.add_argument('--baseline-build',type=Path,required=True);p.add_argument('--report',type=Path,required=True)
a=p.parse_args(sys.argv[sys.argv.index('--')+1:]);rows=[]
def check(label,condition):
    rows.append(dict(check=label,passed=bool(condition)))
    if not condition:raise AssertionError(label)
def snapshot(obj):
    mesh=obj.data if obj.type=='MESH' else None
    return dict(vertices=[list(v.co) for v in mesh.vertices] if mesh else [],
        faces=[list(poly.vertices) for poly in mesh.polygons] if mesh else [],
        uv=[list(loop.uv) for loop in mesh.uv_layers.active.data] if mesh and mesh.uv_layers.active else [],
        materials=[mat.name for mat in mesh.materials] if mesh else [],
        location=list(obj.location),rotation=list(obj.rotation_euler),scale=list(obj.scale),
        fields={k:(list(obj[k]) if hasattr(obj[k],'to_list') else obj[k]) for k in obj.keys()
                if k.startswith('wf_') and k not in ('wf_Script',)})
bpy.ops.wm.open_mainfile(filepath=str(a.baseline_build.resolve()/'parmenides_slice.blend'))
baseline={o.name:snapshot(o) for o in bpy.context.scene.objects}
bpy.ops.wm.open_mainfile(filepath=str(a.build_dir.resolve()/'parmenides_slice.blend'))
roster=[('Player',['Player']),('Goddess',['Goddess']),('First Love',['FirstLove']),('Starlet',['Starlet']),
 ('White-Clad Self',['WhiteSelf']),('Wild Self',['WildSelf']),('Prosecutor',['Prosecutor']),('Analyst',['DefenceAttorney']),
 ('Judge',['Judge']),('Old lady',['OldLady']),('Young man',['YoungMan']),('Old man',['HolyMan']),('Horror visage',['void_visage']),
 ('Surgeon',['surgeon_1','surgeon_2','surgeon_3']),('Crowd and gallery body',['LoveCrowd0','LoveCrowd1','LoveCrowd2','LoveCrowd3','CourtGallery0','CourtGallery1','CourtGallery2'])]
objects=bpy.context.scene.objects;manifest=json.loads((a.build_dir/'art-manifest.json').read_text())
changed=set(manifest['disposition']['replaced']);masked=set(manifest['disposition']['presentationMasked'])
gates=json.loads((a.build_dir/'visual-gates.json').read_text());success=False;inventory=[]
old_gates=json.loads((a.baseline_build/'visual-gates.json').read_text());reverse_gates={v:k for k,v in old_gates.items()}
def family(obj):
    x=obj.location.x
    if obj.type=='MESH' and obj.get('wf_Model Type')=='Mesh' and obj.data.vertices:
        world_x=[(obj.matrix_world @ vertex.co).x for vertex in obj.data.vertices]
        x=(min(world_x)+max(world_x))/2
    if obj.name=='Player' or obj.name.startswith('Player'):return 'Shared player'
    if obj.name.startswith('card_'):return 'Source reading sheets'
    if x>780:return 'Surgery'
    if x>680:return 'NotBeing'
    if x>580:return 'Both'
    if x>480:return 'Being'
    if x>350 or obj.name.startswith(('god_','GodCanopy','GodRoute','GodSummit')):return 'God'
    if x>250:return 'Truth'
    if x>150:return 'Reason'
    if x>50:return 'Love'
    return 'Temple / shared setup'
try:
    check('F explicit stage',manifest['stage']=='polish')
    check('actor roster unchanged from E',set(objects.keys())==set(baseline))
    for name,obj in objects.items():
        old=baseline[name];new=snapshot(obj)
        for key in ('location','rotation','scale'):check(name+' exact actor '+key,new[key]==old[key])
        for key,val in old['fields'].items():
            if key=='wf_Visibility Mailbox' and name in masked:continue
            expected=gates[reverse_gates[val]] if key=='wf_Visibility Mailbox' and val in reverse_gates else val
            check(name+' preserves logical '+key,new['fields'].get(key)==expected)
        if name in masked:
            original=reverse_gates[old['fields']['wf_Visibility Mailbox']]
            target='490' if original=='1' else '491' if original=='242' else original
            check(name+' Being-only derived visibility preserves original logical input',new['fields']['wf_Visibility Mailbox']==gates[target])
        if name not in changed:
            for key in ('vertices','faces','uv','materials'):check(name+' exact E '+key,new[key]==old[key])
        else:
            check(name+' still shares original painted diffuse',all(mat.startswith('art_surfaces') for mat in new['materials']))
            check(name+' normalized painted UVs',all(-1e-6<=c<=1+1e-6 for uv in new['uv'] for c in uv))
            # Independent connected solids retain their own vertices in this
            # construction. Summed signed volume rejects an inverted edit.
            total=0
            for poly in obj.data.polygons:
                vertices=[obj.data.vertices[i].co for i in poly.vertices]
                total+=sum(vertices[0].dot(vertices[j].cross(vertices[j+1]))/6 for j in range(1,len(vertices)-1))
            check(name+' positive outward aggregate volume',total>1e-6)
        invisible=obj.get('wf_Model Type')=='None'
        disposition='refined in F' if name in changed else 'deliberately reused from E'
        rationale=('Local hands or canonical motif framing; actor/authored collision fields preserved; changed statplat render triangles can also alter implicit native mesh collision' if name in changed
                   else 'Existing A–E original artwork or simple supporting surface retained without a demonstrated visual defect')
        if invisible:
            disposition='intentionally invisible'
            rationale=('Exact collision foundation; visible absence is source-correct' if name in ('being_support','void_support')
                       else 'Runtime actor/camera/light/room setup has no authored visible mesh')
        elif name.startswith('card_'):rationale='Complete canonical reading pixels and source inspection contract retained exactly'
        elif name in masked:rationale='Exact existing ordinary world art/sign retained; original visibility restores outside Being, while this ending excludes inherited God/court/background presentation'
        inventory.append(dict(actor=name,family=family(obj),disposition=disposition,rationale=rationale,
            local_bounds=([min(v.co[i] for v in obj.data.vertices) for i in range(3)]+[max(v.co[i] for v in obj.data.vertices) for i in range(3)]) if obj.type=='MESH' and obj.data.vertices else None,
            actor_location=list(obj.location),model_type=obj.get('wf_Model Type'),schema=Path(obj.get('wf_schema_path','')).stem,
            original_art_stage=obj.get('art_stage','baseline supporting geometry'),
            vertices=len(obj.data.vertices) if obj.type=='MESH' else 0,
            triangles=sum(len(poly.vertices)-2 for poly in obj.data.polygons) if obj.type=='MESH' else 0,
            nonphysical_dressing=obj.get('wf_Mass')==0 and Path(obj.get('wf_schema_path','')).stem=='platform'))
    for filename in ('content.json','art-textures.json'):
        check(filename+' exact E bytes',(a.build_dir/filename).read_bytes()==(a.baseline_build/filename).read_bytes())
    for path in a.baseline_build.glob('*.tga'):
        if path.name.startswith(('Room','Perm')):continue
        check(path.name+' exact E source texture',(a.build_dir/path.name).read_bytes()==path.read_bytes())
    for name in ('being_support','void_support'):
        check(name+' deliberate invisible support exactly preserved',snapshot(objects[name])==baseline[name] and objects[name]['wf_Model Type']=='None')
    check('voice-only Old Woman has no invented actor',not any('oldwoman' in name.lower().replace('_','') for name in objects.keys()))
    for design,actors in roster:check(design+' art-bible model-design coverage',all(name in objects for name in actors))
    success=True
finally:
    a.report.parent.mkdir(parents=True,exist_ok=True)
    a.report.write_text(json.dumps(dict(stage='polish',passed=success,checks=rows,inventory=inventory,
        build=json.loads((a.build_dir/'build-receipt.json').read_text()),
        model_designs=[dict(design=design,actors=actors) for design,actors in roster],
        scope='Complete actor disposition and exact E→F geometry/texture/frame/field preservation audit; full native winding/UV, motion and source regression run separately.',
        roster_note='All fifteen art-bible designs map to actual actors. The additional Student and every remaining prop appear in the complete inventory; Old Woman remains voice-only.'),indent=2)+'\n')
print('F static checks',len(rows))
