from pathlib import Path
import hashlib,json,sys
root=Path('/home/will/finding-your-way'); helpers=root/'game/parmenides-slice'; sys.path.insert(0,str(helpers))
e=root/'docs/diagnostics/parmenides/graphics-v0.7/polish'; original=e/'attempts/panel-endpoint-fixed-delay/panel-run/results.json'
read=lambda p:json.loads(p.read_text()); digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
results=read(original)[:2104]; assert len(results)==2104 and all(r['passed'] for r in results)
state=read(e/'panel-run/run-state.json'); sys.argv=['reaudit','--build-dir',str(helpers/'build/v0.7-polish')]
def check(label,condition):
    results.append(dict(check=label,passed=bool(condition))); print(label,condition,flush=True)
    if not condition:raise AssertionError(label)
try:
    from verify_panel_render import finalize
    finalize(helpers/'build/v0.7-polish',e/'panel-run',check,recording_cwd=e/'panel-run')
    state.update(status='re-audited',checks=len(results),error=None,method='Unchanged completed native fixture capture; corrected bounded-interval postprocessing. Original failed finalization retained under attempts/panel-endpoint-fixed-delay.')
finally:
    (e/'panel-run/results.json').write_text(json.dumps(results,indent=2)+'\n')
    controls=[r for r in results if r['check'].startswith('pixel detector ')]
    audit=read(e/'panel-render-audit.json')
    (e/'body-detector-negative-controls.json').write_text(json.dumps(dict(build=audit['build'],passed=audit['passed'] and len(controls)==5 and all(r['passed'] for r in controls),method='Actual controls from the renewed recorded-pixel finalizer.',results=controls,source_results='panel-run/results.json',source_results_sha256=digest(e/'panel-run/results.json'),video_sha256=audit['video_sha256']),indent=2)+'\n')
    (e/'panel-run/run-state.json').write_text(json.dumps(state,indent=2)+'\n')
    passed=audit['passed'] and read(e/'panel-transition-audit.json')['passed'] and len(results)==2530 and all(r['passed'] for r in results)
    (e/'panel-re-audit.json').write_text(json.dumps(dict(build=audit['build'],passed=passed,native_fixture_checks=2104,checks=len(results),original_results_sha256=digest(original),requests_sha256=digest(e/'panel-render-requests.json'),video_sha256=audit['video_sha256'],auditor_sha256=digest(helpers/'verify_panel_render.py'),method='Retain all original passing native fixture assertions unchanged; re-decode the complete original recording with endpoints bounded by recorded next-card selection and strict unchanged pixel checks. This is a recorded-evidence re-audit, not a new native execution.'),indent=2)+'\n')
