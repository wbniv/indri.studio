# Chapter-owned build configuration. The shared engine source is not modified.
# Applied after wf_game exists; defaults in the engine remain unchanged.
function(fyw_configure_web_target)
  if(NOT EMSCRIPTEN OR NOT TARGET wf_game)
    message(FATAL_ERROR "Finding Your Way requires the Emscripten wf_game target")
  endif()
  if(NOT EXISTS "${FYW_WEB_CD}")
    message(FATAL_ERROR "Missing verified chapter CD: ${FYW_WEB_CD}")
  endif()
  if(FYW_WEB_ASAN)
    foreach(target wfengine wf_game)
      target_compile_options(${target} PRIVATE -fsanitize=address -fsanitize-address-use-after-return=always -fno-omit-frame-pointer -g2)
    endforeach()
    target_link_options(wf_game PRIVATE -fsanitize=address)
  endif()
  if(FYW_WEB_CHECKS)
    target_link_options(wf_game PRIVATE -sASSERTIONS=2 "-Wl,-Map=${CMAKE_BINARY_DIR}/wf_game.map")
  endif()
  # Keep the original 64 KiB limit; transient glyph geometry now uses the
  # engine's existing scratch arena. Detect overflow before memory corruption.
  target_link_options(wf_game PRIVATE "-sSTACK_SIZE=${FYW_WEB_STACK_SIZE}" -sSTACK_OVERFLOW_CHECK=2)
  get_target_property(options wf_game LINK_OPTIONS)
  list(FILTER options EXCLUDE REGEX "^SHELL:--(preload-file|shell-file) ")
  set_property(TARGET wf_game PROPERTY LINK_OPTIONS "${options}")
  set_property(TARGET wf_game APPEND PROPERTY LINK_DEPENDS "${CMAKE_CURRENT_FUNCTION_LIST_DIR}/chapter-surface.js")
  target_link_options(wf_game PRIVATE "SHELL:--js-library ${CMAKE_CURRENT_FUNCTION_LIST_DIR}/chapter-surface.js" -g2
    "SHELL:--preload-file ${FYW_WEB_CD}@/parmenides_slice-standalone.iff"
    "SHELL:--shell-file ${FYW_WEB_SHELL}"
    "-sEXPORTED_RUNTIME_METHODS=callMain,requestFullscreen,FS,getValue")
endfunction()
cmake_language(DEFER CALL fyw_configure_web_target)
