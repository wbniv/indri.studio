"""Explicit diagnostic-only upward framing; production camera remains unchanged."""
import argparse,json
from pathlib import Path
import build_review_fixtures as f
p=argparse.ArgumentParser();p.add_argument('--build-dir',type=Path,required=True);a=p.parse_args();f.BASE=a.build_dir.resolve();ids=json.loads((f.BASE/'actors.json').read_text())['ids']
def tour(original,scenes,mode,content):
 tail=original.splitlines(keepends=True)[-1]
 helper=f': fy-art-camera 499 read-mailbox 0 <> 140 read-mailbox 0 = & if 8.3 INDEXOF_Z_POS {ids["LookAt"]} write-actor-mailbox then ;\n'
 return original[:-len(tail)]+helper+tail.replace('fy-camera ','fy-camera fy-art-camera ',1),[dict(scene='aether-upward',diagnostic_camera='Mailbox499 alone raises LookAtZ8.3; modal reading preserves production camera',not_production_pitch_control=True)]
f.tour=tour;f.SCENES=[('aether-camera',0,0,-5,'intro',{})];f.make(0,0,scene_only='aether-camera')
