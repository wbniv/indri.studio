#!/usr/bin/env python3
"""Compare world/label pixels at identical simulation steps for two slot layouts."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

import numpy as np
from PIL import Image
from glyph_atlas import append_to_level
from texture_slots import LEGACY_ARGS, runtime_args

p = argparse.ArgumentParser()
p.add_argument('--engine', type=Path, required=True)
p.add_argument('--build-dir', type=Path, required=True)
p.add_argument('--evidence', type=Path, required=True)
p.add_argument('--scenes', default='all', help='Comma-separated realm scene names, or all.')
a = p.parse_args()
a.evidence.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(a.engine/'tests'))
from debug_bridge_client import BridgeClient
from build_review_fixtures import SCENES
scenes = [row for row in SCENES[:9] if a.scenes == 'all' or row[0] in a.scenes.split(',')]
if not scenes:
    raise ValueError('No matching realm scenes')

original = (a.build_dir/'chapter.fth').read_text()
tail = original.splitlines(keepends=True)[-1]
source = (a.build_dir/'parmenides_slice.lev').read_text()
player = json.loads((a.build_dir/'actors.json').read_text())['ids']['Player']
results = []
display = subprocess.Popen(['Xvfb', ':95', '-screen', '0', '1280x720x24', '-nolisten', 'tcp'],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(.5)

def sha(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()

def wait(proc, predicate, label):
    deadline = time.monotonic()+30
    while time.monotonic() < deadline:
        if proc.poll() is not None:
            raise RuntimeError('Engine exited: '+label)
        if predicate():
            return
        time.sleep(.01)
    raise RuntimeError('Timed out: '+label)

def capture(folder, flags, target, name):
    target.unlink(missing_ok=True)
    log = (folder/(name+'.log')).open('w')
    argv = [str(a.engine/'engine/wf_game'), '-L'+str(folder/'parmenides_slice-standalone.iff'),
            '-rate14', '-width=1280', '-height=720', '--no-fps', '--debug-port', '7831',
            '--debug-bind', '127.0.0.1', *flags]
    proc = subprocess.Popen(argv, cwd=folder, env=dict(os.environ, DISPLAY=':95'),
                            stdout=log, stderr=subprocess.STDOUT)
    b = None
    try:
        b = BridgeClient(port=7831, timeout=20)
        b.watch(player, 638)
        value = lambda: b.mailbox_values.get((player, 638), 0)
        wait(proc, lambda: value() > 0, 'simulation counter')
        b.send({'op': 'pause'})
        wait(proc, lambda: any(row.get('op') == 'paused' for row in b._inbox), 'pause acknowledgement')
        time.sleep(.15)
        current = int(value())
        if current >= 200:
            raise RuntimeError('Connected too late to capture simulation step 200')
        b.send({'op': 'step', 'frames': 200-current})
        wait(proc, lambda: value() == 200, 'exact simulation step 200')
        # Rendering continues while simulation is paused. Let the final camera
        # and label quads reach the presented framebuffer before capturing it.
        time.sleep(.15)
        b.send({'op': 'screenshot', 'filename': str(target)})
        wait(proc, lambda: target.exists() and target.stat().st_size > 0, 'presented frame')
        if value() != 200:
            raise RuntimeError('Simulation advanced beyond the requested capture')
        return dict(argv=argv, simulationStep=int(value()), pngSha256=sha(target))
    finally:
        if b:
            b.close()
        proc.terminate()
        proc.wait(timeout=10)
        log.close()

try:
    for scene, realm, x, y, _, history in scenes:
        for camera in (0, 1):
            folder = a.evidence/f'{scene}-view-{camera}'
            folder.mkdir(exist_ok=True)
            for file in a.build_dir.iterdir():
                if file.is_file() and file.suffix in ('.iff', '.tga', '.ruv', '.cyc'):
                    shutil.copyfile(file, folder/file.name)
            setters = ''.join(f'{value} {mailbox} write-mailbox ' for mailbox, value in history.items())
            if realm == 8:
                setters += '2 189 write-mailbox 2 222 write-mailbox 1 223 write-mailbox '
            setup = (f': slot-start 639 read-mailbox 0 = if 1 639 write-mailbox '
                     f'{x} {y} fy-teleport {realm} 102 write-mailbox {camera} 101 write-mailbox '
                     f'0 140 write-mailbox {setters}then ;\n'
                     ': slot-count 638 read-mailbox 1 + 638 write-mailbox ;\n')
            revised = original[:-len(tail)]+setup+tail.replace('fy-init ', 'fy-init slot-start slot-count ', 1)
            count = [0]
            def replace(match):
                if json.loads(match[2]) == original:
                    count[0] += 1
                    return match[1]+json.dumps(revised)+match[3]
                return match[0]
            pattern = r'(\{ \'STR\' \{ \'NAME\' "Script" \} \{ \'STR\' )("(?:[^"\\]|\\.)*")( \} \})'
            level = re.sub(pattern, replace, source)
            if count[0] != 1:
                raise RuntimeError('Expected one Player script replacement')
            (folder/'parmenides_slice.lev').write_text(level)
            tool = lambda name: a.engine/'wftools'/f'{name}-rs'/'target/release'/name
            with (folder/'compile.log').open('w') as log:
                def run(*args):
                    subprocess.run(list(map(str, args)), cwd=folder, stdout=log, stderr=subprocess.STDOUT, check=True)
                run(tool('iffcomp'), '-binary', '-o=parmenides_slice.lev.bin', 'parmenides_slice.lev')
                run(tool('levcomp'), 'parmenides_slice.lev.bin', a.engine/'wfsource/source/oas/objects.lc',
                    'parmenides_slice.lvl', a.engine/'wfsource/source/oas', '--mesh-dir', '.',
                    '--iff-txt', 'parmenides_slice.iff.txt', '--textile-ini', 'parmenides_slice.ini')
                run(tool('iffcomp'), '-binary', '-o=parmenides_slice.iff', 'parmenides_slice.iff.txt')
                wrapper = "{ 'L4' { 'ALGN' .align( 2048 ) } { 'RAM' 'OBJD' 4194304l 'PERM' 16777216l 'ROOM' 8388608l 'FLAG' 1l 1l } { 'ALGN' .align( 2048 ) } [ \"parmenides_slice.iff\" ] }\n"
                (folder/'parmenides_slice-standalone.iff.txt').write_text(wrapper)
                run(tool('iffcomp'), '-binary', '-o=parmenides_slice-standalone.iff', 'parmenides_slice-standalone.iff.txt')
            append_to_level(folder/'parmenides_slice-standalone.iff', (a.build_dir/'dialogue-glyphs.bin').read_bytes())
            old = capture(folder, LEGACY_ARGS, folder/'old.png', 'old')
            small = capture(folder, runtime_args(a.build_dir), folder/'small.png', 'small')
            image_old = np.asarray(Image.open(folder/'old.png').convert('RGB'), dtype=np.int16)
            image_small = np.asarray(Image.open(folder/'small.png').convert('RGB'), dtype=np.int16)
            delta = np.abs(image_small-image_old)
            pixels = int(np.count_nonzero(np.any(delta, axis=2)))
            result = dict(scene=scene, realm=realm, camera=camera, differentPixels=pixels,
                          maxChannelDifference=int(delta.max()), passed=pixels == 0,
                          nonBackgroundPixels=int(np.count_nonzero(np.any(image_old != image_old[0, 0], axis=2))),
                          levelSha256=sha(folder/'parmenides_slice-standalone.iff'), old=old, small=small)
            results.append(result)
            (a.evidence/'results.json').write_text(json.dumps(dict(
                engineSha256=sha(a.engine/'engine/wf_game'), results=results,
                passed=all(row['passed'] for row in results)), indent=2)+'\n')
            print(f'{"PASS" if pixels == 0 else "FAIL"} {scene} camera {camera}: {pixels} differing pixels', flush=True)
finally:
    display.terminate()
    display.wait(timeout=10)
raise SystemExit(0 if len(results) == 2*len(scenes) and all(row['passed'] for row in results) else 1)
