"""Combine 419 unchanged recorded views with the freshly verified final patient view."""
from pathlib import Path
import hashlib,json,shutil

ROOT=Path(__file__).resolve().parent
e=ROOT.parents[1]/'docs/diagnostics/parmenides/graphics-v0.7/polish'
read=lambda p:json.loads(p.read_text())
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
key=lambda r:(r['card'],r['camera'],r['patient'])
target=(208,1,True)
base=read(e/'panel-render-audit.json')
transition=read(e/'panel-transition-audit.json')
assert len(base['results'])==420
assert [key(r) for r in base['results'] if not r['passed']]==[target]
assert all(r['passed'] for r in transition['results'])
probe=e/'patient-presentation-probe'
fresh=read(probe/'panel-render-audit.json')
fresh_transition=read(probe/'panel-transition-audit.json')
state=read(probe/'panel-run/run-state.json')
assert fresh['passed'] and fresh_transition['passed'] and state['status']=='completed'
assert fresh['build']==base['build']
assert fresh['video_sha256']==digest(probe/'rendered-panels/panel-render.mp4')
assert len(fresh['results'])==4 and all(r['passed'] for r in fresh['results'])
assert all(r['readable_presented_clock']>r['readable_clock'] for r in fresh['results'])
original=e/'attempts/panel-endpoint-fixed-delay/panel-run/results.json'
native=read(original)[:2104]
assert len(native)==2104 and all(r['passed'] for r in native)
base_results=read(e/'panel-run/results.json')
assert base_results[:2104]==native
assert len(base_results)==2529 and not base_results[-1]['passed']
attempt=e/'attempts/panel-endpoint-recovered-without-final-hold'
attempt.mkdir(exist_ok=False)
for name in ('panel-render-audit.json','panel-transition-audit.json','body-detector-negative-controls.json','panel-re-audit.json'):
    shutil.copy2(e/name,attempt/name)
shutil.copytree(e/'panel-run',attempt/'panel-run')
(attempt/'disposition.md').write_text('# Recovered endpoints, truncated final patient frame\n\n- [x] Re-audit the unchanged complete recording: 419 endpoint views and their sampled opening intervals pass.\n- [x] Preserve its sole remaining failed endpoint, the final patient completion page, whose recording stopped before a readable frame completed.\n- [x] Recheck both patient pages in both views with two native presentation updates after readiness and two further updates during the recorded hold.\n- [x] Replace only the failed final patient view in combined coverage; preserve all other original rows, native assertions and source identities. The supplemental recording is explicitly identified per row.\n')
supplement=dict(file='patient-presentation-probe/rendered-panels/panel-render.mp4',sha256=fresh['video_sha256'])
replacement=next(dict(r) for r in fresh['results'] if key(r)==target)
replacement.update(video=supplement['file'],video_sha256=supplement['sha256'])
shutil.copy2(probe/'rendered-panels'/replacement['file'],e/'rendered-panels'/replacement['file'])
base['results']=[replacement if key(r)==target else r for r in base['results']]
base.update(passed=all(r['passed'] for r in base['results']),supplemental_videos=[supplement],
            method='419 source-verified endpoints from the original full native FBO sweep plus the explicitly identified fresh final patient view. Hidden endpoint latency is checked across encoded frames within recorded card boundaries; pixel thresholds are unchanged.')
fresh_samples=[dict(r,video=supplement['file'],video_sha256=supplement['sha256']) for r in fresh_transition['results'] if key(r)==target]
assert fresh_samples and all(r['passed'] for r in fresh_samples)
transition['results']=[r for r in transition['results'] if key(r)!=target]+fresh_samples
assert {key(r) for r in transition['results']}=={key(r) for r in base['results']}
transition.update(passed=True,cases=420,sampled_cases=420,supplemental_videos=[supplement],
                  method='8 Hz opening samples from the original 419 passing card intervals and the explicitly identified fresh final patient interval; hidden frames allowed before the separately verified readable endpoint.')
write(e/'panel-render-audit.json',base)
write(e/'panel-transition-audit.json',transition)
fresh_checks=read(probe/'panel-run/results.json')
assert len(fresh_checks)==state['checks'] and all(r['passed'] for r in fresh_checks)
endpoint_label=base_results[-1]['check']
endpoint_check=next(r for r in fresh_checks if r['check']==endpoint_label)
results=base_results[:-1]+[endpoint_check,dict(check='all opening transition pixel samples are hidden or the intended readable sheet',passed=True)]
assert len(results)==2530 and all(r['passed'] for r in results)
write(e/'panel-run/results.json',results)
run_state=read(e/'panel-run/run-state.json')
run_state.update(status='re-audited',checks=len(results),error=None,supplemental_checks=len(fresh_checks),
                 method='Unchanged 2,104-row native fixture prefix, renewed recorded-pixel processing and one explicitly identified fresh patient endpoint. Original failed finalizations retained separately.')
write(e/'panel-run/run-state.json',run_state)
negative=read(e/'body-detector-negative-controls.json')
negative.update(passed=True,source_results_sha256=digest(e/'panel-run/results.json'))
assert negative['results']==[r for r in results if r['check'].startswith('pixel detector ')]
write(e/'body-detector-negative-controls.json',negative)
write(e/'panel-re-audit.json',dict(build=base['build'],passed=True,native_fixture_checks=2104,checks=2530,
    original_results_sha256=digest(original),requests_sha256=digest(e/'panel-render-requests.json'),
    video_sha256=base['video_sha256'],auditor_sha256=digest(ROOT/'verify_panel_render.py'),
    base_audit=str((attempt/'panel-render-audit.json').relative_to(e)),base_audit_sha256=digest(attempt/'panel-render-audit.json'),
    supplemental_audit='patient-presentation-probe/panel-render-audit.json',supplemental_audit_sha256=digest(probe/'panel-render-audit.json'),
    supplemental_checks=len(fresh_checks),replacement=list(target),supplemental_video=supplement,
    method='Preserve 419 passing source-verified original views and their native fixture assertions; replace only the truncated final patient view with its freshly verified exact-build endpoint and opening samples. This is combined coverage across explicitly identified recordings, not a new full native execution.'))
print('Combined panel coverage passed: 420 views, 2530 assertions plus',len(fresh_checks),'supplemental patient assertions')
