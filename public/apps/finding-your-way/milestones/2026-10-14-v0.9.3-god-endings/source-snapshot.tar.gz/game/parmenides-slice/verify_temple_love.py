"""Native iteration-B checks: departures, replay, source histories and signs."""
import json
import time
import sys

def run(b,player,value,check,tap,position,read_pages,groups,ids,out,evidence,capture):
    for mb in (133,134,135,480,481,482,483,484,485,*range(230,238)):b.watch(player,mb)
    for name in ('FirstLove','Starlet','biology_book','back_sign','love_door_1_2'):
        for mb in (3009,3010,3014):b.watch(ids[name],mb)
    timeout=float(sys.argv[sys.argv.index('--motion-timeout')+1]) if '--motion-timeout' in sys.argv else 30
    if timeout<=0:raise ValueError('--motion-timeout must be positive')
    def wait(label,predicate):
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline and not predicate():time.sleep(.025)
        if not predicate():
            print("Iteration B wait diagnostic",label,{m:value(m) for m in (103,104,106,108,110,133,134,135,140,481)},{n:[actor(n,m) for m in (3009,3010)] for n in ("Starlet","biology_book")},flush=True)
        check(label,predicate())
    def setm(m,v):b.set_mailbox(m,v,idx=player)
    def reset():
        for m in (103,104,105,106,107,133,134,135):setm(m,0)
    def actor(name,mb):return b.mailbox_values.get((ids[name],mb))
    for mode in (0,1):
        if value(101)!=mode:tap(2)
        reset();setm(102,0);setm(140,0);position(0,8);tap()
        wait('crowd arrival timer runs',lambda:value(135) is not None and value(135)>.05)
        # Record an arrival fixture with native time bounded to the first phase.
        setm(135,0);capture('love-arrival-view-'+str(mode))
        wait('arrival dispersal completes with all crowd absent',lambda:value(135)>=3.8 and all(value(482+i)==0 for i in range(4)))
        check('crowd dispersal cannot complete encounters',value(103)==0 and value(104)==0 and value(106)==0)
        position(104,1);capture('love-seated-starlet-view-'+str(mode))
        tap();check('seated starlet retains exact source',value(140)==groups['starlet'][0])
        tap(16384);check('starlet cancellation keeps encounter available',value(104)==0 and value(140)==0)
        tap();read_pages('iteration B starlet camera='+str(mode),groups['starlet'])
        wait('starlet and book finish the same withdrawal',lambda:value(134)==1 and value(481)==0)
        check('starlet canonical completion unchanged',value(104)==1 and value(252)==0)
        check('book follows departure position',abs(actor('biology_book',3009)-actor('Starlet',3009)-.10)<.002 and abs(actor('biology_book',3010)-actor('Starlet',3010)-.10)<.002)
        capture('love-starlet-departed-view-'+str(mode))
        setm(104,0)
        wait('starlet replay restores seated encounter/book',lambda:value(134)==0 and bool(value(481)) and abs(actor('Starlet',3009)-104)<.002)
        position(100,-6);capture('love-return-sign-view-'+str(mode))
        expected=(value(114)-.25)%1
        check('TEMPLE sign faces the actual view heading',abs((actor('back_sign',3014)-expected+.5)%1-.5)<.002)
        tap(8);check('reduced motion available during Love',value(108)==1)
        setm(103,1);setm(104,1);setm(135,0)
        wait('reduced departure goes directly to final state',lambda:value(133)==1 and value(134)==1 and value(480)==0 and value(481)==0)
        wait('reduced crowd immediately absent',lambda:all(value(482+i)==0 for i in range(4)))
        check('reduced departures keep Love choice uncommitted',value(106)==0 and value(107)==0)
        capture('love-reduced-final-view-'+str(mode));tap(8)
        setm(103,0);wait('First Love replay restores original encounter',lambda:value(133)==0 and bool(value(480)) and abs(actor('FirstLove',3009)-96)<.002)
        position(100,-8);tap();check('return portal remains available',value(102)==0)
        for choice in (1,-1):
            setm(106,1);setm(107,choice);position(3,3);tap()
            key='return_being' if choice==1 else 'return_notbeing'
            check('source-derived Temple Love return',value(140)==groups[key][0])
            read_pages(f'iteration B Temple return {choice} camera={mode}',groups[key])
            wait('source tapestry history settles',lambda:all(value(234+i) is not None and bool(value(234+i))==(choice==1) and value(230+i)==0 for i in range(4)))
            position(0,-5);capture(f'temple-love-{choice}-view-{mode}')
    receipt=out/('build-receipt.json' if (out/'build-receipt.json').exists() else 'level-receipt.json')
    (evidence/'temple-love-audit.json').write_text(json.dumps(dict(build=json.loads(receipt.read_text()),
        passed=True,scope='Both-view native arrival, seated speaker/book, cancellation, completed departures, reduced motion, replay, wayfinding and Love Temple source histories'),indent=2)+'\n')
