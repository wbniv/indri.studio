"""Create E editable assets in isolation while D's production sources are frozen."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--baseline-build',type=Path,required=True)
p.add_argument('--source-dir',type=Path,default=ROOT)
p.add_argument('--out',type=Path,default=ROOT/'build/v0.6-endings-preparation')
a=p.parse_args();base=a.baseline_build.resolve();source=a.source_dir.resolve();out=a.out.resolve()
src=out/'source';assets=out/'assets';src.mkdir(parents=True,exist_ok=True);assets.mkdir(exist_ok=True)
expected=json.loads((base/'art-manifest.json').read_text())['sources']
for name,digest in expected.items():
    if hashlib.sha256((source/name).read_bytes()).hexdigest()!=digest:
        raise SystemExit('Source differs from frozen D artwork: '+name)
for path in source.glob('*.py'):shutil.copy2(path,src/path.name)
# E's original editable geometry lives beside this preparation builder, even
# when the D baseline sources are supplied from their frozen snapshot.
shutil.copy2(ROOT/'art_endings.py',src/'art_endings.py')
for path in base.iterdir():
    if path.suffix in ('.tga','.png') or path.name in ('content.json','art-textures.json'):
        shutil.copy2(path,assets/path.name)
path=src/'blender_scene.py';text=path.read_text()
needle='    from art_motion import MOTION, TEMPLE_LOVE_MOTION\n'
insert="""    from art_endings import dress as dress_endings, MOTION as ENDING_MOTION
    previous=disposition
    disposition=dress_endings(Painted,scene,OUT)
    disposition['previousIteration']=previous
    (OUT/'endings-preparation-manifest.json').write_text(json.dumps(dict(stage='endings-surgery-preparation',disposition=disposition,motion=ENDING_MOTION),indent=2)+'\\n')
"""
if text.count(needle)!=1:raise SystemExit('D Blender insertion boundary changed')
path.write_text(text.replace(needle,insert+needle))
env=dict(os.environ,FYW_WF_ROOT='/home/will/WorldFoundry-wbniv',FYW_SLICE_OUT=str(assets),FYW_ART_STAGE='god-final')
subprocess.run(['blender','--background','--python-exit-code','1','--python',str(path)],env=env,check=True)
files={path.name:hashlib.sha256(path.read_bytes()).hexdigest() for path in src.glob('*.py')}
(out/'source-boundary.json').write_text(json.dumps(dict(stage='endings-surgery-preparation',
    scope='Editable geometry only; no new production APK or native/device acceptance.',
    baselineSourceHashes=expected,preparationSources=files,
    blendSHA256=hashlib.sha256((assets/'parmenides_slice.blend').read_bytes()).hexdigest()),indent=2)+'\n')
print(out)
