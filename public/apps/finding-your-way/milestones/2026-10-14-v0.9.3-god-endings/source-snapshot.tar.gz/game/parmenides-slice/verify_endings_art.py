"""Actual native E motion, source-reading pause and patient projection review.

Fixtures arrange existing scenes; real native input cancels/reopens accounts.
Separate complete ending regression proves the sole coda and all eligible edges.
"""
import itertools
import json
import math
import time


def run(b,player,value,check,tap,position,read_pages,groups,ids,out,evidence,capture,features=None,require_full_gloves=False):
    names=['being_light','being_threshold','being_ripples','void_closing_portal',
           'void_visage','surgeon_1','surgeon_2','surgeon_3']
    for mb in (488,489):b.watch(player,mb)
    for name in names:
        for mb in (3009,3010,3011,3012,3013,3014,3040,3041,3042):b.watch(ids[name],mb)
    def av(n,mb):return b.mailbox_values.get((ids[n],mb))
    def setm(m,v):b.set_mailbox(m,v,idx=player)
    def wait(label,predicate):
        deadline=time.monotonic()+45
        while time.monotonic()<deadline and not predicate():time.sleep(.025)
        check(label,bool(predicate()))
    def sample(seconds=.5):
        start=value(110);deadline=time.monotonic()+60;rows=[];last=None
        while time.monotonic()<deadline:
            clock=value(110)
            if clock is not None and clock!=last:
                rows.append(dict(clock=clock,wall_time=time.time(),release=value(488),surgery=value(489),
                    actors={n:{str(m):av(n,m) for m in (3011,3012,3013,3014,3040,3041,3042)} for n in names}));last=clock
                if clock>=start+seconds:break
            time.sleep(.02)
        check('E native simulation clock advances',bool(rows) and rows[-1]['clock']>=start+seconds)
        samples.extend(rows);return rows
    def enter(realm,key,selected,x,heading=.25):
        for m,v in ((102,realm),(140,groups[key][0]),(189,selected),(222,1),(223,0),(224,0),(225,0),(488,0),(489,0),(108,0)):
            setm(m,v)
        setm(114,heading);position(x,0)
        wait(key+' exact source sheet opens',lambda:value(140)==groups[key][0])
    def photograph(name):
        capture(name)
        phases.append(dict(file=name+'.png',clock=value(110),release=value(488),surgery=value(489),
            realm=value(102),camera=value(101),reading=value(140),reduced=value(108)))
    def close():tap(16384);check('E real Left cancellation closes without completion',value(140)==0 and value(225)==0)
    def signed(v):return (v+.5)%1-.5
    def transform(point,pose):
        a,bb,c=[signed(pose[str(m)])*math.tau for m in (3012,3013,3014)]
        ca,sa,cb,sb,cc,sc=math.cos(a),math.sin(a),math.cos(bb),math.sin(bb),math.cos(c),math.sin(c)
        # Pinned Matrix34::ConstructEuler, row-vector multiplication.
        matrix=((cb*cc,cb*sc,-sb),(sb*sa*cc-ca*sc,sb*sa*sc+ca*cc,cb*sa),
                (sb*ca*cc+sa*sc,sb*ca*sc-sa*cc,cb*ca))
        scaled=[point[i]*pose[str(3040+i)] for i in range(3)]
        return [sum(scaled[k]*matrix[k][i] for k in range(3))+pose[str(3009+i)] for i in range(3)]
    def vector_sub(a,c):return [x-y for x,y in zip(a,c)]
    def dot(a,c):return sum(x*y for x,y in zip(a,c))
    def norm(a):return [x/math.sqrt(dot(a,a)) for x in a]
    def cross(a,c):return [a[1]*c[2]-a[2]*c[1],a[2]*c[0]-a[0]*c[2],a[0]*c[1]-a[1]*c[0]]
    features=features or {'masked-face':((-.34,-.30,2.79),(.34,.30,3.40)),
              'cap':((-.30,-.30,3.27),(.30,.35,3.56)),
              'left-glove':((-.40,.28,2.56),(-.11,.53,2.81)),
              'right-glove':((.11,.28,2.56),(.40,.53,2.81))}
    def projected_margins(label):
        camera=[av('Camera',3009+i) for i in range(3)]
        aim=[av('LookAt',3009+i)+value(3009+i)-av('CamTarget',3009+i) for i in range(3)]
        forward=norm(vector_sub(aim,camera));right=norm(cross(forward,[0,0,1]));up=cross(right,forward)
        rows=[]
        for name in ('surgeon_1','surgeon_2','surgeon_3'):
            pose={str(m):av(name,m) for m in (3009,3010,3011,3012,3013,3014,3040,3041,3042)}
            for feature,(low,high) in features.items():
                points=[];depths=[]
                for local in itertools.product(*[(low[i],high[i]) for i in range(3)]):
                    v=vector_sub(transform(local,pose),camera);depth=dot(v,forward);depths.append(depth)
                    points.append((.5+dot(v,right)/(depth*math.tan(math.pi/6)*(1280/720)*2),
                                   .5-dot(v,up)/(depth*math.tan(math.pi/6)*2)))
                margins=[min(p[0] for p in points),min(p[1] for p in points),1-max(p[0] for p in points),1-max(p[1] for p in points)]
                if feature in ('masked-face','cap') and not (min(depths)>1 and min(margins)>.025):
                    diagnostic=dict(label=label,actor=name,feature=feature,pose=pose,camera=camera,aim=aim,margins=margins,depths=depths,points=points,look=[av('LookAt',3009+i) for i in range(3)],origin=[av('CamTarget',3009+i) for i in range(3)],player=[value(3009+i) for i in range(3)])
                    (evidence/'patient-projection-failure.json').write_text(json.dumps(diagnostic,indent=2)+'\n')
                    print(json.dumps(diagnostic),flush=True)
                if feature in ('masked-face','cap'):
                    check(label+' '+name+' '+feature+' live projected margins',min(depths)>1 and min(margins)>.025)
                else:
                    check(label+' '+name+' '+feature+' enters the patient viewport',min(depths)>1 and max(p[0] for p in points)>0 and min(p[0] for p in points)<1 and max(p[1] for p in points)>0 and min(p[1] for p in points)<1)
                    if require_full_gloves:
                        check(label+' '+name+' '+feature+' complete glove margin',min(depths)>1 and min(margins)>.025)
                rows.append(dict(actor=name,feature=feature,pose=pose,margins=margins,minimum_depth=min(depths),fully_inside_viewport=min(margins)>=0,contract='2.5% complete masked-face/cap margin' if feature in ('masked-face','cap') else ('2.5% complete glove margin required by F' if require_full_gloves else 'Measured glove projection and visible intersection; full hands not required by the established patient framing')))
        framing.append(dict(label=label,camera=camera,aim=aim,features=rows))
    samples=[];phases=[];framing=[]
    for mode in (0,1):
        if value(101)!=mode:tap(2)
        enter(5,'ending_10a',1,500,.75);photograph(f'being-source-view-{mode}')
        s=sample(.8);check('Being visual time pauses throughout source reading',max(r['release'] for r in s)-min(r['release'] for r in s)<.00001)
        close();setm(488,0);photograph(f'being-opening-view-{mode}')
        s=sample(.6);check('Being release actually rises in native renderer',max(r['actors']['being_light']['3011'] for r in s)-min(r['actors']['being_light']['3011'] for r in s)>.01)
        setm(488,2);photograph(f'being-release-view-{mode}')
        setm(488,4.1);wait('Being reaches quiet contour/ocean endpoint',lambda:value(254)==0 and bool(value(255)))
        photograph(f'being-endpoint-view-{mode}')
        tap(8);wait('reduced Being holds stable bright forms',lambda:bool(value(254)) and abs(av('being_light',3011))<.0001)
        s=sample(.5);check('reduced Being holds visual time',max(r['release'] for r in s)-min(r['release'] for r in s)<.00001)
        photograph(f'being-reduced-view-{mode}')
        check('Being cosmetic release never completes source',value(223)==0 and value(224)==0 and value(225)==0)
        enter(6,'ending_10b',2,600);photograph(f'both-source-view-{mode}');close()
        position(600,-1);setm(114,.25);photograph(f'both-passage-view-{mode}')
        tap();check('Both reopens its exact source',value(140)==groups['ending_10b'][0])
        read_pages('E Both actual source camera='+str(mode),groups['ending_10b'],groups['ending_101b'][0])
        check('E actual Both advances only into surgery',value(102)==8 and value(189)==2 and value(222)==2 and value(223)==1 and value(224)==0 and value(225)==0)
        photograph(f'surgery-source-view-{mode}');close();setm(489,0)
        s=sample(1)
        for name in ('surgeon_1','surgeon_2','surgeon_3'):
            check(name+' native breathing actually changes position',max(r['actors'][name]['3011'] for r in s)-min(r['actors'][name]['3011'] for r in s)>.0003)
        for index,clock in enumerate((0,2.0833,4.1667,6.25,8.3333,10.4167,16.0)):
            setm(489,clock);sample(.15)
            for name in ('surgeon_1','surgeon_2','surgeon_3'):
                check(name+' bounded live breath/lean at '+str(clock),abs(av(name,3011))<=.0121 and abs(signed(av(name,3012)))<=.0016 and abs(signed(av(name,3013)))<=.0009 and abs(signed(av(name,3014)))<.0001)
            photograph(f'surgery-motion-{index}-view-{mode}');projected_margins(f'view {mode} nominal clock {clock}')
        tap(8);wait('reduced surgeons return to stable composed pose',lambda:all(abs(av(n,3011))<.0001 and abs(signed(av(n,3012)))<.0001 and abs(signed(av(n,3013)))<.0001 for n in ('surgeon_1','surgeon_2','surgeon_3')))
        photograph(f'surgery-reduced-view-{mode}');projected_margins(f'reduced view {mode}')
        check('patient rig preserves camera preference and stops movement',value(101)==mode and value(250)==0 and abs(av('FollowShot',3011)-.9)<.04 and abs(av('LookAt',3011)-3.4)<.04)
        tap();check('surgery reopens its sole exact source',value(140)==groups['ending_101b'][0])
        s=sample(.5);check('source reading pauses surgeon time',max(r['surgery'] for r in s)-min(r['surgery'] for r in s)<.00001)
        check('source cancellation/reopen never completes surgery',value(224)==0 and value(225)==0)
        enter(7,'ending_10c',3,700,.75);photograph(f'notbeing-source-view-{mode}')
        s=sample(.8);check('NotBeing source reading cannot skip portal closure',max(r['release'] for r in s)-min(r['release'] for r in s)<.00001 and bool(value(257)))
        close();setm(488,0);photograph(f'notbeing-closing-view-{mode}')
        setm(488,.5);s=sample(.4)
        check('NotBeing arch actually squeezes in native renderer',max(r['actors']['void_closing_portal']['3040'] for r in s)-min(r['actors']['void_closing_portal']['3040'] for r in s)>.03)
        setm(488,1.6);setm(114,.25);wait('original visage follows the single closed portal',lambda:value(257)==0 and bool(value(259)))
        photograph(f'notbeing-visage-view-{mode}')
        setm(488,5.6);wait('normal NotBeing dissolves to the retained empty darkness',lambda:value(257)==0 and value(259)==0 and bool(value(258)))
        photograph(f'notbeing-empty-view-{mode}')
        tap(8);wait('reduced NotBeing holds a quiet original visage',lambda:value(257)==0 and bool(value(259)) and abs(av('void_visage',3011))<.0001)
        photograph(f'notbeing-reduced-view-{mode}')
        check('NotBeing presentation cannot select a coda or complete',value(189)==3 and value(223)==0 and value(224)==0 and value(225)==0)
    report=dict(build=json.loads((out/'build-receipt.json').read_text()),passed=True,
        scope=('Both native views; actual rigid ending release/portal closure, reading pause, quiet reduced states, masked surgeon breath/lean and complete 2.5% face/cap/glove margins. Recorded FBO images require visual inspection for occlusion; complete source/eligible-edge regression runs separately.' if require_full_gloves else 'Both native views; actual rigid ending release/portal closure, reading pause, quiet reduced states, masked surgeon breath/lean, full face/cap margins and measured partial glove visibility. Recorded FBO images require visual inspection for occlusion; complete source/eligible-edge regression runs separately.'),
        samples=samples,phases=phases,framing=framing,
        projection_basis='Pinned Matrix34::ConstructEuler row-vector rotation and backend 60-degree vertical perspective at 1280×720, using live native actor/camera/target state; not the provisional skin-color detector.')
    (evidence/'endings-art-audit.json').write_text(json.dumps(report,indent=2)+'\n')
