"""Build repeatable iteration-B phone workloads; never production route proof.

Only the Player script changes. Meshes, textures and the phone native runtime
are shared with the production candidate. The coordinator owns all device work.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

import build_review_fixtures as fixtures

ROOT = Path(__file__).resolve().parent


def sustained_tour(original, scenes, mode, content):
    name, realm, x, y, _, history = scenes[0]
    tail = original.splitlines(keepends=True)[-1]
    assert tail.startswith('fy-init fy-input ')
    setters = ''.join(f'{v} {mb} write-mailbox ' for mb, v in history.items())
    setup = (
        ': fy-phone-benchmark\n'
        'INDEXOF_DELTA_TIME read-mailbox 0 max 0.1 min 470 read-mailbox + 470 write-mailbox\n'
        '470 read-mailbox 8 / 0 | 1 + 471 write-mailbox\n'
        '470 read-mailbox 8 / fy-wrap 8 * 473 write-mailbox\n'
        f'471 read-mailbox 472 read-mailbox <> if 471 read-mailbox 472 write-mailbox '
        f'{x} {y} fy-teleport {realm} 102 write-mailbox {mode} 101 write-mailbox '
        f'0 140 write-mailbox 0 108 write-mailbox {setters}then\n'
        # Keep all four arrival crowds visible for a conservative Love load.
        # Production normally disperses them after approximately 3.2 seconds.
        '0 135 write-mailbox\n'
        '473 read-mailbox 1 >= 473 read-mailbox 3 < & if 2048 INDEXOF_INPUT write-mailbox then\n'
        '470 read-mailbox 8 / fy-sin 0.035 * 0.25 + 114 write-mailbox\n'
        ';\n'
    )
    phases = [dict(scene=name, realm=realm, camera=mode, history=history,
                   loop_game_seconds=8, phase='native forward for seconds 1–3; gentle repeated turn',
                   crowds='four retained arrival crowds' if realm == 1 else 'none',
                   reduced_motion=False, reading_modal=False)]
    return original[:-len(tail)] + setup + tail.replace('fy-input ', 'fy-input fy-phone-benchmark ', 1), phases


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-build', type=Path, required=True)
    parser.add_argument('--runtime', type=Path, required=True)
    parser.add_argument('--source-receipt', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    fixtures.BASE = args.source_build.resolve()
    fixtures.tour = sustained_tour
    production = json.loads((fixtures.BASE / 'build-receipt.json').read_text())
    variants = []
    for realm, scene, x, history in [(0, 'temple', 0, {106: 1, 107: 1}),
                                      (1, 'love-crowds', 100, {})]:
        for mode in (0, 1):
            fixtures.SCENES = [(scene, realm, x, -5, 'intro', history)]
            fixtures.make(0, mode, scene_only=scene)
            source = fixtures.BASE / 'review-fixtures' / f'group-0-view-{mode}-{scene}'
            diagnostic = json.loads((source / 'review-receipt.json').read_text())
            diagnostic.update(duration=None, changed_level_source='Only Player script adds sustained eight-second loop',
                              scope='Repeated native rendering and movement; retained Love crowds are diagnostic stress, not route or touch acceptance')
            (source / 'review-receipt.json').write_text(json.dumps(diagnostic, indent=2) + '\n')
            # Confirm source mesh and texture inputs survived unchanged.
            inputs = {}
            for original in fixtures.BASE.iterdir():
                if original.is_file() and (original.name.startswith('mesh') and original.suffix == '.iff' or original.suffix == '.tga'):
                    copied = source / original.name
                    assert copied.read_bytes() == original.read_bytes(), original.name
                    inputs[original.name] = hashlib.sha256(original.read_bytes()).hexdigest()
            label = f'{scene}-view-{mode}'
            out = args.out.resolve() / label
            subprocess.run(['python3', str(ROOT / 'package_touch_review.py'), '--source-build', str(source),
                            '--runtime', str(args.runtime.resolve()), '--source-receipt', str(args.source_receipt.resolve()),
                            '--abi', 'arm64-v8a', '--out', str(out), '--version', f'{production["version"]}-touch.{len(variants)+2}'], check=True)
            receipt = json.loads((out / 'build-receipt.json').read_text())
            receipt.update(diagnostic_only=True, production_apk_sha256=production['sha256'],
                           phases=diagnostic['phases'], unchanged_mesh_texture_inputs=inputs,
                           scope=diagnostic['scope'])
            (out / 'build-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
            variants.append(dict(label=label, apk=receipt['apk'], warmup=180 if not variants else 30, runs=1))
    (args.out / 'variants.json').write_text(json.dumps(variants, indent=2) + '\n')


if __name__ == '__main__':
    main()
