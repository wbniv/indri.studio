"""Match runtime slot sizes to exported world atlases; glyph storage is separate."""
import json
import struct

LEGACY_ARGS = ['--vram-width=5120', '--vram-height=2048',
               '--vram-slot-width=1024', '--vram-slot-height=2048',
               '--vram-perm-width=2048', '--vram-perm-height=2048']


def image_sizes(output):
    sizes = {}
    for name in ('Perm', 'Room0', 'Room1'):
        header = (output/(name+'.tga')).read_bytes()[:18]
        width, height = struct.unpack_from('<HH', header, 12)
        if not width or not height:
            raise ValueError('Invalid exported atlas size: '+name)
        sizes[name] = [width, height]
    return sizes


def fit(output):
    sizes = image_sizes(output)
    # Power-of-two dimensions preserve exact binary UV normalization from
    # the original slots, avoiding one-unit texture-filter rounding changes.
    power_of_two = lambda value: 1 << (value-1).bit_length()
    layout = dict(permanent=[power_of_two(value) for value in sizes['Perm']],
                  transient=[power_of_two(max(sizes[n][axis] for n in ('Room0', 'Room1'))) for axis in (0, 1)],
                  rounding='power-of-two',
                  exportedImages=sizes,
                  # Keep the display's independent master buffer unchanged to
                  # isolate the texture-slot variation from another allocation.
                  display=[5120, 2048])
    (output/'texture-slots.json').write_text(json.dumps(layout, indent=2)+'\n')
    return layout


def runtime_args(output):
    config = output/'texture-slots.json'
    if not config.exists():
        return list(LEGACY_ARGS)
    layout = json.loads(config.read_text())
    sizes = image_sizes(output)
    for name, size in sizes.items():
        slot = layout['permanent' if name == 'Perm' else 'transient']
        if any(size[i] > slot[i] or slot[i] < 1 or slot[i] > 65535 for i in (0, 1)):
            raise ValueError('Exported atlas does not fit runtime slot: '+name)
    return [f'--vram-width={layout["display"][0]}', f'--vram-height={layout["display"][1]}',
            f'--vram-slot-width={layout["transient"][0]}', f'--vram-slot-height={layout["transient"][1]}',
            f'--vram-perm-width={layout["permanent"][0]}', f'--vram-perm-height={layout["permanent"][1]}']
