"""Style proof (plan 2026-10-11): the Temple and the goddess against the art bible.

Overlay on the polish stage, selected with ``build.py --art-stage style-proof``.
Blender runs the ordinary polish construction, then ``dress`` adds six layers:
sky dome, painted compass floor, baked light, vault shell with oculus and window
cut-outs, dressing (four realm banners, two torch stands, a stepped dais) and a
remodelled goddess with two-tier wings.

Engine-independent by design: the pinned exporter writes every vertex colour as
white, so no value can travel in vertex colours. All value is baked in Blender
(Cycles) or painted, and lands in textures:

* sky, floor, shell and dressing use the exporter's existing ``wf_prelit``
  material flag, so their texels are final colour (lighting, ambient occlusion,
  torch pools and the warm key are baked in);
* the goddess and wings stay lit by the room's existing lights, like the
  player; their 512² sheet carries baked albedo, folds, trim and ambient
  occlusion.

Actor names, narrative visibility and collision bounds are preserved: replaced
actors use ``art_temple_love.replace`` (which records ``wf_original_bbox``).
New dressing is ``platform`` (box collider from an explicit, never larger than
needed bbox), so no new triangle collider enters the level (only ``statplat``
actors get Jolt mesh colliders). Original art only; the concept sheets are
colour/value reference, never projection sources.
"""
import json
import math
import os
from pathlib import Path

STAGE = 'style-proof'
SHEET = 512
GUTTER = 4
DAIS_H = .75          # impact pass: five 0.15 m steps (was two, 0.30 m)
DAIS_STEPS = 5
GODDESS_SCALE = 1.3   # impact pass: about 2.35 m without the dais
PILLAR_H = 6.5        # impact pass: nave pillars, plinth to abacus (were 4 m)
SIGN_Z = 3.55         # goddess label raised clear of the taller figure
# The goddess is the focal accent: a small lift over the shared exposure keeps
# her ivory reading as the brightest value in the frame (colour script).
GODDESS_LIFT = 1.05  # the focal accent: brightest value in the frame (impact pass, measured)
# Sky-bounce floor added to every baked texel (linear, x albedo): creases that
# no ray reaches read as deep colour, never as a black hole.
AMBIENT_FLOOR = .09
# Impact-pass light rig (bake only), tuned by measure_value.py at the reference pose.
KEY_POWER, CROWN_POWER, FILL_POWER, TORCH_POWER = 5500, 2600, 700, 320
WASH_POWER = 2300   # each of two side washes on the back wall and vault; the wall behind the goddess stays dark
# Exposure is set where the eye should land: the floor just in front of the
# dais reads at EXPOSURE_TARGET; the rest of the hall falls away from it.
EXPOSURE_TARGET = .92
FLOOR_FALLOFF = (5.0, .03, .90)   # metres from the dais before falloff, per metre, floor
# The target's floor is the brightest band of the frame (warm cream, not white):
# the floor sheet's own exposure over the hall's.
FLOOR_LIFT = 1.3
GODDESS_AT = (3.0, 3.0)
# Braziers flank the stair's front corners (in front of the bottom step), seen
# between the outer piers from the reference pose.
TORCHES = ((1.75, .45), (4.25, .45))
# Stair (tread, width, back edge past the goddess, landing depth): it fills the
# phase 1 dais footprint (x 1.25-4.75, y 1.6-4.6) and no more.
STAIR = (.25, 2.8, 1.6, 2.0)
BRAZIER_TOP = 1.95   # flame height above the floor (tall plinth, bowl, flame)

# ---- Geometry density -----------------------------------------------------------
# One table owns every procedural count in the Temple and goddess generators;
# build.py --detail-scale (FYW_DETAIL_SCALE) multiplies it. 1.0 is the budget
# this pass ships; nothing below hard-codes a count the table owns.
DETAIL_SCALE = float(os.environ.get('FYW_DETAIL_SCALE', '1.0'))
DETAIL = dict(
    sky_azimuth=16, sky_rings=7,                 # sky dome segments, elevation bands
    vault_segments=16, end_wall_segments=16,      # barrel vault half-circle, end-wall arcs
    niche_segments=12,                            # shrine niche wall, around its arc
    crown_segments=24, crown_chunks=18,           # broken crown ring and its loose stones
    pier_courses=3,                               # stacked shaft blocks per pier (light and paint density)
    pillar_sides=12,                              # the round collision core inside each nave pier
    brazier_sides=12, flame_cards=3, flame_points=7,
    banner_hem_points=1,                          # extra vertices along each banner's pointed hem
    gown_sides=28, gown_sections=7, bodice_sides=16, belt_sides=16,
    sleeve_sides=12, arm_sides=8, hand_sides=8, finger_segments=2,
    face_sides=14, face_rings=7, feature_sides=8, ear_sides=8,
    hair_tiers=7, hair_sides=8, hair_lock_rings=4, circlet_sides=16,
    gem_sides=8, gem_rings=4, ear_rings=3, finger_sides=5, palm_rings=4,
    halo_segments=16, halo_points=4,
    wing_primaries=7, wing_secondaries=6, wing_coverts=5, wing_scapulars=4, feather_points=6, wing_arm_sides=8,
    cape_rows=5, cape_cols=7, sash_rows=5, sash_cols=3,
)


def n(key, minimum=3):
    """A count from the detail table at the build's detail scale."""
    return max(minimum, int(round(DETAIL[key] * DETAIL_SCALE)))


def resample(points, count):
    """Linear resample of an authored profile to `count` points (identity at its own length)."""
    if count == len(points):
        return list(points)
    out = []
    for k in range(count):
        t = k * (len(points) - 1) / (count - 1)
        i = min(int(t), len(points) - 2)
        f = t - i
        out.append(tuple(a + (b - a) * f for a, b in zip(points[i], points[i + 1])))
    return out


# ---- Shrine niche (layout decision B, plan 2026-10-12 target match) ----------------
SHRINE_C = (3.0, 2.0)           # centre of the pier circle; the goddess is on its axis
PIERS = ((1.0, -1.0), (1.0, 5.0), (5.0, 5.0), (5.0, -1.0))   # L outer, L inner, R inner (pillar3), R outer (pillar1)
NEW_PIERS = ((1.0, -1.0), (1.0, 5.0))  # mirrors of pillar1 and pillar3; collision 0.9 m, clear of the x = 0 route
PIER_H = 6.5
NICHE_R, NICHE_ARC, NICHE_H = 4.3, (54.0, 126.0), 6.6
CROWN_R, CROWN_Z = (2.85, 4.45), (6.5, 7.35)
# Banner hanging angles on the niche wall (degrees from +X about SHRINE_C) by
# tapestry realm index: 0 Love (red sun), 1 Reason (violet spiral),
# 2 Truth (blue ring), 3 God (green tree). The goddess stands between 98 and 82.
# Red and violet hang on the inner piers' front faces, blue and green on the
# niche wall just outside the wings: four banners across the shrine with the
# goddess between the middle two. ('pier', x, y) or ('wall', angle in degrees).
BANNER_SPOT = {0: ('pier', 1.0, 5.0), 2: ('wall', 106.0), 3: ('wall', 74.0), 1: ('pier', 5.0, 5.0)}
BANNER_W, BANNER_TOP, BANNER_HEM, BANNER_POINT = .66, 5.45, 2.75, 2.35
TAPESTRY_SIZE = (512, 256)      # eight 64 x 256 tiles: variant x 4 + realm
# Logical visibility: Temple realm (102 == 0) and Temple present (207). The sky
# is a backdrop for the Temple only; other realms keep their established look.
SKY_VISIBILITY = 227
SKY_FORTH = '102 read-mailbox 0 = 207 read-mailbox & 227 write-mailbox\n'
SKY_RADIUS = 34.0

# Sheet layouts, image pixels, top-down rows: (x0, y0, x1, y1).
TEMPLE_SMART = (0, 4, 480, 196)     # hall shell: vault, walls, end walls (far, dim)
SHRINE_SMART = (0, 196, 512, 512)   # shrine: niche, crown, piers, braziers, stair (close, lit)
# Small trim (rims, rods, brackets, bowls, flames) shares flat painted swatches
# rather than taking one tiny baked island each.
SWATCHES = {region: (484, 4 + 23 * k, 508, 23 + 23 * k) for k, region in enumerate(
    ('gold', 'gold_dark', 'bronze', 'iron', 'flame', 'ember', 'stone_light'))}
SWATCH_COLOURS = dict(gold='#C7A04C', gold_dark='#8A682D', bronze='#4F3C29', iron='#2A2725',
                      flame='#FFE08A', ember='#FF9A3C', stone_light='#C8BA9C')
GODDESS_BODY = (0, 0, 512, 352)
GODDESS_WING = (0, 352, 512, 512)
FLOOR_SPAN = 28.6  # metres across the 512 floor sheet, both axes (28 m floor + 4 px gutters)

# Region colours (sRGB). Gold concentrates around the goddess (colour script).
REGIONS = dict(
    # Colour script (target match): cool, dark teal-grey stone for the hall and
    # niche; warm lit marble for piers, crown, stair and plinths; gold accents.
    wall='#3B4547', vault='#46504F', lining='#3E4748', stone_light='#D3C6A8', marble='#E0D3B6',
    niche='#2F3B3C', pier='#D8CBAE', crown='#C9BC9E',
    gold='#D9B75F', gold_dark='#A8823A', bronze='#5C4631', flame='#FFC45C', ember='#F07A2A', iron='#2E2B29',
    skin='#D7A784', hair='#5E3E26', gown='#EEE5CF', sleeve='#E7DCC2', cream='#F1EBDD', ink='#2B2220',
    red='#C07A6C', wing='#C99E48', halo='#EBCB6E', sandal='#B8913F')


def linear(hexcolor):
    rgb = [int(hexcolor[i:i + 2], 16) / 255 for i in (1, 3, 5)]
    return tuple(c / 12.92 if c <= .04045 else ((c + .055) / 1.055) ** 2.4 for c in rgb)


def to_srgb8(values):
    import numpy as np
    v = np.clip(values, 0, 1)
    v = np.where(v <= .0031308, v * 12.92, 1.055 * np.power(v, 1 / 2.4) - .055)
    return (np.clip(v, 0, 1) * 255 + .5).astype('uint8')


def rect_uv(rect, u, v, size=(SHEET, SHEET)):
    """Map (u, v) in [0,1] (v up) into a top-down pixel rect, inside the gutter."""
    x0, y0, x1, y1 = rect
    w, h = size
    px = x0 + GUTTER + u * (x1 - x0 - 2 * GUTTER)
    py = y1 - GUTTER - v * (y1 - y0 - 2 * GUTTER)
    return (px / w, 1 - py / h)


# --------------------------------------------------------------------------
# Painted sources (PIL, run by build.py before Blender)

BANNER_ART = {0: ('sun', '#8B2723'), 1: ('spiral', '#5C3A85'), 2: ('ring', '#2C4A84'), 3: ('tree', '#2E6A3C')}


def paint_banners(out):
    """Paint the eight banner tiles at 4x and downsample (anti-aliased edges)."""
    from PIL import Image, ImageDraw
    import hashlib
    F = 4
    tw, th = 64, TAPESTRY_SIZE[1]
    sheet = Image.new('RGB', TAPESTRY_SIZE, (40, 36, 30))
    gold, deep_gold = (220, 182, 92), (168, 128, 58)
    hem_v = (BANNER_HEM - BANNER_POINT) / (BANNER_TOP - BANNER_POINT)
    for variant in (0, 1):
        for realm, (motif, field) in BANNER_ART.items():
            W, H = tw * F, th * F
            g0 = GUTTER * F
            base = [int(field[i:i + 2], 16) for i in (1, 3, 5)]
            if variant:
                base = [min(255, int(c * 1.22 + 10)) for c in base]
            tile = Image.new('RGB', (W, H), tuple(base))
            d = ImageDraw.Draw(tile)
            def vy(v):  # v up from the point (0) to the top (1)
                return g0 + (1 - v) * (H - 2 * g0)
            def ux(u):
                return g0 + u * (W - 2 * g0)
            # Realm fractal in the field: the emblem echoed at halving scales.
            def emblem(cx, cy, r, colour, width):
                if motif == 'sun':
                    for k in range(12):
                        a = k * math.tau / 12
                        d.polygon([(cx + r * .62 * math.cos(a - .2), cy + r * .62 * math.sin(a - .2)),
                                   (cx + r * 1.3 * math.cos(a), cy + r * 1.3 * math.sin(a)),
                                   (cx + r * .62 * math.cos(a + .2), cy + r * .62 * math.sin(a + .2))], fill=colour)
                    d.ellipse((cx - r * .66, cy - r * .66, cx + r * .66, cy + r * .66), fill=colour)
                elif motif == 'ring':
                    d.ellipse((cx - r, cy - r, cx + r, cy + r), outline=colour, width=max(2, int(width)))
                elif motif == 'tree':
                    d.rectangle((cx - r * .09, cy - r * .1, cx + r * .09, cy + r * 1.15), fill=colour)
                    for dx, dy, rr in ((0, -.55, .5), (-.5, -.2, .4), (.5, -.2, .4), (-.28, .2, .34), (.28, .2, .34)):
                        d.ellipse((cx + (dx - rr) * r, cy + (dy - rr) * r, cx + (dx + rr) * r, cy + (dy + rr) * r), fill=colour)
                    for side in (-1, 1):
                        d.line((cx, cy + r * 1.15, cx + side * r * .55, cy + r * 1.38), fill=colour, width=max(2, int(width * .6)))
                else:
                    pts = [(cx + (r * .06 + r * .94 * k / 160) * math.cos(k * .17), cy + (r * .06 + r * .94 * k / 160) * math.sin(k * .17)) for k in range(161)]
                    d.line(pts, fill=colour, width=max(2, int(width * .7)))
            pattern = (tuple(min(255, c + 16) for c in base) if not variant else deep_gold)
            cx, r = W / 2, (W - 2 * g0) * .32
            for level, (y, count, scale) in enumerate(((vy(.36), 2, .45), (vy(.22), 4, .22))):
                for k in range(count):
                    px = ux((k + .5) / count)
                    emblem(px, y, r * scale, pattern, r * scale * .18)
            # Gold border, top band (also the rod's paint) and the hem's V.
            d.rectangle((ux(0), vy(1), ux(1), vy(.965)), fill=gold)
            for edge in ((ux(0), vy(.965), ux(.07), vy(hem_v)), (ux(.93), vy(.965), ux(1), vy(hem_v))):
                d.rectangle(edge, fill=gold)
            d.polygon([(ux(0), vy(hem_v)), (ux(.5), vy(0)), (ux(1), vy(hem_v)),
                       (ux(.93), vy(hem_v + .02)), (ux(.5), vy(.06)), (ux(.07), vy(hem_v + .02))], fill=gold)
            # The realm emblem, large, in the upper field. Love completed with
            # Being (v1) crowns it with a gold aureole that reads at distance.
            if variant:
                ey, ar = vy(.68), r * 1.55
                d.ellipse((cx - ar, ey - ar, cx + ar, ey + ar), fill=tuple(min(255, int(c * 1.25 + 24)) for c in base),
                          outline=gold, width=max(3, int(r * .12)))
            emblem(cx, vy(.68), r, gold, r * .2)
            # Painted light: brighter toward the braziers below, broad fold bands.
            import numpy as np
            a = np.asarray(tile, dtype=np.float32)
            rows = np.linspace(.80, 1.02, H)[:, None, None]
            cols = (1 + .07 * np.sin(np.linspace(0, 5 * math.pi, W)))[None, :, None]
            tile = Image.fromarray(np.clip(a * rows * cols, 0, 255).astype('uint8'))
            tile = tile.resize((tw, th), Image.Resampling.LANCZOS)
            sheet.paste(tile, ((variant * 4 + realm) * tw, 0))
    sheet.save(out / 'art_tapestries.tga')
    sheet.save(out / 'art_tapestries.png')
    textures = out / 'art-textures.json'
    if textures.exists():
        record = json.loads(textures.read_text())
        record['textures']['art_tapestries.tga'] = dict(size=list(TAPESTRY_SIZE), sha256=hashlib.sha256((out / 'art_tapestries.tga').read_bytes()).hexdigest(),
                                                       note='style proof: the four realm banners (target match)')
        textures.write_text(json.dumps(record, indent=2) + '\n')


def generate_sources(out):
    """Sky (final, prelit), banner and floor albedo sources for the bakes."""
    from PIL import Image, ImageDraw
    import random
    rng = random.Random(20261011)
    # Sky: 256x128, full turn of azimuth across U; V from 12 degrees below the
    # horizon (bottom row) to the zenith (top row). Night above an open crown.
    sky = Image.new('RGB', (256, 128))
    px = sky.load()
    # Late dusk: deep blue at the zenith, a cooler band and a low warm glow.
    stops = [(0.0, (24, 33, 58)), (.40, (40, 55, 88)), (.70, (74, 86, 116)), (.84, (112, 112, 128)), (.89, (140, 124, 112)), (1.0, (48, 44, 46))]
    for row in range(128):
        t = row / 127  # 0 zenith .. 1 below horizon
        for (a, ca), (b, cb) in zip(stops, stops[1:]):
            if a <= t <= b:
                f = (t - a) / (b - a)
                c = tuple(int(ca[k] + (cb[k] - ca[k]) * f) for k in range(3))
                break
        for col in range(256):
            px[col, row] = c
    d = ImageDraw.Draw(sky)
    # Distant hills: two silhouette bands; the horizon sits at row ~110.
    for layer, (base, amp, color) in enumerate(((105, 7, (44, 46, 58)), (111, 4, (28, 30, 38)))):
        points = [(0, 128)]
        phase = rng.random() * 6.28
        for col in range(0, 257, 4):
            a = col / 256 * math.tau
            y = base - amp * (math.sin(3 * a + phase) * .6 + math.sin(7 * a + 2 * phase) * .3 + math.sin(13 * a) * .1)
            points.append((col, y))
        points.append((256, 128))
        d.polygon(points, fill=color)
    for _ in range(26):  # sparse faint stars, high in the sky only
        x, y = rng.randrange(256), rng.randrange(4, 60)
        v = rng.randrange(70, 120)
        d.point((x, y), fill=(v, v, v + 12))
    sky.save(out / 'art_sky.tga')
    sky.save(out / 'art_sky.png')

    # The living tapestries become the target's four realm banners
    # (art_tapestries.tga, 512 x 256: eight 64 x 256 tiles, variant x 4 + realm).
    # v0 is the initial state and matches the target: rich realm colour, gold
    # border and emblem, the realm's fractal as a quiet tonal pattern in the
    # field. v1 (Love affirmed: "the tapestries glow with vibrance; their
    # patterns weave and twist") lifts the colour and weaves that fractal in
    # gold across the field. NotBeing leaves the wall bare (no tapestry shown).
    paint_banners(out)
    temple = Image.new('RGB', (SHEET, SHEET), REGIONS['lining'])
    temple.save(out / 'style-temple-albedo.png')

    # Floor: 512² over 28.6 m (5.6 cm per texel). Flagstones and the compass
    # mosaic centred where the earlier courses were. Painted at 4x and
    # downsampled, so edges carry coverage instead of hard stair-steps under
    # the runtime's texel sampling.
    F = 4
    size = SHEET * F
    floor = Image.new('RGB', (size, size), (140, 124, 98))
    fd = ImageDraw.Draw(floor)
    m2p = lambda x, y: ((x + FLOOR_SPAN / 2) / FLOOR_SPAN * size, (1 - (y + FLOOR_SPAN / 2) / FLOOR_SPAN) * size)
    flag = 1.4
    for gx in range(-10, 10):
        for gy in range(-10, 10):
            x0, y1 = m2p(gx * flag, gy * flag)
            x1, y0 = m2p((gx + 1) * flag, (gy + 1) * flag)
            v = rng.randrange(-10, 10)
            warm = rng.randrange(-4, 5)
            fd.rectangle((x0 + F, y0 + F, x1 - F, y1 - F), fill=(184 + v + warm, 166 + v, 140 + v - warm))
            if rng.random() < .25:  # a few chips/worn corners
                cx, cy = x0 + F * rng.randrange(3, 20), y0 + F * rng.randrange(3, 20)
                fd.ellipse((cx, cy, cx + 4 * F, cy + 3 * F), fill=(132 + v, 125 + v, 110 + v))
    cx, cy = m2p(0, -3)
    s = size / FLOOR_SPAN
    # Rings outermost first: bronze edge, gold, lapis, ivory field, inner rings.
    layers = [(5.05, (112, 86, 48)), (4.85, (196, 158, 82)), (4.55, (52, 74, 116)), (4.05, (204, 184, 146)),
              (2.55, (196, 158, 82)), (2.30, (52, 74, 116)), (2.05, (208, 190, 152))]
    for r, color in layers:
        fd.ellipse((cx - r * s, cy - r * s, cx + r * s, cy + r * s), fill=color)
    # Tesserae: small value-varied squares across the bands and ivory field.
    for i in range(1800):
        a = rng.random() * math.tau
        r = 2.05 + rng.random() * 3.0
        x, y = cx + r * s * math.cos(a), cy + r * s * math.sin(a)
        base = floor.getpixel((int(x), int(y)))
        dv = rng.randrange(-12, 12)
        fd.rectangle((x - F, y - F, x + F, y + F), fill=tuple(max(0, min(255, c + dv)) for c in base))
    # Eight-point star: long cardinal points in deep blue/gold halves.
    for k in range(8):
        a = k * math.tau / 8 + math.pi / 2
        long = k % 2 == 0
        tip = (4.3 if long else 2.9) * s
        side = (.55 if long else .42) * s
        p_tip = (cx + tip * math.cos(a), cy - tip * math.sin(a))
        p_l = (cx + side * math.cos(a + math.pi / 4), cy - side * math.sin(a + math.pi / 4))
        p_r = (cx + side * math.cos(a - math.pi / 4), cy - side * math.sin(a - math.pi / 4))
        fd.polygon([(cx, cy), p_l, p_tip], fill=(50, 68, 106) if long else (170, 142, 80))
        fd.polygon([(cx, cy), p_tip, p_r], fill=(196, 166, 98) if long else (140, 114, 62))
    fd.ellipse((cx - .42 * s, cy - .42 * s, cx + .42 * s, cy + .42 * s), fill=(214, 182, 100))
    fd.ellipse((cx - .22 * s, cy - .22 * s, cx + .22 * s, cy + .22 * s), fill=(44, 64, 108))
    # Twelve gold studs on the outer ring (one per hour of the old temple day).
    for k in range(12):
        a = k * math.tau / 12
        x, y = cx + 4.70 * s * math.cos(a), cy + 4.70 * s * math.sin(a)
        fd.ellipse((x - 3 * F, y - 3 * F, x + 3 * F, y + 3 * F), fill=(232, 204, 120))
    floor = floor.resize((SHEET, SHEET), Image.Resampling.LANCZOS)
    floor.save(out / 'style-floor-albedo.png')
    textures = {}
    import hashlib
    for name in ('art_sky.tga', 'style-temple-albedo.png', 'style-floor-albedo.png'):
        textures[name] = dict(size=list(Image.open(out / name).size), sha256=hashlib.sha256((out / name).read_bytes()).hexdigest())
    (out / 'style-proof-sources.json').write_text(json.dumps(textures, indent=2) + '\n')


# --------------------------------------------------------------------------
# Construction kit

def kit_type(base):
    """A mesh builder that tags every triangle with a paint region."""
    class Kit(base):
        def __init__(self, swatches=False):
            super().__init__()
            self.regions = []
            self.uvfns = []
            self.swatches = swatches

        def part(self, verts, faces, color, uvfn=None, facing=None):
            faces = [tuple(f) for f in faces]
            if facing is not None:
                # Open sheet: orient each face toward (or away from) a point.
                target, toward = facing
                fixed = []
                for f in faces:
                    a, b, c = (verts[f[0]], verts[f[1]], verts[f[2]])
                    n = _cross(_sub(b, a), _sub(c, a))
                    centre = [sum(verts[i][k] for i in f) / len(f) for k in range(3)]
                    d = _dot(n, _sub(target, centre))
                    fixed.append(f if (d > 0) == toward else tuple(reversed(f)))
                faces = fixed
            elif _closed(faces):
                if _volume(verts, faces) < 0:
                    faces = [tuple(reversed(f)) for f in faces]
            if uvfn is None and self.swatches and color in SWATCHES:
                uvfn = _swatch_uv(SWATCHES[color])
            fallback = color if color in ('stone', 'cream', 'gold', 'ink', 'blue', 'skin', 'hair', 'brown', 'red') else 'stone'
            start = len(self.faces)
            super().part(verts, faces, fallback)
            added = len(self.faces) - start
            self.regions.extend([color] * added)
            self.uvfns.extend([uvfn] * added)

        def beam(self, start, end, width, color):
            from mathutils import Vector
            a, b = Vector(start), Vector(end)
            direction = (b - a).normalized()
            reference = Vector((0, 1, 0)) if abs(direction.y) < .99 else Vector((0, 0, 1))
            side = direction.cross(reference).normalized() * width / 2
            up = direction.cross(side).normalized() * width / 2
            verts = [tuple(p + side * s + up * t) for p in (a, b) for s, t in [(-1, -1), (1, -1), (1, 1), (-1, 1)]]
            self.part(verts, [(0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)], color)

        def loft(self, sections, color, sides=10, folds=0, phase=0.):
            # (z, centreX, centreY, depthX, halfWidthY[, fold amplitude]).
            verts = []
            for s in sections:
                z, x, y, dx, dy = s[:5]
                amp = s[5] if len(s) > 5 else 0
                for i in range(sides):
                    t = i * math.tau / sides
                    r = 1 + amp * math.cos(folds * t + phase) if folds else 1
                    verts.append((x + dx * r * math.cos(t), y + dy * r * math.sin(t), z))
            n = len(sections)
            faces = [tuple(reversed(range(sides))), tuple(range((n - 1) * sides, n * sides))]
            faces += [(j * sides + i, j * sides + (i + 1) % sides, (j + 1) * sides + (i + 1) % sides, (j + 1) * sides + i)
                      for j in range(n - 1) for i in range(sides)]
            self.part(verts, faces, color)

        def blade(self, outline, depth, thickness, color, uvfn=None):
            # Closed prism in YZ (feather, cloth), extruded along X.
            n = len(outline)
            verts = [(depth + x, y, z) for x in (-thickness / 2, thickness / 2) for y, z in outline]
            faces = [tuple(reversed(range(n))), tuple(range(n, 2 * n))]
            faces += [(i, (i + 1) % n, (i + 1) % n + n, i + n) for i in range(n)]
            self.part(verts, faces, color, uvfn)

        def tube(self, path, radii, color, sides):
            """Closed tube along a 3D polyline; radii are (r_a, r_b) ellipse half-axes per point."""
            import math as _m
            from mathutils import Vector
            pts = [Vector(q) for q in path]
            verts = []
            for k, q in enumerate(pts):
                t = (pts[min(k + 1, len(pts) - 1)] - pts[max(k - 1, 0)]).normalized()
                ref = Vector((0, 0, 1)) if abs(t.z) < .9 else Vector((1, 0, 0))
                a = t.cross(ref).normalized()
                b = t.cross(a).normalized()
                ra, rb = radii[k]
                for i in range(sides):
                    th = i * _m.tau / sides
                    verts.append(tuple(q + a * ra * _m.cos(th) + b * rb * _m.sin(th)))
            rings = len(pts)
            faces = [tuple(reversed(range(sides))), tuple(range((rings - 1) * sides, rings * sides))]
            faces += [(j * sides + i, j * sides + (i + 1) % sides, (j + 1) * sides + (i + 1) % sides, (j + 1) * sides + i)
                      for j in range(rings - 1) for i in range(sides)]
            self.part(verts, faces, color)

        def slab(self, rows, offset, color):
            # Closed sheet from a grid of points (rows x cols) and a thickness vector.
            r, c = len(rows), len(rows[0])
            front = [p for row in rows for p in row]
            back = [(p[0] + offset[0], p[1] + offset[1], p[2] + offset[2]) for p in front]
            verts = front + back
            n = r * c
            idx = lambda i, j: i * c + j
            faces = []
            for i in range(r - 1):
                for j in range(c - 1):
                    faces.append((idx(i, j), idx(i + 1, j), idx(i + 1, j + 1), idx(i, j + 1)))
                    faces.append(tuple(n + k for k in (idx(i, j + 1), idx(i + 1, j + 1), idx(i + 1, j), idx(i, j))))
            ring = [idx(0, j) for j in range(c)] + [idx(i, c - 1) for i in range(1, r)] + \
                   [idx(r - 1, j) for j in range(c - 2, -1, -1)] + [idx(i, 0) for i in range(r - 2, 0, -1)]
            # Rim quads run opposite to the front faces along each shared edge.
            for a, b in zip(ring, ring[1:] + ring[:1]):
                faces.append((a, b, b + n, a + n))
            self.part(verts, faces, color)

        def object(self, name, location=(0, 0, 0), kind='platform', visibility=1, mass=0):
            obj = super().object(name, location, kind=kind, visibility=visibility, mass=mass)
            obj['art_stage'] = STAGE
            obj['style_regions'] = json.dumps(self.regions)
            return obj
    return Kit


def _swatch_uv(rect):
    def fn(co, rect=rect):
        # Any point inside the inset swatch reads the same flat colour.
        fx, fz = (co[0] + co[1]) % 1.0, co[2] % 1.0
        return rect_uv(rect, .2 + .6 * fx, .2 + .6 * fz)
    return fn


def _sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def _dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _closed(faces):
    edges = {}
    for f in faces:
        for a, b in zip(f, f[1:] + f[:1]):
            key = (min(a, b), max(a, b))
            edges[key] = edges.get(key, 0) + 1
    return bool(edges) and all(v == 2 for v in edges.values())


def _volume(verts, faces):
    c = [sum(v[k] for v in verts) / len(verts) for k in range(3)]
    total = 0
    for f in faces:
        for k in range(1, len(f) - 1):
            a, b, d = (_sub(verts[i], c) for i in (f[0], f[k], f[k + 1]))
            total += _dot(a, _cross(b, d)) / 6
    return total


# --------------------------------------------------------------------------
# Geometry

def sky_dome(K):
    m = K()
    seg = n('sky_azimuth')
    elevations = [e for (e,) in resample([(e,) for e in (-12, 0, 6, 14, 26, 42, 62, 90)], n('sky_rings') + 1)]
    # Azimuth starts behind the opening camera (-Y) so the U seam is unseen.
    rows = []
    for e in elevations:
        er = math.radians(e)
        rows.append([(SKY_RADIUS * math.cos(er) * math.cos(math.radians(270 + 360 * i / seg)),
                      SKY_RADIUS * math.cos(er) * math.sin(math.radians(270 + 360 * i / seg)),
                      SKY_RADIUS * math.sin(er)) for i in range(seg + 1)])
    vmap = lambda e: (e + 12) / 102
    for r in range(len(elevations) - 1):
        for i in range(seg):
            quad = [rows[r][i], rows[r][i + 1], rows[r + 1][i + 1], rows[r + 1][i]]
            us = [i / seg, (i + 1) / seg, (i + 1) / seg, i / seg]
            vs = [vmap(elevations[r]), vmap(elevations[r]), vmap(elevations[r + 1]), vmap(elevations[r + 1])]
            if elevations[r + 1] == 90:
                quad = quad[:3]; us = [i / seg, (i + 1) / seg, (i + .5) / seg]; vs = vs[:3]
            table = {tuple(round(c, 5) for c in p): (u, v) for p, u, v in zip(quad, us, vs)}
            fn = lambda co, table=table: _sky_uv(*table[min(table, key=lambda k: sum((k[j] - co[j]) ** 2 for j in range(3)))])
            m.part(quad, [tuple(range(len(quad)))], 'sky', uvfn=fn, facing=((0, 0, 0), True))
    return m


def _sky_uv(u, v):
    return rect_uv((0, 0, 256, 128), u, v, size=(256, 128))


R_VAULT = 10.4
WINDOWS = (-7, 0, 7)


def shell(K):
    """Vault lining, upper walls with window cut-outs, end walls and oculus."""
    m = K(swatches=True)
    inside = ((0, 0, 4), True)
    # Barrel vault, centre z=5, radius 10.4; the broken crown is open, its edge
    # varying bay by bay. Open lining sheet facing the interior only.
    bays = [-12.6, -9.0, -5.0, -1.0, 2.0, 5.5, 9.0, 12.6]
    # Crown opening per bay as fractions of the half-circle (kept below the
    # first, kept above the second). Over the shrine (y -1 to 9) the crown is
    # broken wide so the night sky shows beyond the shrine's stone ring.
    crown = [(6, 10), (7, 10), (6, 11), (3, 13), (3, 13), (3, 13), (6, 10)]
    segs = n('vault_segments')
    for b, (y0, y1) in enumerate(zip(bays, bays[1:])):
        left = round(crown[b][0] / 16 * segs) - 1
        right = round(crown[b][1] / 16 * segs)
        for i in list(range(0, left + 1)) + list(range(right, segs)):
            a, c = i * math.pi / segs, (i + 1) * math.pi / segs
            quad = [(R_VAULT * math.cos(a), y0, 5 + R_VAULT * math.sin(a)), (R_VAULT * math.cos(c), y0, 5 + R_VAULT * math.sin(c)),
                    (R_VAULT * math.cos(c), y1, 5 + R_VAULT * math.sin(c)), (R_VAULT * math.cos(a), y1, 5 + R_VAULT * math.sin(a))]
            m.part(quad, [(0, 1, 2, 3)], 'vault', facing=((0, (y0 + y1) / 2, 5), True))
        # Gold rim along the broken crown edge and a few loose edge blocks.
        for i, sign in ((left + 1, 1), (right, -1)):
            t = i * math.pi / segs
            p = (R_VAULT * .985 * math.cos(t), 0, 5 + R_VAULT * .985 * math.sin(t))
            m.beam((p[0], y0 + .05, p[2]), (p[0], y1 - .05, p[2]), .16, 'gold')
            if b % 2 == 0:
                q = (R_VAULT * .96 * math.cos(t + sign * .05), (y0 + y1) / 2, 5 + R_VAULT * .96 * math.sin(t + sign * .05))
                m.box(q, (.55, .7, .35), 'stone_light')
    # Upper side walls at x=+-10.4 from the low wall (z 1.2) to the springing.
    for x in (-10.4, 10.4):
        spans = [(-12.6, -8.35), (-5.65, -1.35), (1.35, 5.65), (8.35, 12.6)]
        for y0, y1 in spans:
            m.part([(x, y0, 1.2), (x, y1, 1.2), (x, y1, 5), (x, y0, 5)], [(0, 1, 2, 3)], 'wall', facing=inside)
        for cy in WINDOWS:
            for z0, z1 in ((1.2, 1.32), (4.05, 5)):
                m.part([(x, cy - 1.35, z0), (x, cy + 1.35, z0), (x, cy + 1.35, z1), (x, cy - 1.35, z1)], [(0, 1, 2, 3)], 'wall', facing=inside)
        # Cornice at the springing: stone band and gold string course.
        m.beam((x * .985, -12.5, 5.0), (x * .985, 12.5, 5.0), .32, 'stone_light')
        m.beam((x * .97, -12.5, 4.78), (x * .97, 12.5, 4.78), .10, 'gold')
    # End walls: rectangle to the springing and a solid lunette (the target has
    # no disc in the wall; its sky is above the shrine's broken crown).
    segs = n('end_wall_segments')
    for y in (12.6, -12.6):
        m.part([(-10.4, y, 1.2), (10.4, y, 1.2), (10.4, y, 5), (-10.4, y, 5)], [(0, 1, 2, 3)], 'wall', facing=inside)
        arc = [(R_VAULT * math.cos(k * math.pi / segs), y, 5 + R_VAULT * math.sin(k * math.pi / segs)) for k in range(segs + 1)]
        for k in range(segs):
            m.part([(0, y, 5), arc[k], arc[k + 1]], [(0, 1, 2)], 'wall', facing=inside)
    return m


def pier(m, x, y, height=PIER_H):
    """A massive square pier: plinth, coursed shaft, gold necking and capital bands, abacus."""
    m.box((x, y, .25), (1.3, 1.3, .5), 'marble')
    m.box((x, y, .56), (1.12, 1.12, .12), 'pier')
    courses = n('pier_courses', 1)
    z0, z1 = .62, height - 1.0
    for k in range(courses):
        a, b = z0 + (z1 - z0) * k / courses, z0 + (z1 - z0) * (k + 1) / courses
        m.box((x, y, (a + b) / 2), (1.0, 1.0, b - a), 'pier')
    m.box((x, y, height - .94), (1.08, 1.08, .12), 'gold')
    m.box((x, y, height - .66), (1.2, 1.2, .44), 'pier')
    m.box((x, y, height - .38), (1.3, 1.3, .1), 'gold')
    m.box((x, y, height - .16), (1.42, 1.42, .32), 'pier')


def shrine(K):
    """Niche wall behind the goddess and the broken crown ring over the piers."""
    import random
    m = K(swatches=True)
    cx, cy = SHRINE_C
    segs = n('niche_segments')
    a0, a1 = (math.radians(a) for a in NICHE_ARC)
    for k in range(segs):
        a, b = a0 + (a1 - a0) * k / segs, a0 + (a1 - a0) * (k + 1) / segs
        ring = [(cx + r * math.cos(t), cy + r * math.sin(t)) for r in (NICHE_R, NICHE_R + .35) for t in (a, b)]
        verts = [(px, py, z) for z in (0, NICHE_H) for px, py in ring]
        # Closed block: inner face (toward the goddess), outer face, top, ends.
        m.part(verts, [(0, 1, 3, 2), (4, 6, 7, 5), (0, 4, 5, 1), (2, 3, 7, 6), (0, 2, 6, 4), (1, 5, 7, 3)], 'niche')
    segs = n('crown_segments')
    r0, r1 = CROWN_R
    z0, z1 = CROWN_Z
    for k in range(segs):
        a, b = math.tau * k / segs, math.tau * (k + 1) / segs
        ring = [(cx + r * math.cos(t), cy + r * math.sin(t)) for r in (r0, r1) for t in (a, b)]
        verts = [(px, py, z) for z in (z0, z1) for px, py in ring]
        m.part(verts, [(0, 1, 3, 2), (4, 6, 7, 5), (0, 4, 5, 1), (2, 3, 7, 6), (0, 2, 6, 4), (1, 5, 7, 3)], 'crown')
        p, q = ((cx + (r0 - .04) * math.cos(t), cy + (r0 - .04) * math.sin(t), z0 + .18) for t in (a, b))
        m.beam(p, q, .1, 'gold')
    rng = random.Random(1012)
    chunks = n('crown_chunks')
    for k in range(chunks):
        t = math.tau * (k + rng.random() * .6) / chunks
        if math.sin(t) > .55 and rng.random() < .55:
            continue   # the broken gap faces the camera over the niche
        r = rng.uniform(r0 + .15, r1 - .15)
        size = (rng.uniform(.5, .9), rng.uniform(.5, .9), rng.uniform(.25, .7))
        m.box((cx + r * math.cos(t), cy + r * math.sin(t), z1 + size[2] / 2 - .05), size, 'crown')
    return m


def brazier(K):
    """Tall square plinth, bronze tripod bowl and large opaque flame cards."""
    m = K(swatches=True)
    m.box((0, 0, .55), (.66, .66, 1.1), 'marble')
    m.box((0, 0, 1.13), (.78, .78, .06), 'stone_light')
    m.box((0, 0, .05), (.78, .78, .1), 'stone_light')
    sides = n('brazier_sides')
    for k in range(3):
        a = k * math.tau / 3
        m.beam((.22 * math.cos(a), .22 * math.sin(a), 1.16), (.1 * math.cos(a), .1 * math.sin(a), 1.5), .045, 'bronze')
    m.loft([(1.45, 0, 0, .12, .12), (1.56, 0, 0, .30, .30), (1.64, 0, 0, .34, .34)], 'gold_dark', sides)
    m.loft([(1.62, 0, 0, .3, .3), (1.635, 0, 0, .3, .3)], 'ember', sides)
    cards, points = n('flame_cards', 2), n('flame_points', 5)
    for k in range(cards):
        a = k * math.pi / cards
        # A tongue of flame: wide at the bowl, a few licks, a tall tip.
        outline = []
        for j in range(points):
            f = j / (points - 1)
            width = .30 * (1 - f) ** .8 * (1 + .25 * math.sin(f * 9 + k))
            outline.append((-width, 1.62 + f * (BRAZIER_TOP + .3 - 1.62) * (.86 if j % 2 else 1.0)))
        outline = outline + [(-x * (1.05 if j % 2 else .95), z) for j, (x, z) in enumerate(reversed(outline[1:-1]))]
        verts = [(math.cos(a) * u - math.sin(a) * d, math.sin(a) * u + math.cos(a) * d, z)
                 for d in (-.012, .012) for u, z in outline]
        cnt = len(outline)
        faces = [tuple(reversed(range(cnt))), tuple(range(cnt, 2 * cnt))] + [(i, (i + 1) % cnt, (i + 1) % cnt + cnt, i + cnt) for i in range(cnt)]
        m.part(verts, faces, 'flame' if k % 2 == 0 else 'ember')
    return m


def stair(K):
    """A wide stair with broad steps up to a deep landing around the goddess."""
    m = K(swatches=True)
    gx, gy = GODDESS_AT
    rise, (tread, width, back, landing) = DAIS_H / DAIS_STEPS, STAIR
    back += gy
    front_of_landing = back - landing
    for k in range(DAIS_STEPS):
        front = front_of_landing - (DAIS_STEPS - 1 - k) * tread
        top = rise * (k + 1)
        m.box((gx, (front + back) / 2, top / 2), (width, back - front, top), 'marble')
        m.box((gx, front - .006, top - .012), (width * .98, .02, .024), 'gold')
    return m


# --- the goddess, facing +X, Z up, feet at the dais top ---------------------

GOWN = [(.02, 0, .31, .41), (.09, 0, .30, .40), (.26, -.004, .275, .365), (.46, -.008, .25, .33),
        (.66, -.012, .222, .29), (.84, -.01, .18, .235), (.95, -.006, .148, .205), (1.08, 0, .148, .216),
        (1.19, 0, .152, .235), (1.28, -.012, .137, .25), (1.335, -.022, .095, .17)]


def gown_x(z, y, front=True, margin=.02):
    """X of the gown surface at height z and lateral y, plus a clearance."""
    for (z0, c0, d0, w0), (z1, c1, d1, w1) in zip(GOWN, GOWN[1:]):
        if z0 <= z <= z1 or z < GOWN[0][0] or (z > GOWN[-1][0] and (z1, c1) == GOWN[-1][:2]):
            t = 0 if z < z0 else 1 if z > z1 else (z - z0) / (z1 - z0)
            c, d, w = c0 + (c1 - c0) * t, (d0 + (d1 - d0) * t) * 1.11, (w0 + (w1 - w0) * t) * 1.11
            break
    k = math.sqrt(max(0., 1 - min(1., (y / w) ** 2)))
    return c + d * k + margin if front else c - d * k - margin


def face_and_hair(m):
    """A finer head: more face rings, a nose wedge, level arched brows, almond
    eyes, lips, ears; chestnut hair as a mass, two locks and a back braid."""
    S = n('face_sides')
    head = resample([(1.40, .006, 0, .052, .062), (1.45, .022, 0, .085, .088), (1.50, .018, 0, .108, .106),
                     (1.56, .006, 0, .122, .118), (1.62, -.008, 0, .124, .121), (1.68, -.022, 0, .112, .112),
                     (1.73, -.04, 0, .07, .074)], n('face_rings'))
    m.loft(head, 'skin', S)
    m.loft([(1.27, -.016, 0, .06, .064), (1.43, -.012, 0, .058, .062)], 'skin', n('arm_sides'))
    # Nose: a closed wedge on the face plane; lips; chin softened by the loft.
    m.blade([(-.016, 1.505), (.016, 1.505), (0, 1.585)], .128, .03, 'skin')
    m.box((.118, 0, 1.478), (.02, .05, .012), 'red')
    m.box((.114, 0, 1.465), (.018, .042, .01), 'red')
    for side in (-1, 1):
        m.box((.111, side * .045, 1.566), (.012, .036, .016), 'cream')       # eye white
        m.box((.118, side * .045, 1.566), (.012, .018, .016), 'ink')         # iris
        m.beam((.114, side * .022, 1.597), (.112, side * .074, 1.600), .009, 'hair')   # level, slightly arched brow
        m.sphere((-.012, side * .122, 1.55), (.02, .014, .036), 'skin', n('ear_sides'), n('ear_rings', 2))
    # Hair: a mass over the crown and back, parted; locks to the shoulders; braid.
    hs = n('hair_sides')
    m.loft([(1.50, -.075, 0, .085, .128), (1.60, -.05, 0, .118, .136), (1.69, -.035, 0, .12, .132),
            (1.755, -.045, 0, .085, .10)], 'hair', max(hs, S))
    for side in (-1, 1):
        lock = resample([(-.02, side * .118, 1.66), (-.03, side * .135, 1.52), (-.045, side * .14, 1.40), (-.06, side * .13, 1.28)],
                        n('hair_lock_rings'))
        m.tube(lock, resample([(.04, .035), (.045, .04), (.042, .036), (.03, .026)], len(lock)), 'hair', hs)
    tiers = n('hair_tiers')
    for k in range(tiers):
        z = 1.47 - k * .62 / tiers
        m.loft([(z - .05, -.13 - .004 * k, 0, .045 - .002 * k, .05 - .003 * k),
                (z + .04, -.125 - .004 * k, 0, .052 - .002 * k, .058 - .003 * k)], 'hair', max(4, hs - 2))
    m.loft([(1.705, -.03, 0, .132, .138), (1.735, -.035, 0, .128, .134)], 'gold', n('circlet_sides'))
    m.sphere((.104, 0, 1.735), (.018, .035, .045), 'gold', n('gem_sides'), n('gem_rings', 2))


def open_hand(m, wrist, out, up):
    """An open palm facing forward and a little up: palm, four fingers, thumb."""
    from mathutils import Vector
    w, o, u = Vector(wrist), Vector(out).normalized(), Vector(up).normalized()
    f = o.cross(u).normalized()
    palm = w + o * .05
    hs = n('hand_sides')
    m.sphere(tuple(palm), (.05, .05, .05), 'skin', hs, n('palm_rings', 2))
    segs = n('finger_segments', 2)
    for k, spread in enumerate((-.6, -.2, .2, .6)):
        base = palm + o * .045 + f * spread * .035
        tip = base + (o * .085 + f * spread * .02 + u * .015)
        path = [tuple(base + (tip - base) * (i / segs)) for i in range(segs + 1)]
        m.tube(path, [(.011, .009)] * len(path), 'skin', n('finger_sides'))
    thumb = palm - f * .05 + u * .01
    m.tube([tuple(thumb), tuple(thumb + o * .04 - f * .03 + u * .02)], [(.012, .01)] * 2, 'skin', n('finger_sides'))


def goddess(K):
    m = K()
    # Gown: a fold loft with eight ridges fading toward the waist; flared hem.
    m.loft([(z, c, 0, d, w, a) for z, c, d, w, a in resample(
        [(.02, 0, .31, .41, .10), (.09, 0, .30, .40, .095), (.26, -.004, .275, .365, .085), (.46, -.008, .25, .33, .07),
         (.66, -.012, .222, .29, .055), (.84, -.01, .18, .235, .035), (.95, -.006, .148, .205, .012)], n('gown_sections'))],
        'gown', n('gown_sides'), folds=8, phase=.2)
    m.loft([(.94, -.006, 0, .147, .206), (1.08, 0, 0, .148, .216), (1.19, 0, 0, .152, .235),
            (1.28, -.012, 0, .137, .25), (1.335, -.022, 0, .095, .17)], 'gown', n('bodice_sides'))
    m.loft([(.935, 0, 0, .154, .214), (1.005, 0, 0, .16, .222)], 'gold', n('belt_sides'))
    m.sphere((.165, 0, .97), (.028, .07, .062), 'gold_dark', n('gem_sides'), n('gem_rings', 2))
    # Gold sash from the left shoulder to the right hip; cloak behind.
    rows = []
    rr, cc = n('sash_rows', 2), n('sash_cols', 2)
    for k in range(rr):
        t = k / (rr - 1)
        z = 1.30 - .80 * t
        rows.append([(gown_x(z - .03 * j, -.25 + .40 * t + j * .09 / (cc - 1), margin=.03), -.25 + .40 * t + j * .09 / (cc - 1), z - .03 * j)
                     for j in range(cc)])
    m.slab(rows, (.025, 0, 0), 'gold')
    rows = []
    rr, cc = n('cape_rows', 2), n('cape_cols', 3)
    for k in range(rr):
        t = k / (rr - 1)
        z = 1.31 - 1.27 * t
        w = .30 + .16 * t
        rows.append([(gown_x(z, -w + j * 2 * w / (cc - 1), front=False) - .05 * (1 - (2 * j / (cc - 1) - 1) ** 2) - .02 * math.cos(j * 2.1),
                      -w + j * 2 * w / (cc - 1), z) for j in range(cc)])
    m.slab(rows, (-.025, 0, 0), 'sleeve')
    # Neckline V.
    for side in (-1, 1):
        m.beam((.128, side * .085, 1.33), (.152, 0, 1.19), .022, 'gold')
    # Open, welcoming arms: draped sleeves to the wrist, gold cuffs, open palms.
    for side in (-1, 1):
        shoulder, elbow, wrist = (0, side * .235, 1.27), (.03, side * .36, 1.02), (.2, side * .47, .92)
        sleeve = [shoulder, (.015, side * .30, 1.15), elbow, (.12, side * .42, .97), wrist]
        m.tube(sleeve, [(.075, .07), (.08, .075), (.085, .08), (.105, .095), (.125, .11)], 'sleeve', n('sleeve_sides'))
        cuff = (.21, side * .475, .915)
        m.tube([(.185, side * .465, .925), (.235, side * .485, .905)], [(.06, .055)] * 2, 'gold', n('arm_sides'))
        m.tube([(.22, side * .48, .91), (.27, side * .50, .89)], [(.042, .038)] * 2, 'skin', n('arm_sides'))
        open_hand(m, (.27, side * .50, .89), (.75, side * .55, -.05), (.1, side * .1, 1))
        # Sandalled feet below the hem.
        m.loft([(.055, .13, side * .16, .14, .085), (.11, .085, side * .16, .10, .078)], 'skin', n('arm_sides'))
        m.box((.13, side * .16, .012), (.30, .17, .024), 'sandal')
        m.beam((.16, side * .16 - .07, .07), (.16, side * .16 + .07, .07), .025, 'sandal')
    face_and_hair(m)
    # Halo behind the head with short star points.
    segs = n('halo_segments')
    for i in range(segs):
        a, b = i * math.tau / segs, (i + 1) * math.tau / segs
        m.beam((-.17, .235 * math.cos(a), 1.665 + .235 * math.sin(a)), (-.17, .235 * math.cos(b), 1.665 + .235 * math.sin(b)), .032, 'halo')
    points = n('halo_points', 0)
    for k in range(points):
        a = k * math.tau / points + math.pi / 4
        cy, cz = .235 * math.cos(a), 1.665 + .235 * math.sin(a)
        m.blade([(cy + .035 * math.cos(a + 1.57), cz + .035 * math.sin(a + 1.57)), (cy + .10 * math.cos(a), cz + .10 * math.sin(a)),
                 (cy + .035 * math.cos(a - 1.57), cz + .035 * math.sin(a - 1.57))], -.17, .02, 'halo')
    return m


def feather(m, root, tip, width, depth, side):
    """One feather blade from root to tip in the wing plane (YZ), pointed at the tip."""
    pts = n('feather_points', 4)
    ry, rz = root
    ty, tz = tip
    dy, dz = ty - ry, tz - rz
    length = math.hypot(dy, dz)
    ny, nz = -dz / length, dy / length
    left, right = [], []
    for k in range(pts):
        f = k / (pts - 1)
        half = width * (math.sin(math.pi * min(1, f * 1.15)) ** .7) * (1 - f * .15)
        cy, cz = ry + dy * f, rz + dz * f
        left.append((cy + ny * half, cz + nz * half))
        right.append((cy - ny * half * .75, cz - nz * half * .75))
    outline = [root] + left[1:-1] + [tip] + list(reversed(right[1:-1]))
    m.blade(outline, depth, .022, 'wing')


def wing(K, side):
    """A full feathered wing rising behind the shoulders: primaries, secondaries,
    coverts and scapulars layered on a closed wing arm."""
    m = K()
    # Wing arm: root at the back, up and out to the wrist, on to the tip.
    # Compact and upright, as in the target: about a shoulder-width out, the
    # primaries rising above the head.
    arm = [(-.17, 0, 0), (-.08, side * .16, .30), (-.04, side * .30, .62), (-.02, side * .36, .92)]
    m.tube(arm, [(.08, .07), (.075, .065), (.055, .05), (.035, .03)], 'wing', n('wing_arm_sides'))
    tiers = ((n('wing_primaries'), .80, .075, -.065, (.50, .98), (60, 96)),
             (n('wing_secondaries'), .58, .07, -.035, (.25, .75), (40, 86)),
             (n('wing_coverts'), .38, .06, -.005, (.12, .55), (25, 76)),
             (n('wing_scapulars'), .24, .05, .02, (.05, .35), (12, 62)))
    for count, reach, width, depth, (s0, s1), (a0, a1) in tiers:
        for i in range(count):
            f = i / max(1, count - 1)
            # Roots along the wing arm; feathers fan from low-outward to upright.
            along = s0 + (s1 - s0) * f
            k = min(int(along * (len(arm) - 1)), len(arm) - 2)
            g = along * (len(arm) - 1) - k
            ry = arm[k][1] + (arm[k + 1][1] - arm[k][1]) * g
            rz = arm[k][2] + (arm[k + 1][2] - arm[k][2]) * g
            angle = math.radians(a0 + (a1 - a0) * f)
            length = reach * (.75 + .25 * f)
            tip = (ry + side * length * math.cos(angle), rz + length * math.sin(angle))
            feather(m, (ry, rz), tip, width, depth - i * .004, side)
    return m


# --------------------------------------------------------------------------
# UVs, bakes and composition

def _select_only(obj):
    import bpy
    bpy.context.view_layer.update()
    for other in list(bpy.context.view_layer.objects):
        if other is not None and other.select_get() != (other == obj):
            other.select_set(other == obj)
    bpy.context.view_layer.objects.active = obj


def _combined(name, objects, local=False, location=(0, 0, 0)):
    """One temporary mesh holding several objects, polygon order kept.

    World space by default; ``local`` keeps object space so procedural paint
    masks (hem, panel, wing gradient) read in the figure's own frame.
    """
    import bpy
    verts, faces, owners = [], [], []
    for obj in objects:
        offset = len(verts)
        world = obj.matrix_world
        verts.extend([tuple(v.co) if local else tuple(world @ v.co) for v in obj.data.vertices])
        for poly in obj.data.polygons:
            faces.append(tuple(offset + i for i in poly.vertices))
            owners.append(obj.name)
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.scene.collection.objects.link(obj)
    obj.location = location
    return obj


def _smart(obj, faces, rect, size=(SHEET, SHEET), margin=.03, angle=55):
    """Smart-project the given polygon indices, then fit them into a pixel rect."""
    import bpy
    import bmesh
    _select_only(obj)
    if not obj.data.uv_layers:
        obj.data.uv_layers.new(name='Painted diffuse')
    bpy.ops.object.mode_set(mode='EDIT')
    bm = bmesh.from_edit_mesh(obj.data)
    bm.faces.ensure_lookup_table()
    chosen = set(faces)
    for f in bm.faces:
        f.select = f.index in chosen
    bmesh.update_edit_mesh(obj.data)
    # The island count grows with the detail scale while the pixel rect stays
    # fixed, so the packing margin grows with it to hold the 4 px gutter.
    margin *= DETAIL_SCALE
    bpy.ops.uv.smart_project(angle_limit=math.radians(angle), island_margin=margin, area_weight=0.0, correct_aspect=True, scale_to_bounds=False)
    bpy.ops.object.mode_set(mode='OBJECT')
    uv = obj.data.uv_layers.active.data
    for index in chosen:
        for loop in obj.data.polygons[index].loop_indices:
            u, v = uv[loop].uv
            uv[loop].uv = rect_uv(rect, min(1, max(0, u)), min(1, max(0, v)), size)


def _explicit(obj, fns):
    uv = obj.data.uv_layers.active.data
    for poly, fn in zip(obj.data.polygons, fns):
        if fn is None:
            continue
        for loop in poly.loop_indices:
            uv[loop].uv = fn(obj.data.vertices[obj.data.loops[loop].vertex_index].co)


def _copy_uvs(source, targets):
    """Copy loop UVs from a combined mesh back to the objects it was built from."""
    uv = source.data.uv_layers.active.data
    loop = 0
    for obj in targets:
        if not obj.data.uv_layers:
            obj.data.uv_layers.new(name='Painted diffuse')
        layer = obj.data.uv_layers.active.data
        for poly in obj.data.polygons:
            for target in poly.loop_indices:
                layer[target].uv = uv[loop].uv
                loop += 1


def _region_material(region, albedo=None):
    """A matte Principled material for one paint region (bake input only)."""
    import bpy
    mat = bpy.data.materials.new('bake_' + region)
    mat.use_nodes = True
    nodes, links = mat.node_tree.nodes, mat.node_tree.links
    bsdf = nodes['Principled BSDF']
    for name, value in (('Roughness', 1.0), ('Specular IOR Level', 0.0), ('Metallic', 0.0)):
        if name in bsdf.inputs:
            bsdf.inputs[name].default_value = value
    if region.startswith('banner_') and albedo is not None:
        tex = nodes.new('ShaderNodeTexImage')
        tex.image = albedo
        links.new(tex.outputs['Color'], bsdf.inputs['Base Color'])
        return mat
    colour = (*linear(REGIONS.get(region, '#808080')), 1)
    coord = nodes.new('ShaderNodeTexCoord')
    xyz = nodes.new('ShaderNodeSeparateXYZ')
    links.new(coord.outputs['Object'], xyz.inputs[0])
    def mix(factor_socket, a, b):
        node = nodes.new('ShaderNodeMix')
        node.data_type = 'RGBA'
        links.new(factor_socket, node.inputs[0])
        for socket, value in ((node.inputs[6], a), (node.inputs[7], b)):
            if isinstance(value, tuple):
                socket.default_value = value
            else:
                links.new(value, socket)
        return node.outputs[2]
    def ramp(axis, lo, hi):
        node = nodes.new('ShaderNodeMapRange')
        links.new(xyz.outputs[axis], node.inputs['Value'])
        node.inputs['From Min'].default_value = lo
        node.inputs['From Max'].default_value = hi
        return node.outputs['Result']
    def step(socket, edge, below=True):
        node = nodes.new('ShaderNodeMath')
        node.operation = 'LESS_THAN' if below else 'GREATER_THAN'
        links.new(socket, node.inputs[0])
        node.inputs[1].default_value = edge
        return node.outputs[0]
    out = None
    if region == 'gown':
        # Lighter bodice, slightly deeper hem, a gold hem band and front panel.
        S = GODDESS_SCALE
        shade = mix(ramp('Z', DAIS_H + .1 * S, DAIS_H + 1.2 * S), (*linear('#D8CBAA'), 1), colour)
        absy = nodes.new('ShaderNodeMath'); absy.operation = 'ABSOLUTE'; links.new(xyz.outputs['Y'], absy.inputs[0])
        front = nodes.new('ShaderNodeMath'); front.operation = 'MULTIPLY'
        links.new(step(absy.outputs[0], .055 * S), front.inputs[0]); links.new(step(xyz.outputs['X'], .05 * S, below=False), front.inputs[1])
        panel = nodes.new('ShaderNodeMath'); panel.operation = 'MULTIPLY'
        links.new(front.outputs[0], panel.inputs[0]); links.new(step(xyz.outputs['Z'], DAIS_H + .93 * S), panel.inputs[1])
        with_panel = mix(panel.outputs[0], shade, (*linear('#E2C27A'), 1))
        node = nodes.new('ShaderNodeMix'); node.data_type = 'RGBA'
        links.new(step(xyz.outputs['Z'], DAIS_H + .14 * S), node.inputs[0])
        links.new(with_panel, node.inputs[6]); node.inputs[7].default_value = (*linear(REGIONS['gold']), 1)
        out = node.outputs[2]
    elif region == 'sleeve':
        out = mix(ramp('Z', DAIS_H + .15 * GODDESS_SCALE, DAIS_H + 1.25 * GODDESS_SCALE), (*linear('#D6C8A6'), 1), colour)
    elif region == 'wing':
        absy = nodes.new('ShaderNodeMath'); absy.operation = 'ABSOLUTE'; links.new(xyz.outputs['Y'], absy.inputs[0])
        reach = nodes.new('ShaderNodeMapRange'); links.new(absy.outputs[0], reach.inputs['Value'])
        reach.inputs['From Min'].default_value = .05 * GODDESS_SCALE; reach.inputs['From Max'].default_value = .95 * GODDESS_SCALE
        out = mix(reach.outputs['Result'], (*linear('#A97F35'), 1), (*linear('#F0D58E'), 1))
    elif region in ('wall', 'vault'):
        # Large blocks with a warm/cool value shift; no fine grain.
        brick = nodes.new('ShaderNodeTexBrick')
        brick.inputs['Scale'].default_value = .55
        brick.inputs['Mortar Size'].default_value = .012
        brick.inputs['Color1'].default_value = colour
        darker = tuple(c * .82 for c in colour[:3]) + (1,)
        brick.inputs['Color2'].default_value = darker
        brick.inputs['Mortar'].default_value = tuple(c * .6 for c in colour[:3]) + (1,)
        geometry = nodes.new('ShaderNodeNewGeometry')
        nxyz = nodes.new('ShaderNodeSeparateXYZ'); links.new(geometry.outputs['Normal'], nxyz.inputs[0])
        absx = nodes.new('ShaderNodeMath'); absx.operation = 'ABSOLUTE'; links.new(nxyz.outputs['X'], absx.inputs[0])
        yz = nodes.new('ShaderNodeCombineXYZ'); links.new(xyz.outputs['Y'], yz.inputs[0]); links.new(xyz.outputs['Z'], yz.inputs[1])
        xz = nodes.new('ShaderNodeCombineXYZ'); links.new(xyz.outputs['X'], xz.inputs[0]); links.new(xyz.outputs['Z'], xz.inputs[1])
        pick = nodes.new('ShaderNodeMix'); pick.data_type = 'VECTOR'
        links.new(step(absx.outputs[0], .5, below=False), pick.inputs[0])
        links.new(xz.outputs[0], pick.inputs[4]); links.new(yz.outputs[0], pick.inputs[5])
        links.new(pick.outputs[1], brick.inputs['Vector'])
        out = brick.outputs['Color']
    if out is not None:
        links.new(out, bsdf.inputs['Base Color'])
    else:
        bsdf.inputs['Base Color'].default_value = colour
    if region in ('flame', 'ember'):
        bsdf.inputs['Emission Color'].default_value = colour
        bsdf.inputs['Emission Strength'].default_value = 9.0 if region == 'flame' else 4.0
    return mat


def _assign_bake_materials(obj, regions, target, albedo=None):
    import bpy
    mesh = obj.data
    mesh.materials.clear()
    names = sorted(set(regions))
    cache = {}
    for name in names:
        mat = _region_material(name, albedo)
        node = mat.node_tree.nodes.new('ShaderNodeTexImage')
        node.image = target
        mat.node_tree.nodes.active = node
        cache[name] = mat
        mesh.materials.append(mat)
    for poly, region in zip(mesh.polygons, regions):
        poly.material_index = names.index(region)
    return list(cache.values())


def _fill(image, rgb):
    import numpy as np
    w, h = image.size
    image.pixels.foreach_set(np.tile(np.array([*rgb, 1.0], dtype='float32'), w * h))


def _bake(obj, kind, target, samples, margin=6, pass_filter=None, fill=None):
    """Cycles bake into ``target``. With ``fill`` the image is pre-filled
    (scene-linear) instead of cleared, so a sub-texel island that no pixel
    centre falls in reads as neutral stone rather than black."""
    import bpy
    scene = bpy.context.scene
    scene.cycles.samples = samples
    scene.render.bake.margin = margin
    scene.render.bake.margin_type = 'EXTEND'
    if fill is not None:
        _fill(target, fill)
    scene.render.bake.use_clear = fill is None
    _select_only(obj)
    kwargs = dict(type=kind, use_clear=fill is None, margin=margin)
    if pass_filter is not None:
        kwargs['pass_filter'] = pass_filter
    bpy.ops.object.bake(**kwargs)


def _pixels(image):
    import numpy as np
    w, h = image.size
    return np.array(image.pixels[:], dtype='float32').reshape(h, w, 4)[::-1]  # top-down rows


def _new_image(name, size=(SHEET, SHEET)):
    import bpy
    # Float buffers hold scene-linear values; converted to sRGB once on save.
    return bpy.data.images.new(name, size[0], size[1], alpha=True, float_buffer=True)


def _blur(array, sigma=1.2):
    """Separable Gaussian over the first two axes (bake-noise smoothing)."""
    import numpy as np
    radius = int(3 * sigma)
    kernel = np.exp(-(np.arange(-radius, radius + 1) ** 2) / (2 * sigma * sigma))
    kernel /= kernel.sum()
    padded = np.pad(array, ((radius, radius), (0, 0), (0, 0)), mode='edge')
    array = sum(kernel[i] * padded[i:i + array.shape[0]] for i in range(len(kernel)))
    padded = np.pad(array, ((0, 0), (radius, radius), (0, 0)), mode='edge')
    return sum(kernel[i] * padded[:, i:i + array.shape[1]] for i in range(len(kernel)))


def _save_tga(array_srgb8, path):
    from PIL import Image
    Image.fromarray(array_srgb8[:, :, :3], 'RGB').save(path)


def _bake_lights(scene_objects):
    """Warm crown key, two torch pools and a cool night ambient (bake only)."""
    import bpy
    created = []
    def light(name, kind, location, energy, color, size=None, rotation=(0, 0, 0)):
        data = bpy.data.lights.new(name, kind)
        data.energy = energy
        data.color = color
        if size is not None:
            if kind == 'AREA':
                data.shape = 'RECTANGLE'; data.size, data.size_y = size
            else:
                data.shadow_soft_size = size
        obj = bpy.data.objects.new(name, data)
        bpy.context.scene.collection.objects.link(obj)
        obj.location = location
        obj.rotation_euler = rotation
        created.append(obj)
        return obj
    # The oculus key falls from in front and above onto the goddess and the
    # stair (aimed about 25 degrees off vertical toward +Y), so her front reads.
    light('bake_oculus_key', 'AREA', (GODDESS_AT[0], GODDESS_AT[1] - 4.5, 11.5), KEY_POWER, (1.0, .88, .70), size=(4.0, 4.0),
          rotation=(math.radians(25), 0, 0))
    light('bake_crown_key', 'AREA', (1.5, 2.0, 13.5), CROWN_POWER, (.92, .90, .88), size=(7.0, 22.0), rotation=(math.radians(8), math.radians(-6), 0))
    for side in (-1, 1):
        light(f'bake_wall_wash_{side}', 'AREA', (side * 6.5, 6.0, 10.0), WASH_POWER, (1.0, .86, .68), size=(6.0, 3.0),
              rotation=(math.radians(62), 0, 0))
    light('bake_fill', 'AREA', (0, -11.5, 7.0), FILL_POWER, (.80, .80, .82), size=(16.0, 6.0), rotation=(math.radians(70), 0, 0))
    for i, (x, y) in enumerate(TORCHES):
        light(f'bake_torch_{i}', 'POINT', (x, y, BRAZIER_TOP - .15), TORCH_POWER, (1.0, .56, .26), size=.15)
    world = bpy.data.worlds.new('bake_night')
    world.use_nodes = True
    world.node_tree.nodes['Background'].inputs[0].default_value = (.020, .028, .048, 1)
    world.node_tree.nodes['Background'].inputs[1].default_value = 1.0
    previous = bpy.context.scene.world
    bpy.context.scene.world = world
    return created, world, previous


def dress(M, scene, out, setup_material):
    """Apply the six style-proof layers; return the disposition record."""
    import bpy
    import numpy as np
    from art_temple_love import replace
    Base = M.__bases__[0]
    K = kit_type(Base)
    added, replaced, removed = [], [], []
    regions_of = {}

    def make(name, kit, visibility, bbox, location=(0, 0, 0), kind='platform'):
        obj = kit.object(name, location, kind=kind, visibility=visibility)
        # Explicit collision box: never the render bounds of a large lining.
        obj['wf_original_bbox'] = tuple(bbox)
        obj['wf_had_authored_bbox'] = True
        regions_of[name] = (kit.regions, kit.uvfns)
        added.append(name)
        return obj

    # 1. Sky dome (backdrop only, Temple realm only, prelit).
    sky_kit = sky_dome(K)
    sky = make('temple_sky', sky_kit, SKY_VISIBILITY, (-.05, -.05, 30.0, .05, .05, 30.1))
    # 4. Shell; 5. dressing.
    shell_obj = make('temple_shell', shell(K), 207, (-.05, -.05, 15.6, .05, .05, 15.7))
    # Shrine niche (layout B): wall, broken crown ring. No collision (box out of reach).
    shrine_obj = make('temple_shrine', shrine(K), 207, (-.05, -.05, 9.0, .05, .05, 9.1))
    # Two new piers mirror pillar1 and pillar3; 0.9 m collision boxes keep
    # 0.15 m clear of the x = 0 route for the player's 0.4 m half-diagonal.
    pier_objs = []
    for i, (x, y) in enumerate(NEW_PIERS):
        kit = K(swatches=True)
        pier(kit, 0, 0)
        pier_objs.append(make(f'temple_pier_{i}', kit, 207, (-.45, -.45, 0, .45, .45, PIER_H), (x, y, 0)))
    # Square massive shells around the four nave pillars: visual girth only;
    # the pillars keep their round collision cores (footprints unchanged).
    shells = K(swatches=True)
    for name in ('pillar0', 'pillar1', 'pillar2', 'pillar3'):
        px, py = scene.objects[name].location[:2]
        pier(shells, px, py)
    shells_obj = make('temple_pier_shells', shells, 207, (-.05, -.05, 9.2, .05, .05, 9.3))
    torch_objs = []
    for i, (x, y) in enumerate(TORCHES):
        # The torch's own 0.5 m box, unchanged: the plinth's extra width is
        # visual girth only (footprints are never enlarged).
        torch_objs.append(make(f'temple_torch_{i}', brazier(K), 207, (-.25, -.25, 0, .25, .25, 1.25), (x, y, 0)))
    # A climbable stair (0.15 m rises under the 0.4 m step-up) with a deep
    # landing: the player can climb toward the goddess, whose own box stops
    # them, and stays inside her 2.5 m dialogue reach. Mesh collider (statplat).
    gx, gy = GODDESS_AT
    tread, width, back, landing = STAIR
    dais_obj = make('temple_dais', stair(K), 207, (gx - width / 2, gy + back - landing - (DAIS_STEPS - 1) * tread, 0,
                                                   gx + width / 2, gy + back, DAIS_H), kind='statplat')
    # The polish gold courses would sit on top of the painted compass.
    old = scene.objects.get('temple_mosaic_courses')
    if old is not None:
        bpy.data.objects.remove(old, do_unlink=True)
        removed.append('temple_mosaic_courses')

    # 6. Goddess and wings: replace() keeps names, visibility and the polish
    # collision box; the visible model stands on the dais (DAIS_H).
    from mathutils import Vector
    bpy.context.view_layer.update()
    feet = scene.objects['Goddess'].matrix_world.translation.copy()
    wing_world = scene.objects['GoddessWingL'].matrix_world.copy()
    wing_local = wing_world.inverted()
    def lifted(kit):
        # Mesh and rig scale together: the body about its feet, the wing about
        # the goddess's feet in world space, so the wing root stays on her back
        # while the wing actor (motion pivot, collision box) does not move.
        kit.verts = [(x * GODDESS_SCALE, y * GODDESS_SCALE, z * GODDESS_SCALE + DAIS_H) for x, y, z in kit.verts]
        return kit
    def lifted_wing(kit):
        out = []
        for v in kit.verts:
            w = wing_world @ Vector(v)
            w = feet + (w - feet) * GODDESS_SCALE + Vector((0, 0, DAIS_H))
            out.append(tuple(wing_local @ w))
        kit.verts = out
        return kit
    body = lifted(goddess(K))
    wing_kit = lifted_wing(wing(K, -1))
    sign = scene.objects.get('goddess_sign')
    if sign is not None:
        sign.location.z = SIGN_Z
    # Nave pillars grow in height only: the round plinth keeps the old base
    # radius, so the footprint and walkable space are unchanged.
    from art_temple_love import replace as replace_kit
    for i in range(4):
        # The round core inside each square shell: same base radius as before,
        # so the pillar's mesh collider keeps its footprint.
        pm = M()
        pm.cone((0, 0, 0), .52, .38, 'stone', sides=n('pillar_sides'))
        pm.cone((0, 0, .38), .33, PIER_H - .38, 'cream', .33, sides=n('pillar_sides'))
        pillar = replace_kit(scene, M, 'pillar' + str(i), pm)
        pillar['art_stage'] = STAGE
        replaced.append('pillar' + str(i))
    banner_actors = []
    cx, cy = SHRINE_C
    for realm in range(4):
        spot = BANNER_SPOT[realm]
        if spot[0] == 'pier':
            centre = (spot[1], spot[2] - .5 - .045)
            along, inward = (1.0, 0.0), (0.0, -1.0)
        else:
            t = math.radians(spot[1])
            centre = (cx + (NICHE_R - .06) * math.cos(t), cy + (NICHE_R - .06) * math.sin(t))
            along, inward = (-math.sin(t), math.cos(t)), (-math.cos(t), -math.sin(t))
        for variant in (0, 1):
            name = f'cloth{realm}v{variant}'
            obj = scene.objects[name]
            ox, oy = obj.location[:2]
            tile = (64 * (variant * 4 + realm), 0, 64 * (variant * 4 + realm + 1), TAPESTRY_SIZE[1])
            kit = K()
            w = BANNER_W
            hem = n('banner_hem_points', 1)
            outline = [(-w / 2, BANNER_TOP), (w / 2, BANNER_TOP), (w / 2, BANNER_HEM)]
            outline += [(w / 2 - w * (k + 1) / (2 * (hem + 1)), BANNER_HEM - (BANNER_HEM - BANNER_POINT) * (k + 1) / (hem + 1)) for k in range(hem)]
            outline += [(0, BANNER_POINT)]
            outline += [(-x, z) for x, z in reversed(outline[3:-1])] + [(-w / 2, BANNER_HEM)]
            def at(u, z, d):
                return (centre[0] + along[0] * u + inward[0] * d - ox, centre[1] + along[1] * u + inward[1] * d - oy, z)
            cnt = len(outline)
            verts = [at(u, z, d) for d in (.02, -.02) for u, z in outline]
            faces = [tuple(reversed(range(cnt))), tuple(range(cnt, 2 * cnt))] + [(i, (i + 1) % cnt, (i + 1) % cnt + cnt, i + cnt) for i in range(cnt)]
            def front_uv(co, tile=tile, ox=ox, oy=oy, centre=centre, along=along, w=w):
                u = ((co[0] + ox - centre[0]) * along[0] + (co[1] + oy - centre[1]) * along[1]) / w + .5
                v = (co[2] - BANNER_POINT) / (BANNER_TOP - BANNER_POINT)
                return rect_uv(tile, max(0, min(1, u)), max(0, min(1, v)), TAPESTRY_SIZE)
            gold_uv = lambda co, tile=tile: rect_uv(tile, .5, .985, TAPESTRY_SIZE)
            start = len(kit.faces)
            kit.part(verts, faces, 'banner', uvfn=gold_uv)
            for k in range(start, len(kit.faces)):
                a, b, c = (kit.verts[i] for i in kit.faces[k])
                normal = _cross(_sub(b, a), _sub(c, a))
                if _dot(normal, (inward[0], inward[1], 0)) > 1e-9:
                    kit.uvfns[k] = front_uv
            # Gold hanging rod with square finials, part of the banner.
            for u0, u1 in ((-w / 2 - .14, w / 2 + .14),):
                kit.beam(at(u0, BANNER_TOP + .05, .05), at(u1, BANNER_TOP + .05, .05), .05, 'banner')
            for side in (-1, 1):
                kit.box(at(side * (w / 2 + .16), BANNER_TOP + .05, .05), (.08, .08, .08), 'banner')
            for k in range(len(kit.uvfns)):
                if kit.uvfns[k] is None:
                    kit.uvfns[k] = gold_uv
            replace(scene, M, name, kit)
            obj['art_stage'] = STAGE
            regions_of[name] = (kit.regions, kit.uvfns)
            banner_actors.append(obj)
    replaced.extend(o.name for o in banner_actors)
    goddess_obj = replace(scene, M, 'Goddess', body)
    goddess_obj['art_stage'] = STAGE; goddess_obj['art_role'] = 'principal (style proof remodel)'
    regions_of['Goddess'] = (body.regions, body.uvfns)
    wing_l = replace(scene, M, 'GoddessWingL', wing_kit)
    wing_l['art_stage'] = STAGE
    regions_of['GoddessWingL'] = (wing_kit.regions, wing_kit.uvfns)
    replaced.extend(['Goddess', 'GoddessWingL', 'GoddessWingR'])

    # UVs. Temple sheet: one joint smart projection for shell and dressing so
    # their islands never overlap; banner fronts keep their painted rects.
    shrine_objs = [shrine_obj, *pier_objs, shells_obj, *torch_objs, dais_obj]
    temple_objs = [shell_obj] + shrine_objs
    bpy.context.view_layer.update()  # world matrices of the new actors
    for obj in temple_objs + [sky, goddess_obj, wing_l] + banner_actors:
        if not obj.data.uv_layers:
            obj.data.uv_layers.new(name='Painted diffuse')
    joint = _combined('style_temple_joint', temple_objs)
    joint.data.uv_layers.new(name='Painted diffuse')
    fns = [f for obj in temple_objs for f in regions_of[obj.name][1]]
    regions = [r for obj in temple_objs for r in regions_of[obj.name][0]]
    # Two smart regions: the far hall shell gets less of the sheet than the
    # shrine the camera looks at.
    shell_faces = len(regions_of['temple_shell'][1])
    _smart(joint, [i for i, f in enumerate(fns) if f is None and i < shell_faces], TEMPLE_SMART, margin=.035, angle=60)
    _smart(joint, [i for i, f in enumerate(fns) if f is None and i >= shell_faces], SHRINE_SMART, margin=.014, angle=60)
    _explicit(joint, fns)
    _copy_uvs(joint, temple_objs)
    for obj in banner_actors:
        _explicit(obj, regions_of[obj.name][1])
    _explicit(sky, regions_of['temple_sky'][1])
    # Isolated far below the level so the bake sees only the figure itself.
    figure = _combined('style_goddess_joint', [goddess_obj], local=True, location=(0, 0, -200))
    figure.data.uv_layers.new(name='Painted diffuse')
    _smart(figure, range(len(figure.data.polygons)), GODDESS_BODY, margin=.013, angle=72)
    _copy_uvs(figure, [goddess_obj])
    feathers = _combined('style_wing_joint', [wing_l], local=True, location=(0, 4, -200))
    feathers.data.uv_layers.new(name='Painted diffuse')
    _smart(feathers, range(len(feathers.data.polygons)), GODDESS_WING, margin=.04, angle=72)
    _copy_uvs(feathers, [wing_l])
    # The right wing is the left wing mirrored, sharing its UVs (sheet region I).
    wing_r = scene.objects['GoddessWingR']
    if 'wf_original_bbox' not in wing_r:
        old_mesh = wing_r.data
        wing_r['wf_original_bbox'] = tuple(min(v.co[i] for v in old_mesh.vertices) for i in range(3)) + tuple(max(v.co[i] for v in old_mesh.vertices) for i in range(3))
        wing_r['wf_had_authored_bbox'] = True
    mirrored = wing_l.data.copy()
    from mathutils import Matrix
    mirrored.transform(Matrix.Scale(-1, 4, (0, 1, 0)))
    mirrored.flip_normals()
    mirrored.name = 'GoddessWingR_style'
    wing_r.data = mirrored
    wing_r['art_stage'] = STAGE

    # Floor: the existing top faces of temple_floor and temple_walk take the
    # painted compass sheet; same triangles, so the same collider.
    floor_uv = lambda co, origin: ((origin[0] + co[0] + FLOOR_SPAN / 2) / FLOOR_SPAN, (origin[1] + co[1] + FLOOR_SPAN / 2) / FLOOR_SPAN)
    floor_faces = {}
    for name in ('temple_floor', 'temple_walk'):
        obj = scene.objects[name]
        top = max(v.co.z for v in obj.data.vertices)
        floor_faces[name] = [p.index for p in obj.data.polygons if p.normal.z > .9 and all(abs(obj.data.vertices[i].co.z - top) < 1e-5 for i in p.vertices)]
    # The 2.4 cm walk strip takes the floor paint on every face, so its edges
    # vanish into the mosaic instead of drawing a cream line across it.
    bind_faces = dict(floor_faces, temple_walk=[p.index for p in scene.objects['temple_walk'].data.polygons])

    # ---- bakes --------------------------------------------------------------
    import time
    started = time.time()
    previous_engine = scene.render.engine
    scene.render.engine = 'CYCLES'
    scene.cycles.device = 'CPU'
    scene.cycles.seed = 0
    scene.cycles.use_denoising = False
    initial_hidden = {'stained_glass', 'reason_blue', 'aether_rings', 'AetherShell1', 'AetherShell2', 'mosaic_dim', 'mosaic_lit',
                      'god_portal', 'final_being', 'final_both', 'final_notbeing', 'final_beingCrown', 'final_bothCrown',
                      'final_notbeingCrown', 'temple_sky', 'Player', 'PlayerArmL', 'PlayerArmR', 'PlayerLegL', 'PlayerLegR'}
    hidden = {}
    for obj in scene.objects:
        vertices = obj.data.vertices if obj.type == 'MESH' else []
        step = max(1, len(vertices) // 24)
        far = bool(len(vertices)) and min((obj.matrix_world @ vertices[i].co).length for i in range(0, len(vertices), step)) > 45
        if (obj.type != 'MESH' or obj.get('wf_Model Type') != 'Mesh' or obj.name in initial_hidden
                # Every living tapestry stays out of the bake: they come and go
                # with the Love history, so none may leave a shadow on the wall.
                or obj.name.startswith('cloth') or obj.name.endswith('_sign') or far):
            hidden[obj.name] = obj.hide_render
            obj.hide_render = True

    # Temple bakes: lights and a night world; the joint proxies receive light,
    # the goddess model takes part as an occluder (shadows on the dais).
    figure.hide_render = feathers.hide_render = True
    for obj in temple_objs:
        hidden.setdefault(obj.name, obj.hide_render)
        obj.hide_render = True
    lights, night, previous_world = _bake_lights(scene.objects)
    # Floor lighting factor (white albedo) on a proxy of the two top faces.
    proxy_verts, proxy_faces, proxy_uv = [], [], []
    for name, faces in floor_faces.items():
        obj = scene.objects[name]
        world = obj.matrix_world
        for index in faces:
            poly = obj.data.polygons[index]
            start = len(proxy_verts)
            for i in poly.vertices:
                p = world @ obj.data.vertices[i].co
                proxy_verts.append((p.x, p.y, p.z + .0005))
                proxy_uv.append(((p.x + FLOOR_SPAN / 2) / FLOOR_SPAN, (p.y + FLOOR_SPAN / 2) / FLOOR_SPAN))
            proxy_faces.append(tuple(range(start, start + len(poly.vertices))))
    mesh = bpy.data.meshes.new('style_floor_proxy'); mesh.from_pydata(proxy_verts, [], proxy_faces); mesh.update()
    layer = mesh.uv_layers.new(name='Painted diffuse')
    for loop in mesh.loops:
        layer.data[loop.index].uv = proxy_uv[loop.vertex_index]
    proxy = bpy.data.objects.new('style_floor_proxy', mesh); scene.collection.objects.link(proxy)
    floor_light = _new_image('style_floor_light')
    white = bpy.data.materials.new('bake_floor_white'); white.use_nodes = True
    bsdf = white.node_tree.nodes['Principled BSDF']
    bsdf.inputs['Base Color'].default_value = (1, 1, 1, 1); bsdf.inputs['Roughness'].default_value = 1
    if 'Specular IOR Level' in bsdf.inputs:
        bsdf.inputs['Specular IOR Level'].default_value = 0
    node = white.node_tree.nodes.new('ShaderNodeTexImage'); node.image = floor_light; white.node_tree.nodes.active = node
    mesh.materials.append(white)
    for name in floor_faces:
        scene.objects[name].hide_render = True
    _bake(proxy, 'DIFFUSE', floor_light, 160, pass_filter={'DIRECT', 'INDIRECT'})
    proxy.hide_render = True
    for name in floor_faces:
        scene.objects[name].hide_render = False
    light = _pixels(floor_light)[:, :, :3]
    # Exposure: the open nave floor (inside the walls, off the compass) reads
    # like the room-lit polish floor (0.45 ambient + 0.7 key at ~52 degrees).
    ys, xs = np.mgrid[0:SHEET, 0:SHEET]
    wx = (xs + .5) / SHEET * FLOOR_SPAN - FLOOR_SPAN / 2
    wy = (1 - (ys + .5) / SHEET) * FLOOR_SPAN - FLOOR_SPAN / 2
    focus = np.hypot(wx - GODDESS_AT[0], wy - (GODDESS_AT[1] - 2.2)) < 1.0
    reference = float(np.median(light[focus].mean(axis=1)))
    exposure = EXPOSURE_TARGET / max(reference, 1e-4)
    # Painted falloff toward the camera end: the dais keeps its light, the
    # foreground compass no longer competes with the goddess.
    reach, rate, floor_min = FLOOR_FALLOFF
    distance = np.hypot(wx - GODDESS_AT[0], wy - GODDESS_AT[1])
    falloff = np.clip(1 - rate * np.maximum(0, distance - reach), floor_min, 1)[:, :, None]
    from PIL import Image
    floor_albedo = np.asarray(Image.open(out / 'style-floor-albedo.png').convert('RGB'), dtype='float32') / 255
    floor_albedo = np.where(floor_albedo <= .04045, floor_albedo / 12.92, np.power((floor_albedo + .055) / 1.055, 2.4))
    smooth = _blur(light)
    _save_tga(to_srgb8(floor_albedo * smooth * exposure * FLOOR_LIFT * falloff), out / 'art_temple_floor.tga')

    # Temple sheet: full combined bake (albedo x light, flames emit), same exposure.
    temple_target = _new_image('style_temple_bake')
    banner_albedo = bpy.data.images.load(str(out / 'style-temple-albedo.png'))
    joint.hide_render = False
    _assign_bake_materials(joint, regions, temple_target, banner_albedo)
    _bake(joint, 'COMBINED', temple_target, 192, pass_filter={'EMIT', 'DIRECT', 'INDIRECT', 'DIFFUSE'}, fill=(.55, .50, .44))
    lit = _pixels(temple_target)[:, :, :3].copy()
    _bake(joint, 'DIFFUSE', temple_target, 4, pass_filter={'COLOR'}, fill=(.30, .27, .23))
    temple = to_srgb8(lit * exposure + _pixels(temple_target)[:, :, :3] * AMBIENT_FLOOR)
    for region, (x0, y0, x1, y1) in SWATCHES.items():
        temple[y0:y1, x0:x1] = [int(SWATCH_COLOURS[region][i:i + 2], 16) for i in (1, 3, 5)]
    _save_tga(temple, out / 'art_temple.tga')
    temple_seconds = time.time() - started

    # Goddess sheet: the same lights, in place, so the statue-like figure
    # carries the warm key, torch fill and its own fold occlusion. The bake
    # proxies keep object space (paint masks) but stand at the actors' poses.
    joint.hide_render = True
    for obj in temple_objs:
        obj.hide_render = False
    for obj in (goddess_obj, wing_l, wing_r):
        hidden.setdefault(obj.name, obj.hide_render)
        obj.hide_render = True
    figure.matrix_world = goddess_obj.matrix_world.copy()
    feathers.matrix_world = wing_l.matrix_world.copy()
    figure.hide_render = feathers.hide_render = False
    goddess_target = _new_image('style_goddess_bake')
    layers = {}
    for joint_obj, regs, label in ((figure, regions_of['Goddess'][0], 'body'), (feathers, regions_of['GoddessWingL'][0], 'wing')):
        _assign_bake_materials(joint_obj, regs, goddess_target)
        _bake(joint_obj, 'COMBINED', goddess_target, 160, pass_filter={'EMIT', 'DIRECT', 'INDIRECT', 'DIFFUSE'}, fill=(1.6, 1.4, 1.1))
        lit = _pixels(goddess_target)[:, :, :3].copy()
        _bake(joint_obj, 'DIFFUSE', goddess_target, 4, pass_filter={'COLOR'}, fill=(.7, .62, .45))
        layers[label] = lit * exposure * GODDESS_LIFT + _pixels(goddess_target)[:, :, :3] * AMBIENT_FLOOR
    sheet = np.zeros((SHEET, SHEET, 3), 'float32')
    for label, (x0, y0, x1, y1) in (('body', GODDESS_BODY), ('wing', GODDESS_WING)):
        sheet[y0:y1, x0:x1] = layers[label][y0:y1, x0:x1]
    _save_tga(to_srgb8(sheet), out / 'art_goddess.tga')
    bake_seconds = time.time() - started
    goddess_seconds = bake_seconds - temple_seconds

    # ---- restore the scene and bind the exported materials --------------------
    for obj in lights:
        data = obj.data; bpy.data.objects.remove(obj, do_unlink=True); bpy.data.lights.remove(data)
    scene.world = previous_world
    bpy.data.worlds.remove(night)
    for obj in (proxy, joint, figure, feathers):
        data = obj.data; bpy.data.objects.remove(obj, do_unlink=True); bpy.data.meshes.remove(data)
    for name, state in hidden.items():
        if name in scene.objects:
            scene.objects[name].hide_render = state
    for mat in list(bpy.data.materials):
        if mat.name.startswith('bake_'):
            bpy.data.materials.remove(mat)
    for image in (goddess_target, floor_light, temple_target, banner_albedo):
        bpy.data.images.remove(image)
    scene.render.engine = previous_engine

    def bind(obj, material):
        obj.data.materials.clear(); obj.data.materials.append(material)
        for poly in obj.data.polygons:
            poly.material_index = 0
    mat_sky = setup_material(out, 'art_sky.tga'); mat_sky['wf_prelit'] = True
    mat_temple = setup_material(out, 'art_temple.tga'); mat_temple['wf_prelit'] = True
    mat_floor = setup_material(out, 'art_temple_floor.tga'); mat_floor['wf_prelit'] = True
    mat_goddess = setup_material(out, 'art_goddess.tga'); mat_goddess['wf_prelit'] = True
    bind(sky, mat_sky)
    for obj in temple_objs:
        bind(obj, mat_temple)
    mat_banner = bpy.data.materials.get('art_tapestries.tga') or setup_material(out, 'art_tapestries.tga')
    mat_banner['wf_prelit'] = True
    for obj in banner_actors:
        bind(obj, mat_banner)
    for obj in (goddess_obj, wing_l, wing_r):
        bind(obj, mat_goddess)
    for name, faces in bind_faces.items():
        obj = scene.objects[name]
        obj.data.materials.append(mat_floor)
        slot = len(obj.data.materials) - 1
        uv = obj.data.uv_layers.active.data
        for index in faces:
            poly = obj.data.polygons[index]
            poly.material_index = slot
            for loop in poly.loop_indices:
                p = obj.matrix_world @ obj.data.vertices[obj.data.loops[loop].vertex_index].co
                uv[loop].uv = ((p.x + FLOOR_SPAN / 2) / FLOOR_SPAN, (p.y + FLOOR_SPAN / 2) / FLOOR_SPAN)
        obj['art_stage_overlay'] = STAGE
    for obj in [sky, *temple_objs, goddess_obj, wing_l, wing_r]:
        if 'style_regions' in obj:
            del obj['style_regions']

    sheets = dict(
        art_sky=dict(size=[256, 128], prelit=True, meshes=['temple_sky'], regions={'sky': [0, 0, 256, 128]}, continuous=['sky']),
        art_temple=dict(size=[SHEET, SHEET], prelit=True, meshes=[o.name for o in temple_objs],
                        regions={'smart': list(TEMPLE_SMART), 'shrine': list(SHRINE_SMART),
                                 **{'swatch_' + k: list(v) for k, v in SWATCHES.items()}},
                        continuous=[]),
        art_tapestries=dict(size=list(TAPESTRY_SIZE), prelit=True, meshes=[o.name for o in banner_actors],
                            regions={f'banner_{k}': [64 * k, 0, 64 * (k + 1), TAPESTRY_SIZE[1]] for k in range(8)},
                            continuous=[f'banner_{k}' for k in range(8)]),
        art_temple_floor=dict(size=[SHEET, SHEET], prelit=True, meshes=list(floor_faces), regions={'floor': [0, 0, SHEET, SHEET]}, continuous=['floor']),
        art_goddess=dict(size=[SHEET, SHEET], prelit=True, meshes=['Goddess', 'GoddessWingL', 'GoddessWingR'],
                         regions={'body': list(GODDESS_BODY), 'wings (L/R shared, mirrored)': list(GODDESS_WING)}))
    (out / 'style-proof-sheets.json').write_text(json.dumps(dict(gutter=GUTTER, sheets=sheets), indent=2) + '\n')
    return dict(stage=STAGE, base='polish', added=added, replaced=replaced, removed=removed,
                sheets=sheets, exposure=exposure, floorReferenceLight=reference,
                bakeSeconds=dict(goddess=round(goddess_seconds, 1), total=round(bake_seconds, 1)),
                skyVisibility=dict(mailbox=SKY_VISIBILITY, forth=SKY_FORTH.strip()),
                detailScale=DETAIL_SCALE, detailTable=DETAIL,
                collision='Replaced goddess/wings and the eight banner actors keep their polish bboxes via replace(); two new niche piers '
                          'are platform with 0.9 m boxes clear of the routes; braziers keep the torches\' 0.5 m boxes (moved); the stair is a '
                          'statplat mesh collider inside the phase 1 dais box (0.15 m rises under the 0.4 m step-up); shell, sky, shrine wall/crown and nave pier shells have '
                          'boxes out of reach; nave pillar cores keep their 0.52 m base; floor triangles unchanged (UV/material only)',
                lighting='All slice materials prelit: sky painted; floor, shell, dressing and goddess carry Cycles-baked light (crown key, torch pools, night ambient, occlusion); room lights and fog unchanged',
                originality='Procedural original Blender geometry, PIL-painted motifs and Cycles bakes; no external imagery')
