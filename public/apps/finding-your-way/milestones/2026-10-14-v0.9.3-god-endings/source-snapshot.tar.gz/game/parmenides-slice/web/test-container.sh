#!/usr/bin/env bash
set -euo pipefail
export PATH="/home/will/finding-your-way/game/parmenides-slice/build/web-sdk/node/24.19.0_64bit/bin:$PATH"
export PLAYWRIGHT_BROWSERS_PATH=/home/will/finding-your-way/game/parmenides-slice/build/web-browsers
bundle="$1"
evidence=${FYW_EVIDENCE:-/home/will/finding-your-way/docs/diagnostics/browser-player-2026-10-10/stack-remediated}
mkdir -p "$evidence"
cat /etc/os-release > "$evidence/container-os.txt"
python3 -m http.server 4390 --bind 127.0.0.1 --directory /home/will/finding-your-way/game/parmenides-slice/build/web-v0.8/bundles > /tmp/fyw-web-server.log 2>&1 &
server_pid=$!
trap 'kill "$server_pid" 2>/dev/null || true' EXIT
node game/parmenides-slice/web/verify-browser.mjs "http://127.0.0.1:4390/$bundle/frame.html" "$evidence/chromium"
node node_modules/@playwright/test/cli.js install firefox
xvfb-run -a -s '-screen 0 1920x1080x24' env FYW_BROWSER=firefox node game/parmenides-slice/web/verify-browser.mjs "http://127.0.0.1:4390/$bundle/frame.html" "$evidence/firefox"
