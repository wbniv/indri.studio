# Build-time Atkinson fonts

Unmodified Atkinson Hyperlegible Next Regular and SemiBold from pinned Google Fonts project commit [7925f50](https://github.com/googlefonts/atkinson-hyperlegible-next/tree/7925f50f649b3813257faf2f4c0b381011f434f1/fonts/ttf). Redistributed under the [SIL Open Font License](Atkinson-OFL.txt).

The container uses these fonts to bake the shared chapter glyph atlas. The game uses that atlas and exported metrics; it does not rasterize the TTF files at runtime.

| File | SHA-256 |
| --- | --- |
| AtkinsonHyperlegibleNext-Regular.ttf | `88ed5c31a71584c7772963b02d04bef1eb7e3d2e9c8b9cb204339b1f82cf432c` |
| AtkinsonHyperlegibleNext-SemiBold.ttf | `8e2fff779f35ac25239656bb0f3b2bd35959a2009e3dd21a12141c3b9030362b` |
