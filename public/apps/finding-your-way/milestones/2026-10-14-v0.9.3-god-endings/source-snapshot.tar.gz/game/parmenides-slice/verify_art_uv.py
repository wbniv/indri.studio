"""Prove normalized art-UV convention conversion against the editable Blender file.

When the build carries ``style-proof-sheets.json`` (``--art-stage style-proof``),
also prove the sheet layout: every face of a sheet lies inside a declared region
inset by the gutter, and distinct UV islands inside a baked region keep at least
the gutter (4 px) between them, measured on the sheet's own pixel grid.
"""
import argparse
import collections
import json
from pathlib import Path
import struct
import sys
import bpy

parser=argparse.ArgumentParser();parser.add_argument('--build-dir',type=Path,required=True)
parser.add_argument('--report',type=Path,required=True)
args=parser.parse_args(sys.argv[sys.argv.index('--')+1:]);out=args.build_dir.resolve()
bpy.ops.wm.open_mainfile(filepath=str(out/'parmenides_slice.blend'))
rows=[]
for obj in bpy.context.scene.objects:
    if obj.type!='MESH' or not any(m and m.name.startswith('art_') for m in obj.data.materials):continue
    mesh=obj.data;expected=set()
    for loop in mesh.loops:
        p=mesh.vertices[loop.vertex_index].co;uv=mesh.uv_layers.active.data[loop.index].uv
        # Blender loop assignment stores float32. VRTX then truncates both UV
        # and position toward zero, after rounded keys canonicalize seam order.
        native_v=struct.unpack('<f',struct.pack('<f',1-uv.y))[0]
        expected.add((int(uv.x*65536),int(native_v*65536),*(int(c*65536) for c in p)))
    data=(out/obj['wf_Mesh Name']).read_bytes();start=data.index(b'VRTX')+8
    size=struct.unpack_from('<I',data,start-4)[0]
    actual=set()
    for i in range(start,start+size,24):
        u,v,_,x,y,z=struct.unpack_from('<iiIiii',data,i);actual.add((u,v,x,y,z))
    def unmatched(source,target):
        by_position=collections.defaultdict(list)
        for u,v,*p in target:by_position[tuple(p)].append((u,v))
        return [row for row in source if not any(abs(row[0]-u)<=1 and abs(row[1]-v)<=1
                 for u,v in by_position[tuple(row[2:])])]
    missing=unmatched(expected,actual);unexpected=unmatched(actual,expected)
    # Canonical seam merging can collapse float noise within one fixed32 unit;
    # every source loop and every native vertex must still match its UV/position.
    rows.append(dict(name=obj.name,source_uv_count=len(expected),native_uv_count=len(actual),passed=not missing and not unexpected,
                     missing=sorted(missing)[:3],unexpected=sorted(unexpected)[:3]))


def gutter_audit(manifest):
    """Region containment and island spacing for the style-proof sheets."""
    import numpy as np
    from PIL import Image, ImageDraw, ImageFilter
    gutter=manifest['gutter'];results=[]
    for sheet,spec in manifest['sheets'].items():
        w,h=spec['size'];regions=spec['regions']
        texture=sheet+'.tga'
        rects=list(regions.items())
        overlap=[(a,b) for i,(a,ra) in enumerate(rects) for b,rb in rects[i+1:]
                 if ra[0]<rb[2] and rb[0]<ra[2] and ra[1]<rb[3] and rb[1]<ra[3]]
        results.append(dict(sheet=sheet,check='declared regions are disjoint',passed=not overlap,detail=overlap))
        seen_uv_sets=[];per_region=collections.defaultdict(list)
        for name in spec['meshes']:
            obj=bpy.data.objects[name];mesh=obj.data;uv=mesh.uv_layers.active.data
            slot={i for i,m in enumerate(mesh.materials) if m and m.name==texture}
            faces=[p for p in mesh.polygons if p.material_index in slot]
            pixel=lambda loop:(uv[loop].uv.x*w,(1-uv[loop].uv.y)*h)
            outside=[];assigned=collections.defaultdict(list)
            for poly in faces:
                pts=[pixel(l) for l in poly.loop_indices]
                x0,y0=min(p[0] for p in pts),min(p[1] for p in pts);x1,y1=max(p[0] for p in pts),max(p[1] for p in pts)
                home=[k for k,(rx0,ry0,rx1,ry1) in regions.items()
                      if x0>=rx0+gutter-1e-3 and y0>=ry0+gutter-1e-3 and x1<=rx1-gutter+1e-3 and y1<=ry1-gutter+1e-3]
                if not home:outside.append(poly.index)
                else:assigned[home[0]].append(poly)
            results.append(dict(sheet=sheet,mesh=name,check=f'every face inside a declared region inset by {gutter} px',
                                passed=not outside,faces=len(faces),outside=outside[:5]))
            signature=sorted((round(uv[l].uv.x,5),round(uv[l].uv.y,5)) for p in faces for l in p.loop_indices)
            if signature in seen_uv_sets:
                results.append(dict(sheet=sheet,mesh=name,check='shares an already audited UV layout (mirrored pair)',passed=True))
                continue
            seen_uv_sets.append(signature)
            # Islands: faces joined by shared (vertex, UV) corners, collected
            # per region across every mesh of the sheet.
            for region,polys in assigned.items():
                parent={p.index:p.index for p in polys}
                def find(i):
                    while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
                    return i
                corner=collections.defaultdict(list)
                for p in polys:
                    for l in p.loop_indices:
                        corner[(mesh.loops[l].vertex_index,round(uv[l].uv.x,6),round(uv[l].uv.y,6))].append(p.index)
                for members in corner.values():
                    for other in members[1:]:parent[find(other)]=find(members[0])
                groups=collections.defaultdict(list)
                for p in polys:groups[find(p.index)].append([pixel(l) for l in p.loop_indices])
                for members in groups.values():per_region[region].append((name,members))
        for region,islands in per_region.items():
            # Swatches are flat paint shared by many small faces; continuous
            # regions map world position 1:1 (sky, floor, banner fronts), so
            # neighbouring faces are neighbours on the sheet by design.
            if region.startswith('swatch_') or region in spec.get('continuous',()):
                results.append(dict(sheet=sheet,region=region,passed=True,meshes=sorted({m for m,_ in islands}),
                                    check='flat swatch' if region.startswith('swatch_') else 'continuous painted region (no island spacing)'))
                continue
            label=Image.new('I',(w,h),0);draw=ImageDraw.Draw(label);masks={}
            for n,(_,members) in enumerate(islands,start=1):
                mask=Image.new('L',(w,h),0);md=ImageDraw.Draw(mask)
                for pts in members:
                    md.polygon(pts,fill=255,outline=255);draw.polygon(pts,fill=n,outline=n)
                masks[n]=mask
            labels=np.asarray(label);close=[]
            for n,mask in masks.items():
                grown=np.asarray(mask.filter(ImageFilter.MaxFilter(2*gutter+1)))>0
                others=set(int(v) for v in np.unique(labels[grown]))-{0,n}
                if others:close.append((islands[n-1][0],n,sorted(others)[:3]))
            results.append(dict(sheet=sheet,region=region,check=f'distinct islands at least {gutter} px apart (all meshes in the region)',
                                passed=not close,meshes=sorted({m for m,_ in islands}),islands=len(islands),violations=len(close),examples=close[:5]))
    return results


receipt=out/'build-receipt.json'
if not receipt.exists():receipt=out/'level-receipt.json'  # --native-only builds
report=dict(build=json.loads(receipt.read_text()),models=rows,
            method='Every source/native UV at its exact quantized position; Blender U/(1-V), float32 assignment and truncation, one fixed32 UV-unit tolerance for canonical seam merging',
            passed=bool(rows) and all(r['passed'] for r in rows))
sheets=out/'style-proof-sheets.json'
if sheets.exists():
    gutters=gutter_audit(json.loads(sheets.read_text()))
    report['gutters']=dict(method='Each sheet face rasterised on the sheet pixel grid: containment in its declared region inset by the gutter; '
                                  'islands (faces joined by shared vertex+UV corners) dilated by the gutter must not reach another island',
                           results=gutters,passed=all(r['passed'] for r in gutters))
    report['passed']=report['passed'] and report['gutters']['passed']
args.report.parent.mkdir(parents=True,exist_ok=True);args.report.write_text(json.dumps(report,indent=2)+'\n')
print('Art UV conversion:',len(rows),'meshes; passed:',all(r['passed'] for r in rows))
if 'gutters' in report:
    bad=[r for r in report['gutters']['results'] if not r['passed']]
    print('Style-proof sheet gutters:',len(report['gutters']['results']),'checks;',len(bad),'failed')
    for r in bad[:8]:print('  FAIL',json.dumps({k:v for k,v in r.items() if k!='passed'}))
if not report['passed']:raise SystemExit('Art UV conversion failed')
