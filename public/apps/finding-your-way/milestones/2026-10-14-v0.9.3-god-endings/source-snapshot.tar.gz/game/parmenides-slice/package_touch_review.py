"""Package an isolated Android touch runtime with the immutable selected level."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parent
PROJECT=ROOT.parents[1]
SDK=Path('/home/will/android-sdk-local')
TOOLS=SDK/'build-tools/34.0.0'
SOURCE=PROJECT/'game/milestones/2026-10-06-v0.6-proof-a-review/parmenides-v0.6-proof.1-e3d12ae1542536ca.apk'
EXPECTED='e3d12ae1542536ca497d9f0169695ba59724c61d85a5a056ff74a32b86bc4c8e'
digest=lambda data:hashlib.sha256(data).hexdigest()

def run(*args):subprocess.run([str(a) for a in args],check=True)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--runtime',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--source-receipt',type=Path,required=True)
    parser.add_argument('--abi',choices=['arm64-v8a','armeabi-v7a'],action='append')
    parser.add_argument('--version',default='0.6-proof.1-touch.1')
    parser.add_argument('--source-build',type=Path,help='Validated build receipt and manifest; default is archived iteration A')
    args=parser.parse_args();out=args.out.resolve();out.mkdir(parents=True,exist_ok=True)
    source=SOURCE;expected_source=EXPECTED;source_version='0.6-proof.1';version_code=60;source_stage='proof'
    manifest_path=ROOT/'build/v0.6-proof/apk/AndroidManifest.xml'
    if args.source_build:
        original_receipt=json.loads((args.source_build/'build-receipt.json').read_text())
        source=Path(original_receipt['apk']);expected_source=original_receipt['sha256']
        source_version=original_receipt['version'];version_code=original_receipt['versionCode'];source_stage=original_receipt['artStage']
        manifest_path=args.source_build/'apk/AndroidManifest.xml'
    assert digest(source.read_bytes())==expected_source,'Immutable source APK changed'
    with zipfile.ZipFile(source) as original:
        original_assets={name:original.read(name) for name in original.namelist() if name.startswith('assets/') and not name.endswith('/')}
        for name in original.namelist():
            if (name.startswith('assets/') or name.startswith('res/')) and not name.endswith('/'):
                target=out/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(original.read(name))
    manifest=manifest_path.read_text()
    assert f'android:versionName="{source_version}"' in manifest
    assert f'android:versionCode="{version_code}"' in manifest
    prefix=source_version+'-touch.'
    assert args.version.startswith(prefix) and args.version.removeprefix(prefix).isdigit()
    manifest=manifest.replace(f'android:versionName="{source_version}"',f'android:versionName="{args.version}"')
    (out/'AndroidManifest.xml').write_text(manifest)
    run(TOOLS/'aapt','package','-f','-M',out/'AndroidManifest.xml','-S',out/'res',
        '-I',SDK/'platforms/android-34/android.jar','-A',out/'assets','-F',out/'unsigned.apk')
    with zipfile.ZipFile(args.runtime) as runtime:
        native={name:runtime.read(name) for name in runtime.namelist() if name.startswith('lib/') and name.endswith('.so')}
    expected={f'lib/{abi}/libwf_game.so' for abi in (args.abi or ['arm64-v8a','armeabi-v7a'])}
    assert set(native)==expected
    with zipfile.ZipFile(out/'unsigned.apk','a') as bundle:
        for name,data in native.items():bundle.writestr(name,data,compress_type=zipfile.ZIP_STORED)
    run(TOOLS/'zipalign','-f','4',out/'unsigned.apk',out/'aligned.apk')
    run(TOOLS/'apksigner','sign','--ks',ROOT/'build/v0.6-proof/development-signing.p12',
        '--ks-pass','pass:android','--out',out/'signed.apk',out/'aligned.apk')
    run(TOOLS/'apksigner','verify','--verbose',out/'signed.apk')
    data=(out/'signed.apk').read_bytes();sha=digest(data)
    apk=out/('parmenides-touch-review-'+sha[:16]+'.apk');apk.write_bytes(data)
    with zipfile.ZipFile(apk) as final:
        for name,data in original_assets.items():assert final.read(name)==data, name+' changed'
        for name,data in native.items():assert final.read(name)==data
    receipt={'apk':str(apk),'sha256':sha,'version':args.version,'versionCode':version_code,
             'scope':f'Phone prompt and local touch controls; immutable {source_stage} assets and level',
             'artStage':source_stage,
             'source_apk_sha256':expected_source,'assets_unchanged':True,
             'cd_sha256':digest(original_assets['assets/cd.iff']),
             'nativeLibraries':{name:digest(data) for name,data in native.items()},
             'runtime_bundle_sha256':digest(args.runtime.read_bytes()),
             'abis':args.abi or ['arm64-v8a','armeabi-v7a'],
             'engine_source_receipt':json.loads(args.source_receipt.read_text()),
             'phone_hands_on_acceptance':'pending'}
    (out/'build-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
