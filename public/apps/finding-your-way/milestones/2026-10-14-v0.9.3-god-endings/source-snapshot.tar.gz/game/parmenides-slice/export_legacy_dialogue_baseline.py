#!/usr/bin/env python3
"""Export an archived pre-font chapter for same-engine device comparisons.

Run in the chapter authoring container, with the Blender addon and schemas
mounted at the paths expected by the archived source. Package the resulting
level with the current build.py and the candidate's frozen native libraries.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

p = argparse.ArgumentParser()
p.add_argument('--archive', type=Path, required=True)
p.add_argument('--source-commit', required=True)
p.add_argument('--engine', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
source = a.archive / 'game/parmenides-slice'
sys.path.insert(0, str(source))
spec = importlib.util.spec_from_file_location('legacy_dialogue_build', source/'build.py')
legacy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(legacy)
legacy.WF = a.engine
legacy.OUT = a.output
legacy.ART_STAGE = 'polish'
legacy.content()
legacy.native_build()
receipt = dict(sourceCommit=a.source_commit, sourceFilesSha256={
    str(file.relative_to(a.archive)): hashlib.sha256(file.read_bytes()).hexdigest()
    for file in sorted(source.glob('*.py'))})
(a.output/'legacy-export-provenance.json').write_text(json.dumps(receipt, indent=2)+'\n')
