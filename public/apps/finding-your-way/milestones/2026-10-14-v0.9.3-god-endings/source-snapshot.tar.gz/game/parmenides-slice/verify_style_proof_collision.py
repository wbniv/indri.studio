"""Style-proof collision audit (plan 2026-10-11, step 5).

Run: blender --background --python-exit-code 1 --python verify_style_proof_collision.py --
     --build-dir STYLE_PROOF_BUILD --baseline-dir POLISH_BUILD --report OUT.json

Checks, all on exported artefacts:
1. every object carrying ``wf_original_bbox`` in the editable blend exports
   exactly that box (BOX3 in the LEV): difference zero;
2. every actor present in both builds exports a box equal to, or inside, the
   polish box (zero or inward);
3. the Temple floor and walk keep identical native triangles (their Jolt
   mesh colliders), so painting them changed UVs and materials only;
4. new style-proof actors are listed with their explicit boxes.
"""
import argparse
import json
from pathlib import Path
import re
import struct
import sys

import bpy

parser = argparse.ArgumentParser()
parser.add_argument('--build-dir', type=Path, required=True)
parser.add_argument('--baseline-dir', type=Path, required=True)
parser.add_argument('--report', type=Path, required=True)
parser.add_argument('--allow', default='', help='comma-separated actors whose box or position may change (recorded, not failed)')
args = parser.parse_args(sys.argv[sys.argv.index('--') + 1:])
out, base = args.build_dir.resolve(), args.baseline_dir.resolve()
FIX = 1 / 65536


def boxes(lev):
    rows = {}
    for section in re.split(r"\n\t\{\s*'OBJ'", lev.read_text())[1:]:
        name = re.search(r"\{ 'NAME' \"([^\"]+)\"", section).group(1)
        box = re.search(r"\"Global Bounding Box\" \} \{ 'DATA' ((?:[-0-9.]+\(1\.15\.16\)\s*){6})", section)
        kind = re.search(r"\"Class Name\" \} \{ 'DATA' \"([^\"]+)\"", section)
        pos = re.search(r"\"Position\" \} \{ 'DATA' ((?:[-0-9.]+\(1\.15\.16\)\s*){3})", section)
        if box:
            rows[name] = dict(box=[float(v) for v in re.findall(r'([-0-9.]+)\(1\.15\.16\)', box.group(1))],
                              kind=kind.group(1) if kind else None,
                              position=[float(v) for v in re.findall(r'([-0-9.]+)\(1\.15\.16\)', pos.group(1))] if pos else None)
    return rows


def triangles(mesh):
    data = mesh.read_bytes()
    def chunk(tag):
        start = data.index(tag) + 4
        size = struct.unpack_from('<I', data, start)[0]
        return data[start + 4:start + 4 + size]
    vrtx, face = chunk(b'VRTX'), chunk(b'FACE')
    points = [struct.unpack_from('<iii', vrtx, i + 12) for i in range(0, len(vrtx), 24)]
    tris = []
    for i in range(0, len(face), 8):
        a, b, c, _ = struct.unpack_from('<hhhh', face, i)
        tri = [points[a], points[b], points[c]]
        k = tri.index(min(tri))  # canonical rotation keeps winding
        tris.append(tuple(tri[k:] + tri[:k]))
    return sorted(tris)


style, polish = boxes(out / 'parmenides_slice.lev'), boxes(base / 'parmenides_slice.lev')
room_layout = json.loads((out / 'room-layout.json').read_text()) if (out / 'room-layout.json').exists() else {}
split_rooms = {name: bounds for name, bounds, *_ in room_layout.get('rooms', [])} if room_layout.get('layout') == 'scene9' else {}
bpy.ops.wm.open_mainfile(filepath=str(out / 'parmenides_slice.blend'))
results = []
for obj in bpy.context.scene.objects:
    if 'wf_original_bbox' not in obj or obj.name not in style:
        continue
    authored = list(obj['wf_original_bbox'])
    exported = style[obj.name]['box']
    if obj.name in split_rooms:
        authored = split_rooms[obj.name]
    worst = max(abs(a - b) for a, b in zip(authored, exported))
    results.append(dict(check='authored wf_original_bbox exported unchanged', name=obj.name,
                        stage=obj.get('art_stage'), authored=authored, exported=exported,
                        maxDifference=worst, passed=worst <= 2 * FIX))
allowed = {n for n in args.allow.split(',') if n}
for name in sorted(set(style) & set(polish)):
    s, p = style[name]['box'], polish[name]['box']
    inward = all(s[i] >= p[i] - 2 * FIX for i in range(3)) and all(s[i] <= p[i] + 2 * FIX for i in range(3, 6))
    same = max(abs(a - b) for a, b in zip(s, p)) <= 2 * FIX
    moved = (style[name]['position'] and polish[name]['position'] and
             max(abs(a - b) for a, b in zip(style[name]['position'], polish[name]['position'])) > 2 * FIX)
    results.append(dict(check='box equal to or inside the baseline box, actor not moved', name=name, kind=style[name]['kind'],
                        baselineKind=polish[name]['kind'],
                        polish=p, style=s, unchanged=same, moved=bool(moved),
                        positions=[polish[name]['position'], style[name]['position']] if moved else None,
                        allowedChange=name in allowed, passed=(inward and not moved) or name in allowed))
for name in ('temple_floor', 'temple_walk'):
    a, b = triangles(out / (name + '.iff')), triangles(base / (name + '.iff'))
    results.append(dict(check='native collider triangles identical to polish', name=name,
                        triangles=len(a), passed=a == b))
added = sorted(set(style) - set(polish))
results.append(dict(check='new style-proof actors use explicit boxes; only the walkable dais uses a mesh collider',
                    actors={n: style[n] for n in added},
                    passed=all(style[n]['kind'] == ('statplat' if n == 'temple_dais' else 'platform') for n in added)))
removed = sorted(set(polish) - set(style))
report = dict(build=str(out), baseline=str(base), removed=removed, added=added, results=results,
              replacedChecked=sum(r['check'].startswith('authored') for r in results),
              sharedChecked=sum(r['check'].startswith('box equal') for r in results),
              sharedChanged=[r['name'] for r in results if r['check'].startswith('box equal') and not r['unchanged']],
              sharedMoved=[r['name'] for r in results if r['check'].startswith('box equal') and r['moved']],
              sharedKindChanged=[r['name'] for r in results if r['check'].startswith('box equal') and r['kind'] != r['baselineKind']],
              allowed=sorted(allowed),
              passed=all(r['passed'] for r in results))
args.report.parent.mkdir(parents=True, exist_ok=True)
args.report.write_text(json.dumps(report, indent=2) + '\n')
print('COLLISION:', report['replacedChecked'], 'authored boxes;', report['sharedChecked'], 'shared actors;',
      'changed boxes:', report['sharedChanged'], '; moved actors:', report['sharedMoved'], '; allowed:', report['allowed'],
      '; collider kind changed:', report['sharedKindChanged'], '; added:', added, '; removed:', removed, '; passed:', report['passed'])
for r in results:
    if not r['passed']:
        print('  FAIL', json.dumps({k: v for k, v in r.items() if k != 'passed'})[:300])
if not report['passed']:
    raise SystemExit('Style-proof collision audit failed')
