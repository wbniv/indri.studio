"""Verify F's current-build regression, presentation, media and TV evidence."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--build-dir', type=Path, required=True)
    parser.add_argument('--evidence', type=Path, required=True)
    args = parser.parse_args()
    out, evidence = args.build_dir.resolve(), args.evidence.resolve()
    read = lambda path: json.loads(path.read_text())
    build = read(out / 'build-receipt.json')
    sha = build['sha256']
    assert (build['artStage'], build['version'], build['versionCode']) == ('polish', '0.7-polish.2', 71)
    assert digest(Path(build['apk'])) == sha
    with zipfile.ZipFile(build['apk']) as apk:
        assert hashlib.sha256(apk.read('assets/cd.iff')).hexdigest() == build['levelSha256']
        for name, expected in build['nativeLibraries'].items():
            assert hashlib.sha256(apk.read(name)).hexdigest() == expected, name
    assert read(out / 'art-manifest.json') == build['art']
    for name, expected in build['art']['sources'].items():
        assert digest(ROOT / name) == expected, name
    engine = build['engineProvenance']
    desktop = engine['desktopExecutableSha256']
    assert digest(Path(engine['desktopRebuild']['executable'])) == desktop

    def matching(path):
        report = read(path)
        identity = report['build']
        assert identity['sha256'] == sha, path
        assert identity['levelSha256'] == build['levelSha256'], path
        assert identity['nativeLibraries'] == build['nativeLibraries'], path
        return report

    def captures(folder, rows):
        assert rows, folder
        for row in rows:
            assert digest(folder / row['file']) == row['sha256'], row['file']

    counts = {}
    for name in ('asset-audit.json', 'text-audit.json', 'asset-dispositions.json'):
        report = matching(evidence / name)
        rows = report.get('results', report.get('checks'))
        assert rows and all(row['passed'] for row in rows), name
        counts[name] = len(rows)
    disposition = matching(evidence / 'asset-dispositions.json')
    actor_names = set(read(out / 'actors.json')['ids'])
    assert {row['actor'] for row in disposition['inventory']} == actor_names
    assert len(actor_names) == 441
    mesh = matching(evidence / 'mesh-audit.json')
    uv = matching(evidence / 'art-uv-audit.json')
    assert mesh['passed'] and mesh['native_winding_matches']
    assert not mesh['inward_components'] and not mesh['inconsistent_edges'] and not mesh['mirrored_objects']
    assert uv['passed'] and all(row['passed'] for row in uv['models'])
    counts.update(mesh_objects=len(mesh['objects']), painted_models=len(uv['models']))

    cards, checks = set(), 0
    for name in ('art', 'full-regression', 'supplemental-text', 'transition-safety', 'dialogue-camera-regression', 'truth-counsel-safety'):
        folder = evidence / name
        state = read(folder / 'run-state.json')
        assert state['status'] == 'completed' and state['apk_sha256'] == sha
        assert state['desktop_sha256'] == desktop
        results = read(folder / 'results.json')
        assert results and len(results) == state['checks'] and all(row['passed'] for row in results)
        identity = read(folder / 'build-receipt.json')
        assert identity['sha256'] == sha and identity['levelSha256'] == build['levelSha256']
        for row in read(folder / 'transcripts.json'):
            cards.update(row['cards'])
        checks += len(results)
    content = read(out / 'content.json')
    assert cards == {row['id'] for row in content['cards']} and len(cards) == 208
    routes = read(evidence / 'full-regression/results.json')
    edges = sum('terminal completion matches chosen route' in row['check'] for row in routes)
    assert edges == 66
    camera = matching(evidence / 'dialogue-camera-regression/camera-regression.json')
    assert camera['passed'] and len(camera['results']) == 94
    assert all(row['error'] < .02 for row in camera['results'])

    art = matching(evidence / 'art/endings-art-audit.json')
    assert art['passed'] and len(art['framing']) == 16
    for pose in art['framing']:
        assert len(pose['features']) == 12
        for feature in pose['features']:
            assert feature['minimum_depth'] > 1 and min(feature['margins']) > .025
    polish = matching(evidence / 'art/polish-art-audit.json')
    assert polish['passed'] and len(polish['both_projection']) == 6
    assert polish['background_mask'] == build['art']['disposition']['presentationMasked']
    assert polish['background_mask']
    assert len(polish['outside_Being_visibility_checks']) == 32
    for state in polish['outside_Being_visibility_checks']:
        assert state['derived_world'] == (0 if state['reading'] else state['original_world'])
        assert state['derived_signs'] == (0 if state['reading'] else state['original_signs'])
    for pose in polish['both_projection']:
        assert pose['minimum_depth'] > .1 and min(pose['margins']) > .025
    art_captures = matching(evidence / 'art/capture-manifest.json')
    assert digest(evidence / 'art/art-proof.mp4') == art_captures['movie_sha256']
    captures(evidence / 'art', art_captures['shots'])
    manual = read(evidence / 'art/visual-review.json')
    assert manual['passed'] and manual['apk_sha256'] == sha
    captures(evidence / 'art', manual['captures'])

    panels = matching(evidence / 'panel-render-audit.json')
    assert panels['passed'] and len(panels['results']) == 420 and all(row['passed'] for row in panels['results'])
    assert digest(evidence / 'rendered-panels/panel-render.mp4') == panels['video_sha256']
    captures(evidence / 'rendered-panels', panels['results'])
    transition = matching(evidence / 'panel-transition-audit.json')
    assert transition['passed'] and transition['cases'] == transition['sampled_cases'] == 420
    assert transition['video_sha256'] == panels['video_sha256']
    for row in panels['results']:
        assert row['transition_start'] <= row['presentation_start'] <= row['wall_time']
        assert row['presented_clock'] > row['opening_clock']
        assert row['initial_video_time'] <= row['video_time'] < row['endpoint_window_end']
    panel_state = read(evidence / 'panel-run/run-state.json')
    panel_results = read(evidence / 'panel-run/results.json')
    assert panel_state['status'] in ('completed', 're-audited')
    assert panel_state['checks'] == len(panel_results) and all(row['passed'] for row in panel_results)
    if panel_state['status'] == 're-audited':
        reaudit = matching(evidence / 'panel-re-audit.json')
        original = evidence / 'attempts/panel-endpoint-fixed-delay/panel-run/results.json'
        assert reaudit['passed'] and digest(original) == reaudit['original_results_sha256']
        assert reaudit['requests_sha256'] == digest(evidence / 'panel-render-requests.json')
        assert reaudit['video_sha256'] == panels['video_sha256']
        assert reaudit['auditor_sha256'] == digest(ROOT / 'verify_panel_render.py')
        count = reaudit['native_fixture_checks']
        assert count == 2104 and panel_results[:count] == read(original)[:count]
        if 'replacement' in reaudit:
            key = lambda row: (row['card'], row['camera'], row['patient'])
            target = tuple(reaudit['replacement'])
            assert target == (208, 1, True)
            base_path = evidence / reaudit['base_audit']
            fresh_path = evidence / reaudit['supplemental_audit']
            assert digest(base_path) == reaudit['base_audit_sha256']
            assert digest(fresh_path) == reaudit['supplemental_audit_sha256']
            base = matching(base_path)
            fresh = matching(fresh_path)
            assert len(base['results']) == 420
            assert [key(row) for row in base['results'] if not row['passed']] == [target]
            assert fresh['passed'] and len(fresh['results']) == 4
            assert [row for row in panels['results'] if key(row) != target] == [row for row in base['results'] if key(row) != target]
            supplement = reaudit['supplemental_video']
            assert panels['supplemental_videos'] == transition['supplemental_videos'] == [supplement]
            assert digest(evidence / supplement['file']) == supplement['sha256'] == fresh['video_sha256']
            repaired = next(row for row in panels['results'] if key(row) == target)
            expected = dict(next(row for row in fresh['results'] if key(row) == target),
                            video=supplement['file'], video_sha256=supplement['sha256'])
            assert repaired == expected and repaired['readable_presented_clock'] > repaired['readable_clock']
            fresh_state = read(fresh_path.parent / 'panel-run/run-state.json')
            fresh_checks = read(fresh_path.parent / 'panel-run/results.json')
            assert fresh_state['status'] == 'completed' and fresh_state['apk_sha256'] == sha
            assert fresh_state['desktop_sha256'] == desktop
            assert len(fresh_checks) == fresh_state['checks'] == reaudit['supplemental_checks']
            assert all(row['passed'] for row in fresh_checks)
            fresh_opening = matching(fresh_path.parent / 'panel-transition-audit.json')
            expected_samples = [dict(row, video=supplement['file'], video_sha256=supplement['sha256'])
                                for row in fresh_opening['results'] if key(row) == target]
            assert fresh_opening['passed'] and [row for row in transition['results'] if key(row) == target] == expected_samples
    negative = matching(evidence / 'body-detector-negative-controls.json')
    assert negative['passed'] and negative['video_sha256'] == panels['video_sha256']
    controls = [row for row in read(evidence / 'panel-run/results.json')
                if row['check'].startswith('pixel detector ')]
    assert len(controls) == 5 and all(row['passed'] for row in controls)
    assert negative['results'] == controls
    assert negative['source_results_sha256'] == digest(evidence / 'panel-run/results.json')
    for name, expected in (('desktop', 18), ('desktop/history-states', 70)):
        folder = evidence / name
        render = matching(folder / 'render-review.json')
        cases = {(row['name'], row['camera']) for row in render['results'] if row['kind'] == 'world'}
        assert len(cases) == expected and render['failed_sheet_frames'] == 0
        assert digest(folder / 'review.mp4') == render['video_sha256']
        captures(folder, render['results'])
        manual = matching(folder / 'manual-world-review.json')
        assert manual['passed'] and {(row['scene'], row['camera']) for row in manual['cases']} == cases
        assert all(row['outcome'].startswith('accepted') for row in manual['cases'])

    media_folder = evidence / 'share/v0.7'
    media = read(media_folder / 'media-audit.json')
    manifest = read(media_folder / 'capture-manifest.json')
    assert media['passed'] and media['apk_sha256'] == sha
    assert (media['duration'], media['chapters'], media['screenshots']) == (527, 44, 103)
    assert media['movie_sha256'] == manifest['sha256'] == digest(media_folder / manifest['mp4'])
    recipe_path = PROJECT / 'docs/diagnostics/parmenides/patient-framing-v0.5.5/share/v0.5.5/author-shot-list.json'
    assert media['comparison_recipe_sha256'] == digest(recipe_path)
    recipe, pinned = read(media_folder / 'author-shot-list.json'), read(recipe_path)
    assert recipe['shots'] == pinned['shots'] and recipe['catalog_shots'] == pinned['catalog_shots']
    for name, key in (('screenshot-catalog.json', 'screenshot_catalog_sha256'), ('author-shot-list.json', 'shot_list_sha256')):
        assert digest(media_folder / name) == manifest[key]
    captures(media_folder, read(media_folder / 'screenshot-catalog.json')['shots'])
    for name, expected in manifest['source_videos'].items():
        assert digest(PROJECT / name) == expected
    manual = read(media_folder / 'manual-movie-review.json')
    assert manual['passed'] and manual['movie_sha256'] == manifest['sha256']

    def device(folder, expected):
        receipt = read(folder / 'receipt.json')
        assert receipt['result'] == 'completed' and receipt['cleanup_verified']
        assert receipt['job']['request']['device'] == 'chromecast-test-01'
        assert receipt['job']['request']['apk'] == expected + '.apk'
        return receipt

    tours = []
    for group in range(5):
        for mode in (0, 1):
            folder = evidence / f'cast1-group-{group}-view-{mode}'
            fixture = read(out / f'review-fixtures/group-{group}-view-{mode}/review-receipt.json')
            assert fixture['diagnostic_only'] and fixture['production_apk_sha256'] == sha
            assert fixture['nativeLibraries'] == build['nativeLibraries']
            assert digest(Path(fixture['apk'])) == fixture['sha256']
            receipt = device(folder, fixture['sha256'])
            audit = read(folder / 'sheet-audit.json')
            assert audit['passed'] and audit['device_job'] == receipt['job']['id']
            assert audit['production_apk_sha256'] == sha and audit['diagnostic_apk_sha256'] == fixture['sha256']
            assert audit['sheet_frames'] > 0 and all(row['passed'] for row in audit['results'])
            assert digest(folder / 'capture.mp4') == audit['video_sha256']
            captures(folder, [row for row in audit['results'] if row.get('file')])
            manual = read(folder / 'visual-review.json')
            assert manual['passed'] and manual['production_apk_sha256'] == sha
            assert manual['device_job'] == receipt['job']['id']
            captures(folder, manual['captures'])
            tours.append(dict(group=group, camera=mode, job=receipt['job']['id'], checked_sheet_frames=audit['sheet_frames']))
    production = device(evidence / 'cast1-review', sha)
    assert production['job']['request']['validator'] == 'poke-resume'
    assert (evidence / 'cast1-review/resumed-screenshot.png').exists()
    visual = read(evidence / 'cast1-review/visual-review.json')
    assert visual['passed'] and visual['apk_sha256'] == sha and visual['device_job'] == production['job']['id']
    captures(evidence / 'cast1-review', visual['captures'])
    reading_fixture = read(out / 'review-fixtures/lifecycle-reading-view-0/review-receipt.json')
    assert reading_fixture['diagnostic_only'] and reading_fixture['production_apk_sha256'] == sha
    assert reading_fixture['nativeLibraries'] == build['nativeLibraries']
    reading_device = device(evidence / 'cast1-sheet-lifecycle', reading_fixture['sha256'])
    assert reading_device['job']['request']['validator'] == 'poke-resume'
    reading_visual = read(evidence / 'cast1-sheet-lifecycle/visual-review.json')
    assert reading_visual['passed'] and reading_visual['production_apk_sha256'] == sha
    assert reading_visual['device_job'] == reading_device['job']['id']
    captures(evidence / 'cast1-sheet-lifecycle', reading_visual['captures'])

    phone_folder = evidence / 'phone-review'
    phone_build = read(phone_folder / 'build-receipt.json')
    phone_receipt = read(phone_folder / 'receipt.json')
    phone_visual = read(phone_folder / 'visual-review.json')
    assert phone_build['source_apk_sha256'] == sha and phone_build['assets_unchanged']
    assert phone_build['cd_sha256'] == build['levelSha256']
    assert digest(Path(phone_build['apk'])) == phone_build['sha256']
    with zipfile.ZipFile(phone_build['apk']) as phone_apk:
        assert hashlib.sha256(phone_apk.read('assets/cd.iff')).hexdigest() == build['levelSha256']
        for name, expected in phone_build['nativeLibraries'].items():
            assert hashlib.sha256(phone_apk.read(name)).hexdigest() == expected
    assert phone_receipt['result'] == 'completed' and phone_receipt['cleanup_verified']
    assert phone_receipt['job']['request']['device'] == 'phone-pixel-8-pro'
    assert phone_receipt['job']['request']['apk'] == phone_build['sha256'] + '.apk'
    assert phone_visual['passed'] and phone_visual['apk_sha256'] == phone_build['sha256']
    assert phone_visual['production_apk_sha256'] == sha and phone_visual['device_job'] == phone_receipt['job']['id']
    captures(phone_folder, phone_visual['captures'])

    summary = dict(passed=True, iteration='F', art_stage='polish', apk_sha256=sha,
        level_sha256=build['levelSha256'], scope='v0.7 polish, complete both-view native narrative/source regression, current-build presentation and ten TV scene/history tours; matched private author-review movie/catalog.',
        runtime_checks=checks, distinct_cards=len(cards), eligible_edges=edges,
        static_checks=counts, asset_inventory=len(actor_names), full_face_cap_glove_margin=.025,
        close_both_approaches=6, art_capture_count=len(art_captures['shots']), rendered_panel_checks=420,
        opening_transition_samples=len(transition['results']), world_cases=88, tours=tours,
        author_movie_seconds=527, author_movie_chapters=44, author_catalog_screenshots=103,
        production_device_job=production['job']['id'], final_all_realm_regression_complete=True,
        reading_lifecycle_device_job=reading_device['job']['id'],
        current_phone_verified=False, current_phone_launch_resume_verified=True,
        phone_device_job=phone_receipt['job']['id'], reading_camera_fix_verified=True,
        hidden_reading_transition_seconds=.35, performance_optimization_deferred=True,
        experimental_realm_candidate_adopted=False,
        known_visual_issues=['General camera obstruction/collision remains deferred; extreme close or inside-mesh approaches can crop geometry.',
            'Low Chromecast frame rate remains recorded; no optimization or new sustained performance acceptance is claimed.',
            'Authored collision fields/support are preserved, but changed statplat render triangles can change native mesh colliders.',
            'Distant inherited scenery outside Being remains visible from some approaches.'],
        pending_gates=['Additional phone presentation modes and phone/tablet route coverage; a picture-in-picture video overlaid the lower-right controls during the successful current phone launch/resume check. Prior phone touch controls were confirmed manually and the touch runtime remains unchanged.',
            'Complete remote-driven Android route acceptance; fixture-based tours/movie do not certify it.',
            'Max feedback after separately authorized delivery of the private A–F package.',
            'Optimization and sustained phone/TV measurements in v0.8.'])
    (evidence / 'verification-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print('F declared scope passed:', sha, checks, 'native checks;', len(tours), 'TV tours; 44 chapters / 527s / 103 shots')


if __name__ == '__main__':
    main()
