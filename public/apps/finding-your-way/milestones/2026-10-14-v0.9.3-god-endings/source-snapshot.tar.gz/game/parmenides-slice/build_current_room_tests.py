"""Freeze matched authored all-active/current-only variants of existing scene9 fixtures."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import struct
import subprocess
import zipfile
from level_settings import attach

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
WF = Path('/home/will/WorldFoundry-wbniv')
ENGINE = None # Required explicitly; never silently select a temporary runtime
BASE = ROOT / 'docs/diagnostics/parmenides/current-baseline-2026-10-09'
EVID = BASE / 'current-room'
OUT = HERE / 'build-current-room-tests'
TOOLS = Path('/home/will/android-sdk-local/build-tools/34.0.0')

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def run(args, **kw):
    subprocess.run([str(x) for x in args], check=True, **kw)

def main(argv=None):
    global ENGINE, BASE, EVID, OUT
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--engine',type=Path,required=True,help='Reviewed engine checkout containing the LevelRenderSettings reader')
    parser.add_argument('--baseline',type=Path,default=BASE)
    parser.add_argument('--out',type=Path,default=OUT)
    parser.add_argument('--evidence',type=Path)
    args=parser.parse_args(argv)
    ENGINE=args.engine.resolve();BASE=args.baseline.resolve();OUT=args.out.resolve()
    EVID=args.evidence.resolve() if args.evidence else BASE/'current-room'
    if not (ENGINE/'engine/room_render_settings.hpp').is_file():parser.error('Selected engine lacks the authored room-render reader')
    OUT.mkdir(exist_ok=True)
    EVID.mkdir(exist_ok=True)
    lib = OUT / 'libwf_game.so'
    shutil.copyfile(ENGINE / 'build-android/libwf_game.so', lib)
    run(['/home/will/android-sdk-local/ndk/26.2.11394342/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip', '--strip-unneeded', lib])
    variants = []
    for fixture in ['g0', 'g1', 'g2', 'g3', 'g4', 'loop']:
        baseline = json.loads((BASE / (fixture + '-variant.json')).read_text())
        source = Path(baseline['source_apk']).parent
        settings_payloads = []
        for scope, label in [(0, 'all-active'), (1, 'current-only')]:
            folder = OUT / fixture / label
            folder.mkdir(parents=True, exist_ok=True)
            level = folder / 'parmenides_slice-standalone.iff'
            original = source / level.name
            shutil.copyfile(original, level)
            settings = attach(level, source / 'actors.json', folder, WF, scope)
            raw = level.read_bytes()
            old = original.read_bytes()
            size = struct.unpack_from('<I', old, 2052)[0]
            # The existing attachment changes only L4 size, RAM locator/padding,
            # and the appended catalog. All compiled actors/atlases stay identical.
            expected = bytearray(old)
            expected[4:8] = raw[4:8]
            expected[2052:2056] = raw[2052:2056]
            expected[2056 + size:2056 + size + 20] = raw[2056 + size:2056 + size + 20]
            assert raw[:len(old)] == expected
            settings_payloads.append((folder / 'settings.rprp').read_bytes())
            run([WF / 'wftools/cdpack-rs/target/release/cdpack', WF / 'wfsource/source/game/shell.fth', level, '-o', folder / 'cd.iff'])
            unsigned, aligned, signed = [folder / (n + '.apk') for n in ('unsigned', 'aligned', 'signed')]
            with zipfile.ZipFile(baseline['apk']) as zin, zipfile.ZipFile(unsigned, 'w') as zout:
                for info in zin.infolist():
                    if info.filename.startswith('META-INF/'):
                        continue
                    data = zin.read(info.filename)
                    if info.filename == 'assets/cd.iff':
                        data = (folder / 'cd.iff').read_bytes()
                    if info.filename == 'lib/armeabi-v7a/libwf_game.so':
                        data = lib.read_bytes()
                    zout.writestr(info, data)
            run([TOOLS / 'zipalign', '-f', '4', unsigned, aligned])
            run([TOOLS / 'apksigner', 'sign', '--ks', HERE / 'build/development-signing.p12', '--ks-pass', 'pass:android', '--out', signed, aligned])
            run([TOOLS / 'apksigner', 'verify', signed])
            frozen = folder / (fixture + '-' + label + '-' + sha(signed)[:16] + '.apk')
            signed.rename(frozen)
            unsigned.unlink()
            aligned.unlink()
            with zipfile.ZipFile(baseline['apk']) as a, zipfile.ZipFile(frozen) as b:
                for n in b.namelist():
                    if not n.startswith('META-INF/') and n not in ('assets/cd.iff', 'lib/armeabi-v7a/libwf_game.so'):
                        assert a.read(n) == b.read(n), n
                assert b.getinfo('assets/cd.iff').compress_type == zipfile.ZIP_STORED
            receipt = dict(fixture=fixture, scope=label, apk=str(frozen), apk_sha256=sha(frozen),
                           native_sha256=sha(lib), level_sha256=sha(folder / 'cd.iff'),
                           original_standalone_sha256=sha(original), standalone_sha256=sha(level),
                           catalog_sha256=sha(folder / 'settings.rprp'), settings=settings,
                           baseline_apk_sha256=baseline['apk_sha256'], room_count=9,
                           original_visibility_gates=True, compiled_actors_and_atlases_identical=True)
            variants.append(receipt)
            (EVID / (fixture + '-' + label + '-variant.json')).write_text(json.dumps(receipt, indent=2) + '\n')
            print(fixture, label, frozen, flush=True)
        a, b = settings_payloads
        assert len(a) == len(b)
        diffs = [i for i in range(len(a)) if a[i] != b[i]]
        assert len(diffs) == 1 and a[diffs[0]:diffs[0]+1] == b'0' and b[diffs[0]:diffs[0]+1] == b'1'
    patch = subprocess.check_output(['git', '-C', str(ENGINE), 'diff'], text=True)
    (EVID / 'engine.patch').write_text(patch)
    shutil.copyfile(ENGINE / 'engine/room_render_settings.hpp', EVID / 'room_render_settings.hpp')
    (EVID / 'build-receipt.json').write_text(json.dumps(dict(base_engine_commit=subprocess.check_output(['git', '-C', str(ENGINE), 'rev-parse', 'HEAD'], text=True).strip(),
        engine_patch_sha256=sha(EVID / 'engine.patch'), settings_header_sha256=sha(EVID / 'room_render_settings.hpp'),
        native_sha256=sha(lib), settings_oas_sha256=sha(HERE / 'settings.oas'),
        settings_bindings_sha256=sha(HERE / 'settings-bindings.json'), variants=variants,
        comparison='Same native library and fixtures; catalogs differ only in authored initial value 0 vs 1. Existing visibility gates retained.'), indent=2) + '\n')

if __name__ == '__main__':
    main()
