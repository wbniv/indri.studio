| Date | Change |
|------|--------|
| [2026-04-21](https://github.com/wbniv/finding-your-way/commit/d7e1168) | readme: add pending section for items awaiting author input |
| [2026-04-21](https://github.com/wbniv/finding-your-way/commit/dbcb784) | readme: replace Astro boilerplate with actual project README |
| [2026-04-20](https://github.com/wbniv/finding-your-way/commit/8b5db15) | Scaffold Astro + convert 144 HTM pages to Markdown |

<!--history-meta v1
d7e1168	author	Will Norris
d7e1168	added	7
d7e1168	deleted	0
d7e1168	files	1
d7e1168	body	Co-Authored-By: Claude Sonnet 4.6 <noreply@anthropic.com>
dbcb784	author	Will Norris
dbcb784	added	29
dbcb784	deleted	32
dbcb784	files	1
dbcb784	body	Co-Authored-By: Claude Sonnet 4.6 <noreply@anthropic.com>
8b5db15	author	Will Norris
8b5db15	added	43
8b5db15	deleted	0
8b5db15	files	1
8b5db15	body	Phase 1 (steps 1–6) of the Parmenides port — see docs/plans/PLAN.md.\n\n- Astro 5 (pinned; Node 20 compatible), plain JS — no TypeScript\n- Content Collection "pages" with zod schema for title/realm/bg/fg/images\n- scripts/convert.mjs: iconv windows-1252 + linkedom + turndown pipeline\n- 144 pages converted, smart quotes normalized, zero broken links\n- 19 images copied into public/images/\n\nNext: layout + dynamic route + link checker + Terraform + deploy.\n\nCo-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
-->
