#!/usr/bin/env python3
"""Audit saved coordinator latency buffers without accessing any device."""
import argparse
import hashlib
import json
from pathlib import Path
import statistics

p = argparse.ArgumentParser()
p.add_argument('--profile', type=Path, required=True)
p.add_argument('--report', type=Path, required=True)
a = p.parse_args()
summary = json.loads((a.profile/'summary.json').read_text())
report = dict(passed=True, runs=[])
for run in summary['runs']:
    source = a.profile/f'run-{run["run"]}/samples.json'
    previous = set()
    presents = set()
    holes = []
    empty = []
    for index, sample in enumerate(json.loads(source.read_text())):
        current = set()
        for line in sample['raw'].splitlines()[1:]:
            cells = line.split()
            if len(cells) == 3 and all(c.isdigit() for c in cells) and 0 < int(cells[1]) < 9223372036854775807:
                current.add(int(cells[1]))
        if not current:
            empty.append(index)
            continue
        if previous and not previous & current and min(current) > max(previous):
            holes.append(dict(sample=index, previousLastNs=max(previous), nextFirstNs=min(current)))
        presents.update(current)
        previous = current
    ordered = sorted(presents)
    intervals = [(y-x)/1e6 for x, y in zip(ordered, ordered[1:])]
    fps = 1000/statistics.mean(intervals) if intervals else 0
    passed = not holes and len(intervals) == run['frames'] and abs(fps-run['fps']) < 1e-6
    report['runs'].append(dict(run=run['run'], passed=passed, samplingHoles=holes,
                              emptySampleIndices=empty, intervals=len(intervals), fps=fps,
                              observedSpanSeconds=(ordered[-1]-ordered[0])/1e9 if ordered else 0,
                              samplesSha256=hashlib.sha256(source.read_bytes()).hexdigest()))
    report['passed'] &= passed
a.report.write_text(json.dumps(report, indent=2)+'\n')
print(f'{"PASS" if report["passed"] else "FAIL"} {len(report["runs"])} profile coverage audits')
raise SystemExit(0 if report['passed'] else 1)
