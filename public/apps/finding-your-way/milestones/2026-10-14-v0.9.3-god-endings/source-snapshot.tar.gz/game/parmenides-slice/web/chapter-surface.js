// This frozen chapter's largest reader needs at least 960 x 720 logical pixels.
// Preserve the visible canvas aspect while allowing CSS to scale the surface.
// This link-time chapter override leaves the shared engine/gallery unchanged.
addToLibrary({
  emscripten_get_element_css_size__proxy: 'sync',
  emscripten_get_element_css_size__deps: ['$findEventTarget', '$getBoundingClientRect'],
  emscripten_get_element_css_size: (target, width, height) => {
    target = target ? findEventTarget(target) : Module['canvas'];
    if (!target) return {{{ cDefs.EMSCRIPTEN_RESULT_UNKNOWN_TARGET }}};
    var rect = getBoundingClientRect(target);
    var w = rect.width, h = rect.height;
    if (target === Module['canvas'] && w > 0 && h > 0) {
      var scale = Math.max(1, 960 / w, 720 / h);
      // At 900px the native reader selects its 1080p atlas sizes.
      // Those larger metrics need the corresponding safe minimum too.
      if (h * scale >= 900) scale = Math.max(scale, 1440 / w, 1080 / h);
      w = Math.ceil(w * scale); h = Math.ceil(h * scale);
    }
    {{{ makeSetValue('width', '0', 'w', 'double') }}};
    {{{ makeSetValue('height', '0', 'h', 'double') }}};
    return {{{ cDefs.EMSCRIPTEN_RESULT_SUCCESS }}};
  }
});
