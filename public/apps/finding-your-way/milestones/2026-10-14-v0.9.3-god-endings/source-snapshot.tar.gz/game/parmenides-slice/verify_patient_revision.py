"""Verify a scene-only revision with explicit inherited baseline provenance."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT=Path(__file__).resolve().parent
PROJECT=ROOT.parents[1]
read=lambda p:json.loads(p.read_text())
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    p=argparse.ArgumentParser();p.add_argument('--evidence',type=Path,required=True);a=p.parse_args()
    e=a.evidence.resolve();build=read(ROOT/'build/build-receipt.json');content=read(ROOT/'build/content.json')
    assert digest(Path(build['apk']))==build['sha256']
    with zipfile.ZipFile(build['apk']) as apk:
        assert hashlib.sha256(apk.read('assets/cd.iff')).hexdigest()==build['levelSha256']
        for name,expected in build['nativeLibraries'].items():assert hashlib.sha256(apk.read(name)).hexdigest()==expected
    assert digest(Path('/home/will/WorldFoundry-wbniv/engine/wf_game'))==build['engineProvenance']['desktopExecutableSha256']
    def current(receipt):
        assert receipt['sha256']==build['sha256'] and receipt['levelSha256']==build['levelSha256'] and receipt['nativeLibraries']==build['nativeLibraries']
    for name in ('delta-audit','mesh-audit','framing-audit','manual-review'):
        audit=read(e/(name+'.json'));assert audit['passed'];current(audit['build'])
    for name in ('text-audit','asset-audit'):
        audit=read(e/(name+'.json'));current(audit['build']);assert all(r['passed'] for r in audit['results'])
    runtime=[];transcripts=[];sheets=0
    for name in ('ending-routes','transition-safety','motion','reduced'):
        folder=e/'desktop'/name;current(read(folder/'build-receipt.json'))
        rows=read(folder/'results.json');assert rows and all(r['passed'] for r in rows);runtime+=rows
        transcripts+=read(folder/'transcripts.json')
        if name in ('motion','reduced'):
            report=read(folder/'render-review.json');assert report['failed_sheet_frames']==0
            assert digest(folder/'review.mp4')==report['video_sha256']
            for row in report['results']:assert digest(folder/row['file'])==row['sha256']
            sheets+=report['sheet_frames']
    edges={(m[1],m[2],int(m[3])) for t in transcripts if (m:=re.search(r'Ending (9[a-p]) → (10[abc]) camera=([01]): confirm transition',t['interaction']))}
    expected={(history,door,mode) for history,row in content['god_histories'].items() for door in row['doors'] for mode in (0,1)}
    assert edges==expected and len(edges)==66,(len(edges),expected-edges)
    seen={c for t in transcripts for c in t['cards']}
    assert {c for k in ('ending_10a','ending_10b','ending_10c','ending_101b','ending_complete') for c in content['groups'][k]}<=seen
    for mode in (0,1):
        folder=e/f'cast1-motion-view-{mode}';audit=read(folder/'sheet-audit.json');device=read(folder/'receipt.json')
        assert audit['passed'] and audit['production_apk_sha256']==build['sha256']
        assert device['result']=='completed' and device['cleanup_verified'] and device['job']['id']==audit['device_job']
        assert digest(folder/'capture.mp4')==audit['video_sha256']
        lifecycle=e/f'cast1-patient-lifecycle-view-{mode}';review=read(lifecycle/'visual-review.json');device=read(lifecycle/'receipt.json')
        assert review['passed'] and review['production_apk_sha256']==build['sha256'] and review['device_job']==device['job']['id']
        assert device['result']=='completed' and device['cleanup_verified']
        for capture in review['captures']:assert digest(lifecycle/capture['file'])==capture['sha256']
    for name in ('cast1-review',):
        folder=e/name;device=read(folder/'receipt.json');review=read(folder/'visual-review.json')
        assert device['result']=='completed' and device['cleanup_verified']
        assert device['job']['request']['apk']==build['sha256']+'.apk'
        assert review['passed'] and review['apk_sha256']==build['sha256'] and review['device_job']==device['job']['id']
        for capture in review['captures']:assert digest(folder/capture['file'])==capture['sha256']
    folder=e/'share/v0.5.5';media=read(folder/'capture-manifest.json');audit=read(folder/'media-audit.json')
    assert audit['passed'] and audit['apk_sha256']==build['sha256'] and digest(folder/media['mp4'])==media['sha256']==audit['movie_sha256']
    assert read(folder/'manual-movie-review.json')['passed']
    for file,key in (('screenshot-catalog.json','screenshot_catalog_sha256'),('author-shot-list.json','shot_list_sha256')):assert digest(folder/file)==media[key]
    prior=PROJECT/'game/milestones/2026-10-06-visual-review-v0.5.5/manifest.json';baseline=read(prior)
    assert baseline['sha256']==read(e/'delta-audit.json')['prior_build']['sha256']
    # This is reuse of recorded evidence, not fresh captures or a fresh 208-card
    # route run. The source/Blender delta audit proves the relevant inputs exact.
    result=dict(passed=True,apk_sha256=build['sha256'],level_sha256=build['levelSha256'],runtime_checks=len(runtime),
                source_checks=len(read(e/'text-audit.json')['results']),asset_checks=len(read(e/'asset-audit.json')['results']),
                distinct_cards=len(seen),new_build_cards=sorted(seen),dialogue_sequences=len(transcripts),eligible_edges=len(edges),
                rendered_panel_checks=sheets,engine_source_commit=build['engineSourceCommit'],
                patient_framing=dict(passed=True,changed_actors=read(e/'delta-audit.json')['changed_actors'],
                    desktop_margin_samples=len(read(e/'framing-audit.json')['results']),native_sheet_samples=sheets,
                    device_movies=2,patient_lifecycle_modes=2,strategic_replacement=media['strategic_replacement']),
                inherited_baseline=dict(manifest=str(prior.relative_to(PROJECT)),manifest_sha256=digest(prior),
                    apk_sha256=baseline['sha256'],verification=baseline['verification'],
                    scope='Prior complete realm/card/panel/history coverage retained with original build identity. Exact unchanged scripts, textures, camera and unrelated actors verified; only surgery gets new captures.'),
                known_visual_issues=['Camera obstruction/collision postponed','Provisional models and effects; full remote-driven Android routes and phone acceptance remain open'])
    (e/'verification-summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print({k:v for k,v in result.items() if k not in ('inherited_baseline','patient_framing')})

if __name__=='__main__':main()
