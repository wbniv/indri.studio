#!/usr/bin/env python3
"""Temple route check: every fixture can still reach every door (target-match plan, step 2).

Reads the exported level only (the LEV's actor positions, classes and boxes,
and the native mesh files of mesh-collider actors) and walks a 2.5D grid with
the runtime player's own limits:

  capsule radius  min(half X, half Y) of the Player box (jolt_backend.cc
                  CharacterVirtual: a Z-up capsule filling the ColSpace AABB)
  height          the Player box height
  step-up         0.4 m (mWalkStairsStepUp)
  reach           a door counts as reached when a walkable cell lies within
                  2.5 m (fy-near: distance squared under 6.25) of its
                  interaction point

Colliders: ``platform`` actors are their exported boxes (position + box);
``statplat`` actors are the triangles of their native mesh (Jolt trimesh from
the render mesh). Boxes are world-axis-aligned, as the runtime builds them. Walls and steep faces block the column they occupy; near-
horizontal triangles are surfaces the player can stand on. A cell is open at
standing height h when nothing within the capsule radius occupies the band
(h + step-up, h + height).

Run:  python3 verify_temple_routes.py --build-dir BUILD [--report OUT.json]
      [--inject-box X0,Y0,X1,Y1]   (negative control: add a 3 m wall)
Exit 1 if any fixture cannot reach any door.
"""
import argparse
from collections import deque
import json
from pathlib import Path
import re
import struct
import sys

import numpy as np

FIXTURES = [(0, -11), (0, -3), (0, -5), (0, 8), (3, 0), (3, 3), (-3.8, -1), (7, 8)]
DOORS = {'Love': (0, 9), 'Reason': (7, 9), 'Truth': (-7, 9)}
REACH = 2.5
STEP_UP = .4
BOUNDS = (-11.0, -14.0, 11.0, 14.0)   # the Temple hall, x0 y0 x1 y1
CELL = .1
FIX = re.compile(r'([-0-9.]+)\(1\.15\.16\)')


def actors(lev):
    rows = {}
    for section in re.split(r"\n\t\{\s*'OBJ'", lev.read_text())[1:]:
        name = re.search(r"\{ 'NAME' \"([^\"]+)\"", section).group(1)
        get = lambda field: re.search(r'"' + field + r"\" \} \{ 'DATA' ([^}]*)\}", section)
        box, kind, pos, rot = get('Global Bounding Box'), get('Class Name'), get('Position'), get('Orientation')
        if not (box and kind and pos):
            continue
        rows[name] = dict(kind=kind.group(1).strip().strip('"'), box=[float(v) for v in FIX.findall(box.group(1))][:6],
                          position=[float(v) for v in FIX.findall(pos.group(1))][:3],
                          orientation=[float(v) for v in FIX.findall(rot.group(1))][:3] if rot else [0, 0, 0])
    return rows


def mesh_triangles(path):
    data = path.read_bytes()
    def chunk(tag):
        start = data.index(tag) + 4
        size = struct.unpack_from('<I', data, start)[0]
        return data[start + 4:start + 4 + size]
    vrtx, face = chunk(b'VRTX'), chunk(b'FACE')
    points = np.array([struct.unpack_from('<iii', vrtx, i + 12) for i in range(0, len(vrtx), 24)], dtype=float) / 65536
    tris = np.array([struct.unpack_from('<hhh', face, i) for i in range(0, len(face), 8)], dtype=int)
    return points[tris]


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--build-dir', type=Path, required=True)
    parser.add_argument('--report', type=Path)
    parser.add_argument('--inject-box', help='x0,y0,x1,y1: add a 3 m high wall (negative control)')
    args = parser.parse_args()
    out = args.build_dir.resolve()
    rows = actors(out / 'parmenides_slice.lev')
    player = rows['Player']['box']
    radius = min(player[3] - player[0], player[4] - player[1]) / 2
    height = player[5] - player[2]
    x0, y0, x1, y1 = BOUNDS
    nx, ny = int(round((x1 - x0) / CELL)), int(round((y1 - y0) / CELL))
    cx = x0 + (np.arange(nx) + .5) * CELL
    cy = y0 + (np.arange(ny) + .5) * CELL
    # Per cell: walkable surfaces (z) and solid bands (zlo, zhi).
    surfaces = [[[] for _ in range(ny)] for _ in range(nx)]
    solids = [[[] for _ in range(ny)] for _ in range(nx)]
    used = []

    def cells(ax0, ay0, ax1, ay1):
        i0, i1 = max(0, int((ax0 - x0) / CELL)), min(nx - 1, int((ax1 - x0) / CELL))
        j0, j1 = max(0, int((ay0 - y0) / CELL)), min(ny - 1, int((ay1 - y0) / CELL))
        return i0, i1, j0, j1

    def add_box(bx0, by0, bz0, bx1, by1, bz1):
        if bx1 < x0 or bx0 > x1 or by1 < y0 or by0 > y1:
            return False
        i0, i1, j0, j1 = cells(bx0, by0, bx1, by1)
        for i in range(i0, i1 + 1):
            for j in range(j0, j1 + 1):
                if bx0 <= cx[i] <= bx1 and by0 <= cy[j] <= by1:
                    solids[i][j].append((bz0, bz1))
                    surfaces[i][j].append(bz1)
        return True

    def add_triangles(tris):
        for tri in tris:
            a, b, c = tri
            n = np.cross(b - a, c - a)
            norm = np.linalg.norm(n)
            if norm < 1e-9:
                continue
            n = n / norm
            lo, hi = tri.min(axis=0), tri.max(axis=0)
            if hi[0] < x0 or lo[0] > x1 or hi[1] < y0 or lo[1] > y1:
                continue
            i0, i1, j0, j1 = cells(lo[0], lo[1], hi[0], hi[1])
            if abs(n[2]) > .5:     # floor-like (slope under 60 degrees): a surface
                d = np.cross(np.append(b[:2] - a[:2], 0), np.append(c[:2] - a[:2], 0))[2]
                for i in range(i0, i1 + 1):
                    for j in range(j0, j1 + 1):
                        p = np.array([cx[i], cy[j]])
                        w1 = ((b[0] - p[0]) * (c[1] - p[1]) - (c[0] - p[0]) * (b[1] - p[1])) / d
                        w2 = ((c[0] - p[0]) * (a[1] - p[1]) - (a[0] - p[0]) * (c[1] - p[1])) / d
                        w3 = 1 - w1 - w2
                        if min(w1, w2, w3) >= -1e-6:
                            z = w1 * a[2] + w2 * b[2] + w3 * c[2]
                            surfaces[i][j].append(z)
                            solids[i][j].append((z - .05, z))
            else:                  # wall-like: blocks every cell its footprint crosses
                steps = max(2, int(np.hypot(hi[0] - lo[0], hi[1] - lo[1]) / (CELL / 2)) + 2)
                for e0, e1 in ((a, b), (b, c), (c, a)):
                    for t in np.linspace(0, 1, steps):
                        p = e0 + (e1 - e0) * t
                        i, j = int((p[0] - x0) / CELL), int((p[1] - y0) / CELL)
                        if 0 <= i < nx and 0 <= j < ny:
                            solids[i][j].append((lo[2], hi[2]))

    for name, row in sorted(rows.items()):
        if row['kind'] not in ('platform', 'statplat') or name.startswith('Player'):
            continue
        px, py, pz = row['position']
        if not (x0 - 30 < px < x1 + 30 and y0 - 30 < py < y1 + 30):
            continue   # other rooms (the slice lays rooms out along +X)
        if row['kind'] == 'platform':
            b = row['box']
            if add_box(px + b[0], py + b[1], pz + b[2], px + b[3], py + b[4], pz + b[5]):
                used.append(name)
        else:
            path = out / (name.lower() + '.iff')
            if not path.exists():
                continue
            # Platform boxes are world-axis-aligned (jolt_backend.cc passes an
            # identity rotation); a mesh collider would carry its rotation.
            ra, rb, rc = row['orientation']   # radians; only yaw (about Z) is supported
            if abs(ra) > 1e-6 or abs(rb) > 1e-6:
                raise SystemExit(f'{name}: pitched or rolled mesh collider near the Temple; not supported by this check')
            yaw = np.array([[np.cos(rc), -np.sin(rc), 0], [np.sin(rc), np.cos(rc), 0], [0, 0, 1]])
            tris = mesh_triangles(path) @ yaw.T + np.array([px, py, pz])
            lo, hi = tris.reshape(-1, 3).min(axis=0), tris.reshape(-1, 3).max(axis=0)
            if hi[0] < x0 or lo[0] > x1 or hi[1] < y0 or lo[1] > y1:
                continue
            add_triangles(tris)
            used.append(name)
    if args.inject_box:
        bx0, by0, bx1, by1 = map(float, args.inject_box.split(','))
        add_box(bx0, by0, 0, bx1, by1, 3.0)

    # Ground at a cell for a player standing at h: the highest surface within
    # step-up. Clearance: no solid band within the capsule radius rises into
    # (ground + step-up, ground + height).
    reach_cells = int(np.ceil(radius / CELL))
    offsets = [(di, dj) for di in range(-reach_cells, reach_cells + 1) for dj in range(-reach_cells, reach_cells + 1)
               if (di * CELL) ** 2 + (dj * CELL) ** 2 <= (radius + CELL / 2) ** 2]

    def ground(i, j, h):
        tops = [z for z in surfaces[i][j] if z <= h + STEP_UP + 1e-6]
        return max(tops) if tops else None

    clear_cache = {}

    def clear(i, j, g):
        key = (i, j, round(g, 2))
        if key not in clear_cache:
            ok = True
            for di, dj in offsets:
                ii, jj = i + di, j + dj
                if not (0 <= ii < nx and 0 <= jj < ny):
                    ok = False
                    break
                if any(lo < g + height and hi > g + STEP_UP for lo, hi in solids[ii][jj]):
                    ok = False
                    break
            clear_cache[key] = ok
        return clear_cache[key]

    def walk(start):
        i, j = int((start[0] - x0) / CELL), int((start[1] - y0) / CELL)
        g = ground(i, j, 0.0)
        if g is None or not clear(i, j, g):
            # Fixture points sit on actors' own spots; start from the nearest open cell.
            best = None
            for r in range(1, 15):
                for di in range(-r, r + 1):
                    for dj in range(-r, r + 1):
                        ii, jj = i + di, j + dj
                        if 0 <= ii < nx and 0 <= jj < ny:
                            gg = ground(ii, jj, 0.0)
                            if gg is not None and clear(ii, jj, gg):
                                best = (ii, jj, gg)
                                break
                    if best:
                        break
                if best:
                    break
            if not best:
                return None, set()
            i, j, g = best
        origin = (i, j)
        seen = {(i, j): g}
        queue = deque([(i, j)])
        while queue:
            i, j = queue.popleft()
            h = seen[(i, j)]
            for di, dj in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                ii, jj = i + di, j + dj
                if not (0 <= ii < nx and 0 <= jj < ny) or (ii, jj) in seen:
                    continue
                gg = ground(ii, jj, h)
                if gg is None or not clear(ii, jj, gg):
                    continue
                seen[(ii, jj)] = gg
                queue.append((ii, jj))
        return origin, seen

    results = []
    for fixture in FIXTURES:
        start, seen = walk(fixture)
        row = dict(fixture=list(fixture), start=[round(float(cx[start[0]]), 2), round(float(cy[start[1]]), 2)] if start else None,
                   reachableCells=len(seen), doors={})
        for door, (dx, dy) in DOORS.items():
            best = min((np.hypot(cx[i] - dx, cy[j] - dy) for i, j in seen), default=None)
            row['doors'][door] = dict(nearest=round(float(best), 2) if best is not None else None,
                                      reached=best is not None and best < REACH)
        row['passed'] = all(d['reached'] for d in row['doors'].values())
        results.append(row)
    # Probes: solid spots must be unreachable (the check sees the new piers,
    # braziers and the goddess), and the stair must lift the player onto the
    # landing (it is climbable by design).
    union = {}
    for fixture in FIXTURES[:1]:
        union = walk(fixture)[1]
    def at(x, y):
        return union.get((int((x - x0) / CELL), int((y - y0) / CELL)))
    probes = {f'solid {name} ({x}, {y})': dict(point=[x, y], standingHeight=at(x, y), passed=at(x, y) is None)
              for name, (x, y) in dict(pier_0=(1, -1), pier_1=(1, 5), pillar1=(5, -1), pillar3=(5, 5), pillar0=(-5, -1),
                                       pillar2=(-5, 5), goddess=(3, 3), torch_0=(1.75, .45), torch_1=(4.25, .45)).items()}
    # The wing boxes (unchanged polish boxes, z 1.0-2.1 from y 1.97) stop the
    # player on the first tread, about 1.3 m from the goddess: inside her reach.
    tread = at(3.0, 1.65)
    probes['stair tread (3.0, 1.65) climbable'] = dict(point=[3.0, 1.65], standingHeight=tread,
                                                        passed=tread is not None and tread > .1)
    climbed = [(float(cy[j]), h) for (i, j), h in union.items() if abs(cx[i] - 3.0) < CELL / 2 and 0 < cy[j] < 4.5]
    top = max(climbed, key=lambda r: r[1]) if climbed else None
    probes['goddess in reach from the highest tread on the axis'] = dict(
        point=[3.0, top[0]] if top else None, standingHeight=top[1] if top else None,
        passed=bool(top) and abs(3.0 - top[0]) < REACH)
    report = dict(build=str(out), player=dict(radius=radius, height=height, stepUp=STEP_UP), cell=CELL, reach=REACH,
                  colliders=used, injected=args.inject_box, results=results, probes=probes,
                  passed=all(r['passed'] for r in results) and all(p['passed'] for p in probes.values()))
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2, default=lambda o: o.item()) + '\n')
    print(f'ROUTES: player radius {radius:.2f} m, height {height:.2f} m, step-up {STEP_UP} m, cell {CELL} m, '
          f'{len(used)} colliders' + (f', injected wall {args.inject_box}' if args.inject_box else ''))
    for r in results:
        doors = '  '.join(f"{k} {'ok' if v['reached'] else 'NO'} ({v['nearest']} m)" for k, v in r['doors'].items())
        print(f"  fixture ({r['fixture'][0]:5.1f},{r['fixture'][1]:5.1f}) start {r['start']}  {r['reachableCells']:6d} cells  {doors}")
    for label, probe in probes.items():
        h = probe['standingHeight']
        print(f"  probe {label}: {'unreachable' if h is None else f'reachable at {h:.2f} m'}  {'ok' if probe['passed'] else 'FAIL'}")
    print('ROUTES PASSED' if report['passed'] else 'ROUTES FAILED')
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    sys.exit(main())
