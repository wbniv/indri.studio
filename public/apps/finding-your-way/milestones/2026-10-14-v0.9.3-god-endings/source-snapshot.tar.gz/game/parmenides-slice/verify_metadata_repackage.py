"""Prove a version-name-only APK repackage retains every gameplay byte."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parent
TOOLS=Path('/home/will/android-sdk-local/build-tools/34.0.0')
parser=argparse.ArgumentParser()
parser.add_argument('--before',type=Path,required=True)
parser.add_argument('--after',type=Path,required=True)
args=parser.parse_args()
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda tool,*args:subprocess.check_output([str(TOOLS/tool),*map(str,args)]).decode()
with zipfile.ZipFile(args.before) as old,zipfile.ZipFile(args.after) as new:
    if set(old.namelist())!=set(new.namelist()):raise SystemExit('APK entries changed')
    entries={name:sha(new.read(name)) for name in new.namelist()}
    changed=[name for name in entries if old.read(name)!=new.read(name)]
    if any(name!='AndroidManifest.xml' and not name.startswith('META-INF/') for name in changed):
        raise SystemExit('Gameplay/resource bytes changed: '+str(changed))
    manifests=[read('aapt','dump','xmltree',path,'AndroidManifest.xml') for path in (args.before,args.after)]
    # Compare every decoded attribute/node, allowing only the version-name value.
    normalize=lambda value:re.sub(r'A: android:versionName[^\n]*','A: android:versionName=<version-name>',value)
    if normalize(manifests[0])!=normalize(manifests[1]):raise SystemExit('Other manifest attributes changed')
certs=[read('apksigner','verify','--print-certs',path) for path in (args.before,args.after)]
cert_digest=lambda output:re.findall(r'certificate SHA-256 digest: (\w+)',output)
if not cert_digest(certs[0]) or cert_digest(certs[0])!=cert_digest(certs[1]):raise SystemExit('APK signer changed')
report={'before_apk_sha256':sha(args.before.read_bytes()),'after_apk_sha256':sha(args.after.read_bytes()),
        'changed_entries':changed,'after_entries_sha256':entries,'signer_sha256':cert_digest(certs[0]),
        'scope':'Only version-name manifest value and APK signatures changed; every gameplay/resource entry is identical',
        'passed':True}
target=ROOT.parents[1]/'docs/diagnostics/parmenides/endings/metadata-only-repackage.json'
target.write_text(json.dumps(report,indent=2)+'\n')
print(report['scope'])
