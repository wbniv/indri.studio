#!/usr/bin/env python3
"""Verify deployed bytes, provenance, framing and cache headers after publication."""
from pathlib import Path
from urllib.request import urlopen,Request
import argparse,hashlib,json,re,datetime
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--bundle',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
p.add_argument('--site',default='https://indri.studio');p.add_argument('--release',required=True)
a=p.parse_args();receipt=json.loads((a.bundle/'receipt.json').read_text());bundle_id=receipt['bundleId'];root=a.site.rstrip('/')+'/apps/finding-your-way/play/';assets=root+'bundles/'+bundle_id+'/'
def get(url):
 with urlopen(Request(url,headers={'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/154.0.0.0 Safari/537.36','Accept-Encoding':'identity'}),timeout=45) as r:
  assert r.status==200,(url,r.status)
  return r.read(),dict(r.headers.items()),r.url
def header(headers,name):return next((v for k,v in headers.items() if k.lower()==name.lower()),'')
manifest,mh,_=get(root+'manifest.json');assert json.loads(manifest)['bundleId']==bundle_id
assert 'must-revalidate' in header(mh,'cache-control')
remote,_,_=get(assets+'receipt.json');assert json.loads(remote)==receipt
files=[]
for name,info in sorted(receipt['files'].items()):
 data,headers,url=get(assets+name)
 normalized=False;beacon=False
 if name=='frame.html':
  assert "frame-ancestors 'self'" in header(headers,'content-security-policy')
  assert header(headers,'cache-control')=='no-store'
  data=re.sub(rb' nonce="[^"]*"',b'',data);normalized=True
  data,count=re.subn(rb'\n<script type="module" src="https://static\.cloudflareinsights\.com/beacon\.min\.js/[a-zA-Z0-9]+" [^>]*></script>',b'',data);assert count<=1;beacon=bool(count)
 else:
  assert 'immutable' in header(headers,'cache-control'),(name,header(headers,'cache-control'))
 assert len(data)==info['bytes'],(name,len(data),info['bytes'])
 assert hashlib.sha256(data).hexdigest()==info['sha256'],name
 files.append({'name':name,'url':url,'bytes':len(data),'sha256':info['sha256'],'matchesReceipt':True,'htmlNonceRemovedForHash':normalized,'cloudflareBeaconRemovedForHash':beacon,'cacheControl':header(headers,'cache-control'),'contentType':header(headers,'content-type')})
app,ah,_=get(a.site.rstrip('/')+'/apps/finding-your-way/');player,ph,_=get(root)
assert 'frame-ancestors \'none\'' in header(ph,'content-security-policy')
assert bundle_id.encode() in player
source_bundle=receipt.get('provenance',{}).get('sourceBundle','')
version=source_bundle.split('-')[0]
assert re.fullmatch(r'v[0-9]+(?:\.[0-9]+){1,2}',version),source_bundle
source_receipt=json.loads((a.bundle.parent/source_bundle/'receipt.json').read_text())
assert source_receipt['version']==version[1:]
assert re.search(rb'class="fyw-browser-version"[^>]*>'+version.encode()+rb'<',player)
apk_links=len(re.findall(rb'href="[^"]+\.apk"',app))
assert apk_links>=1 and source_receipt['apkSha256'].encode() in app,apk_links
result={'passed':True,'site':a.site,'release':a.release,'bundleId':bundle_id,'verifiedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'apkLinks':apk_links,'manifestCacheControl':header(mh,'cache-control'),'playerCacheControl':header(ph,'cache-control'),'files':files,'limits':'The Worker injects per-request HTML script nonces; frame hashes are verified after removing those nonce attributes and, when present, the specifically identified Cloudflare Insights beacon injection. Browser acceptance is recorded separately.'}
a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(result,indent=2)+'\n');print('PASS live bundle bytes, cache/CSP headers, player version, manifest and APK links')
