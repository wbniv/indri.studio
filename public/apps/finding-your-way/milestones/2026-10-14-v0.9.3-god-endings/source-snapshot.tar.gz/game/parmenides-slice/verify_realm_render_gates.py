"""Prove D render culling leaves exported physical objects and assets intact."""
import argparse,hashlib,json,re
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--build-dir',type=Path,required=True);p.add_argument('--baseline-build',type=Path,required=True);p.add_argument('--report',type=Path,required=True);a=p.parse_args();out=a.build_dir.resolve();base=a.baseline_build.resolve();rows=[]
def check(label,value):
 rows.append(dict(check=label,passed=bool(value)))
 if not value:raise AssertionError(label)
def objects(p):
 return {re.search(r"\{ 'NAME' \"([^\"]+)\"",s)[1]:s for s in re.split(r"\n\t\{\s*'OBJ'",p.read_text())[1:]}
def stripped(s,player=False):
 s=re.sub(r"\{ 'I32' \{ 'NAME' \"Visibility Mailbox\" \} \{ 'DATA' \d+l \} \{ 'STR' \"\d+\" \} \}","VISIBILITY",s)
 if player:s=re.sub(r"(\{ 'STR' \{ 'NAME' \"Script\" \} \{ 'STR' )(\"(?:[^\"\\]|\\.)*\")( \} \})",r'\g<1>SCRIPT\3',s)
 return s
from level_settings import readback
success=False
try:
 before,after=objects(base/'parmenides_slice.lev'),objects(out/'parmenides_slice.lev');check('same exported object order and identities',list(before)==list(after));check('same native actor IDs',json.loads((base/'actors.json').read_text())==json.loads((out/'actors.json').read_text()))
 for name in before:check(name+' retains every physical/gameplay field except render mailbox and Player script',stripped(before[name],name=='Player')==stripped(after[name],name=='Player'))
 for src in base.iterdir():
  if src.is_file() and (src.suffix=='.tga' or src.suffix=='.iff' and src.name not in ('cd.iff','parmenides_slice.iff','parmenides_slice-standalone.iff')):check(src.name+' production mesh/texture bytes unchanged',(out/src.name).read_bytes()==src.read_bytes())
 check('all source content and exact route links retained',(out/'content.json').read_bytes()==(base/'content.json').read_bytes())
 gates=json.loads((out/'visual-gates.json').read_text());check('realm-specific gates are unique within existing mailbox allocation',len(set(gates.values()))==len(gates) and max(gates.values())<640 and any(':' in k for k in gates))
 script=(out/'chapter.fth').read_text()
 for key,actual in gates.items():
  if ':' in key:
   logical,realm=map(int,key.split(':'));check(key+' composes source visibility, exact realm and inherited modal contract',f'{logical} read-mailbox 102 read-mailbox {realm} = & 140 read-mailbox 0 = & {actual} write-mailbox' in script)
 success=True
finally:
 a.report.parent.mkdir(parents=True,exist_ok=True);a.report.write_text(json.dumps(dict(build=json.loads((out/'build-receipt.json').read_text()),baseline_build=json.loads((base/'build-receipt.json').read_text()),passed=success,results=rows,scope='Byte-identical mesh/TGA inputs and every physical/gameplay exported object field; render mailbox/Player script alone changed. Native hidden-route movement remains separately required.'),indent=2)+'\n')
print('Realm rendering preservation checks',len(rows))
