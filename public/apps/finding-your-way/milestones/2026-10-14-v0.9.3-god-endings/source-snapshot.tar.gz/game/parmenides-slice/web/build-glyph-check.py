"""Link a focused WebGL fixture against the already-built pinned engine."""
from pathlib import Path
import shlex, subprocess, os
here=Path(__file__).resolve().parent
build=here.parent/'build/web-v0.8/cmake';out=build.parent/'glyph-check';out.mkdir(exist_ok=True)
flags=(build/'CMakeFiles/wfengine.dir/flags.make').read_text();defs=next(s.split(' = ',1)[1] for s in flags.splitlines() if s.startswith('CXX_DEFINES = '));incs=(build/'CMakeFiles/wfengine.dir/includes_CXX.rsp').read_text()
args=[str(here.parent/'build/web-sdk/upstream/emscripten/em++'),*shlex.split(defs),*shlex.split(incs),str(here/'glyph-scratch-check.cc'),'-w','-Wno-register','-std=c++17','-O3','-flto=thin','-sMIN_WEBGL_VERSION=2','-sMAX_WEBGL_VERSION=2','-sSTACK_SIZE=65536','-sSTACK_OVERFLOW_CHECK=2','-sASSERTIONS=2','-sALLOW_MEMORY_GROWTH=1','-sEXIT_RUNTIME=0','-sEXPORTED_FUNCTIONS=_main,_scratchBytesFree',str(build/'libwfengine.a'),str(build/'runtime-properties/libwf_attr_edit.a'),str(build/'libzforth.a'),str(build/'libJolt.a'),'-o',str(out/'glyph.js')]
subprocess.run(args,check=True,env=dict(os.environ,EM_CACHE=str(build.parent/'emscripten-cache')))
(out/'index.html').write_text('''<!doctype html><canvas id="canvas" width="32" height="32"></canvas><script>
window.glyphResults=[];window.glyphDone=false;window.Module={canvas:document.getElementById('canvas')};
const upload=WebGL2RenderingContext.prototype.bufferSubData;
WebGL2RenderingContext.prototype.bufferSubData=function(...args){if(window.glyphCase){const view=args[2];const begin=args[3]||0;const length=args[4]||view.length-begin;window.glyphCase.uploads.push({bytes:length*view.BYTES_PER_ELEMENT,freeDuring:Module._scratchBytesFree(),last:Array.from(new Float32Array(view.buffer,view.byteOffset+(begin+length)*view.BYTES_PER_ELEMENT-54*4,54)),first:Array.from(new Float32Array(view.buffer,view.byteOffset+begin*view.BYTES_PER_ELEMENT,Math.min(54,length*view.BYTES_PER_ELEMENT/4)))});}return upload.apply(this,args);};
const draw=WebGL2RenderingContext.prototype.drawArrays;
WebGL2RenderingContext.prototype.drawArrays=function(...args){if(window.glyphCase)window.glyphCase.draws.push(args[2]);return draw.apply(this,args);};
</script><script src="glyph.js"></script>''')
print(out)
