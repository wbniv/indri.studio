"""Identify distant pixels by changing one actor's render scale while paused.

Uses existing chapter fixtures and runtime; does not edit engine or level data.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time

from e3_parity import PrivateDisplay, CHAPTER_ARGS
sys.path.insert(0, '/home/will/WorldFoundry-wbniv/tests')
from debug_bridge_client import BridgeClient


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--binary', type=Path, required=True)
    ap.add_argument('--fixtures', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    a = ap.parse_args()
    a.out.mkdir(parents=True, exist_ok=True)
    results = {}
    from PIL import Image, ImageChops
    with PrivateDisplay() as display:
        for label in ('control', 'scene9'):
            fixture = a.fixtures / label / 'group-0-view-0'
            ids = json.loads((fixture / 'actors.json').read_text())['ids']
            player = ids['Player']
            with socket.socket() as sock:
                sock.bind(('127.0.0.1', 0))
                port = sock.getsockname()[1]
            log = (a.out / (label + '.log')).open('w')
            proc = subprocess.Popen([str(a.binary), '-L'+str(fixture/'parmenides_slice-standalone.iff'),
                '-rate14', *CHAPTER_ARGS, '--no-fps', '--debug-port', str(port)],
                cwd=fixture, env={**os.environ, 'DISPLAY':display.name, 'WF_REST_PORT':'0'},
                stdout=log, stderr=subprocess.STDOUT)
            b = None
            try:
                b = BridgeClient(port=port, timeout=20)
                def wait(fn, seconds=15):
                    deadline=time.monotonic()+seconds
                    while time.monotonic()<deadline:
                        if proc.poll() is not None: raise RuntimeError('runtime exited')
                        if fn(): return
                        time.sleep(.005)
                    raise TimeoutError('probe boundary')
                for mb in (101,102,110,140,150,151,163,470,471,473,486,550,3009,3010,3011):
                    b.watch(player,mb)
                candidates=[n for n in ids if n.startswith('ReasonCanopy') or n in ('reason_grove','WhiteSelf','WildSelf','Child')]
                for name in candidates: b.watch(ids[name],3042)
                wait(lambda:b.mailbox_values.get((player,470),0)>=13.3,40)
                b.send({'op':'pause'})
                assert b.wait_for(lambda m:m.get('op')=='paused',timeout=5)
                time.sleep(.15)
                state={str(m):v for (i,m),v in b.mailbox_values.items() if i==player}
                def snap(name):
                    path=(a.out/(label+'-'+name+'.png')).resolve()
                    b.send({'op':'screenshot','filename':str(path)})
                    assert b.wait_for(lambda m:m.get('op')=='screenshot_done' and m.get('filename')==str(path),timeout=10)
                    return Image.open(path).convert('RGB')
                base=snap('baseline')
                row={'state':state,'scale_tests':[]}
                for name in candidates:
                    idx=ids[name];scale=b.mailbox_values.get((idx,3042),1)
                    b.set_mailbox(3042,.001,idx=idx)
                    time.sleep(.1)
                    test=snap(name)
                    diff=ImageChops.difference(base,test)
                    bbox=diff.getbbox()
                    row['scale_tests'].append({'actor':name,'idx':idx,'scale':scale,'bbox':bbox})
                    b.set_mailbox(3042,scale,idx=idx)
                    time.sleep(.1)
                results[label]=row
                print(label,json.dumps(row),flush=True)
            finally:
                if b: b.close()
                proc.terminate()
                try:proc.wait(timeout=5)
                except subprocess.TimeoutExpired:proc.kill();proc.wait()
                log.close()
    results['binary_sha256']=hashlib.sha256(a.binary.read_bytes()).hexdigest()
    (a.out/'results.json').write_text(json.dumps(results,indent=2)+'\n')


if __name__ == '__main__':main()
