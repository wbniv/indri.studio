"""Audit C furniture contact and source collision frames in editable Blender."""
import argparse,json,sys
from pathlib import Path
import bpy
p=argparse.ArgumentParser();p.add_argument('--build-dir',type=Path,required=True);p.add_argument('--report',type=Path,required=True)
a=p.parse_args(sys.argv[sys.argv.index('--')+1:]);out=a.build_dir.resolve()
bpy.ops.wm.open_mainfile(filepath=str(out/'parmenides_slice.blend'));objects=bpy.context.scene.objects
rows=[]
def check(label,condition):
    rows.append(dict(check=label,passed=bool(condition)))
    if not condition:raise AssertionError(label)
def world_bounds(name):
    obj=objects[name];points=[obj.matrix_world@v.co for v in obj.data.vertices]
    return [min(v[i] for v in points) for i in range(3)]+[max(v[i] for v in points) for i in range(3)]
def close(a,b):return len(a)==len(b) and max(abs(x-y) for x,y in zip(a,b))<.00001
try:
    for name in ('hearing_bench','facts_table','interpretations_table','prosecutor_lectern','defenceattorney_lectern',*[f'gallery_bench_{x}_{y}' for x in (292,308) for y in (-5,-2)]):
        check(name+' visible feet/base meet the floor',abs(world_bounds(name)[2])<.00001)
    for stem in ('facts','interpretations'):
        table=world_bounds(stem+'_table');paper=world_bounds(stem+'_document')
        check(stem+' document rests at its table top',paper[2]<=table[5]+.00001 and paper[5]>=table[5]-.00001)
        check(stem+' accessible document remains over its support',table[0]<paper[0]<paper[3]<table[3] and table[1]<paper[1]<paper[4]<table[4])
    bench=world_bounds('hearing_bench');exhibits=world_bounds('presented_exhibits')
    check('presented exhibits rest on original hearing height',abs(exhibits[2]-bench[5])<.025)
    for name,expected in (
        ('hearing_bench',(-2.25,-.6,-.65,2.25,.6,.65)),
        ('facts_table',(-.7,-.6,-.4,.7,.6,.4)),('interpretations_table',(-.7,-.6,-.4,.7,.6,.4)),
        ('prosecutor_lectern',(-.5,-.3,-.55,.5,.3,.55)),('defenceattorney_lectern',(-.5,-.3,-.55,.5,.3,.55))):
        check(name+' retains baseline collision frame',close(list(objects[name]['wf_original_bbox']),expected))
    for name in ('WhiteSelf','WildSelf','YoungerSelf','Prosecutor','DefenceAttorney','Student','Judge','OldLady'):
        obj=objects[name];check(name+' uses unchanged permanent-asset route',obj['wf_Moves Between Rooms']=='True')
    for name in ('JudgeChair','DefenceAttorneyChair'):
        check(name+' shares seated character contact origin',close(tuple(objects[name].location),tuple(objects[name.removesuffix('Chair')].location)))
        check(name+' chair back faces behind its character',abs((objects[name].rotation_euler.z-objects[name.removesuffix('Chair')].rotation_euler.z)-__import__('math').pi/2)<.00001)
finally:
    a.report.parent.mkdir(parents=True,exist_ok=True);a.report.write_text(json.dumps(dict(build=json.loads((out/'build-receipt.json').read_text()),passed=bool(rows) and all(x['passed'] for x in rows),results=rows),indent=2)+'\n')
print('C furniture/contact/collision checks',len(rows))
