"""Combine the source, asset and native audits with an exact build identity."""
import hashlib
import json
from pathlib import Path
import zipfile
import sys

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT.parents[1] / 'docs/diagnostics/parmenides/endings'
read = lambda path: json.loads(path.read_text())
build = read(ROOT / 'build/build-receipt.json')
if hashlib.sha256(Path(build['apk']).read_bytes()).hexdigest()!=build['sha256']:
    raise SystemExit('Frozen APK changed after packaging.')
with zipfile.ZipFile(build['apk']) as apk:
    if hashlib.sha256(apk.read('assets/cd.iff')).hexdigest()!=build['levelSha256']:
        raise SystemExit('APK does not contain the verified compiled level.')
    if any(hashlib.sha256(apk.read(name)).hexdigest()!=digest for name,digest in build['nativeLibraries'].items()):
        raise SystemExit('APK native libraries differ from their verified receipt.')
accepted_apks={build['sha256']}
metadata_path=EVIDENCE/'metadata-only-repackage.json'
metadata=None
if metadata_path.exists():
    metadata=read(metadata_path)
    if metadata.get('after_apk_sha256')!=build['sha256']:
        metadata=None  # Historical proof cannot transfer checks to a new build.
if metadata:
    if not metadata['passed']:
        raise SystemExit('Version-name repackage proof failed.')
    with zipfile.ZipFile(build['apk']) as apk:
        actual={name:hashlib.sha256(apk.read(name)).hexdigest() for name in apk.namelist()}
    if actual!=metadata['after_entries_sha256']:
        raise SystemExit('APK entries changed after version-name repackage verification.')
    if any(name!='AndroidManifest.xml' and not name.startswith('META-INF/') for name in metadata['changed_entries']):
        raise SystemExit('Repackage changed gameplay bytes.')
    accepted_apks.add(metadata['before_apk_sha256'])
engine=build['engineProvenance']
executable=Path('/home/will/WorldFoundry-wbniv/engine/wf_game')
if hashlib.sha256(executable.read_bytes()).hexdigest()!=engine['desktopExecutableSha256']:
    raise SystemExit('Desktop engine changed after provenance capture: rerun its checks and chapter verification.')
content = read(ROOT / 'build/content.json')
text = read(EVIDENCE / 'text-audit.json')
assets = read(EVIDENCE / 'asset-audit.json')
panels={'results':[]}
if content.get('visual_fixes'):
    panels=read(EVIDENCE/'panel-render-audit.json')
    if not panels['passed'] or panels['build']['sha256'] not in accepted_apks or panels['build']['levelSha256']!=build['levelSha256'] or panels['build']['nativeLibraries']!=build['nativeLibraries']:
        raise SystemExit('Complete matching rendered clipping/occlusion audit is required.')
    if len(panels['results']) != 420 or not all(row['passed'] for row in panels['results']):
        raise SystemExit('All 420 rendered dialogue views must pass.')
    if hashlib.sha256((EVIDENCE/'rendered-panels/panel-render.mp4').read_bytes()).hexdigest()!=panels['video_sha256']:
        raise SystemExit('Rendered panel recording changed after the pixel audit.')
    for row in panels['results']:
        if hashlib.sha256((EVIDENCE/'rendered-panels'/row['file']).read_bytes()).hexdigest()!=row['sha256']:
            raise SystemExit('Rendered frame changed: '+row['file'])
baseline='--visual-baseline' in sys.argv
native = [EVIDENCE / 'desktop', EVIDENCE / 'desktop/supplemental-text']
if baseline:
    native=[EVIDENCE/'desktop'/name for name in ('realms','god-routes','ending-routes','supplemental-text')]
for receipt in [text['build'], assets['build']] + [read(folder / 'build-receipt.json') for folder in native]:
    if receipt['sha256'] not in accepted_apks or receipt['levelSha256']!=build['levelSha256'] or receipt['nativeLibraries']!=build['nativeLibraries']:
        raise SystemExit('Audit build mismatch: rerun native:verify for the current APK.')
runtime = [row for folder in native for row in read(folder / 'results.json')]
transcripts = [row for folder in native for row in read(folder / 'transcripts.json')]
if not all(row['passed'] for row in runtime + text['results'] + assets['results']):
    raise SystemExit('An audit contains a failed check.')
seen = {index for row in transcripts for index in row['cards']}
expected = {card['id'] for card in content['cards']}
if seen != expected:
    raise SystemExit('Dialogue card coverage mismatch: ' + str(seen ^ expected))
review={}
if baseline:
    review_root=EVIDENCE.parent/'visual-baseline-review'
    def matching(receipt):
        return receipt['sha256']==build['sha256'] and receipt['levelSha256']==build['levelSha256'] and receipt['nativeLibraries']==build['nativeLibraries']
    mesh=read(review_root/'mesh-audit.json');negative=read(EVIDENCE/'body-detector-negative-controls.json')
    if not mesh['passed'] or not matching(mesh['build']) or len(mesh['objects'])!=359 or not negative['passed'] or not matching(negative['build']):
        raise SystemExit('Matching complete mesh audit and body-detector negative controls required.')
    transition=read(EVIDENCE/'panel-transition-audit.json')
    if not transition['passed'] or not matching(transition['build']) or transition['cases']!=420 or transition['sampled_cases']!=420 or transition['video_sha256']!=panels['video_sha256']:
        raise SystemExit('Matching complete opening-interval pixel checks required.')
    for sub,count in (('desktop',18),('desktop/history-states',70)):
        folder=review_root/sub;render=read(folder/'render-review.json');manual=read(folder/'manual-world-review.json')
        cases={(r['name'],r['camera']) for r in render['results'] if r['kind']=='world'}
        reviewed={(r['scene'],r['camera']) for r in manual['cases']}
        if not matching(render['build']) or render['failed_sheet_frames'] or len(cases)!=count or not manual['passed'] or reviewed!=cases or not matching(manual['build']) or any(not r['outcome'].startswith('accepted') for r in manual['cases']):
            raise SystemExit('Complete matching sampled world review required: '+sub)
        if hashlib.sha256((folder/'review.mp4').read_bytes()).hexdigest()!=render['video_sha256']:
            raise SystemExit('World recording changed: '+sub)
        for name,digest in render.get('additional_videos',{}).items():
            if hashlib.sha256((folder/name).read_bytes()).hexdigest()!=digest:
                raise SystemExit('Corrected fixture recording changed: '+name)
        for row in render['results']:
            if hashlib.sha256((folder/row['file']).read_bytes()).hexdigest()!=row['sha256']:
                raise SystemExit('World/transition frame changed: '+row['file'])
        review[sub]={'world_cases':count,'sheet_frames':sum(r['kind']=='sheet' for r in render['results'])}
    safety=review_root/'transition-safety'
    if not matching(read(safety/'build-receipt.json')) or not all(r['passed'] for r in read(safety/'results.json')):
        raise SystemExit('Matching hidden-input/coda transition safety required.')
    devices=review_root/'final-device';manual=read(devices/'manual-world-review.json');jobs=read(devices/'jobs.json')
    if len(jobs)!=10 or {(r['group'],r['camera']) for r in jobs}!={(g,c) for g in range(5) for c in range(2)}:
        raise SystemExit('All five Android groups in both camera modes are required.')
    if not manual['passed'] or not matching(manual['build']) or len(manual['cases'])!=10 or any(not r['outcome'].startswith('accepted') for r in manual['cases']):
        raise SystemExit('All ten Android world movies require explicit review.')
    for row in jobs:
        folder=devices/f'group-{row["group"]}-view-{row["camera"]}';audit=read(folder/'sheet-audit.json');device=read(folder/'receipt.json');diagnostic=read(folder/'diagnostic-build-receipt.json')
        if not audit['passed'] or audit['production_apk_sha256']!=build['sha256'] or device['result']!='completed' or not device['cleanup_verified'] or audit['device_job']!=row['job'] or device['job']['request']['apk']!=diagnostic['sha256']+'.apk' or diagnostic['production_apk_sha256']!=build['sha256'] or diagnostic['nativeLibraries']!=build['nativeLibraries']:
            raise SystemExit('Complete matching Android evidence required: '+folder.name)
        if hashlib.sha256((folder/'capture.mp4').read_bytes()).hexdigest()!=audit['video_sha256']:
            raise SystemExit('Android movie changed: '+folder.name)
        if not any(r['group']==row['group'] and r['camera']==row['camera'] and r['job']==row['job'] for r in manual['cases']):
            raise SystemExit('Manual Android review job mismatch: '+folder.name)
    for sub in ('cast1-review','cast1-sheet-lifecycle'):
        folder=review_root/sub;device=read(folder/'receipt.json');visual=read(folder/'visual-review.json')
        if device['result']!='completed' or not device['cleanup_verified'] or not visual['passed'] or visual['production_apk_sha256']!=build['sha256'] or visual['device_job']!=device['job']['id']:
            raise SystemExit('Completed matching production/reading lifecycle review required: '+sub)
        for capture in visual['captures']:
            if hashlib.sha256((folder/capture['file']).read_bytes()).hexdigest()!=capture['sha256']:
                raise SystemExit('Lifecycle capture changed: '+capture['file'])
    media_root=review_root/'share/v0.5.5';media=read(media_root/'media-audit.json');manifest=read(media_root/'capture-manifest.json')
    if not media['passed'] or media['apk_sha256']!=build['sha256'] or media['movie_sha256']!=hashlib.sha256((media_root/manifest['mp4']).read_bytes()).hexdigest():
        raise SystemExit('Matching author MP4/catalog verification required.')
    for filename,key in (('screenshot-catalog.json','screenshot_catalog_sha256'),('author-shot-list.json','shot_list_sha256')):
        if hashlib.sha256((media_root/filename).read_bytes()).hexdigest()!=manifest[key]:
            raise SystemExit('Author comparison recipe changed: '+filename)
    for row in read(media_root/'screenshot-catalog.json')['shots']:
        if hashlib.sha256((media_root/row['file']).read_bytes()).hexdigest()!=row['sha256']:
            raise SystemExit('Author catalog frame changed: '+row['id'])
    movie_review=read(media_root/'manual-movie-review.json')
    if not movie_review['passed'] or movie_review['movie_sha256']!=manifest['sha256']:
        raise SystemExit('Author movie requires explicit composition review.')
    review.update(meshes=359,panel_transition_cases=420,transition_samples=len(transition['results']),android_movies=10,
        author_movie_seconds=media['duration'],author_catalog_screenshots=media['screenshots'],
        android_scope='Scripted scene/page setup with native movement; sampled sheets and manual world review; ordinary remote input and Home/resume on production world and diagnostic reading account. Full remote-driven Android route traversal and phone certification are not claimed.')
summary = {'runtime_checks': len(runtime), 'source_checks': len(text['results']),
           'asset_checks': len(assets['results']), 'dialogue_sequences': len(transcripts),
           'visual_fixes':bool(content.get('visual_fixes')),'known_visual_issues':['Text clipping/occlusion','Face rendering','Camera obstruction'] if not content.get('visual_fixes') else ['World depth/rendering review remains open','Camera obstruction','Camera transition and patient framing review remains open'],
           'rendered_panel_checks':len(panels['results']), 'distinct_cards': len(seen), 'missing_cards': [], 'passed': True,
           'apk_sha256': build['sha256'],'engine_source_commit':engine['sourceCommit'],
           'desktop_executable_sha256':engine['desktopExecutableSha256'],
           'engine_texture_cases':engine['textureCases']}
if metadata:summary['metadata_only_repackage']=metadata
if baseline:
    summary['visual_baseline_review']=review
    summary['known_visual_issues']=['Camera obstruction/collision postponed','Upward surgery composition crops surgeons; framing postponed','Sampled rendering coverage; complete remote-driven Android routes and phone acceptance remain open']
(EVIDENCE / 'verification-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
if baseline:(review_root/'verification-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
