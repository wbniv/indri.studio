"""Verify the declared iteration-D candidate; never certify final v0.6 gates."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-dir', type=Path, required=True)
    parser.add_argument('--evidence', type=Path, required=True)
    parser.add_argument('--generator-source', type=Path, help='Explicit frozen original generator snapshot; every packaged source hash still required')
    args = parser.parse_args()
    build_dir, evidence = args.build_dir.resolve(), args.evidence.resolve()
    read = lambda path: json.loads(path.read_text())
    build = read(build_dir / 'build-receipt.json')
    apk_hash = build['sha256']
    assert build['artStage'] == 'god-final'
    assert digest(Path(build['apk'])) == apk_hash
    with zipfile.ZipFile(build['apk']) as apk:
        assert hashlib.sha256(apk.read('assets/cd.iff')).hexdigest() == build['levelSha256']
        for name, sha in build['nativeLibraries'].items():
            assert hashlib.sha256(apk.read(name)).hexdigest() == sha
    assert read(build_dir / 'art-manifest.json') == build['art']
    for name, sha in build['art']['sources'].items():
        assert digest((args.generator_source.resolve() if args.generator_source else Path(__file__).resolve().parent) / name) == sha, name
    desktop_hash = build['engineProvenance']['desktopExecutableSha256']
    assert digest(Path(build['engineProvenance']['desktopRebuild']['executable'])) == desktop_hash

    def matching(name):
        report = read(evidence / name)
        assert report['build']['sha256'] == apk_hash, name
        assert report['build']['levelSha256'] == build['levelSha256'], name
        return report

    counts = {}
    for name, count in [('asset-audit.json', 2000), ('text-audit.json', 358), ('path-clearance-audit.json', 2278)]:
        report = matching(name)
        assert len(report['results']) == count and all(row['passed'] for row in report['results']), name
        counts[name] = count
    mesh = matching('mesh-audit.json')
    assert mesh['passed'] and mesh['native_winding_matches'] and not mesh['inward_components'] and not mesh['inconsistent_edges']
    uv = matching('art-uv-audit.json')
    assert uv['passed'] and all(row['passed'] for row in uv['models'])
    counts.update(mesh_objects=len(mesh['objects']), painted_models=len(uv['models']))
    assert counts['mesh_objects'] == 426 and counts['painted_models'] == 159
    distinct_cards = set()
    art_count=read(evidence/'final-native/run-state.json')['checks']
    for folder, expected in [('final-native', art_count), ('desktop-god', 1229)]:
        state = read(evidence / folder / 'run-state.json')
        assert state['status'] == 'completed' and state['apk_sha256'] == apk_hash
        assert state['desktop_sha256'] == desktop_hash and state['checks'] == expected
        receipt = read(evidence / folder / 'build-receipt.json')
        assert receipt['sha256'] == apk_hash
        results = read(evidence / folder / 'results.json')
        assert len(results) == expected and all(row['passed'] for row in results)
        for transcript in read(evidence / folder / 'transcripts.json'):
            distinct_cards.update(int(card) for card in transcript['cards'])
    assert matching('final-native/god-art-audit.json')['passed']
    captures = matching('final-native/capture-manifest.json')
    assert digest(evidence / 'final-native/art-proof.mp4') == captures['movie_sha256']
    assert len(captures['shots']) == 20
    for row in captures['shots']:
        assert digest(evidence / 'final-native' / row['file']) == row['sha256']
    turnarounds = matching('blender/turnaround-manifest.json')
    assert len(turnarounds['views']) == 6
    gallery = matching('review-manifest.json')
    assert len(gallery['images']) == 30
    supplemental=read(evidence/'aether-native/aether-camera-audit.json')
    assert supplemental['passed'] and supplemental['diagnostic_receipt']['production_apk_sha256']==apk_hash
    assert supplemental['build']['nativeLibraries']==build['nativeLibraries']
    overhead=read(evidence/'aether-native/capture-manifest.json')
    assert len(overhead['shots'])==4 and digest(evidence/'aether-native/art-proof.mp4')==overhead['movie_sha256']
    for row in overhead['shots']:assert digest(evidence/'aether-native'/row['file'])==row['sha256']
    for row in gallery['images']:
        assert digest(evidence / row['file']) == row['sha256']
    assert {row['file'] for row in gallery['images'] if row['file'].startswith('blender/')} == {'blender/' + row['file'] for row in turnarounds['views']}

    def device_receipt(folder, sha):
        receipt = read(folder / 'receipt.json')
        assert receipt['result'] == 'completed' and receipt['cleanup_verified']
        assert receipt['job']['request']['device'] == 'chromecast-test-01'
        assert receipt['job']['request']['apk'] == sha + '.apk'
        return receipt

    tours = []
    for group, mode in ((0,0),(0,1),(1,0),(1,1)):
        folder = evidence / f'cast1-group-{group}-view-{mode}'
        fixture = build_dir / f'review-fixtures/group-{group}-view-{mode}'
        diagnostic = read(fixture / 'review-receipt.json')
        assert diagnostic['diagnostic_only'] and diagnostic['production_apk_sha256'] == apk_hash
        assert diagnostic['nativeLibraries'] == build['nativeLibraries']
        assert digest(Path(diagnostic['apk'])) == diagnostic['sha256']
        receipt = device_receipt(folder, diagnostic['sha256'])
        audit = read(folder / 'sheet-audit.json')
        assert audit['passed'] and audit['device_job'] == receipt['job']['id']
        assert audit['production_apk_sha256'] == apk_hash and audit['diagnostic_apk_sha256'] == diagnostic['sha256']
        assert digest(folder / 'capture.mp4') == audit['video_sha256']
        required, seen = set(audit['expected_cards']), set(audit['seen_cards'])
        assert required == ({124,125,147,148,149} if group==0 else {157,158,195,196,146})
        assert required <= seen <= required | set(audit['optional_cards'])
        assert set(audit['optional_cards']) == {1}
        assert audit['results'] and all(row['passed'] for row in audit['results'])
        for row in audit['results']:
            if 'file' in row:
                assert digest(folder / row['file']) == row['sha256']
        world = read(folder / 'visual-review.json')
        assert world['passed'] and world['device_job'] == receipt['job']['id']
        assert world['production_apk_sha256'] == apk_hash
        for row in world['captures']:
            assert digest(folder / row['file']) == row['sha256']
        tours.append(dict(group=group,camera=mode, job=receipt['job']['id'], checked_sheet_frames=audit['sheet_frames'], video_sha256=audit['video_sha256']))
    folder = evidence / 'cast1-review'
    receipt = device_receipt(folder, apk_hash)
    visual = read(folder / 'visual-review.json')
    assert visual['passed'] and visual['apk_sha256'] == apk_hash and visual['device_job'] == receipt['job']['id']
    for row in visual['captures']:
        assert digest(folder / row['file']) == row['sha256']
    summary = dict(passed=True, apk_sha256=apk_hash, level_sha256=build['levelSha256'], art_stage='god-final', iteration='D',
        scope='Intermediate D candidate: static sources, unchanged God navigation faces/frames, off-route forest clearance, exact native God art/motion and sixteen-history God regression; four declared diagnostic TV tours plus production lifecycle. Complete final all-realm/ending regression and phone gates remain open.',
        runtime_checks=1229+art_count, native_art_checks=art_count, native_realms_checks=1229, static_checks=counts,
        source_cards_static=208, native_distinct_cards=len(distinct_cards), native_cards=sorted(distinct_cards),
        final_endings_regression_complete=False, current_phone_verified=False, gallery_images=30,
        tours=tours, production_device_job=receipt['job']['id'],
        generator_source=str(args.generator_source.resolve() if args.generator_source else Path(__file__).resolve().parent),
        performance_optimization_deferred=True, experimental_realm_candidate_adopted=False,
        known_visual_issues=['Later E/F art remains provisional.', 'Measured TV speed remains low: matched held D workloads approximately12.5–13.2fps; optimization deferred at Will’s request.', 'Camera collision remains deferred; inherited authored bounds do not certify unchanged native static triangle collision.'],
        pending_gates=['Current-build Pixel performance and affected touch interactions.', 'Full final v0.6 all-realm/endings and both-view production regression.', 'Final matching 44-chapter/103-shot catalog and movie.', 'Max feedback after all A–F iterations; no intermediate Will style approval.'])
    (evidence / 'verification-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(f'Iteration D declared scope passed: {apk_hash}; {1229+art_count} native checks, 30 images, four TV tours and production lifecycle')


if __name__ == '__main__':
    main()
