"""Identity-bound TV C/D held scene comparison with observed sampling coverage."""
import argparse,json,hashlib
from pathlib import Path
from report_phone_performance import analyze

def main():
 p=argparse.ArgumentParser();p.add_argument('--evidence',type=Path,required=True);p.add_argument('--campaign',default='campaign');p.add_argument('--comparison',action='append',type=Path,required=True);p.add_argument('--report-name',default='baseline-report');a=p.parse_args();root=a.evidence.resolve();campaign=root/a.campaign;receipt=json.loads((campaign/'receipt.json').read_text());assert receipt['result']=='completed' and receipt['cleanup_verified'];lookup={}
 for path in a.comparison:
  spec=json.loads(path.read_text())
  for variant in spec['variants']:lookup[variant['label']]=(variant,spec['source_build'])
 rows=[]
 for case in receipt['job']['request']['variants']:
  fixture,production=lookup[case['label']];build=json.loads(Path(fixture['receipt']).read_text());assert case['apk']==fixture['sha256']+'.apk';assert build['nativeLibraries']==production['nativeLibraries'];assert build['sha256']==fixture['sha256'];r=analyze(campaign/case['label']/'run-1');r.update(label=case['label'],diagnostic_apk_sha256=build['sha256'],diagnostic_level_sha256=build['levelSha256'],production_apk_sha256=production['sha256'],production_level_sha256=production['levelSha256'],phases=build['phases'],warmup_seconds=case['warmup'],native_libraries=production['nativeLibraries']);rows.append(r)
 report=dict(job=receipt['job']['id'],device=receipt['device'],finished=receipt['finished'],cleanup_verified=True,workloads=rows,scope='Unrecorded matched held no-modal God / bright final Temple scenes in both views, normal decorative motion. Single fixed-order campaign; not a controlled cold start or full-route/phone proof. Sampling bridges excluded; no claimed sustained gate with any coverage gap.',analysis_source_sha256=hashlib.sha256(Path(__file__).with_name('report_phone_performance.py').read_bytes()).hexdigest());(root/(a.report_name+'.json')).write_text(json.dumps(report,indent=2)+'\n')
 lines=['# Matched held-scene TV performance','',f"Coordinator `{report['job']}` completed and restored the requested APK with verified cleanup. Each case uses 30 seconds warm-up and 65 seconds unrecorded measurement. Fixture inputs, camera, scene state and native libraries are identity-bound in JSON; meshes/textures retain each declared production build's bytes.",'','| Workload | fps | p50 / p95 / p99 ms | Coverage holes | PSS MiB | Thermal |','| --- | ---: | --- | ---: | ---: | ---: |']
 for r in rows:lines.append(f"| {r['label']} | {r['fps']:.2f} | {r['p50_ms']:.2f} / {r['p95_ms']:.2f} / {r['p99_ms']:.2f} | {r['missing_sampling_gaps']} | {r['pss_mib']:.1f} | {r['thermal']['service_status']} |")
 lines+=['','These rates use deduplicated SurfaceFlinger presentation intervals. Nonoverlapping reads create unobserved bridges, which are excluded and reported with duration, poll gaps and observed buffer capacity. Thermal readings are point-in-time HAL snapshots. Cases run in fixed order on one TV; temperature and time are not independently controlled. This compares the held workloads and does not establish a route-wide or phone target. Idle images must be inspected separately before interpreting the scene comparison.',''];(root/(a.report_name+'.md')).write_text('\n'.join(lines));print(json.dumps({r['label']:{k:r[k] for k in ['fps','p95_ms','missing_sampling_gaps','pss_mib']} for r in rows},indent=2))
if __name__=='__main__':main()
