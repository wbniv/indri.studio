"""Iteration E: original ending silhouettes and patient-view clinical kit.

Construction uses the existing painted, closed-mesh primitives. Actor names,
origins, narrative visibility and the accepted patient camera remain intact.
Invisible foundation meshes deliberately retain their original geometry.
"""
import math
from art_temple_love import replace

STAGE = 'endings-surgery'


def portal(m, color, width=2.8):
    """Closed voussoirs form a broad arch with an unobstructed opening."""
    radius=width/2
    for side in (-1,1):
        m.box((side*radius,0,1.25),(.28,.42,2.5),color)
        m.box((side*radius,0,.12),(.48,.60,.24),'stone')
        m.box((side*radius,0,2.48),(.42,.54,.18),'gold')
    for n in range(12):
        a=n*math.pi/12;b=(n+1)*math.pi/12
        verts=[(r*math.cos(t),y,2.5+r*math.sin(t))
               for y in (-.21,.21) for r,t in
               ((radius-.14,a),(radius+.14,a),(radius+.14,b),(radius-.14,b))]
        # Outward winding on both flat faces and the four edge surfaces.
        m.part(verts,[(0,1,2,3),(7,6,5,4),(0,4,5,1),(1,5,6,2),
                      (2,6,7,3),(3,7,4,0)],color)


def surgeon(M, variant=0):
    """Downward facial planes, opaque folded mask and solid cap/eye accents.

    Head heights preserve the previous geometry's +0.7 m raise. Idle motion
    writes the actor Z, so the raise must stay in vertices, not actor location.
    """
    m=M();cloth=('blue','green','blue')[variant%3]
    m.loft([(3.24,0,0,.25,.31),(3.45,0,-.035,.28,.37),
            (3.80,0,-.025,.25,.39),(4.18,0,-.06,.20,.31)],cloth,10)
    # The jaw plane looks toward the fixed camera beneath the physicians.
    m.loft([(2.88,0,0,.21,.25),(2.98,0,0,.26,.30),
            (3.20,0,.015,.27,.29),(3.40,0,.02,.22,.24)],'skin',12)
    for side in (-1,1):
        m.sphere((side*.285,0,3.15),(.055,.065,.105),'skin',8,4)
        # Solid cream sclera and colored pupils remain legible from below.
        m.box((side*.115,-.130,2.872),(.11,.09,.034),'cream')
        m.box((side*.115,-.140,2.851),(.045,.052,.022),'ink')
        m.beam((side*.065,-.211,2.870),(side*.177,-.197,2.870),.027,'hair')
        # Ear loops and a folded mask edge share the clinical cream tile.
        m.beam((side*.247,.14,2.918),(side*.286,.01,3.07),.022,'cream')
    m.box((0,.113,2.856),(.50,.265,.105),'cream')
    for y in (.052,.121,.190):m.beam((-.235,y,2.797),(.235,y,2.797),.018,'stone')
    m.loft([(2.856,0,-.01,.037,.035),(2.98,0,-.022,.050,.047)],'skin',6)
    # The broad cap follows the cranial shell and closes at its back.
    m.loft([(3.27,0,.015,.28,.31),(3.43,0,.03,.275,.30),
            (3.56,0,.04,.19,.21)],cloth,12)
    m.box((0,-.238,3.30),(.45,.054,.08),'cream')
    m.box((0,-.203,2.906),(.51,.081,.060),cloth)
    for side in (-1,1):
        # Sleeves taper to gloves, preserving the accepted patient's margins.
        elbow=(side*.39,.17,3.32)
        hand=(side*.25,.40,2.68)
        m.beam((side*.37,0,3.89),elbow,.23,cloth)
        m.beam(elbow,(side*.27,.37,2.82),.18,cloth)
        m.sphere(hand,(.135,.12,.09),'cream',8,4)
        for finger in range(3):
            m.box((side*.25+(finger-1)*.065,.463,2.662),(.053,.10,.046),'cream')
        m.beam((side*.36,.355,2.723),(side*.345,.427,2.671),.059,'cream')
    # Quiet collar, wrap seam and pocket describe the shared gown construction.
    m.box((0,-.265,3.74),(.04,.035,.53),'cream')
    m.box((-.145,-.280,3.80),(.19,.036,.19),cloth)
    m.box((-.145,-.303,3.90),(.21,.030,.035),'cream')
    return m


def visage(M):
    """Original asymmetric distorted face, facing the approach in negative Y."""
    m=M()
    m.loft([(.80,0,.08,.35,.18),(1.45,-.11,.03,.65,.29),
            (2.16,-.04,.08,.73,.32),(2.85,0,.06,.94,.38),
            (3.47,.05,.12,.80,.35),(3.98,.12,.13,.44,.24)],'stone',12)
    for side in (-1,1):
        z=3.05 if side<0 else 3.17
        m.sphere((side*.39,-.315,z),(.27,.105,.23),'hair',10,5)
        m.sphere((side*.39,-.411,z),(.15,.042,.095),'paper',8,4)
        m.box((side*.40,-.452,z),(.044,.034,.073),'ink')
        m.beam((side*.15,-.39,z+.24),(side*.65,-.26,z+.30),.095,'ink')
        m.beam((side*.47,-.30,2.50),(side*.71,-.23,2.88),.095,'cream')
    m.loft([(2.57,0,-.39,.10,.09),(2.83,.03,-.46,.145,.12),
            (3.27,.01,-.28,.085,.07)],'stone',7)
    m.sphere((-.05,-.318,2.21),(.34,.100,.45),'hair',10,5)
    # Two disconnected pale lip edges carry the expression without teeth,
    # copied skull imagery or a recurring jump-scare gesture.
    m.beam((-.35,-.327,2.38),(.04,-.415,2.57),.078,'cream')
    m.beam((-.03,-.410,1.79),(.25,-.345,1.94),.077,'cream')
    return m


def dress(M, scene, out):
    replaced=[]
    def put(name,model,role):
        obj=replace(scene,M,name,model);obj['art_stage']=STAGE
        obj['art_role']=role;obj['wf_Moves Between Rooms']='True'
        replaced.append(name);return obj
    # The floor/support geometry remains exact. Only the water's diffuse
    # vocabulary changes to a quiet bright plane, with no alpha or bloom.
    old=scene.objects['being_ocean'].data;m=M()
    for poly in old.polygons:
        m.part([tuple(old.vertices[i].co) for i in poly.vertices],
               [tuple(range(len(poly.vertices)))],'cream')
    put('being_ocean',m,'bright ground plane with existing physical support')
    m=M()
    for radius in (3,6,10):
        for n in range(24):
            a=n*math.tau/24;b=(n+1)*math.tau/24
            m.beam((radius*math.cos(a),radius*math.sin(a),.10),
                   (radius*math.cos(b),radius*math.sin(b),.10),.065,'gold')
    put('being_ripples',m,'three quiet concentric dissolution contours')
    m=M()
    for n in range(12):
        a=n*math.tau/12;r=7.8+(n%3)*.60;z=2.2+(n%4)*.68
        x,y=r*math.cos(a),r*math.sin(a)
        m.cone((x,y,z),.16,.8+(n%3)*.3,'cream',.04,6)
        m.sphere((x,y,z+.96),(.13,.13,.20),'gold',6,3)
    put('being_light',m,'sparse solid fragments; no transparent overlay or exposure pulse')
    m=M();portal(m,'cream');put('being_threshold',m,'bright arch threshold')
    m=M();portal(m,'purple');put('both_passage',m,'combined passage from the exact source account')
    m=M()
    # Canonical vector motif: filled downward triangle above an outlined
    # upward triangle. Both occupy XZ so approach views see their faces.
    down=[(-.95,0,1.30),(.95,0,1.30),(0,0,-.02)]
    m.part([(x,y-.035,z) for x,y,z in down]+[(x,y+.035,z) for x,y,z in down],
           [(2,1,0),(3,4,5),(1,4,3,0),(2,5,4,1),(0,3,5,2)],'ink')
    up=[(-.95,.07,-1.04),(.95,.07,-1.04),(0,.07,.28)]
    for a,b in zip(up,up[1:]+up[:1]):m.beam(a,b,.10,'gold')
    put('both_triangles',m,'canonical filled-down and outlined-up ending motif')
    m=M();portal(m,'purple');put('void_closing_portal',m,'closing portal in the retained empty dark footprint')
    put('void_visage',visage(M),'original restrained distorted face; Old Woman remains voice-only')
    for i in range(3):put('surgeon_'+str(i+1),surgeon(M,i),'shared masked surgeon variant viewed from below')
    m=M();m.cone((0,0,4.18),.58,.15,'steel',.49,16)
    m.cone((0,0,4.16),.46,.035,'cream',.46,16)
    for n in range(6):
        a=n*math.tau/6
        m.cone((.31*math.cos(a),.31*math.sin(a),4.113),.092,.039,'paper',.092,8)
    m.cone((0,0,4.103),.087,.046,'cream',.087,8)
    m.beam((0,0,4.36),(-.32,0,4.64),.085,'steel')
    m.beam((-.32,0,4.64),(-.12,0,4.96),.085,'steel')
    for p in ((0,0,4.36),(-.32,0,4.64),(-.12,0,4.96)):
        m.sphere(p,(.09,.09,.09),'stone',8,4)
    # The inherited centre is occluded by a glove in the patient shot. Shift
    # the authored fixture sideways, retaining its actor origin and camera.
    m.verts=[(x-.9,y,z) for x,y,z in m.verts]
    m.projections=[(color,[(lo-.9,hi-.9) if i==0 else (lo,hi)
                          for i,(lo,hi) in enumerate(bounds)])
                   for color,bounds in m.projections]
    put('surgical_lamp',m,'closed six-reflector lamp with an articulated suspension; patient-visible lateral offset')
    m=M();m.box((0,0,1),(1.2,.6,.08),'steel')
    for x in (-.60,.60):m.box((x,0,1.075),(.04,.64,.11),'steel')
    for y in (-.30,.30):m.box((0,y,1.075),(1.20,.04,.11),'steel')
    for x in (-.44,.44):m.beam((x,0,.15),(x,0,.96),.055,'steel')
    # A scalpel, paired forceps and closed scissors are original geometry.
    m.box((-.39,0,1.065),(.075,.32,.043),'cream')
    m.box((-.39,.21,1.066),(.045,.11,.022),'steel')
    for x in (-.17,-.07):m.beam((x,-.17,1.067),(-.12,.23,1.067),.035,'steel')
    m.beam((.17,-.03,1.067),(.27,.22,1.067),.033,'steel')
    m.beam((.30,-.03,1.067),(.20,.22,1.067),.033,'steel')
    for x in (.14,.33):
        for n in range(10):
            a=n*math.tau/10;b=(n+1)*math.tau/10
            m.beam((x+.065*math.cos(a),-.13+.075*math.sin(a),1.067),
                   (x+.065*math.cos(b),-.13+.075*math.sin(b),1.067),.025,'steel')
    put('surgical_instrument_tray',m,'rimmed clinical tray with original scalpel, forceps and scissors')
    return dict(stage=STAGE,replaced=replaced,added=[],
        reused=['exact invisible Being/NotBeing support triangles and actor transforms',
                'unchanged surgery floor, bed, ceiling and fixed upward patient camera',
                'all A–D artwork and complete source cards',
                'existing ending visibility and only 10b → 101b coda routing'],
        intentionallyInvisible=['being_support','void_support','voice-only Old Woman'],
        pending=['Native export/render inspection, motion extremes and patient margins',
                 'Both perspectives and all four source accounts with cancel/reopen/completion',
                 'Exact production archive and coordinator-owned Chromecast installation'],
        originality='Original procedural closed meshes and the established original painted atlas; no borrowed likeness or imagery')


def emit_visuals(emit,actor):
    """Cosmetic simulation clocks never commit or gate source completion.

    488/489 follow the existing 486/487 cosmetic clocks and precede the
    remapped visibility range at 520. Reading sheets pause authored release;
    reduced motion shows a deliberate stable endpoint without waiting.
    """
    emit('102 read-mailbox 5 >= 102 read-mailbox 7 <= & 140 read-mailbox 0 = & 108 read-mailbox 0 = & if 488 read-mailbox 115 read-mailbox + 6 min 488 write-mailbox then\n')
    emit('102 read-mailbox 8 = 140 read-mailbox 0 = & 108 read-mailbox 0 = & if 489 read-mailbox 115 read-mailbox + 100 / fy-wrap 100 * 489 write-mailbox then\n')
    emit('102 read-mailbox 5 = 255 write-mailbox\n')
    emit('102 read-mailbox 5 = 108 read-mailbox 0 <> 488 read-mailbox 4 < | & 254 write-mailbox\n')
    emit('102 read-mailbox 6 = 256 write-mailbox\n102 read-mailbox 7 = 258 write-mailbox\n')
    emit('102 read-mailbox 7 = 108 read-mailbox 0 = & 488 read-mailbox 1.5 < & 257 write-mailbox\n')
    emit('102 read-mailbox 7 = 108 read-mailbox 0 <> 488 read-mailbox 1.5 >= 488 read-mailbox 5.5 < & | & 259 write-mailbox\n')
    emit('102 read-mailbox 8 = dup 213 write-mailbox 140 read-mailbox 0 = & 159 write-mailbox\n')
    # A broad bright field opens and rises before its fragments disappear.
    for name in ('being_light','being_threshold'):
        idx=actor(name)
        emit(f'108 read-mailbox 0 = if 488 read-mailbox 4 / 1 min else 0 then\n')
        emit(f'dup .9 * INDEXOF_Z_POS {idx} write-actor-mailbox '
             f'dup .28 * 1 + INDEXOF_X_SCALE {idx} write-actor-mailbox '
             f'.16 * 1 + INDEXOF_Z_SCALE {idx} write-actor-mailbox\n')
    idx=actor('being_ripples')
    emit(f'108 read-mailbox 0 = if 488 read-mailbox .012 * else 0 then INDEXOF_ROTATION_C {idx} write-actor-mailbox\n')
    # Squeeze the existing opaque arch once; never scale to exactly zero.
    idx=actor('void_closing_portal')
    emit(f'108 read-mailbox 0 = if 1 488 read-mailbox 1.5 / 1 min - .015 max else .015 then INDEXOF_X_SCALE {idx} write-actor-mailbox\n')
    idx=actor('void_visage')
    emit(f'108 read-mailbox 0 = if 488 read-mailbox 1.5 - 0 max 4 / 1 min else 0 then '
         f'dup .55 * INDEXOF_Z_POS {idx} write-actor-mailbox '
         f'.23 * 1 swap - INDEXOF_X_SCALE {idx} write-actor-mailbox\n')
    # A source-specific, bounded lean repositions the gloves as part of each
    # rigid physician pose. All Euler axes are written; yaw commits the pose.
    for i in range(1,4):
        idx=actor('surgeon_'+str(i));quiet='108 read-mailbox 0 = 140 read-mailbox 0 = &'
        emit(f'{quiet} if 489 read-mailbox .12 * {i*.2} + fy-sin .012 * else 0 then INDEXOF_Z_POS {idx} write-actor-mailbox\n')
        emit(f'{quiet} if 489 read-mailbox .08 * {i*.2} + fy-sin .0015 * else 0 then INDEXOF_ROTATION_A {idx} write-actor-mailbox\n')
        emit(f'{quiet} if 489 read-mailbox .05 * {i*.17} + fy-sin .0008 * else 0 then INDEXOF_ROTATION_B {idx} write-actor-mailbox\n')
        emit(f'0 INDEXOF_ROTATION_C {idx} write-actor-mailbox\n')


MOTION=[dict(name='Bright release',actors=['being_light','being_ripples','being_threshold'],
    trigger='Being only; normal motion; source completion remains independent',
    representation='Four simulation seconds of rising/opening opaque geometry, followed by quiet contour/ocean endpoint; paused during source reading',
    reduced='stable bright fragments and stationary contours',status='native verification pending'),
    dict(name='Closing portal and visage',actors=['void_closing_portal','void_visage'],
    trigger='NotBeing entry; single restrained reveal; no repeat scare loop',
    representation='1.5 simulation seconds of arch squeeze, then four seconds of original visage release; visual time advances only while the sheet is closed',
    reduced='quiet original visage pose; full caption remains available',status='native verification pending'),
    dict(name='Surgeon breathing',actors=['surgeon_1','surgeon_2','surgeon_3'],
    trigger='Surgery source account only; existing asynchronous idle',
    representation='Asynchronous ±0.012 m breathing, ±0.0015/0.0008-turn rigid lean and glove repositioning; +0.7 m raise stays in vertices; paused during reading',
    reduced='stable masked faces and lamp',status='native motion extremes pending')]
