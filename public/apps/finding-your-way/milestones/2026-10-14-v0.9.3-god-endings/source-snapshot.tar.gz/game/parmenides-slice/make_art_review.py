"""Assemble the iteration-A review from real Blender/native/device evidence."""
import argparse
import hashlib
import html
import json
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('--build-dir',type=Path,required=True);p.add_argument('--evidence',type=Path,required=True)
a=p.parse_args();out=a.build_dir.resolve();folder=a.evidence.resolve()
receipt=json.loads((out/'build-receipt.json').read_text())
items=[]
def add(group,path,label):
    assert (folder/path).exists(),path
    items.append(dict(group=group,file=path,label=label,sha256=hashlib.sha256((folder/path).read_bytes()).hexdigest()))
turnarounds=json.loads((folder/'turnarounds/turnaround-manifest.json').read_text())
assert turnarounds['build']['sha256']==receipt['sha256']
for row in turnarounds['views']:add('Blender','turnarounds/'+row['file'],row['asset'].replace('-',' ').title()+' · '+row['view'])
capture=json.loads((folder/'final-native/capture-manifest.json').read_text())
assert capture['build']['sha256']==receipt['sha256']
for row in capture['shots']:add('Native','final-native/'+row['file'],row['file'].removesuffix('.png').replace('-',' '))
for mode in (0,1):
    for sheet in sorted((folder/f'cast1-tour-{mode}/checked-sheets').glob('card-*.png')):
        n=int(sheet.stem.removeprefix('card-'))
        add('Chromecast',str(sheet.relative_to(folder)),f'Actual TV · {"follow" if mode==0 else "first person"} · source card {n}')
    add('Chromecast',f'cast1-tour-{mode}/contact.png',f'Actual TV · {"follow" if mode==0 else "first person"} · moving-view contact sheet')
if receipt['artStage']=='temple-love':
    for device in (1,2):
        add('Chromecast',f'cast{device}-launcher/launcher/verified-tile.png',f'Verified square launcher artwork · Chromecast {device}')
    for name,label in [('after-keys-screenshot.png','Production input · unobscured intro'),('resumed-screenshot.png','Production Home-resume · Temple')]:
        add('Chromecast','cast1-review/'+name,label)
entries=''.join(f'<figure data-group="{r["group"]}"><a href="{r["file"]}" target="_blank"><img loading="lazy" src="{r["file"]}" alt="{html.escape(r["label"])}"></a><figcaption>{html.escape(r["label"])}</figcaption></figure>' for r in items)
movies=''.join(f'<article><h3>{label}</h3><video controls preload="metadata" src="{file}"></video></article>' for label,file in [
    *([('Native art, motion and complete First Love account','final-native/art-proof.mp4')] if 'movie_sha256' in capture else []),
    ('Chromecast1 · follow camera','cast1-tour-0/capture.mp4'),('Chromecast1 · first person','cast1-tour-1/capture.mp4')])
document='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Finding Your Way — iteration A art review</title><style>
*{box-sizing:border-box}body{margin:0;background:#18242b;color:#ece5d1;font:16px system-ui;line-height:1.5}main{max-width:1440px;margin:auto;padding:36px}h1{font:44px Georgia;margin:8px 0}h2{font:30px Georgia;margin-top:45px}.kicker{color:#d9bb72;letter-spacing:.16em;text-transform:uppercase}p{max-width:1000px}code{color:#d9bb72}.scope{padding:20px;background:#263740;border-left:4px solid #d9bb72}nav{position:sticky;top:0;padding:12px 0;background:#18242bef;z-index:1;display:flex;gap:8px;flex-wrap:wrap}button{border:1px solid #899189;border-radius:6px;background:#263740;color:inherit;padding:10px 18px;cursor:pointer}button[aria-pressed=true]{background:#d9bb72;color:#18242b}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(310px,1fr));gap:18px}figure{margin:0;background:#263740;border-radius:6px;overflow:hidden}img{width:100%;height:260px;object-fit:contain;background:#10191e}figcaption{padding:12px}video{width:100%;max-height:680px;background:black}article{margin:24px 0}a{color:#d9bb72}[hidden]{display:none!important}footer{margin-top:40px;color:#adb8ba}@media(max-width:600px){main{padding:18px}h1{font-size:32px}}
</style><main><div class="kicker">World Foundry · original Blender assets</div><h1>Finding Your Way — iteration A</h1>
<p>Slate blue and worn leather for the traveler; cream, carved gold and layered feathers for the goddess. The Temple and Love corner samples establish stone, plaster, wood, paper and metal before extending the style across the full adventure.</p>
<div class="scope"><strong>Style proof for final author feedback.</strong> Player, goddess, Temple column/mosaic/threshold and Love facade/door/bench/newspaper are implemented. Remaining realms and NPCs retain their baseline art. Pixel both-view, touch and sustained-performance acceptance is pending; the first phone launch used an earlier proof. The temporary level safeguards remain while the engine rotation proposal is reviewed.</div>
<p>Build: <code>VERSION</code> · APK <code>APK</code>. Blender views use neutral review lighting; native and TV views are actual exported gameplay renders. Diagnostic TV tours select scenes/pages by script and exercise native movement; separate route tests verify source selection and completion.</p>
<h2>Models and exported views</h2><nav aria-label="Filter views">'''+''.join(f'<button aria-pressed="{str(g=="All").lower()}" data-filter="{g}">{g}</button>' for g in ('All','Blender','Native','Chromecast'))+'''</nav><div class="grid">ENTRIES</div><h2>Motion and device review</h2>MOVIES<footer>This targeted iteration-A review does not replace the frozen v0.5.5 comparison. The same 44-chapter movie and 103-shot catalog are scheduled for the finished v0.6 art pass.</footer></main><script>
document.querySelectorAll('[data-filter]').forEach(function(button){button.onclick=function(){var group=button.dataset.filter;document.querySelectorAll('[data-filter]').forEach(function(b){b.setAttribute('aria-pressed',String(b===button))});document.querySelectorAll('[data-group]').forEach(function(f){f.hidden=group!=='All'&&f.dataset.group!==group})}});
</script></html>'''
document=document.replace('VERSION',html.escape(receipt['version'])).replace('<code>APK</code>','<code>'+receipt['sha256'][:16]+'</code>').replace('ENTRIES',entries).replace('MOVIES',movies)
if receipt['artStage']=='temple-love':
    document=document.replace('iteration A','iteration B').replace('Iteration A','Iteration B').replace('iteration-A','iteration-B')
    document=document.replace('The Temple and Love corner samples establish stone, plaster, wood, paper and metal before extending the style across the full adventure.','Complete painted Temple and Love kits, original First Love, seated starlet, four crowd variants and restrained departure motion extend the shared construction.')
    document=document.replace('Style proof for final author feedback.','Temple/Love intermediate review record.').replace('Player, goddess, Temple column/mosaic/threshold and Love facade/door/bench/newspaper are implemented. Remaining realms and NPCs retain their baseline art.','Temple stonework, broken dome/windows, faded/vivid realm-scene tapestries, mosaic, complete street/door/window kits and the Love roster are implemented. Later realms and final aether/foundation art retain their baseline designs.')
(folder/'review.html').write_text(document)
(folder/'review-media.json').write_text(json.dumps(dict(build=receipt,images=items,scope=f'{receipt["artStage"]} only; technical phone checks and final Max feedback tracked separately; unchanged TV native runtime'),indent=2)+'\n')
print('Art review:',folder/'review.html',';',len(items),'verified images')
