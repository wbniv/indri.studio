"""Render a top-down orthographic map of the Parmenides slice scene (Workbench, no lighting).

Used for the Rooms floorplan in docs/plans/2026-10-07-v0.8-optimization/rooms-floorplan.html.
Run:  blender --background --python render_rooms_map.py -- OUT.png
Reads build/parmenides_slice.blend (written by build.py). The camera frames world x -50..850,
y -40..65 at 4 px per world unit, so image pixels map to world units exactly.
"""
import os
import bpy, sys
out = sys.argv[sys.argv.index('--')+1]
bpy.ops.wm.open_mainfile(filepath=os.path.join(os.path.dirname(os.path.abspath(__file__)),'build','parmenides_slice.blend'))
sc = bpy.context.scene
sc.render.engine = 'BLENDER_WORKBENCH'
sh = sc.display.shading
sh.light = 'FLAT'; sh.color_type = 'TEXTURE'; sh.show_object_outline = False
sc.render.resolution_x = 3600; sc.render.resolution_y = 420; sc.render.resolution_percentage = 100
sc.render.film_transparent = False
if sc.world is None: sc.world = bpy.data.worlds.new('w')
sc.world.color = (0.09, 0.11, 0.14)
cd = bpy.data.cameras.new('maprender'); cd.type = 'ORTHO'; cd.ortho_scale = 900; cd.clip_start = 0.1; cd.clip_end = 2000
cam = bpy.data.objects.new('maprender', cd); sc.collection.objects.link(cam)
cam.location = (400, 12.5, 600); cam.rotation_euler = (0, 0, 0)
sc.camera = cam
sc.render.image_settings.file_format = 'PNG'
sc.render.filepath = out
bpy.ops.render.render(write_still=True)
n = sum(1 for o in sc.objects if o.type == 'MESH')
print('MAPINFO meshes', n, 'objects', len(sc.objects))
