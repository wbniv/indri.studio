#!/usr/bin/env python3
"""Run chapter migration checks in a container-owned Xvfb session."""
import os
from pathlib import Path
import subprocess
import sys
import time

root=Path(__file__).resolve().parent
xvfb=subprocess.Popen(['Xvfb',':97','-screen','0','1280x720x24','-nolisten','tcp'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
try:
    time.sleep(.5)
    result=subprocess.run([sys.executable,str(root/'verify_desktop.py'),*sys.argv[1:]],env=dict(os.environ,DISPLAY=':97'))
finally:
    xvfb.terminate();xvfb.wait(timeout=10)
sys.exit(result.returncode)
