"""Original Blender style-proof construction, facing +X, Z up, ~1.8 m tall.

Closed faceted lofts allocate triangles to silhouette, facial planes, costume
and contact shapes. Reproducible source remains editable in the exported blend.
"""
import math

def model_type(base, scene, materials):
    from art_materials import tile_uv
    class Painted(base):
        def __init__(self):
            super().__init__();self.projections=[]
        def part(self, verts, faces, color):
            # New paint colors use an existing placeholder material index while
            # constructing; the actual exported mesh uses the image material.
            fallback=color if color not in ('plaster','glass','steel','paper') else 'cream'
            start=len(self.faces);super().part(verts,faces,fallback)
            bounds=[(min(p[i] for p in verts),max(p[i] for p in verts)) for i in range(3)]
            self.projections.extend([(color,bounds)]*(len(self.faces)-start))
        def beam(self,start,end,width,color):
            from mathutils import Vector
            a,b=Vector(start),Vector(end);direction=(b-a).normalized()
            reference=Vector((0,1,0)) if abs(direction.y)<.99 else Vector((0,0,1))
            side=direction.cross(reference).normalized()*width/2
            up=direction.cross(side).normalized()*width/2
            verts=[tuple(p+side*s+up*t) for p in (a,b) for s,t in [(-1,-1),(1,-1),(1,1),(-1,1)]]
            self.part(verts,[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],color)
        def loft(self, sections, color, sides=10):
            # (z, centerX, centerY, depthX, halfWidthY), bottom to top.
            verts=[(x+dx*math.cos(i*math.tau/sides),y+dy*math.sin(i*math.tau/sides),z)
                   for z,x,y,dx,dy in sections for i in range(sides)]
            faces=[tuple(reversed(range(sides))),tuple(range((len(sections)-1)*sides,len(verts)))]
            faces += [(j*sides+i,j*sides+(i+1)%sides,(j+1)*sides+(i+1)%sides,(j+1)*sides+i)
                      for j in range(len(sections)-1) for i in range(sides)]
            self.part(verts,faces,color)
        def blade(self, outline, depth, thickness, color):
            # A closed feather/cloth prism in YZ; reverse outline if needed.
            area=sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(outline,outline[1:]+outline[:1]))
            if area<0:outline=list(reversed(outline))
            n=len(outline);verts=[(depth+x,y,z) for x in (-thickness/2,thickness/2) for y,z in outline]
            faces=[tuple(reversed(range(n))),tuple(range(n,2*n))]
            faces += [(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
            self.part(verts,faces,color)
        def object(self,*args,**kwargs):
            obj=super().object(*args,**kwargs);mesh=obj.data;mesh.materials.clear()
            for mat in materials:mesh.materials.append(mat)
            uv=mesh.uv_layers.new(name='Painted diffuse')
            for poly,(color,bounds) in zip(mesh.polygons,self.projections):
                poly.material_index=0
                normal=poly.normal;major=max(range(3),key=lambda i:abs(normal[i]))
                axes=[i for i in range(3) if i!=major]
                for loop in poly.loop_indices:
                    p=mesh.vertices[mesh.loops[loop].vertex_index].co
                    a,b=[(p[i]-bounds[i][0])/max(.001,bounds[i][1]-bounds[i][0]) for i in axes]
                    uv.data[loop].uv=tile_uv(color,max(0,min(1,a)),max(0,min(1,b)))
            obj['art_stage']=__import__('os').environ.get('FYW_ART_STAGE','proof');obj['art_construction']='Original closed lofts and painted diffuse'
            return obj
    return Painted

def face(m, feminine=False):
    # Six-and-a-half-head proportions. Separate solid nose, ears, eyelids and
    # grouped hair; eye whites prevent the old black-hole facial appearance.
    m.loft([(1.39,0,0,.065,.072),(1.44,.018,0,.112,.098),
            (1.54,0,0,.132,.128),(1.64,-.014,0,.122,.124),
            (1.70,-.03,0,.065,.077)],'skin',12)
    m.loft([(1.27,-.018,0,.068,.072),(1.42,-.012,0,.065,.068)],'skin',8)
    for side in (-1,1):
        m.sphere((-.016,side*.127,1.54),(.045,.023,.062),'skin',8,4)
        # Angular solid eye whites stay closed after the small-face filter.
        m.box((.128,side*.061,1.586),(.027,.049,.028),'cream')
        # Solid eye accents must survive the native minimum-area triangulation.
        m.box((.143,side*.059,1.586),(.016,.026,.026),'ink')
        m.beam((.12,side*.029,1.618),(.107,side*.094,1.624),.019,'hair')
    m.loft([(1.513,.132,0,.033,.022),(1.535,.145,0,.035,.027),
            (1.605,.127,0,.017,.013)],'skin',6)
    m.box((.131,0,1.477),(.022,.055,.016),'red')
    m.loft([(1.625,-.044,0,.106,.127),(1.695,-.035,0,.12,.126),
            (1.75,-.065,0,.075,.095)],'hair',10)
    for side in (-1,1):
        m.loft([(1.49,-.09,side*.08,.047,.046),(1.62,-.074,side*.092,.067,.059),
                (1.70,-.043,side*.06,.07,.069)],'hair',7)
    # A continuous nape makes the ordinary follow-camera rear view intentional.
    m.loft([(1.46,-.107,0,.043,.093),(1.58,-.112,0,.061,.119),
            (1.685,-.080,0,.066,.108)],'hair',10)
    m.blade([(-.112,1.661),(.05,1.751),(.114,1.713),(.017,1.635)],.074,.062,'hair')
    if feminine:
        m.loft([(1.20,-.112,0,.061,.086),(1.45,-.117,0,.076,.109),
                (1.65,-.09,0,.078,.109)],'hair',10)

def hand(m, x, y, z):
    m.loft([(z-.075,x+.012,y,.042,.047),(z-.01,x,y,.042,.058),(z+.055,x,y,.038,.041)],'skin',8)
    # Two grouped fingers and an opposed thumb survive ordinary view distance.
    for dy in (-.022,.023):m.sphere((x+.016,y+dy,z-.083),(.039,.022,.039),'skin',6,4)
    m.sphere((x+.041,y-.045,z-.003),(.031,.029,.042),'skin',6,4)

def limb(M, name, side, arm=False):
    m=M()
    if arm:
        m.loft([(-.36,.012,0,.068,.066),(-.19,0,side*.018,.079,.072),(0,0,0,.1,.096)],'blue',8)
        m.loft([(-.42,.014,0,.057,.057),(-.36,.012,0,.069,.067)],'cream',8)
        m.loft([(-.56,.022,0,.045,.047),(-.42,.014,0,.051,.054)],'skin',8)
        hand(m,.035,0,-.58)
    else:
        m.loft([(-.68,0,0,.071,.078),(-.40,-.013,0,.083,.086),
                (-.30,.025,0,.094,.1),(0,0,0,.105,.11)],'brown',8)
        m.loft([(-.75,0,0,.079,.084),(-.68,0,0,.081,.084)],'brown',8)
        m.loft([(-.81,.071,0,.165,.089),(-.74,.047,0,.14,.093),
                (-.68,0,0,.078,.074)],'hair',8)
        m.box((.07,0,-.817),(.335,.184,.027),'ink')
    obj=m.object(name,visibility=250,kind='platform')
    obj['wf_Moves Between Rooms']='True'
    obj['art_pivot']='shoulder' if arm else 'hip'
    return obj

def traveler(M, location):
    m=M()
    m.loft([(.77,0,0,.13,.177),(.94,0,0,.133,.173)],'brown',10)
    m.loft([(.92,0,0,.144,.2),(1.10,0,0,.129,.2),(1.25,-.008,0,.133,.25),
            (1.32,-.022,0,.105,.205)],'blue',10)
    m.box((.133,0,1.11),(.035,.16,.36),'cream')
    for side in (-1,1):
        m.beam((.13,side*.12,.94),(.146,side*.092,1.27),.025,'blue')
        m.beam((.151,side*.07,1.23),(.126,side*.14,1.29),.048,'blue')
    m.box((.137,0,.93),(.037,.305,.045),'hair')
    m.box((.16,0,.93),(.022,.052,.042),'gold')
    # Thick original satchel and diagonal strap, including a rear continuation.
    m.loft([(.65,-.023,-.249,.071,.095),(.87,-.023,-.25,.076,.098),
            (.94,-.023,-.24,.064,.085)],'brown',8)
    m.beam((.166,-.215,.87),(.149,.176,1.28),.045,'brown')
    m.beam((-.143,-.215,.87),(-.148,.176,1.28),.045,'brown')
    m.box((.06,-.255,.89),(.023,.14,.05),'hair')
    face(m)
    return m.object('traveler',location,kind='platform')

def goddess(M, location):
    m=M()
    m.loft([(.065,0,0,.255,.36),(.18,0,0,.235,.34),(.64,-.015,0,.205,.286),
            (.95,-.006,0,.142,.204),(1.12,0,0,.145,.22),(1.27,-.016,0,.135,.25),
            (1.33,-.022,0,.09,.16)],'cream',12)
    for side in (-1,1):
        if side>0:
            # One welcoming palm is visible at ordinary encounter distance.
            m.loft([(.86,.20,.42,.075,.068),(1.02,.085,.34,.097,.084),
                    (1.24,0,.26,.095,.096)],'cream',8)
            m.box((.245,.434,.825),(.15,.119,.042),'skin')
            for dy in (-.035,.025):
                m.beam((.29,.434+dy,.827),(.405,.44+dy,.854),.036,'skin')
            m.beam((.235,.378,.82),(.30,.343,.83),.038,'skin')
            m.loft([(.84,.20,.42,.079,.073),(.875,.19,.415,.08,.073)],'gold',8)
        else:
            m.loft([(.79,.11,side*.33,.072,.065),(1.01,.045,side*.32,.10,.087),
                    (1.24,0,side*.26,.095,.096)],'cream',8)
            hand(m,.129,side*.33,.74)
        m.loft([(.055,.125,side*.17,.156,.095),(.12,.08,side*.17,.107,.087)],'skin',8)
        m.beam((.16,side*.17,.075),(.2,side*.17,.1),.035,'gold')
    face(m,True)
    m.loft([(.945,0,0,.147,.21),(1.00,0,0,.153,.216)],'gold',12)
    m.sphere((.169,0,.979),(.025,.062,.055),'gold',8,4)
    # Broad closed folds rather than coplanar strips, held clear of the gown.
    for side in (-1,1):
        m.beam((.25,side*.29,.12),(.172,side*.15,.95),.04,'gold')
        m.beam((.16,side*.155,1.31),(.163,0,1.02),.036,'gold')
    m.cone((-.032,0,1.697),.133,.035,'gold',sides=12)
    for i in range(12):
        a=i*math.tau/12;b=(i+1)*math.tau/12
        # Halo in YZ, behind the head and outward with substantial edge width.
        m.beam((-.16,.225*math.cos(a),1.665+.225*math.sin(a)),
               (-.16,.225*math.cos(b),1.665+.225*math.sin(b)),.036,'gold')
    m.sphere((.125,0,1.743),(.023,.042,.06),'gold',6,4)
    return m.object('Goddess',location,kind='platform')

def wing(M, side, location):
    m=M()
    for i in range(7):
        root=(side*(.06+i*.055),-.09+i*.034)
        tip=(side*(.64+i*.078),.09+i*.135)
        outline=[root,(side*(.36+i*.035),-.23+i*.055),tip,
                 (side*(.50+i*.047),.16+i*.091)]
        m.blade(outline,-.06-i*.012,.055,'gold')
        m.beam((-.022-i*.012,root[0],root[1]),
               (-.022-i*.012,tip[0]*.87,tip[1]*.90),.031,'gold')
    m.loft([(-.17,0,0,.09,.09),(.05,0,side*.07,.1,.095),(.3,-.01,side*.15,.073,.076)],'gold',8)
    obj=m.object('GoddessWing'+('L' if side<0 else 'R'),location,kind='platform')
    obj.rotation_euler.z=-math.pi/2;obj['art_pivot']='wing root'
    return obj

def dress_proof(M, cube, scene, out, paper_material):
    """Local corner kit; new decorative platforms don't change narrative gates."""
    objects=[]
    # Temple detail stays off the three-unit central circulation strip.
    m=M()
    for z,r,h in ((.06,.52,.12),(.18,.43,.15),(.33,.30,2.90),(3.23,.40,.17),(3.40,.53,.20)):
        m.cone((0,0,z),r,h,'stone' if z<.33 else 'cream',sides=12)
    for z in (.34,3.18,3.42):m.cone((0,0,z),.41,.055,'gold',sides=12)
    obj=m.object('proof_temple_column',(-3.8,2,0),visibility=207);objects.append(obj)
    m=M()
    for i in range(24):
        a=i*math.tau/24;b=(i+1)*math.tau/24
        m.beam((2.0*math.cos(a),-3+2.0*math.sin(a),.034),
               (2.0*math.cos(b),-3+2.0*math.sin(b),.034),.036,'gold')
    for i in range(8):
        a=i*math.tau/8
        m.beam((.3*math.cos(a),-3+.3*math.sin(a),.035),
               (1.5*math.cos(a),-3+1.5*math.sin(a),.035),.043,'blue')
    objects.append(m.object('proof_temple_mosaic',visibility=206))
    # Door/facade kit lies against the west street wall, outside encounter radii.
    m=M()
    for y in (-1.59,1.59):m.box((0,y,1.7),(.19,1.32,3.4),'plaster')
    m.box((0,0,2.92),(.19,1.86,.96),'plaster')
    m.box((-.06,0,1.13),(.05,1.42,2.26),'ink')
    for y in (-.81,.81):m.box((.13,y,1.17),(.23,.16,2.34),'stone')
    m.box((.13,0,2.36),(.23,1.78,.20),'stone')
    for y in (-1.57,1.57):
        m.box((.16,y,2.53),(.09,.78,.75),'glass')
        for dy in (-.44,.44):m.box((.24,y+dy,2.53),(.1,.075,.90),'brown')
        for z in (2.1,2.95):m.box((.24,y,z),(.1,.95,.075),'brown')
        m.box((.25,y,2.53),(.1,.055,.83),'brown')
    objects.append(m.object('proof_love_facade',(91,5,.12)))
    m=M();m.box((0,.70,1.13),(.13,1.4,2.26),'green')
    for z in (.57,1.67):
        m.box((.078,.70,z),(.04,1.13,.78),'brown')
        m.box((.104,.70,z),(.025,.91,.57),'green')
    for z in (.35,1.9):m.box((.088,.08,z),(.04,.10,.17),'steel')
    m.sphere((.13,1.2,1.12),(.035,.06,.045),'gold',8,4)
    door=m.object('proof_love_door',(91.21,4.3,.12),kind='platform');door['art_pivot']='west hinge';objects.append(door)
    m=M()
    for x in (-.88,.88):
        m.box((x,0,.27),(.11,.53,.54),'ink')
        m.beam((x,.19,.35),(x,.28,.96),.09,'ink')
        m.box((x,0,.69),(.13,.68,.07),'ink')
    for y in (-.20,0,.20):m.box((0,y,.55),(2.1,.16,.10),'brown')
    for z in (.72,.87,1.02):m.box((0,.3,z),(2.1,.09,.11),'brown')
    objects.append(m.object('proof_love_bench',(106,6,.12)))
    # Replace only the old six decorative ink bars; canonical reading sheet stays.
    paper=scene.objects.get('newspaper');old=paper.data
    m=M();m.box((0,0,.6),(1.1,.75,1.2),'blue')
    m.box((0,-.39,.84),(.73,.04,.26),'ink')
    m.box((0,0,1.21),(1.18,.83,.05),'steel')
    temp=m.object('proof_paper_machine');paper.data=temp.data
    import bpy
    bpy.data.objects.remove(temp,do_unlink=True)
    m=M();m.box((0,0,0),(1.06,.76,.017),'paper')
    leaf=m.object('proof_newspaper_leaf',(100,7,1.253));leaf.data.materials.append(paper_material)
    uv=leaf.data.uv_layers.active
    for poly in leaf.data.polygons:
        if poly.normal.z>.9:
            poly.material_index=1
            for loop in poly.loop_indices:
                p=leaf.data.vertices[leaf.data.loops[loop].vertex_index].co
                uv.data[loop].uv=((p.x+.53)/1.06,(p.y+.38)/.76)
    objects.extend([paper,leaf])
    return objects
