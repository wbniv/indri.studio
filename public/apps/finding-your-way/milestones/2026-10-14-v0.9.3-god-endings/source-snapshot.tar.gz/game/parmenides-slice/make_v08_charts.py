#!/usr/bin/env python3
"""Build the self-contained HTML charts for the v0.8 optimization plan.

Reads the Phase 0 evidence (``report.json`` from ``report_frame_profile.py`` and
``windows.json``, one row per 5 s profile window) and writes three charts into the
plan's co-named bundle directory, ``docs/plans/2026-10-07-v0.8-optimization/``:

* ``frame-budget.html``        where a frame's time goes per device and scene
* ``render-vs-triangles.html`` render CPU per frame against triangles per frame
* ``tour-timeline.html``       one cast1 tour, CPU per frame per window against the frame interval

Each chart is inline CSS/SVG/JS only (md-to-html embeds it as a sandboxed iframe),
designed to a 1440x900 canvas, with light and dark tokens, a legend, per-mark
tooltips and a table view. Colors follow the dataviz reference palette
(validated with its six-checks script on 2026-10-07).

Usage:
    make_v08_charts.py [--evidence DIR] [--out DIR]
"""
import argparse
import json
import statistics
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
EVIDENCE = ROOT / 'docs/diagnostics/parmenides/v0.8-optimization'
OUT = ROOT / 'docs/plans/2026-10-07-v0.8-optimization'

CSS = """
:root { color-scheme: light;
  --surface:#fcfcfb; --plane:#f9f9f7; --ink:#0b0b0b; --ink2:#52514e; --muted:#898781;
  --grid:#e1e0d9; --axis:#c3c2b7; --s1:#2a78d6; --s2:#eb6834; --s3:#1baf7a; --other:#c3c2b7;
  --border:rgba(11,11,11,.10); --tip:#ffffff; }
@media (prefers-color-scheme: dark) { :root:not([data-theme="light"]) { color-scheme: dark;
  --surface:#1a1a19; --plane:#0d0d0d; --ink:#ffffff; --ink2:#c3c2b7; --muted:#898781;
  --grid:#2c2c2a; --axis:#383835; --s1:#3987e5; --s2:#d95926; --s3:#199e70; --other:#55554f;
  --border:rgba(255,255,255,.10); --tip:#242423; } }
:root[data-theme="dark"] { color-scheme: dark;
  --surface:#1a1a19; --plane:#0d0d0d; --ink:#ffffff; --ink2:#c3c2b7; --muted:#898781;
  --grid:#2c2c2a; --axis:#383835; --s1:#3987e5; --s2:#d95926; --s3:#199e70; --other:#55554f;
  --border:rgba(255,255,255,.10); --tip:#242423; }
* { box-sizing: border-box; }
body { margin:0; width:1440px; height:900px; overflow:hidden; background:var(--plane); color:var(--ink);
  font: 15px/1.5 system-ui, -apple-system, "Segoe UI", sans-serif; }
header { padding: 26px 40px 10px; display:flex; align-items:flex-start; gap:24px; }
header h1 { margin:0; font-size:22px; font-weight:600; letter-spacing:-.01em; }
header p { margin:4px 0 0; color:var(--ink2); max-width: 980px; }
header .tools { margin-left:auto; display:flex; gap:8px; align-items:center; }
button { font: 600 13px system-ui, sans-serif; color:var(--ink); background:var(--surface);
  border:1px solid var(--border); border-radius:8px; padding:6px 12px; cursor:pointer; }
button[aria-pressed="true"] { background:var(--ink); color:var(--surface); }
figure { margin: 0 40px; background:var(--surface); border:1px solid var(--border); border-radius:12px;
  padding: 18px 24px 14px; height: 720px; position:relative; }
svg { display:block; width:100%; height:100%; }
svg text { font-family: system-ui, -apple-system, "Segoe UI", sans-serif; fill: var(--ink2); font-size: 13px; }
svg text.ink { fill: var(--ink); }
svg text.muted { fill: var(--muted); font-size: 12px; }
svg text.tick { fill: var(--muted); font-size: 12px; font-variant-numeric: tabular-nums; }
svg text.label { fill: var(--ink); font-weight: 600; }
svg text.inside { fill: #ffffff; font-weight: 600; font-size: 12.5px; }
svg .grid { stroke: var(--grid); stroke-width:1; }
svg .axis { stroke: var(--axis); stroke-width:1; }
svg .ref { stroke: var(--ink2); stroke-width:1; }
.legend { position:absolute; left:24px; top:14px; display:flex; gap:22px; font-size:13px; color:var(--ink2); }
.legend span { display:inline-flex; align-items:center; gap:8px; }
.legend i { display:inline-block; width:14px; height:14px; border-radius:3px; }
.legend i.line { height:2px; width:18px; border-radius:1px; }
.tip { position:absolute; display:none; pointer-events:none; background:var(--tip); color:var(--ink);
  border:1px solid var(--border); border-radius:8px; padding:8px 10px; font-size:13px; line-height:1.35;
  box-shadow: 0 4px 16px rgba(0,0,0,.14); min-width: 160px; }
.tip b { font-size:15px; }
.tip .row { display:flex; justify-content:space-between; gap:16px; }
.tip .row span:first-child { color:var(--ink2); }
table { display:none; width:100%; border-collapse:collapse; font-size:13px; font-variant-numeric: tabular-nums; }
th, td { text-align:right; padding:5px 10px; border-bottom:1px solid var(--grid); }
th:first-child, td:first-child, th.l, td.l { text-align:left; }
th { color:var(--ink2); font-weight:600; position:sticky; top:0; background:var(--surface); }
.tablewrap { display:none; position:absolute; inset:18px 24px 14px; overflow:auto; }
figure.table .tablewrap { display:block; } figure.table .tablewrap table { display:table; }
figure.table svg, figure.table .legend { visibility:hidden; }
footer { padding: 10px 40px 0; color:var(--muted); font-size:12.5px; }
.hit { fill: transparent; }
"""

JS_COMMON = """
const NS='http://www.w3.org/2000/svg';
function el(tag, attrs, parent){ const e=document.createElementNS(NS,tag); for(const k in attrs){ e.setAttribute(k, attrs[k]); } if(parent) parent.appendChild(e); return e; }
function text(x,y,str,cls,anchor,parent){ const t=el('text',{x,y,'text-anchor':anchor||'start'},parent); if(cls) t.setAttribute('class',cls); t.textContent=str; return t; }
const tip=document.querySelector('.tip');
function showTip(rows, px, py){ tip.replaceChildren(); rows.forEach((r,i)=>{ const d=document.createElement('div'); if(i===0){ const b=document.createElement('b'); b.textContent=r[0]; d.appendChild(b);} else { d.className='row'; const a=document.createElement('span'); a.textContent=r[0]; const v=document.createElement('span'); v.textContent=r[1]; d.append(a,v);} tip.appendChild(d); }); tip.style.display='block'; const fig=document.querySelector('figure').getBoundingClientRect(); let x=px-fig.left+14, y=py-fig.top+14; if(x+tip.offsetWidth>fig.width-20) x=px-fig.left-tip.offsetWidth-14; if(y+tip.offsetHeight>fig.height-20) y=py-fig.top-tip.offsetHeight-14; tip.style.left=x+'px'; tip.style.top=y+'px'; }
function hideTip(){ tip.style.display='none'; }
document.getElementById('tbl').addEventListener('click', e=>{ const f=document.querySelector('figure'); const on=f.classList.toggle('table'); e.currentTarget.setAttribute('aria-pressed', on?'true':'false'); });
document.getElementById('theme').addEventListener('click', e=>{ const r=document.documentElement; const dark=r.getAttribute('data-theme')==='dark' || (!r.getAttribute('data-theme') && matchMedia('(prefers-color-scheme: dark)').matches); r.setAttribute('data-theme', dark?'light':'dark'); });
function fmt(n,d){ return n==null?'—':Number(n).toLocaleString('en-US',{maximumFractionDigits:d==null?1:d, minimumFractionDigits:d==null?1:d}); }
function fmt0(n){ return n==null?'—':Math.round(n).toLocaleString('en-US'); }
function textWidth(s, size){ return s.length*(size||13)*0.56; }
"""


def page(title, subtitle, body_js, legend_html, table_html, footer, data):
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>{title}</title>
<style>{CSS}</style>
</head>
<body>
<header>
  <div><h1>{title}</h1><p>{subtitle}</p></div>
  <div class="tools"><button id="tbl" aria-pressed="false">Table view</button><button id="theme">Light / dark</button></div>
</header>
<figure>
  <div class="legend">{legend_html}</div>
  <svg viewBox="0 0 1352 688" preserveAspectRatio="xMinYMin meet" role="img" aria-label="{title}"></svg>
  <div class="tablewrap">{table_html}</div>
  <div class="tip" role="status"></div>
</figure>
<footer>{footer}</footer>
<script>
const DATA = {json.dumps(data, separators=(',', ':'))};
{JS_COMMON}
{body_js}
</script>
</body>
</html>
"""


def median(values):
    return statistics.median(values) if values else None


def frame_budget(report):
    rows = {r['label'] + '|' + r['device']['model']: r for r in report}

    def cls(model, label_prefix, phase):
        return [r['classes'][phase] for r in report
                if r['device']['model'] == model and r['label'].startswith(label_prefix) and phase in r.get('classes', {})]

    def agg(group):
        return dict(fps=median([g['fps'] for g in group]), update=median([g['cpu_ms']['update'] for g in group]),
                    render=median([g['cpu_ms']['render'] for g in group]), total=median([g['cpu_ms']['total'] for g in group]),
                    draws=median([g['counters']['draws'] for g in group]), tris=median([g['counters']['triangles'] for g in group]))

    bars = [
        dict(name='Chromecast HD · v0.7 tours, world scenes', note='median of five tour fixtures', **agg(cls('Chromecast HD', 'tour', 'world'))),
        dict(name='Chromecast HD · v0.7 reading sheet', note='production app, idle', **agg(cls('Chromecast HD', 'production', 'world') or cls('Chromecast HD', 'production', 'sheet'))),
        dict(name='Chromecast 4K · D God held scene', note='v0.6 D fixture, before polish', **agg(cls('Chromecast', 'held', 'world'))),
        dict(name='Pixel 8 Pro · v0.7 tour, world scenes', note='group 1 view 1', **agg(cls('Pixel 8 Pro', 'tour', 'world'))),
    ]
    for b in bars:
        b['interval'] = 1000 / b['fps']
        b['other'] = max(0.0, b['interval'] - b['total'])
    table = ['<table><thead><tr><th class="l">Workload</th><th>Frame interval ms</th><th>Window fps</th><th>update CPU ms</th><th>render CPU ms</th><th>total CPU ms</th><th>swap wait and other ms</th><th>Draws</th><th>Triangles</th></tr></thead><tbody>']
    for b in bars:
        table.append(f"<tr><td class=\"l\">{b['name']}</td><td>{b['interval']:.1f}</td><td>{b['fps']:.1f}</td><td>{b['update']:.1f}</td><td>{b['render']:.1f}</td><td>{b['total']:.1f}</td><td>{b['other']:.1f}</td><td>{b['draws']:.0f}</td><td>{b['tris']:,.0f}</td></tr>")
    table.append('</tbody></table>')
    js = """
const svg=document.querySelector('svg'); const W=1352, H=688, L=330, R=190, T=70, B=60;
const maxMs=85; const x=v=>L+(v/maxMs)*(W-L-R);
const rowH=(H-T-B)/DATA.length; const bar=24;
for(let v=0; v<=80; v+=10){ el('line',{x1:x(v),x2:x(v),y1:T-8,y2:H-B,class:'grid'},svg); text(x(v),H-B+22,v+' ms','tick','middle',svg); }
el('line',{x1:L,x2:L,y1:T-8,y2:H-B,class:'axis'},svg);
[[1000/60,'60 fps budget'],[1000/30,'30 fps budget']].forEach(([v,l])=>{ el('line',{x1:x(v),x2:x(v),y1:T-30,y2:H-B,class:'ref'},svg); text(x(v),T-36,l,'ink','middle',svg); });
const segs=[['update','--s1','update'],['render','--s2','render'],['other','--other','swap wait and other threads']];
DATA.forEach((b,i)=>{
  const cy=T+rowH*i+rowH/2;
  text(L-16,cy-4,b.name,'label','end',svg); text(L-16,cy+16,b.note,'muted','end',svg);
  let acc=0;
  segs.forEach(([k,c,name],si)=>{
    const v=b[k]; if(v<=0) return; const x0=x(acc), x1=x(acc+v); const last=(si===segs.length-1)||(segs.slice(si+1).every(s=>b[s[0]]<=0));
    const w=Math.max(0,x1-x0-(last?0:2));
    const r=el('path',{d:roundRight(x0,cy-bar/2,w,bar,last?4:0),fill:'var('+c+')'},svg);
    const lbl=fmt(v)+' ms'; if(w>=textWidth(lbl,12.5)+16 && k!=='other') text(x0+w/2,cy+4.5,lbl,'inside','middle',svg);
    const hit=el('rect',{x:x0,y:cy-rowH/2+4,width:Math.max(w+2,8),height:rowH-8,class:'hit'},svg);
    hit.addEventListener('pointermove',e=>{ r.setAttribute('opacity','0.82'); showTip([[name+': '+fmt(v)+' ms per frame'],['workload',b.name],['frame interval',fmt(b.interval)+' ms ('+fmt(b.fps)+' fps)'],['update',fmt(b.update)+' ms'],['render',fmt(b.render)+' ms'],['draws / triangles',fmt0(b.draws)+' / '+fmt0(b.tris)]],e.clientX,e.clientY); });
    hit.addEventListener('pointerleave',()=>{ r.removeAttribute('opacity'); hideTip(); });
    acc+=v;
  });
  text(x(b.interval)+10,cy+4.5,fmt(b.interval)+' ms · '+fmt(b.fps)+' fps','label','start',svg);
});
function roundRight(x,y,w,h,r){ if(r===0||w<r*2) return `M${x},${y}h${w}v${h}h${-w}z`; return `M${x},${y}h${w-r}a${r},${r} 0 0 1 ${r},${r}v${h-2*r}a${r},${r} 0 0 1 ${-r},${r}h${-(w-r)}z`; }
"""
    legend = ('<span><i style="background:var(--s1)"></i>update CPU</span>'
              '<span><i style="background:var(--s2)"></i>render CPU</span>'
              '<span><i style="background:var(--other)"></i>swap wait and other threads</span>')
    return page('Where a frame goes', 'Main-thread CPU per frame by engine section, drawn to the measured frame interval. Budgets for 30 fps and 60 fps are the vertical rules. '
                'The Chromecast HD spends four fifths of its world frame in the render section and the whole of its reading-sheet frame in the update phase; the Pixel has room to spare.',
                js, legend, ''.join(table),
                'Source: docs/diagnostics/parmenides/v0.8-optimization/report.json, 2026-10-07, median 5 s profile window per class; frame interval = 1000 / window fps.', bars)


def render_vs_triangles(windows):
    devs = ['Chromecast HD', 'Chromecast 4K', 'Pixel 8 Pro']
    fits = {}
    for d in devs:
        pts = [(w['tris'], w['render']) for w in windows if w['dev'] == d and w['tris'] > 0]
        n = len(pts); mx = sum(p[0] for p in pts) / n; my = sum(p[1] for p in pts) / n
        a = sum((p[0] - mx) * (p[1] - my) for p in pts) / sum((p[0] - mx) ** 2 for p in pts); b = my - a * mx
        ss = sum((p[1] - (a * p[0] + b)) ** 2 for p in pts); st = sum((p[1] - my) ** 2 for p in pts)
        fits[d] = dict(a=a, b=b, r2=1 - ss / st, n=n)
    table = ['<table><thead><tr><th class="l">Device</th><th class="l">Workload</th><th>Window</th><th>Triangles</th><th>Draws</th><th>Actors</th><th>render CPU ms</th><th>update CPU ms</th><th>Window fps</th></tr></thead><tbody>']
    for w in windows:
        table.append(f"<tr><td class=\"l\">{w['dev']}</td><td class=\"l\">{w['wl']}</td><td>{w['i']}</td><td>{w['tris']:,}</td><td>{w['draws']}</td><td>{w['actors']}</td><td>{w['render']:.2f}</td><td>{w['update']:.2f}</td><td>{w['fps']:.1f}</td></tr>")
    table.append('</tbody></table>')
    js = """
const svg=document.querySelector('svg'); const W=1352, H=688, L=80, R=330, T=60, B=64;
const maxX=20000, maxY=65; const x=v=>L+(v/maxX)*(W-L-R); const y=v=>H-B-(v/maxY)*(H-T-B);
const color={'Chromecast HD':'--s1','Chromecast 4K':'--s2','Pixel 8 Pro':'--s3'};
for(let v=0; v<=maxY; v+=10){ el('line',{x1:L,x2:W-R,y1:y(v),y2:y(v),class:'grid'},svg); text(L-10,y(v)+4,v,'tick','end',svg); }
for(let v=0; v<=maxX; v+=5000){ el('line',{x1:x(v),x2:x(v),y1:H-B,y2:H-B+6,class:'axis'},svg); text(x(v),H-B+24,v.toLocaleString('en-US'),'tick','middle',svg); }
el('line',{x1:L,x2:W-R,y1:H-B,y2:H-B,class:'axis'},svg);
text(L-10,T-22,'render CPU, ms per frame','muted','start',svg); text(W-R,H-B+44,'triangles per frame','muted','end',svg);
const fits=DATA.fits; const ends=[];
Object.keys(fits).forEach(d=>{ const f=fits[d]; const x0=0, x1=maxX; const y0=f.a*x0+f.b, y1=f.a*x1+f.b;
  el('line',{x1:x(x0),y1:y(Math.max(0,y0)),x2:x(x1),y2:y(y1),stroke:'var('+color[d]+')','stroke-width':2,'stroke-linecap':'round'},svg);
  ends.push({d, yEnd:y(y1), label:d+' · '+(f.a*1000).toFixed(2)+' µs per triangle', sub:'R² '+f.r2.toFixed(3)+', n = '+f.n}); });
ends.sort((p,q)=>p.yEnd-q.yEnd); let last=-99; ends.forEach(e=>{ let ly=Math.max(e.yEnd, last+40); e.ly=ly; last=ly; });
ends.forEach(e=>{ el('line',{x1:W-R+4,y1:e.yEnd,x2:W-R+24,y2:e.ly,class:'axis'},svg); text(W-R+30,e.ly+4,e.label,'label','start',svg); text(W-R+30,e.ly+22,e.sub,'muted','start',svg); });
const pts=DATA.windows.map(w=>({w, px:x(w.tris), py:y(w.render)}));
pts.forEach(p=>{ el('circle',{cx:p.px,cy:p.py,r:4.5,fill:'var('+color[p.w.dev]+')',stroke:'var(--surface)','stroke-width':2},svg); });
const hit=el('rect',{x:L,y:T,width:W-L-R,height:H-T-B,class:'hit'},svg); let ring=el('circle',{r:9,fill:'none',stroke:'var(--ink)','stroke-width':1.5,opacity:0},svg);
hit.addEventListener('pointermove',e=>{ const rect=svg.getBoundingClientRect(); const sx=(e.clientX-rect.left)*(W/rect.width), sy=(e.clientY-rect.top)*(H/rect.height); let best=null, bd=1e9; pts.forEach(p=>{ const d=Math.hypot(p.px-sx,p.py-sy); if(d<bd){bd=d;best=p;} }); if(!best||bd>40){ hideTip(); ring.setAttribute('opacity',0); return; } const w=best.w; ring.setAttribute('cx',best.px); ring.setAttribute('cy',best.py); ring.setAttribute('opacity',1);
  showTip([[fmt(w.render,2)+' ms render for '+w.tris.toLocaleString('en-US')+' triangles'],['device',w.dev],['workload',w.wl+' · window '+w.i],['draws / actors',w.draws+' / '+w.actors],['update CPU',fmt(w.update,2)+' ms'],['window fps',fmt(w.fps)]],e.clientX,e.clientY); });
hit.addEventListener('pointerleave',()=>{ hideTip(); ring.setAttribute('opacity',0); });
"""
    legend = ''.join(f'<span><i style="background:var(--s{i + 1})"></i>{d}</span>' for i, d in enumerate(devs))
    return page('Render CPU scales with triangles', 'Every 5 s profile window from the Phase 0 campaign: render-section CPU per frame against triangles per frame. '
                'A straight line through the origin means the cost is per face, on the CPU, not per screen pixel: the Chromecast HD pays about 3 µs for every triangle it transforms, the Pixel a quarter of a microsecond.',
                js, legend, ''.join(table),
                'Source: docs/diagnostics/parmenides/v0.8-optimization/windows.json, 209 windows across cast1, cast2 and the Pixel, 2026-10-07. Least-squares fit per device.',
                dict(windows=windows, fits=fits))


def tour_timeline(windows):
    wins = [w for w in windows if w['dev'] == 'Chromecast HD' and w['wl'] == 'tour-g0-v0']
    peak = max(w['tris'] for w in wins)
    for w in wins:
        w['phase'] = 'world' if w['tris'] >= 0.5 * peak else 'sheet'
        w['interval'] = 1000 / w['fps']
    table = ['<table><thead><tr><th>Window</th><th>Time s</th><th class="l">Phase</th><th>Window fps</th><th>Frame interval ms</th><th>update CPU ms</th><th>render CPU ms</th><th>total CPU ms</th><th>Draws</th><th>Triangles</th></tr></thead><tbody>']
    for w in wins:
        table.append(f"<tr><td>{w['i']}</td><td>{w['i'] * 5}</td><td class=\"l\">{w['phase']}</td><td>{w['fps']:.1f}</td><td>{w['interval']:.1f}</td><td>{w['update']:.2f}</td><td>{w['render']:.2f}</td><td>{w['total']:.2f}</td><td>{w['draws']}</td><td>{w['tris']:,}</td></tr>")
    table.append('</tbody></table>')
    js = """
const svg=document.querySelector('svg'); const W=1352, H=688, L=80, R=200, T=60, B=86;
const n=DATA.length; const maxY=80; const slot=(W-L-R)/n; const bar=Math.min(24, slot-10);
const x=i=>L+slot*i+slot/2; const y=v=>H-B-(v/maxY)*(H-T-B);
for(let v=0; v<=maxY; v+=10){ el('line',{x1:L,x2:W-R,y1:y(v),y2:y(v),class:'grid'},svg); text(L-10,y(v)+4,v,'tick','end',svg); }
el('line',{x1:L,x2:W-R,y1:y(0),y2:y(0),class:'axis'},svg);
text(L-10,T-22,'milliseconds per frame','muted','start',svg);
[[1000/60,'60 fps'],[1000/30,'30 fps']].forEach(([v,l])=>{ el('line',{x1:L,x2:W-R,y1:y(v),y2:y(v),class:'ref'},svg); text(W-R+8,y(v)+4,l+' budget','ink','start',svg); });
DATA.forEach((w,i)=>{
  const cx=x(i); const u=el('rect',{x:cx-bar/2,y:y(w.update),width:bar,height:y(0)-y(w.update),fill:'var(--s1)'},svg);
  const rh=Math.max(0,y(w.update)-y(w.update+w.render)-2); const r=el('path',{d:roundTop(cx-bar/2,y(w.update+w.render),bar,rh,4),fill:'var(--s2)'},svg);
  if(i%2===0) text(cx,H-B+22,(i*5)+' s','tick','middle',svg);
  text(cx,H-B+44,w.phase==='sheet'?'sheet':'world','muted','middle',svg);
  const hit=el('rect',{x:cx-slot/2,y:T,width:slot,height:H-T-B,class:'hit'},svg);
  hit.addEventListener('pointermove',e=>{ u.setAttribute('opacity','0.82'); r.setAttribute('opacity','0.82'); showTip([['window '+w.i+' · '+(w.i*5)+'–'+(w.i*5+5)+' s · '+w.phase],['frame interval',fmt(w.interval)+' ms ('+fmt(w.fps)+' fps)'],['update CPU',fmt(w.update)+' ms'],['render CPU',fmt(w.render)+' ms'],['total CPU',fmt(w.total)+' ms'],['draws / triangles',w.draws+' / '+w.tris.toLocaleString('en-US')]],e.clientX,e.clientY); });
  hit.addEventListener('pointerleave',()=>{ u.removeAttribute('opacity'); r.removeAttribute('opacity'); hideTip(); });
});
const path=DATA.map((w,i)=>(i?'L':'M')+x(i)+','+y(Math.min(w.interval,maxY))).join(' ');
el('path',{d:path,fill:'none',stroke:'var(--s3)','stroke-width':2,'stroke-linejoin':'round','stroke-linecap':'round'},svg);
DATA.forEach((w,i)=>{ el('circle',{cx:x(i),cy:y(Math.min(w.interval,maxY)),r:4.5,fill:'var(--s3)',stroke:'var(--surface)','stroke-width':2},svg); });
const lastW=DATA[n-1]; text(x(n-1)+14,y(lastW.interval)+4,'frame interval','label','start',svg);
text(x(n-1)+14,y(lastW.total)-8,'CPU total','label','start',svg);
function roundTop(x,y,w,h,r){ if(h<r*2) return `M${x},${y}h${w}v${h}h${-w}z`; return `M${x},${y+r}a${r},${r} 0 0 1 ${r},${-r}h${w-2*r}a${r},${r} 0 0 1 ${r},${r}v${h-r}h${-w}z`; }
"""
    legend = ('<span><i style="background:var(--s1)"></i>update CPU</span>'
              '<span><i style="background:var(--s2)"></i>render CPU</span>'
              '<span><i class="line" style="background:var(--s3)"></i>frame interval (1000 / window fps)</span>')
    return page('One tour on the Chromecast HD, window by window', 'v0.7 tour fixture group 0 view 0 on cast1, 5 s profile windows: update and render CPU per frame stacked, with the frame interval the TV actually achieved. '
                'Reading sheets run at 30–50 fps on the update phase alone; every world window costs about 65 ms of CPU and the frame interval follows it.',
                js, legend, ''.join(table),
                'Source: docs/diagnostics/parmenides/v0.8-optimization/cast1/tour-g0-v0/run-1/wf.log via windows.json, job J-0cb63602fbb7, 2026-10-07.', wins)


def frame_path_svg(report):
    """Hand-laid SVG of the per-frame path, annotated with the cast1 world-scene costs."""
    world = [r['classes']['world'] for r in report if r['device']['model'] == 'Chromecast HD' and r['label'].startswith('tour') and 'world' in r.get('classes', {})]
    fps = median([w['fps'] for w in world]); upd = median([w['cpu_ms']['update'] for w in world]); ren = median([w['cpu_ms']['render'] for w in world])
    draws = median([w['counters']['draws'] for w in world]); tris = median([w['counters']['triangles'] for w in world]); actors = median([w['counters']['render-actors'] for w in world])
    interval = 1000 / fps
    us_per_tri = 1000 * ren / tris; ms_per_draw = ren / draws
    W, H = 1240, 640
    ink, ink2, muted, line = '#0b0b0b', '#52514e', '#898781', '#c3c2b7'
    tints = dict(update=('#2a78d6', 'rgba(42,120,214,0.10)'), render=('#eb6834', 'rgba(235,104,52,0.10)'), swap=('#898781', 'rgba(137,135,129,0.10)'), frame=('#0b0b0b', '#f3f2ee'))
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}" role="img" aria-label="The per-frame path on the Chromecast HD with measured costs">',
           '<style>text{font-family:system-ui,-apple-system,"Segoe UI",sans-serif;font-size:13px;fill:#52514e}.t{font-weight:600;fill:#0b0b0b;font-size:14px}.n{font-weight:700;fill:#0b0b0b;font-size:15px}.m{fill:#898781;font-size:12px}</style>',
           f'<rect width="{W}" height="{H}" fill="#fcfcfb"/>',
           '<defs><marker id="a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="#898781"/></marker></defs>']

    def box(x, y, w, h, kind, title, number, lines):
        stroke, fill = tints[kind]
        out.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="8" fill="{fill}" stroke="{stroke}" stroke-width="1.2"/>')
        out.append(f'<rect x="{x}" y="{y}" width="4" height="{h}" rx="2" fill="{stroke}"/>')
        out.append(f'<text x="{x + 14}" y="{y + 22}" class="t">{title}</text>')
        if number:
            out.append(f'<text x="{x + w - 12}" y="{y + 22}" class="n" text-anchor="end">{number}</text>')
        for i, ln in enumerate(lines):
            out.append(f'<text x="{x + 14}" y="{y + 42 + 17 * i}">{ln}</text>')

    def arrow(x1, y1, x2, y2):
        out.append(f'<path d="M{x1},{y1} C{(x1 + x2) / 2},{y1} {(x1 + x2) / 2},{y2} {x2},{y2}" fill="none" stroke="{line}" stroke-width="1.4" marker-end="url(#a)"/>')

    out.append(f'<text x="24" y="30" class="t">One frame on the Chromecast HD, v0.7 world scene</text>')
    out.append(f'<text x="24" y="50" class="m">median of five tour fixtures, 2026-10-07 · boxes list the engine stage, its measured main-thread CPU and what inspection found there</text>')
    # column 1: the frame
    box(24, 260, 190, 120, 'frame', 'Frame', f'{interval:.0f} ms', [f'{fps:.0f} fps presented', f'{actors:.0f} actors rendered', f'{draws:.0f} draws, {tris:,.0f} triangles'])
    # column 2: the three stages
    box(290, 120, 250, 110, 'update', 'Level::update', f'{upd:.1f} ms', ['every frame, 441 objects,', 'about 950 mailbox writes', 'the floor under every scene'])
    box(290, 300, 250, 110, 'render', 'Level::RenderScene', f'{ren:.1f} ms', ['four fifths of the frame', 'Validate() six times per frame', 'plus per room and per light'])
    box(290, 480, 250, 96, 'swap', 'eglSwapBuffers', f'{max(0.0, interval - upd - ren):.1f} ms', ['wait for the next vsync:', 'the frame lands on the', '4th or 5th refresh'])
    arrow(214, 320, 290, 175); arrow(214, 320, 290, 355); arrow(214, 320, 290, 528)
    # column 3: what the update phase does
    box(610, 70, 290, 78, 'update', 'ActorStartFrame', '', ['one cached zForth word per', 'scripted actor, visible or not'])
    box(610, 160, 290, 78, 'update', 'Jolt step, prediction, collision', '', ['pairwise room list checks;', 'static world of ~45,000 vertices'])
    box(610, 250, 290, 60, 'update', 'updateRoomContents', '', ['all objects; the engine\'s own PERF note'])
    arrow(540, 175, 610, 109); arrow(540, 175, 610, 199); arrow(540, 175, 610, 280)
    # columns 3 and 4: the render chain, per actor then per face then per draw
    box(610, 330, 290, 78, 'render', 'per visible actor', '', ['gate is the visibility mailbox only;', 'no frustum or bounds rejection'])
    box(940, 330, 276, 78, 'render', 'RenderObject3D::Render', '', ['3 vertices per face, no sharing;', '4 asserts per face; UV divides'])
    box(940, 430, 276, 92, 'render', 'DrawTriangle', f'{us_per_tri:.1f} µs/tri', ['software back-face test,', 'pack and push 3 vertices', 'into a CPU vector'])
    box(610, 430, 290, 92, 'render', 'Flush per actor', f'{ms_per_draw:.2f} ms/draw', ['~12 glUniform calls,', 'glBufferData(STREAM) + glDrawArrays', f'{draws:.0f} draws per frame'])
    arrow(540, 355, 610, 369); arrow(900, 369, 940, 369); arrow(1078, 408, 1078, 430); arrow(940, 476, 900, 476)
    out.append(f'<text x="24" y="{H - 20}" class="m">Costs are medians of the five cast1 tour fixtures\' world windows (docs/diagnostics/parmenides/v0.8-optimization/report.json). Blue: update phase. Orange: render section. Gray: swap wait.</text>')
    out.append('</svg>')
    return '\n'.join(out) + '\n'


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.split('\n')[0])
    parser.add_argument('--evidence', type=Path, default=EVIDENCE)
    parser.add_argument('--out', type=Path, default=OUT)
    args = parser.parse_args(argv)
    report = json.loads((args.evidence / 'report.json').read_text())
    windows = json.loads((args.evidence / 'windows.json').read_text())
    args.out.mkdir(parents=True, exist_ok=True)
    for name, html in (('frame-budget', frame_budget(report)), ('render-vs-triangles', render_vs_triangles(windows)), ('tour-timeline', tour_timeline(windows))):
        path = args.out / f'{name}.html'
        path.write_text(html)
        print(f'{path} ({path.stat().st_size // 1024} KB)')
    svg = args.out / 'frame-path.svg'
    svg.write_text(frame_path_svg(report))
    print(f'{svg} ({svg.stat().st_size // 1024} KB)')
    return 0


if __name__ == '__main__':
    sys.exit(main())
