"""Replace surgery captures in the frozen author catalog/movie; reuse the rest.

Every reused screenshot keeps its original source-build identity. No unrelated
scene is recaptured. The original frozen comparison artifacts remain intact.
"""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

from make_review_media import slate

ROOT=Path(__file__).resolve().parent
PROJECT=ROOT.parents[1]
read=lambda p:json.loads(p.read_text())
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    p=argparse.ArgumentParser();p.add_argument('--evidence',type=Path,required=True);a=p.parse_args()
    e=a.evidence.resolve();old=PROJECT/'docs/diagnostics/parmenides/visual-baseline-review/share/v0.5.5'
    previous=read(old/'capture-manifest.json');assert previous['frozen']
    assert digest(old/previous['mp4'])==previous['sha256']
    native=e/'desktop/motion';render=read(native/'render-review.json')
    build=read(ROOT/'build/build-receipt.json');assert render['build']['sha256']==build['sha256']
    assert render['failed_sheet_frames']==0 and read(e/'delta-audit.json')['passed']
    out=e/'share/v0.5.5';out.mkdir(parents=True,exist_ok=True)
    if (out/'capture-manifest.json').exists() and read(out/'capture-manifest.json').get('frozen'):
        raise SystemExit('Corrected media is frozen; refusing overwrite')
    catalog=copy.deepcopy(read(old/'screenshot-catalog.json'));catalog['build']=build
    recipe=copy.deepcopy(read(old/'author-shot-list.json'))
    sources={};replaced=[]
    for row in catalog['shots']:
        target=out/row['file'];target.parent.mkdir(parents=True,exist_ok=True)
        row['source_build']=catalog.get('prior_build',previous['build'])
        if row['scene']!='surgery':
            shutil.copy2(old/row['file'],target);assert digest(target)==row['sha256']
            row['capture_status']='reused unchanged from frozen baseline'
            continue
        if row['kind']=='world':
            matching=[r for r in render['results'] if r['kind']=='world' and r['camera']==row['camera']]
            captured=matching[len(matching)//2]
            sources[row['id']]=dict(movie=native/'review.mp4',start=captured['video_time']-3,duration=6)
        else:
            captured=max((r for r in render['results'] if r['kind']=='sheet' and r['name']=='surgery' and r['camera']==row['camera'] and r.get('passed') and not r.get('presentation')),key=lambda r:r['video_time'])
            sources[row['id']]=dict(image=target)
        shutil.copy2(native/captured['file'],target)
        row.update(source_build=build,capture_status='recaptured for patient framing',sha256=digest(target),
                   source_video=str((native/'review.mp4').relative_to(PROJECT)),video_time=captured['video_time'])
        replaced.append(row['id'])
    assert set(replaced)=={'surgery.world.third','surgery.world.first','surgery.dialogue.1'}
    catalog.update(prior_build=previous['build'],replacement_scope='Three surgery entries replaced; every other screenshot reused with original provenance')
    (out/'screenshot-catalog.json').write_text(json.dumps(catalog,indent=2)+'\n')
    recipe['comparison']='Patient-framing correction: retain these semantic IDs, fixtures and durations for v0.6; unchanged frames retain earlier source provenance.'
    (out/'author-shot-list.json').write_text(json.dumps(recipe,indent=2)+'\n')
    movie=out/'author-review-v0.5.5.mp4'
    with tempfile.TemporaryDirectory(prefix='fyw-patient-movie-',dir='/tmp') as temp:
        temp=Path(temp);clips=[]
        for n,ch in enumerate(previous['chapters']):
            target=temp/f'{n:03d}.mp4';cmd=['ffmpeg','-v','error','-y']
            source=sources.get(ch['id'])
            if ch['id']=='review.introduction':
                intro=temp/'intro.png';slate(intro,'Author review — v0.5.5 patient framing',[
                    'Actual World Foundry prototype footage. Surgery views corrected; other shots reused from the frozen visual baseline.',
                    'Representative realm dialogue, complete ending accounts and only Both → surgery. Reading holds use actual captures.',
                    'Provisional art. Camera collision and phone acceptance remain open. Compare the same shot IDs after v0.6.'])
                source=dict(image=intro)
            if source and 'image' in source:
                cmd+=['-loop','1','-i',str(source['image'])]
            else:
                video=source['movie'] if source else old/previous['mp4']
                start=source['start'] if source else ch['start']
                cmd+=['-ss',str(start),'-i',str(video)]
            cmd+=['-vf','fps=30,scale=1280:720','-t',str(ch['duration']),'-an','-c:v','libx264','-threads','2','-preset','fast','-crf','20','-pix_fmt','yuv420p',str(target)]
            subprocess.run(cmd,check=True,timeout=180);clips.append(target)
        concat=temp/'concat.txt';concat.write_text(''.join("file '"+str(p)+"'\n" for p in clips))
        metadata=temp/'chapters.ffmetadata';metadata.write_text(';FFMETADATA1\n'+''.join('[CHAPTER]\nTIMEBASE=1/1000\nSTART='+str(int(c['start']*1000))+'\nEND='+str(int((c['start']+c['duration'])*1000))+'\ntitle='+c['id']+'\n' for c in previous['chapters']))
        subprocess.run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(concat),'-i',str(metadata),'-map_metadata','1','-map_chapters','1','-c','copy','-movflags','+faststart',str(movie)],check=True,timeout=120)
    videos={r['source_video']:digest(PROJECT/r['source_video']) for r in catalog['shots']}
    videos[str((old/previous['mp4']).relative_to(PROJECT))]=previous['sha256']
    manifest=dict(version='0.5.5',revision='patient-framing',build=build,mp4=movie.name,sha256=digest(movie),
                  duration=previous['duration'],chapters=previous['chapters'],source_videos=videos,
                  screenshot_catalog_sha256=digest(out/'screenshot-catalog.json'),shot_list_sha256=digest(out/'author-shot-list.json'),
                  strategic_replacement=dict(replaced_shots=replaced,reused_screenshots=len(catalog['shots'])-len(replaced),
                      prior_movie_sha256=previous['sha256'],prior_apk_sha256=previous['build']['sha256'],
                      movie_changes='Introduction and three surgery shots replaced; all other chapter intervals reused from prior movie and re-encoded without new capture'))
    (out/'capture-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (out/'author-feedback.md').write_text('# Author feedback\n\nUse a timestamp or semantic screenshot ID. Surgery views are corrected; other captures retain original provenance.\n\n| Timestamp / shot ID | Expected meaning | Observed issue | Suggested change |\n| --- | --- | --- | --- |\n| | | | |\n')
    rel=lambda path:Path(os.path.relpath(path,PROJECT/'docs/plans')).as_posix()
    doc=PROJECT/'docs/plans/2026-10-06-v0.5.5-patient-framing-ladder.md'
    lines=['# v0.5.5 patient framing: screenshot ladder and corrected author movie','',
           'Companion to [the implementation plan](2026-10-06-v0.5.5-patient-framing.md). This revision replaces three surgery catalog entries and their movie intervals. The other 100 screenshots are byte-identical copies from the frozen baseline, with their original build/video provenance retained. No other scene was recaptured.','',
           '```mermaid','flowchart LR','    A[Prior frozen catalog] --> B[Recapture surgery only]','    B --> C[Check faces, text and device lifecycle]','    C --> D[Replace three shots; reuse other 100]','    D --> E[Corrected v0.5.5 comparison for v0.6]','```','',
           '| View | Before | Corrected |','| --- | --- | --- |']
    for mode in ('third','first'):
        file=f'screenshots/surgery-world-{mode}.png'
        lines.append(f'| {mode} preference, upward patient shot | ![Before {mode}]({rel(old/file)}) | ![Corrected {mode}]({rel(out/file)}) |')
    lines+=['','## Completion ladder','',
            '- [x] Preserve prior archive, screenshots and movie.','- [x] Restrict Blender changes to surgeons and lamp.','- [x] Record targeted native world/source/completion intervals.','- [ ] Complete native and device review, then archive and republish.','',
            f'[Corrected author MP4]({rel(movie)}) · [Screenshot catalog manifest]({rel(out/"screenshot-catalog.json")}) · [Same semantic shot recipe]({rel(out/"author-shot-list.json")})','',
            'The movie keeps its 44 chapters and reading durations. Scene setup uses fixtures; this is an edited author review, not a continuous remote-driven playthrough. Camera collision, production graphics and phone acceptance remain open.','',
            '## Screenshot catalog','',
            '| Shot ID | Capture provenance | Screenshot |','| --- | --- | --- |']
    lines += [f'| `{r["id"]}` | {r["capture_status"]} | ![{r["id"]}]({rel(out/r["file"])}) |' for r in catalog['shots']]
    lines+=['','## Repeat after v0.6','',
            '- [ ] Recapture the same semantic shot IDs, source pages, viewpoints and histories after the graphics upgrade.','- [ ] Retain the same chapter order and reading durations; compare corresponding frames side by side.','- [ ] Keep both earlier v0.5.5 media revisions immutable and share the matching movie/catalog with the original author.','',
            'Authored with Codex. Exact tool/model version and reasoning-effort metadata were unavailable for verification.','']
    doc.write_text('\n'.join(lines));print(doc)

if __name__=='__main__':main()
