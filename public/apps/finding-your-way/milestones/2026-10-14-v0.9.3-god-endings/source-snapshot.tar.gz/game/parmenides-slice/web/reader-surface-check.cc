// Check actual baked metrics for every chapter heading and all reader sizes.
#include <game/bitmap_text.hp>
#include <fstream>
#include <iterator>
#include <vector>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <utility>
int main(int argc,char** argv){
 if(argc!=2)return 1;
 std::ifstream input(argv[1],std::ios::binary);
 std::vector<unsigned char> bytes{std::istreambuf_iterator<char>(input),{}};
 bitmaptext::Catalog catalog;const char* error=nullptr;
 if(!catalog.Load(bytes.data(),bytes.size(),error))return 1;
 const char* controls="SELECT: continue   LEFT / C: close   UP / DOWN: text size";
 for(auto surface:{std::pair<int,int>{960,720},{1280,720},{1440,1080},{1920,1080},{1440,3000}}){
  const int w=surface.first,h=surface.second;int minimum=999,checks=0;
  for(int factor:{2,3,4}){
   const int bp=(h<900?28:42)*factor/2,hp=(h<900?36:54)*factor/2,cp=(h<900?24:36)*factor/2;
   const int bi=catalog.SelectVariant(0,bp),hi=catalog.SelectVariant(1,hp),ci=catalog.SelectVariant(0,cp);
   const auto body=catalog.GetVariant(bi),heading=catalog.GetVariant(hi),control=catalog.GetVariant(ci);
   bitmaptext::Layout progress,help,title;const int usable=w-2*int(w*.04f+.5f);
   if(!progress.Wrap(catalog,ci,"256 / 256",9,usable,error)||!help.Wrap(catalog,ci,controls,strlen(controls),usable,error))return 1;
   bitmaptext::Text text;
   for(int id=1;catalog.GetText(id,text);id++){
    if(!title.Wrap(catalog,hi,text.title,text.titleBytes,usable-int(ceilf(progress.GetLine(0).width))-cp,error))return 1;
    const int capacity=(h-2*int(h*.04f+.5f)-title.LineCount()*heading.lineStep-help.LineCount()*control.lineStep-bp)/body.lineStep;
    if(capacity<1){fprintf(stderr,"FAIL reader fit %dx%d beat=%d body=%d\n",w,h,id,bp);return 1;}
    if(capacity<minimum)minimum=capacity;++checks;
   }
  }
  printf("PASS %dx%d: %d beat/size checks, minimum capacity %d line(s)\n",w,h,checks,minimum);
 }
}
