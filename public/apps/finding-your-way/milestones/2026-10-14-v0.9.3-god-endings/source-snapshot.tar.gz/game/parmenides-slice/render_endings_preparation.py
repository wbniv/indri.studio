"""Render the actual editable E preparation meshes, never claimed as WF frames."""
import argparse
import json
import math
from pathlib import Path
import sys

import bpy
from mathutils import Vector

p=argparse.ArgumentParser();p.add_argument('--build-dir',type=Path,required=True)
p.add_argument('--out',type=Path,required=True)
a=p.parse_args(sys.argv[sys.argv.index('--')+1:]);a.out.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(a.build_dir.resolve()/'parmenides_slice.blend'))
scene=bpy.context.scene
actors={o.name:o for o in scene.objects}
for obj in scene.objects:obj.hide_render=True
scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=4
scene.render.threads_mode='FIXED';scene.render.threads=2
scene.render.resolution_x=640;scene.render.resolution_y=480
scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG'
scene.view_settings.view_transform='Standard'
scene.world=bpy.data.worlds.new('E preparation neutral world');scene.world.use_nodes=True
scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.55,.57,.59,1)
scene.world.node_tree.nodes['Background'].inputs[1].default_value=.7
lights=[]
for power,size in ((450,5),(250,4)):
    data=bpy.data.lights.new('Preparation softbox','AREA');data.energy=power;data.shape='DISK';data.size=size
    obj=bpy.data.objects.new('Preparation softbox',data);scene.collection.objects.link(obj);lights.append(obj)
data=bpy.data.cameras.new('Preparation camera');data.type='PERSP';data.lens=32
camera=bpy.data.objects.new('Preparation camera',data);scene.collection.objects.link(camera);scene.camera=camera
rows=[]

def capture(name,names,position,target,ortho=None):
    for obj in actors.values():obj.hide_render=True
    for n in names:actors[n].hide_render=False
    data.type='ORTHO' if ortho else 'PERSP'
    patient=name in ('lamp-patient-position','surgery-patient-composition')
    scene.render.resolution_y=360 if patient else 480
    data.sensor_fit='VERTICAL' if patient else 'AUTO'
    data.lens=data.sensor_height/(2*math.tan(math.radians(30))) if patient else 32
    if ortho:data.ortho_scale=ortho
    camera.location=position;camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler()
    for light,offset in zip(lights,((3,-4,5),(-3,-1,3))):
        light.location=Vector(target)+Vector(offset)
        light.rotation_euler=(Vector(target)-light.location).to_track_quat('-Z','Y').to_euler()
    scene.render.filepath=str(a.out.resolve()/(name+'.png'));bpy.ops.render.render(write_still=True)
    rows.append(dict(file=name+'.png',actors=names,camera=position,target=target,
        representation='Actual Blender geometry/materials under review-only lighting; not a WF runtime capture'))

for i in range(1,4):
    obj=actors['surgeon_'+str(i)];origin=Vector(obj.location)
    for view,offset in (('patient',(0,-.20,1.30)),('side',(3.2,0,3.32)),('back',(0,3.2,3.32))):
        capture(f'surgeon-{i}-{view}',[obj.name],tuple(origin+Vector(offset)),tuple(origin+Vector((0,0,3.34))),2.45)
for view,offset in (('front',(0,-6,2.7)),('side',(6,0,2.7)),('back',(0,6,2.7))):
    capture('visage-'+view,['void_visage'],tuple(Vector((700,6,0))+Vector(offset)),(700,6,2.4),5.4)
capture('being-threshold',['being_ocean','being_ripples','being_light','being_threshold'],(510,-15,8),(500,0,2))
capture('both-passage',['both_floor','both_passage','both_triangles'],(600,-7,3.8),(600,3,2.8))
capture('closing-portal',['void_closing_portal'],(700,-10,3.2),(700,-4,2.1),6.4)
capture('surgical-lamp-underside',['surgical_lamp'],(798.15,1,2.5),(798.15,1,4.2),1.65)
capture('instrument-tray',['surgical_instrument_tray'],(803.4,-.4,2.6),(802,1,1),1.95)
capture('lamp-patient-position',['surgical_lamp','surgery_ceiling'],(800,-.6,.9),(800,.4,3.4))
capture('surgery-patient-composition',['surgeon_1','surgeon_2','surgeon_3','surgical_lamp','surgery_ceiling','surgical_instrument_tray'],
        (800,-.6,.9),(800,.4,3.4))
receipt_path=a.build_dir/'build-receipt.json'
receipt=json.loads(receipt_path.read_text()) if receipt_path.exists() else None
(a.out/'manifest.json').write_text(json.dumps(dict(stage='endings-surgery' if receipt else 'endings-surgery-preparation',build=receipt,
    scope='Actual editable geometry/materials under review lighting/cameras. Native motion, framing and route/device acceptance are separate evidence.',views=rows),indent=2)+'\n')
