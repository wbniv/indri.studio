#!/usr/bin/env python3
"""Rebuild a review fixture with a different engine Room layout and nothing else changed.

Copies the compiler inputs of an existing fixture directory (A), patches only the
Room objects (boxes, adjacency) of its ``parmenides_slice.lev`` and appends any new
Room and light objects to the end of the object list, so that every existing actor
index (and with it the Player script) is unchanged. It then compiles with the same
tool chain and arguments as ``build_review_fixtures.py``. With ``--apk`` it also writes
a fixture APK that is the A APK with only ``assets/cd.iff`` replaced, re-signed with
the same development key.

Layouts:
  control  no patch; the compiled cd.iff must equal A's byte for byte (tool check)
  chain4   temple+love+reason | truth | god | endings, chained truth-T-god-endings

The slot map that ``LevelRooms::InitRoomSlotMap`` (engine room/rooms.cc) will build
is simulated here, and the build fails if two rooms of any active set share a slot
or a slot exceeds the 3 default room-asset slots.

Usage:
    rooms_split.py --fixture A_DIR --out OUT_DIR --layout chain4 [--apk]
"""
import os
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
WF = Path(os.environ.get('FYW_WF_ROOT', '/home/will/WorldFoundry-wbniv'))
TOOLS = Path('/home/will/android-sdk-local/build-tools/34.0.0')
LEVEL = 'parmenides_slice'
NULL = -1
SLOTS = 3                 # DEFAULT_ACTIVE_ROOM_SLOTS (asset/assets.hp); no 'SLOT' field in the wrapper
MAX_ACTIVE_ROOMS = 9      # asset/assets.hp; the forward walk of InitRoomSlotMap wraps here
MAX_ADJ = 2               # oas/levelcon.h MAX_ADJACENT_ROOMS

# name: (box min x,y,z, max x,y,z), adjacency 1, adjacency 2, light templates to copy, light x offset
LAYOUTS = {
    'control': None,
    'chain4': dict(
        rooms=[('ChapterRoom', (-40, -40, -10, 245, 40, 50), 'GodRoom', 'TruthRoom'),
               ('GodRoom', (360, -40, -10, 450, 65, 50), 'ChapterRoom', 'EndingsRoom'),
               ('TruthRoom', (245, -40, -10, 340, 40, 50), 'ChapterRoom', ''),
               ('EndingsRoom', (450, -40, -10, 850, 65, 50), 'GodRoom', '')],
        lights=[('AmbientLight00', 'TruthDirectional', 300), ('Ambient', 'TruthAmbient', 300),
                ('GodDirectional', 'EndingsDirectional', 200), ('GodAmbient', 'EndingsAmbient', 200)]),
    # Best split that is also safe for the Player's render actor (constraint 7):
    # temple+love | reason+truth | god | being | both | notbeing | surgery.
    'safe7': dict(
        rooms=[('ChapterRoom', (-40, -40, -10, 146, 40, 50), 'GodRoom', 'ReasonTruthRoom'),
               ('GodRoom', (360, -40, -10, 450, 65, 50), 'ChapterRoom', ''),
               ('ReasonTruthRoom', (146, -40, -10, 340, 40, 50), 'ChapterRoom', 'GodRoom'),
               ('BeingRoom', (450, -40, -10, 550, 65, 50), 'GodRoom', ''),
               ('BothRoom', (550, -40, -10, 650, 65, 50), 'GodRoom', ''),
               ('NotbeingRoom', (650, -40, -10, 750, 65, 50), 'GodRoom', ''),
               ('SurgeryRoom', (750, -40, -10, 850, 65, 50), 'GodRoom', '')],
        lights=[('AmbientLight00', 'ReasonTruthDirectional', 246), ('Ambient', 'ReasonTruthAmbient', 246)]
               + [(src, room + kind, dx) for room, dx in (('Being', 100), ('Both', 200), ('Notbeing', 300), ('Surgery', 400))
                  for src, kind in (('GodDirectional', 'Directional'), ('GodAmbient', 'Ambient'))]),
    # One room per scene, assertion-free (rooms_optimise.py winner once three extra lists
    # are searched): temple lists god+love, god lists temple+truth, love lists temple+reason.
    'scene9': dict(
        rooms=[('ChapterRoom', (-40, -40, -10, 50, 40, 50), 'GodRoom', 'LoveRoom'),
               ('GodRoom', (360, -40, -10, 450, 65, 50), 'ChapterRoom', 'TruthRoom'),
               ('LoveRoom', (50, -40, -10, 146, 40, 50), 'ChapterRoom', 'ReasonRoom'),
               ('ReasonRoom', (146, -40, -10, 245, 40, 50), 'ChapterRoom', ''),
               ('TruthRoom', (245, -40, -10, 340, 40, 50), 'ChapterRoom', ''),
               ('BeingRoom', (450, -40, -10, 550, 65, 50), 'GodRoom', ''),
               ('BothRoom', (550, -40, -10, 650, 65, 50), 'GodRoom', ''),
               ('NotbeingRoom', (650, -40, -10, 750, 65, 50), 'GodRoom', ''),
               ('SurgeryRoom', (750, -40, -10, 850, 65, 50), 'GodRoom', '')],
        lights=None),
    # The winner of rooms_optimise.py (best weighted active faces with no engine or chapter
    # change): temple | love+reason | truth | god | being | both | notbeing | surgery.
    'best8': dict(
        rooms=[('ChapterRoom', (-40, -40, -10, 50, 40, 50), 'GodRoom', 'TruthRoom'),
               ('GodRoom', (360, -40, -10, 450, 65, 50), 'ChapterRoom', ''),
               ('LoveReasonRoom', (50, -40, -10, 245, 40, 50), 'ChapterRoom', ''),
               ('TruthRoom', (245, -40, -10, 340, 40, 50), 'ChapterRoom', 'LoveReasonRoom'),
               ('BeingRoom', (450, -40, -10, 550, 65, 50), 'GodRoom', ''),
               ('BothRoom', (550, -40, -10, 650, 65, 50), 'GodRoom', ''),
               ('NotbeingRoom', (650, -40, -10, 750, 65, 50), 'GodRoom', ''),
               ('SurgeryRoom', (750, -40, -10, 850, 65, 50), 'GodRoom', '')],
        lights=[('AmbientLight00', 'LoveReasonDirectional', 146), ('Ambient', 'LoveReasonAmbient', 146),
                ('AmbientLight00', 'TruthDirectional', 300), ('Ambient', 'TruthAmbient', 300)]
               + [(src, room + kind, dx) for room, dx in (('Being', 100), ('Both', 200), ('Notbeing', 300), ('Surgery', 400))
                  for src, kind in (('GodDirectional', 'Directional'), ('GodAmbient', 'Ambient'))]),
    # One room per scene plus two card rooms adjacent to every scene. Needs a chapter
    # change: hidden cards park at z = card_park_z (below every scene box) instead of 2.
    'hub11': dict(
        card_park_z=-30,
        # levcomp-rs omits the RMn chunk of a room with no room-chunk assets, but the engine
        # reads the TOC by room index (AssetManager::LoadRoomSlot, roomIndex + 3), so every
        # room must own one. All god-scene art is Moves Between Rooms (permanent); clear the
        # flag on one sign so GodRoom gets a chunk.
        mbr_off=['young_sign'],
        rooms=[('ChapterRoom', (-40, -40, -10, 50, 40, 50), 'CardsTRoom', 'CardsGRoom'),
               ('GodRoom', (360, -40, -10, 450, 65, 50), 'CardsTRoom', 'CardsGRoom'),
               ('LoveRoom', (50, -40, -10, 146, 40, 50), 'CardsTRoom', 'CardsGRoom'),
               ('ReasonRoom', (146, -40, -10, 245, 40, 50), 'CardsTRoom', 'CardsGRoom'),
               ('TruthRoom', (245, -40, -10, 340, 40, 50), 'CardsTRoom', 'CardsGRoom'),
               ('BeingRoom', (450, -40, -10, 550, 65, 50), 'CardsTRoom', 'CardsGRoom'),
               ('BothRoom', (550, -40, -10, 650, 65, 50), 'CardsTRoom', 'CardsGRoom'),
               ('NotbeingRoom', (650, -40, -10, 750, 65, 50), 'CardsTRoom', 'CardsGRoom'),
               ('SurgeryRoom', (750, -40, -10, 850, 65, 50), 'CardsTRoom', 'CardsGRoom'),
               ('CardsTRoom', (-5, -7, -36, 5, 1, -24), 'CardsGRoom', ''),
               ('CardsGRoom', (395, -7, -36, 405, 1, -24), 'CardsTRoom', '')],
        lights=None),
    # Measurement only (per-scene room-stats): one room per scene as a plain x chain. It
    # ignores the card-parking constraint, so the chapter does not play correctly in it.
    'measure9': dict(
        rooms=[('ChapterRoom', (-40, -40, -10, 50, 40, 50), 'LoveRoom', ''),
               ('GodRoom', (360, -40, -10, 450, 65, 50), 'TruthRoom', 'BeingRoom'),
               ('LoveRoom', (50, -40, -10, 146, 40, 50), 'ChapterRoom', 'ReasonRoom'),
               ('ReasonRoom', (146, -40, -10, 245, 40, 50), 'LoveRoom', 'TruthRoom'),
               ('TruthRoom', (245, -40, -10, 340, 40, 50), 'ReasonRoom', 'GodRoom'),
               ('BeingRoom', (450, -40, -10, 550, 65, 50), 'GodRoom', 'BothRoom'),
               ('BothRoom', (550, -40, -10, 650, 65, 50), 'BeingRoom', 'NotbeingRoom'),
               ('NotbeingRoom', (650, -40, -10, 750, 65, 50), 'BothRoom', 'SurgeryRoom'),
               ('SurgeryRoom', (750, -40, -10, 850, 65, 50), 'NotbeingRoom', '')],
        lights=[(src, room + kind, dx)
                for room, dx, pair in (('Love', 96, 'T'), ('Reason', 196, 'T'), ('Truth', 300, 'T'), ('Being', 100, 'G'),
                                       ('Both', 200, 'G'), ('Notbeing', 300, 'G'), ('Surgery', 400, 'G'))
                for src, kind in ([('AmbientLight00', 'Directional'), ('Ambient', 'Ambient')] if pair == 'T'
                                  else [('GodDirectional', 'Directional'), ('GodAmbient', 'Ambient')])]),
}


LIGHTS_PER_SCENE = [(src, room + kind, dx)
                    for room, dx, pair in (('Love', 96, 'T'), ('Reason', 196, 'T'), ('Truth', 300, 'T'), ('Being', 100, 'G'),
                                           ('Both', 200, 'G'), ('Notbeing', 300, 'G'), ('Surgery', 400, 'G'))
                    for src, kind in ([('AmbientLight00', 'Directional'), ('Ambient', 'Ambient')] if pair == 'T'
                                      else [('GodDirectional', 'Directional'), ('GodAmbient', 'Ambient')])]


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def fx(v):
    return '%.16f(1.15.16)' % v


def split_objects(text):
    head, *objs = text.split("\n\t{ 'OBJ'")
    return head, objs


def obj_name(obj):
    return re.search(r"\{ 'NAME' \"([^\"]*)\" \}", obj).group(1)


def set_box(obj, box):
    new, n = re.subn(r"(\{ 'BOX3' \{ 'NAME' \"Global Bounding Box\" \} \{ 'DATA' )[^/]*(//)",
                     lambda m: m.group(1) + ' '.join(fx(v) for v in box) + '  ' + m.group(2), obj)
    assert n == 1, obj_name(obj)
    return new


def set_str(obj, field, value):
    new, n = re.subn(r"(\{ 'STR' \{ 'NAME' \"" + re.escape(field) + r"\" \} \{ 'STR' )\"[^\"]*\"",
                     lambda m: m.group(1) + json.dumps(value), obj)
    assert n == 1, (obj_name(obj), field)
    return new


def set_name(obj, name):
    return re.sub(r"\{ 'NAME' \"[^\"]*\" \}", "{ 'NAME' " + json.dumps(name) + " }", obj, count=1)


def shift_x(obj, dx):
    def repl(m):
        x = float(m.group(2).split('(')[0]) + dx
        return m.group(1) + fx(x)
    new, n = re.subn(r"(\{ 'VEC3' \{ 'NAME' \"Position\" \} \{ 'DATA' )(\S+)", repl, obj)
    assert n == 1, obj_name(obj)
    return new


def set_z(obj, z):
    new, n = re.subn(r"(\{ 'VEC3' \{ 'NAME' \"Position\" \} \{ 'DATA' \S+ \S+ )(\S+)", lambda m: m.group(1) + fx(z), obj)
    assert n == 1, obj_name(obj)
    return new


HIDE_OLD = '-3 INDEXOF_Y_POS 128 read-mailbox write-actor-mailbox 2 INDEXOF_Z_POS 128 read-mailbox write-actor-mailbox ;'


def patch(text, layout):
    if layout.get('card_park_z') is not None:
        assert text.count(HIDE_OLD) == 1, 'fy-hide-card text not found exactly once'
        text = text.replace(HIDE_OLD, HIDE_OLD.replace(' 2 INDEXOF_Z_POS', ' %g INDEXOF_Z_POS' % layout['card_park_z']))
    head, objs = split_objects(text)
    tail_marker = '\n}\n'
    assert objs[-1].endswith(tail_marker), 'unexpected .lev tail'
    objs[-1] = objs[-1][:-len(tail_marker)]
    names = [obj_name(o) for o in objs]
    template_room = objs[names.index('GodRoom')]
    added = []
    for n in layout.get('mbr_off', []):
        i = names.index(n)
        objs[i], k = re.subn(r"(\{ 'I32' \{ 'NAME' \"Moves Between Rooms\" \} \{ 'DATA' )1l \} \{ 'STR' \"True\" \}",
                             lambda m: m.group(1) + '0l } { \'STR\' "False" }', objs[i])
        assert k == 1, n
        added.append(n + ' (Moves Between Rooms cleared)')
    if layout.get('card_park_z') is not None:
        for i, n in enumerate(names):
            if re.fullmatch(r'card_\d+', n):
                objs[i] = set_z(objs[i], layout['card_park_z'])
    for name, box, adj1, adj2 in layout['rooms']:
        if name in names:
            i = names.index(name)
        else:
            objs.append(set_name(template_room, name)); names.append(name); i = len(objs) - 1; added.append(name)
        o = set_box(objs[i], box)
        o = set_str(o, 'Adjacent Room 1', adj1)
        objs[i] = set_str(o, 'Adjacent Room 2', adj2)
    for src, name, dx in layout['lights'] or LIGHTS_PER_SCENE:
        objs.append(shift_x(set_name(objs[names.index(src)], name), dx)); names.append(name); added.append(name)
    objs[-1] = objs[-1] + tail_marker
    return head + ''.join("\n\t{ 'OBJ'" + o for o in objs), added


def slot_map(rooms):
    """Port of LevelRooms::InitRoomSlotMap with its assertions."""
    idx = {r[0]: i for i, r in enumerate(rooms)}
    adj = [[idx[a] if a else NULL for a in (r[2], r[3])] for r in rooms]
    smap = [NULL] * len(rooms)
    problems, asserts = [], []
    for start in range(len(rooms)):
        if smap[start] != NULL:
            continue
        smap[start] = 0
        cur, slot = adj[start][1], 1
        while cur != NULL:
            if smap[cur] != NULL:
                asserts.append(f'forward walk re-marks {rooms[cur][0]} (AssertMsg in a DO_ASSERTIONS build)')
            smap[cur] = slot
            slot += 1
            if slot >= MAX_ACTIVE_ROOMS:
                slot = 0
            s, cur = cur, NULL
            for a in adj[s]:
                if a != NULL and smap[a] == NULL:
                    cur = a; break
        cur, slot = adj[start][0], MAX_ADJ
        while cur != NULL:
            if smap[cur] not in (NULL, slot):
                asserts.append(f'backward walk conflicts at {rooms[cur][0]} (AssertMsg in a DO_ASSERTIONS build)')
            smap[cur] = slot
            slot -= 1
            if slot < 0:
                slot = MAX_ADJ
            s, cur = cur, NULL
            for a in adj[s]:
                if a != NULL and smap[a] == NULL:
                    cur = a; break
    actives = {}
    for i, r in enumerate(rooms):
        active = [i] + [a for a in adj[i] if a != NULL]
        slots = [smap[a] for a in active]
        actives[r[0]] = dict(rooms=[rooms[a][0] for a in active], slots=slots)
        if len(set(slots)) != len(slots):
            problems.append(f'{r[0]}: active rooms share a slot {slots}')
        if max(slots) >= SLOTS:
            problems.append(f'{r[0]}: slot {max(slots)} >= {SLOTS} declared slots')
    return smap, actives, problems, asserts


def compile_level(out, isolate_rendering=False):
    tool = lambda n: WF / 'wftools' / (n + '-rs') / 'target/release' / n
    run = lambda *args: subprocess.run([str(a) for a in args], cwd=out, check=True,
                                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True).stdout
    log = run(tool('iffcomp'), '-binary', '-o=' + LEVEL + '.lev.bin', LEVEL + '.lev')
    log += run(tool('levcomp'), LEVEL + '.lev.bin', WF / 'wfsource/source/oas/objects.lc', LEVEL + '.lvl',
               WF / 'wfsource/source/oas', '--mesh-dir', '.', '--iff-txt', LEVEL + '.iff.txt', '--textile-ini', LEVEL + '.ini')
    log += run(tool('textile'), '-ini=' + LEVEL + '.ini', '-Tlinux', '-transparent=0,0,0', '-pagex=1024', '-pagey=2048',
               '-permpagex=2048', '-permpagey=2048', '-palx=256', '-paly=8', '-alignx=w', '-aligny=h', '-flipyout')
    log += run(tool('iffcomp'), '-binary', '-o=' + LEVEL + '.iff', LEVEL + '.iff.txt')
    (out / (LEVEL + '-standalone.iff.txt')).write_text(
        "{ 'L4' { 'ALGN' .align( 2048 ) } { 'RAM' 'OBJD' 4194304l 'PERM' 16777216l 'ROOM' 8388608l 'FLAG' 1l 1l " + "} { 'ALGN' .align( 2048 ) } [ \"parmenides_slice.iff\" ] }\n")
    log += run(tool('iffcomp'), '-binary', '-o=' + LEVEL + '-standalone.iff', LEVEL + '-standalone.iff.txt')
    if isolate_rendering:
        from level_settings import attach
        attach(out / (LEVEL + '-standalone.iff'), out / 'actors.json', out, WF, scope=1)
    log += run(tool('cdpack'), WF / 'wfsource/source/game/shell.fth', LEVEL + '-standalone.iff', '-o', out / 'cd.iff')
    (out / 'rooms-split-compile.log').write_text(log)
    return log


def make_apk(a_dir, out):
    base = next(p for p in a_dir.glob('parmenides-*.apk'))
    key = a_dir / 'development-signing.p12'
    unsigned, aligned = out / 'rooms-unsigned.apk', out / 'rooms-aligned.apk'
    with zipfile.ZipFile(base) as zin, zipfile.ZipFile(unsigned, 'w') as zout:
        for info in zin.infolist():
            if info.filename.startswith('META-INF/'):
                continue
            data = (out / 'cd.iff').read_bytes() if info.filename == 'assets/cd.iff' else zin.read(info.filename)
            entry = zipfile.ZipInfo(info.filename, date_time=info.date_time)
            entry.compress_type = info.compress_type
            entry.external_attr = info.external_attr
            zout.writestr(entry, data)
    subprocess.run([TOOLS / 'zipalign', '-f', '4', unsigned, aligned], check=True)
    signed = out / 'rooms-signed.apk'
    subprocess.run([TOOLS / 'apksigner', 'sign', '--ks', key, '--ks-pass', 'pass:android', '--out', signed, aligned], check=True)
    subprocess.run([TOOLS / 'apksigner', 'verify', signed], check=True)
    unsigned.unlink(); aligned.unlink()
    digest = sha256(signed)
    frozen = out / ('parmenides-' + digest[:16] + '.apk')
    signed.rename(frozen)
    with zipfile.ZipFile(base) as za, zipfile.ZipFile(frozen) as zb:
        for n in za.namelist():
            if n.startswith('META-INF/') or n == 'assets/cd.iff':
                continue
            assert za.read(n) == zb.read(n), n
    return base, frozen


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__.split('\n')[0])
    p.add_argument('--fixture', type=Path, required=True, help='A fixture directory (group-N-view-M)')
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--layout', choices=sorted(LAYOUTS), required=True)
    p.add_argument('--isolate-rendering', action='store_true', help='Attach the authored current-room RPRP policy (load-time, scene9 only)')
    p.add_argument('--apk', action='store_true', help='also write the B fixture APK (A APK with only cd.iff replaced)')
    p.add_argument('--tour-end', type=float, help='diagnostic: stop the review tour at this game time (park in that scene)')
    p.add_argument('--tour-loop', action='store_true', help='diagnostic: restart the review tour at its end, so teleports recur')
    p.add_argument('--player-x', type=float, help='measurement only: start the Player (and Camera) at this x, to read room-stats of other rooms')
    p.add_argument('--retarget', action='append', default=[], metavar='OLD=>NEW',
                   help='diagnostic: replace exactly one occurrence of OLD with NEW in the .lev (for example a tour teleport target)')
    p.add_argument('--mbr-on', default='', help='comma-separated object names to flag Moves Between Rooms (content fix, e.g. the Player and its limbs)')
    p.add_argument('--keep-inputs', action='store_true', help='keep the copied mesh/texture inputs after compiling')
    a = p.parse_args(argv)
    a_dir, out = a.fixture.resolve(), a.out.resolve()
    if out == a_dir or 'build' in out.parts:
        raise SystemExit('refusing to write inside a shared build/ tree; use a new directory such as build-rooms/')
    out.mkdir(parents=True, exist_ok=True)
    for f in a_dir.iterdir():
        if f.is_file() and (f.suffix in ('.iff', '.tga') or f.name in ('actors.json', 'content.json', 'visual-gates.json', 'chapter.fth',
                                                                      'build-receipt.json', 'runtime-provenance.json', 'review-receipt.json')):
            shutil.copy2(f, out / f.name)
    shutil.copy2(a_dir / 'development-signing.p12', out / 'development-signing.p12')
    lev = (a_dir / (LEVEL + '.lev')).read_text()
    layout = LAYOUTS[a.layout]
    receipt = dict(fixture=str(a_dir), layout=a.layout, a_lev_sha256=sha256(a_dir / (LEVEL + '.lev')),
                   a_cd_sha256=sha256(a_dir / 'cd.iff'))
    if layout:
        smap, actives, problems, asserts = slot_map(layout['rooms'])
        receipt.update(slot_map={r[0]: s for r, s in zip(layout['rooms'], smap)}, active_sets=actives, walk_assertions=asserts,
                       card_park_z=layout.get('card_park_z'))
        if problems:
            raise SystemExit('invalid slot map: ' + '; '.join(problems))
        lev, added = patch(lev, layout)
        receipt['added_objects'] = added
    if a.player_x is not None:
        head, objs = split_objects(lev)
        for i, o in enumerate(objs):
            if obj_name(o) in ('Player', 'Camera', 'PlayerLegL', 'PlayerArmL', 'PlayerLegR', 'PlayerArmR'):
                objs[i] = shift_x(o, a.player_x)
        lev = head + ''.join("\n\t{ 'OBJ'" + o for o in objs)
        receipt['player_x'] = a.player_x
    if a.mbr_on:
        head, objs = split_objects(lev)
        want = set(a.mbr_on.split(','))
        done = set()
        for i, o in enumerate(objs):
            n = obj_name(o)
            if n in want:
                o2, k = re.subn(r"(\{ 'I32' \{ 'NAME' \"Moves Between Rooms\" \} \{ 'DATA' )0l \} \{ 'STR' \"False\" \}",
                                lambda m: m.group(1) + '1l } { \'STR\' "True" }', o)
                assert k == 1, n
                objs[i] = o2; done.add(n)
        assert done == want, want - done
        lev = head + ''.join("\n\t{ 'OBJ'" + o for o in objs)
        receipt['mbr_on'] = sorted(want)
    for spec in a.retarget:
        old, new = spec.split('=>', 1)
        assert lev.count(old) == 1, f'--retarget: {old!r} occurs {lev.count(old)} times'
        lev = lev.replace(old, new)
        receipt.setdefault('retarget', []).append(spec)
    if a.tour_end or a.tour_loop:
        # Diagnostic tour edits, applied identically to A (control) and B; the end of the
        # 3-scene tour is game time 59 s (build_review_fixtures.py tour()).
        old_end = '470 read-mailbox 59 < &'
        assert lev.count(old_end) == 1, 'tour end not found'
        if a.tour_end:
            lev = lev.replace(old_end, '470 read-mailbox %g < &' % a.tour_end)
        if a.tour_loop:
            tick = '470 write-mailbox fy-stop'
            assert lev.count(tick) == 1, 'tour tick not found'
            lev = lev.replace(tick, tick + ' 470 read-mailbox 59 >= if 5 470 write-mailbox then')
        receipt.update(tour_end=a.tour_end, tour_loop=a.tour_loop)
    (out / (LEVEL + '.lev')).write_text(lev)
    if a.isolate_rendering and a.layout != 'scene9':raise SystemExit('Isolation requires one room per gameplay area (scene9)')
    log = compile_level(out, isolate_rendering=a.isolate_rendering)
    receipt['roomRendering']='current' if a.isolate_rendering else 'active'
    if a.isolate_rendering:
        from level_settings import readback
        receipt['levelSettings']=readback(out / (LEVEL + '-standalone.iff'))
    warnings = [ln for ln in log.splitlines() if 'WARNING' in ln or 'falls outside' in ln]
    toc = re.findall(r"'(RM\d+)'\s+\.offsetof", (out / (LEVEL + '.iff.txt')).read_text())
    receipt['toc_rooms'] = toc
    nrooms = len(layout['rooms']) if layout else 2
    if toc != ['RM%d' % i for i in range(nrooms)]:
        raise SystemExit(f'TOC rooms {toc} do not cover rooms 0..{nrooms - 1}: the engine indexes the TOC by room index')
    receipt.update(b_lev_sha256=sha256(out / (LEVEL + '.lev')), b_cd_sha256=sha256(out / 'cd.iff'), compile_warnings=warnings,
                   rooms_pages=sorted(p.name for p in out.glob('Room*.tga')))
    if a.layout == 'control' and not (a.tour_end or a.tour_loop or a.mbr_on or a.retarget):
        receipt['control_identical'] = receipt['a_cd_sha256'] == receipt['b_cd_sha256']
    if a.apk:
        base, frozen = make_apk(a_dir, out)
        receipt.update(a_apk=str(base), a_apk_sha256=sha256(base), b_apk=str(frozen), b_apk_sha256=sha256(frozen),
                       apk_note='Every APK entry except assets/cd.iff and the signature is byte-identical to the A APK.')
    receipt['page_bytes'] = {p.name: p.stat().st_size for p in sorted(out.glob('Room*.tga')) + [out / 'Perm.tga']}
    if not a.keep_inputs:
        # Disk is tight: the runtime needs only the standalone level (and cd.iff for an APK).
        keep = {LEVEL + '-standalone.iff', 'cd.iff', LEVEL + '.lev', LEVEL + '.lvl', LEVEL + '.ini'}
        for f in out.iterdir():
            if f.is_file() and f.suffix in ('.iff', '.tga', '.bin') and f.name not in keep:
                f.unlink()
    (out / 'rooms-split-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({k: v for k, v in receipt.items() if k not in ('active_sets',)}, indent=2))
    if receipt.get('control_identical') is False:
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
