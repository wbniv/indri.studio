"""Painted Reason and Truth dressing for the cumulative chapter-art stage.

The ordered plane, revealed grove and courtroom keep their existing actors,
story mailboxes, motion and collision. New meshes are visual-only platforms.
"""

import json
import math
import random

STAGE = 'chapter-art'
REASON_MAILBOX = 493
TRUTH_MAILBOX = 494
REASON_TRUTH_FORTH = (
    f'102 read-mailbox 2 = {REASON_MAILBOX} write-mailbox\n'
    f'102 read-mailbox 3 = {TRUTH_MAILBOX} write-mailbox\n'
)


def generate_sources(out):
    from PIL import Image, ImageDraw

    sky = Image.new('RGB', (256, 128))
    px = sky.load()
    for y in range(128):
        t = y / 127
        blue = (143, 187, 221)
        haze = (236, 226, 205)
        blend = max(0, min(1, (t - .12) / .88)) ** 1.35
        for x in range(256):
            px[x, y] = tuple(round(blue[k] * (1 - blend) + haze[k] * blend) for k in range(3))
    d = ImageDraw.Draw(sky)
    # The mountain band is part of the distant sky, never a navigable wall.
    d.polygon([(0, 106), (18, 97), (37, 101), (61, 91), (80, 102), (104, 95),
               (128, 104), (149, 92), (169, 98), (194, 89), (218, 101),
               (238, 95), (255, 105), (255, 127), (0, 127)], fill=(160, 177, 189))
    d.polygon([(0, 115), (28, 107), (52, 112), (78, 103), (111, 112),
               (139, 105), (171, 114), (204, 103), (238, 112), (255, 107),
               (255, 127), (0, 127)], fill=(192, 193, 185))
    sky.save(out / 'art_reason_sky.tga')

    tile = Image.new('RGB', (512, 512), (205, 202, 188))
    d = ImageDraw.Draw(tile)
    rng = random.Random(27021)
    for row in range(20):
        for col in range(20):
            x, y = col * 26, row * 26
            variation = rng.randrange(-9, 10)
            color = (max(0, 230 + variation), max(0, 225 + variation), max(0, 209 + variation))
            d.rectangle((x + 1, y + 1, x + 24, y + 24), fill=color)
            d.line((x + 2, y + 2, x + 23, y + 2), fill=(238, 233, 217), width=1)
    tile.save(out / 'art_reason_tile.tga')

    wood = Image.new('RGB', (512, 512), (76, 48, 30))
    d = ImageDraw.Draw(wood)
    rng = random.Random(30111)
    for row in range(21):
        y = row * 25
        offset = -26 if row % 2 else 0
        for col in range(12):
            x = col * 52 + offset
            variation = rng.randrange(-10, 11)
            base = (119 + variation, 75 + variation // 2, 42 + variation // 3)
            d.rectangle((x + 2, y + 2, x + 49, y + 22), fill=base)
            for grain in (7, 13, 18):
                shade = tuple(max(0, c - (7 if grain == 13 else 3)) for c in base)
                d.line((x + 5, y + grain, x + 45, y + grain + rng.choice((-1, 0, 1))), fill=shade, width=1)
            for nail_x in (x + 6, x + 45):
                d.ellipse((nail_x, y + 5, nail_x + 2, y + 7), fill=(62, 48, 36))
    wood.save(out / 'art_truth_wood.tga')
    (out / 'reason-truth-style-sources.json').write_text(json.dumps({
        'art_reason_sky.tga': list(sky.size),
        'art_reason_tile.tga': list(tile.size),
        'art_truth_wood.tga': list(wood.size),
        'method': 'deterministic original painted sources',
    }, indent=2) + '\n')


def _paint_top(scene, name, material, bounds):
    obj = scene.objects[name]
    mesh = obj.data
    slot = len(mesh.materials)
    mesh.materials.append(material)
    uv = mesh.uv_layers.active.data
    x0, x1, y0, y1 = bounds
    faces = []
    for face in mesh.polygons:
        if face.normal.z < .9:
            continue
        face.material_index = slot
        faces.append(face.index)
        for loop in face.loop_indices:
            p = obj.matrix_world @ mesh.vertices[mesh.loops[loop].vertex_index].co
            uv[loop].uv = ((p.x - x0) / (x1 - x0), (p.y - y0) / (y1 - y0))
    obj['art_stage_overlay'] = STAGE
    return faces


def dress(M, scene, out, setup_material):
    from art_style_proof import _explicit, kit_type, sky_dome

    Base = M.__bases__[0]
    sky_kit = sky_dome(kit_type(Base))
    sky = sky_kit.object('reason_sky', (200, 4, 0), kind='platform', visibility=REASON_MAILBOX)
    sky['art_stage'] = STAGE
    sky['art_role'] = 'pale open sky and distant mountains above Reason'
    sky['wf_original_bbox'] = (-.05, -.05, 30.0, .05, .05, 30.1)
    sky['wf_had_authored_bbox'] = True
    sky.data.uv_layers.new(name='Painted diffuse')
    _explicit(sky, sky_kit.uvfns)
    sky.data.materials.clear()
    sky_mat = setup_material(out, 'art_reason_sky.tga')
    sky_mat['wf_prelit'] = True
    sky.data.materials.append(sky_mat)
    if 'style_regions' in sky:
        del sky['style_regions']

    reason_mat = setup_material(out, 'art_reason_tile.tga')
    truth_mat = setup_material(out, 'art_truth_wood.tga')
    reason_mat['wf_prelit'] = True
    truth_mat['wf_prelit'] = True
    painted = {
        'reason_floor': _paint_top(scene, 'reason_floor', reason_mat, (186, 214, -11, 19)),
        'court_floor': _paint_top(scene, 'court_floor', truth_mat, (286, 314, -14, 24)),
    }

    # Existing source-driven grove trees retain their motion and visibility.
    # Static undergrowth thickens the transformed silhouette outside the
    # direct speaker and apparatus approaches.
    grove = M()
    rng = random.Random(2057)
    for tx, ty in ((-7, 0), (7, 0), (-6, 5), (6, 7), (-8, 9), (8, 9)):
        for i in range(6):
            x = tx + (rng.random() - .5) * 1.7
            y = ty + (rng.random() - .5) * 1.6
            h = .45 + rng.random() * .5
            grove.beam((x, y, .04), (x + .12, y + .1, h), .035, 'brown')
            for side in (-1, 1):
                grove.blade([(y - .26 * side, .10), (y + .06 * side, h),
                             (y + .32 * side, .16)], x + side * .09, .06, 'green')
        for side in (-1, 1):
            grove.beam((tx, ty, .10), (tx + side * 1.1, ty + .6, .07), .12, 'brown')
    grove_obj = grove.object('reason_grove_dressing', (200, 4, 0), kind='platform', visibility=163)
    grove_obj['art_stage'] = STAGE
    grove_obj['art_role'] = 'revealed grove undergrowth and roots'
    grove_obj['wf_original_bbox'] = (-.05, -.05, 12.0, .05, .05, 12.1)
    grove_obj['wf_had_authored_bbox'] = True

    court = M()
    # Rear paneling and cross beams complete the timber room without changing
    # the court_structure collider or any source encounter position.
    court.box((0, 0, 6.42), (25.7, 40.0, .18), 'plaster')
    for x in (-10, -5, 0, 5, 10):
        court.box((x, 0, 6.29), (.22, 39.5, .12), 'brown')
    court.box((0, 18.0, 4.0), (25.0, .24, 3.0), 'brown')
    for x in range(-11, 12, 4):
        court.box((x, 17.82, 4.0), (3.5, .07, 2.4), 'plaster')
        court.box((x, 17.70, 3.0), (3.7, .09, .12), 'gold')
        court.box((x, 17.70, 5.1), (3.7, .09, .12), 'gold')
    for y in (-12, -6, 0, 6, 12, 18):
        court.box((0, y, 5.85), (25.7, .38, .34), 'brown')
        for side in (-1, 1):
            court.box((side * 11.7, y, 4.55), (.38, .40, 2.2), 'brown')
    for side in (-1, 1):
        x = side * 12.30
        for y in (-8, 0, 8, 16):
            court.box((x, y, 4.25), (.10, 2.1, 1.65), 'blue')
            for dz in (-.92, .92):
                court.box((x - side * .08, y, 4.25 + dz), (.20, 2.3, .10), 'brown')
            court.box((x - side * .09, y, 4.25), (.21, .10, 1.9), 'brown')
    # Paired reading lamps focus the witness/evidence end of the room.
    for x in (-5.0, 5.0):
        court.box((x, 11.2, 1.28), (.30, .30, .15), 'brown')
        court.beam((x, 11.2, 1.37), (x, 11.2, 2.15), .06, 'gold')
        court.cone((x, 11.2, 2.15), .22, .30, 'gold', .07, 8)
    court_obj = court.object('truth_court_dressing', (300, 5, 0), kind='platform', visibility=TRUTH_MAILBOX)
    court_obj['art_stage'] = STAGE
    court_obj['art_role'] = 'timber court paneling, beams, windows and witness lights'
    court_obj['wf_original_bbox'] = (-.05, -.05, 12.0, .05, .05, 12.1)
    court_obj['wf_had_authored_bbox'] = True

    (out / 'reason-truth-style-sheets.json').write_text(json.dumps({
        'sky': {'size': [256, 128], 'prelit': True, 'mesh': sky.name},
        'painted': painted,
        'dressing': [grove_obj.name, court_obj.name],
    }, indent=2) + '\n')
    return {
        'stage': STAGE,
        'areas': ['Reason ordered', 'Reason grove', 'Truth court'],
        'added': [sky.name, grove_obj.name, court_obj.name],
        'painted': painted,
        'visibility': {'reason': REASON_MAILBOX, 'grove': 163, 'truth': TRUTH_MAILBOX},
        'collision': 'new dressing has explicit unreachable platform bounds; existing floor and encounter bounds unchanged',
        'sources': ['art_reason_sky.tga', 'art_reason_tile.tga', 'art_truth_wood.tga'],
    }
