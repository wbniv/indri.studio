"""Native pixel checks: every card in both views, plus the upward patient shot."""
import hashlib
import json
import subprocess
import re
import shutil
import time
import sys
import numpy as np
from PIL import Image, ImageFilter


def locate_sheet(frame):
    actual=np.asarray(frame.convert('RGB'))
    # The prelit sheet's quiet base color survives RGB555 conversion. World
    # meshes are hidden in this modal view, leaving an unambiguous sheet region.
    base=np.array([32,41,49])
    mask=np.max(np.abs(actual.astype(np.int16)-base.astype(np.int16)),axis=2)<=10
    w,h=frame.size
    # Exclude the tiny runtime FPS plate; select the broad sheet band.
    yy=np.where(mask.sum(axis=1)>w*.2)[0]
    if len(yy)<50:return {'passed':False,'reason':'sheet not rendered'}
    y0,y1=int(yy.min()),int(yy.max())+1
    xx=np.where(mask[y0:y1].sum(axis=0)>(y1-y0)*.5)[0]
    if len(xx)<100:return {'passed':False,'reason':'sheet missing or heavily obscured'}
    x0,x1=int(xx.min()),int(xx.max())+1
    bounds=x0>=w*.06 and x1<=w*.94 and y0>=h*.06 and y1<=h*.94
    return {'bounds':[x0,y0,x1,y1],'safe_bounds':bool(bounds),'crop':frame.convert('RGB').crop((x0,y0,x1,y1))}


def inspect_frame(frame, template, location=None):
    location=locate_sheet(frame) if location is None else location
    if 'crop' not in location:return location
    x0,y0,x1,y1=location['bounds'];bounds=location['safe_bounds']
    crop=location['crop'].resize(template.size,Image.Resampling.BILINEAR)
    got=np.asarray(crop);want=np.asarray(template.convert('RGB'))
    # Native RGB555 sampling and resizing soften antialiased stroke edges.
    ink_got=np.max(got,axis=2)>90;ink_want=np.max(want,axis=2)>110
    grow=lambda a:np.asarray(Image.fromarray(a.astype('uint8')*255).filter(ImageFilter.MaxFilter(5)))>0
    got_wide=grow(ink_got);want_wide=grow(ink_want)
    regions={}
    for label,(a,z) in {'title':(0,18),'body':(22,97),'controls':(98,109)}.items():
        expected=ink_want[a:z];rendered=ink_got[a:z]
        recall=float((got_wide[a:z]&expected).sum()/max(1,expected.sum()))
        precision=float((want_wide[a:z]&rendered).sum()/max(1,rendered.sum()))
        regions[label]={'recall':recall,'precision':precision}
    # Dilation alone can accept unrelated paragraphs with similar line lengths.
    # Compare the body intensities too, allowing one pixel of sampling offset.
    # Matching native captures calibrate above .71; .65 tolerates RGB555 and
    # device resizing while rejecting the same-header negative controls.
    gray_got=got.mean(axis=2);gray_want=want.mean(axis=2)
    correlations=[]
    for dy in (-1,0,1):
        for dx in (-1,0,1):
            expected=gray_want[23:96,1:-1].ravel()
            rendered=gray_got[23+dy:96+dy,1+dx:gray_got.shape[1]-1+dx].ravel()
            score=float(np.corrcoef(expected,rendered)[0,1])
            correlations.append(score if np.isfinite(score) else 0.)
    similarity=max(correlations)
    result={'passed':bool(bounds and similarity>=.65 and all(r['recall']>=.90 and r['precision']>=.85 for r in regions.values())),
            'bounds':[x0,y0,x1,y1],'safe_bounds':bool(bounds),'regions':regions,'body_similarity':similarity}
    if not result['passed'] and not location.get('rectified'):
        # A settling patient camera can tilt the plate. Axis-aligned cropping
        # then shifts the single short coda line by several pixels. Recover the
        # four real plate edges; keep all original text and safety thresholds.
        quad=sheet_quad(frame,(x0,y0,x1,y1))
        if quad:
            w,h=frame.size
            safe=all(w*.06<=x<=w*.94 and h*.06<=y<=h*.94 for x,y in zip(quad[::2],quad[1::2]))
            crop=frame.convert('RGB').transform(template.size,Image.Transform.QUAD,quad,Image.Resampling.BILINEAR)
            result=inspect_frame(frame,template,dict(crop=crop,bounds=[x0,y0,x1,y1],safe_bounds=safe,rectified=True))
            result.update(rectified=True,quad=quad,raw_body_similarity=similarity)
    return result


def sheet_quad(frame,box):
    """Fit the real opaque plate boundary, never inferred glyph positions."""
    pixels=np.asarray(frame.convert('RGB'));w,h=frame.size
    mask=np.max(np.abs(pixels.astype(np.int16)-np.array([32,41,49])),axis=2)<=10
    x0,y0,x1,y1=box;dx=x1-x0;dy=y1-y0
    top=[];bottom=[];left=[];right=[]
    for x in range(int(x0+dx*.15),int(x1-dx*.15)):
        yy=np.where(mask[max(0,y0-40):min(h,y1+40),x])[0]+max(0,y0-40)
        if len(yy)>dy*.5:top.append((x,yy.min()));bottom.append((x,yy.max()+1))
    for y in range(int(y0+dy*.15),int(y1-dy*.15)):
        xx=np.where(mask[y,max(0,x0-40):min(w,x1+40)])[0]+max(0,x0-40)
        if len(xx)>dx*.5:left.append((y,xx.min()));right.append((y,xx.max()+1))
    if any(len(edge)<50 for edge in (top,bottom,left,right)):return None
    fits=[np.polyfit(*np.asarray(edge).T,1) for edge in (top,bottom,left,right)]
    def intersect(horizontal,vertical):
        a,b=horizontal;c,d=vertical
        x=(c*b+d)/(1-c*a);return [float(x),float(a*x+b)]
    quad=sum((intersect(fits[a],fits[b]) for a,b in ((0,2),(1,2),(1,3),(0,3))),[])
    if not all(np.isfinite(quad)):return None
    return quad


def verify_detector(frame, template, wrong_template, check):
    """Prove the visibility check rejects the defects it is intended to catch."""
    inspected=inspect_frame(frame,template)
    check('pixel detector accepts the complete matching rendered card',inspected['passed'])
    x0,y0,x1,y1=inspected['bounds']
    width,height=x1-x0,y1-y0
    base=(32,41,49)
    def covered(top,bottom):
        damaged=frame.convert('RGB').copy()
        damaged.paste(base,(x0,int(y0+height*top/112),x1,int(y0+height*bottom/112)))
        return damaged
    check('pixel detector rejects missing bottom controls',
          not inspect_frame(covered(96,112),template)['passed'])
    check('pixel detector rejects body text obscured by geometry',
          not inspect_frame(covered(22,97),template)['passed'])
    check('pixel detector rejects unrelated source text',
          not inspect_frame(frame,wrong_template)['passed'])
    shifted=Image.new('RGB',frame.size,(0,0,0))
    shifted.paste(frame.convert('RGB'),(frame.width//2,0))
    check('pixel detector rejects a card clipped by the viewport',
          not inspect_frame(shifted,template)['passed'])


def capture_presented(target, bridge, timeout=8):
    # Run this harness without -record_video. The bridge reads the previous
    # default-framebuffer image; recording uses an FBO and makes that read stale.
    # Wait for the renderer below, and for the matching screenshot acknowledgement.
    target.unlink(missing_ok=True)
    with bridge._lock:start=len(bridge._inbox)
    bridge.send({'op':'screenshot','filename':str(target)})
    deadline=time.monotonic()+timeout
    while time.monotonic()<deadline:
        with bridge._lock:messages=bridge._inbox[start:]
        if any(m.get('op')=='screenshot_done' and m.get('filename')==str(target) for m in messages):
            return
        time.sleep(.02)
    raise RuntimeError('No matching native screenshot acknowledgement: '+str(target))

def run(b,player,value,check,tap,position,cards,content,ids,out,evidence):
    timeout=float(sys.argv[sys.argv.index('--reading-timeout')+1]) if '--reading-timeout' in sys.argv else 25
    if timeout<=0:raise ValueError('--reading-timeout must be positive')
    root=evidence.parent if '--build-dir' in sys.argv else out.parents[2]/'docs/diagnostics/parmenides/endings'
    rendered=root/'rendered-panels';rendered.mkdir(parents=True,exist_ok=True)
    receipt=json.loads((out/'build-receipt.json').read_text())
    results=[]
    selected_cards=[cards[n] for n in (1,123,146,148,149,150,151,152,154,157,197,204)] if '--panel-fixture-probe' in sys.argv else list(cards.values())
    if '--panel-transition-probe' in sys.argv:
        selected_cards=[cards[n] for n in (148,149,150)]
    if '--panel-patient-probe' in sys.argv:
        selected_cards=[]
    b.watch(player,139)
    gates=json.loads((out/'visual-gates.json').read_text())
    for actor in (ids['Camera'],ids['FollowShot'],ids['CamTarget']):
        for mailbox in (3009,3010,3011):b.watch(actor,mailbox)
    def fixture_cut():
        # Match fy-teleport/fy-cut-camera for an artificial cross-room fixture.
        # scene:set_transform moves only the player, leaving the camera's old
        # velocity to overshoot hundreds of metres. Cut before opening a page;
        # each world-to-reading transition below still settles naturally.
        x,y,z=[value(m) for m in (3009,3010,3011)]
        patient=value(102)==8
        offset=-.6 if patient else (-3.8 if value(101)==0 else .6)
        height=.9 if patient else (2.7 if value(101)==0 else 1.55)
        b.send({'op':'scene:set_transform','idx':ids['Camera'],'pos':[x,y+offset,z+height]})
        for mailbox in (3018,3019,3020):b.set_mailbox(mailbox,0,idx=ids['Camera'])
    def wait_camera():
        # Direct fixture teleports do not run the game's camera cut. Wait for
        # its real requested pose rather than mistaking a frame of the long
        # world-space slew for the settled source sheet.
        expected=None
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline:
            actual=[b.mailbox_values.get((ids['Camera'],m)) for m in (3009,3010,3011)]
            shot=[b.mailbox_values.get((ids['FollowShot'],m)) for m in (3009,3010,3011)]
            origin=[b.mailbox_values.get((ids['CamTarget'],m)) for m in (3009,3010,3011)]
            actor=[value(m) for m in (3009,3010,3011)]
            if all(v is not None for v in actual+shot+origin+actor):
                expected=[s-o+p for s,o,p in zip(shot,origin,actor)]
                if max(abs(a-e) for a,e in zip(actual,expected))<.02:return
            time.sleep(.05)
        raise AssertionError('Native reading camera did not reach its requested pose: '+str(dict(actual=actual,shot=shot,origin=origin,player=actor,expected=expected,card=value(140),realm=value(102),mode=value(101))))
    def frame(card,mode,patient=False):
        # Fixtures render every texture; separate native route tests prove that
        # gameplay chooses precisely these pages and terminal transitions.
        # Include the world-to-reading transition for every card, instead of
        # retaining the previous card's already-settled reading camera.
        b.set_mailbox(140,0,idx=player)
        time.sleep(.2)
        wait_camera()
        check('closing modal reading restores the requested world camera',True)
        b.set_mailbox(140,card['id'],idx=player)
        b.wait_for_mailbox(player,140,card['id'],timeout=timeout)
        transition=time.time()
        # Watched mailboxes broadcast after RenderEnd, before PageFlip submits
        # that frame to ffmpeg. A fixed 80 ms delay can still select the prior
        # world image under GPU/readback load. Observe the following native
        # update: the preceding frame has now completed PageFlip/readback.
        opening_clock=value(110) or 0
        deadline=time.monotonic()+timeout
        while (value(110) or 0)<=opening_clock and time.monotonic()<deadline:
            time.sleep(.01)
        check('opening frame processed the selected page and suppressed world',
              (value(110) or 0)>opening_clock
              and (receipt.get('artStage')!='polish' or value(139)==card['id'])
              and all(value(m)==0 for m in gates.values()))
        presented=time.time()
        presented_clock=value(110)
        before=value(110) or 0;deadline=time.monotonic()+timeout
        while (value(110) or 0)<before+.2 and time.monotonic()<deadline:time.sleep(.02)
        wait_camera()
        deadline=time.monotonic()+timeout
        while not value(129) and time.monotonic()<deadline:time.sleep(.03)
        check('card becomes readable after its opening transition',bool(value(129)))
        # Sheet actors and the video pipe can lag readiness by a native frame.
        # Two subsequent updates complete a readable RenderEnd/PageFlip even
        # when the desktop is idle-throttled; wall-clock sleeps do not.
        readable_clock=value(110) or 0
        for _ in range(2):
            before=value(110) or 0;deadline=time.monotonic()+timeout
            while (value(110) or 0)<=before and time.monotonic()<deadline:time.sleep(.01)
            if (value(110) or 0)<=before:raise AssertionError('Readable frame did not complete native presentation')
        readable_presented_clock=value(110)
        check('render fixture has exactly its sheet and no world meshes',value(140)==card['id'] and all(value(m)==0 for m in gates.values()))
        check('dialogue never enables the arcade game-over HUD',value(420)==0)
        filename=f'card-{card["id"]:03d}-view-{mode}'+('-patient' if patient else '')+'.png'
        target=rendered/filename
        # Mark a settled interval in the offscreen FBO recording. The existing
        # capture pipe stamps frames with the wall clock, including render stalls.
        stamp=time.time()
        for _ in range(2):
            before=value(110) or 0;deadline=time.monotonic()+timeout
            while (value(110) or 0)<=before and time.monotonic()<deadline:time.sleep(.01)
            if (value(110) or 0)<=before:raise AssertionError('Recorded readable hold did not complete native presentation')
        time.sleep(.3)
        results.append(dict(card=card['id'],key=card['key'],camera=mode,patient=patient,
                            file=filename,wall_time=stamp,transition_start=transition,
                            presentation_start=presented,opening_clock=opening_clock,
                            presented_clock=presented_clock,readable_clock=readable_clock,
                            readable_presented_clock=readable_presented_clock))
        print('recorded settled FBO interval '+filename,flush=True)
    try:
        for mode in (0,1):
            if value(101)!=mode:tap(2)
            resident=None
            for card in selected_cards:
                if card['atlas']!=resident:
                    # Use an unobstructed Temple floor fixture. The old
                    # anchors (10,9), (0,-3), and (3,0) can hold camera Z through native
                    # collision after many artificial card relocations. Other
                    # native approach/transition checks retain their coverage;
                    # this sweep checks every texture and modal opening.
                    x,y,realm={'permanent':(0,5,0),'room':(306,1,3),'god':(400,30,4)}[card['atlas']]
                    b.set_mailbox(140,0,idx=player);b.set_mailbox(102,realm,idx=player)
                    b.set_mailbox(114,.25,idx=player);position(x,y)
                    resident=card['atlas'];time.sleep(.2);fixture_cut()
                frame(card,mode)
            if '--panel-transition-probe' in sys.argv:
                continue
            b.set_mailbox(140,0,idx=player);b.set_mailbox(102,8,idx=player);position(800,0)
            fixture_cut()
            for index in content['groups']['ending_101b']+content['groups']['ending_complete']:
                frame(cards[index],mode,patient=True)
    except BaseException as error:
        (evidence/'fixture-error.json').write_text(json.dumps(dict(error=repr(error),apk_sha256=receipt['sha256']),indent=2)+'\n')
        raise
    finally:
        (root/'panel-render-requests.json').write_text(json.dumps({'build':receipt,'results':results},indent=2)+'\n')


def finalize(out, evidence, check, recording_cwd=None):
    root=evidence.parent if '--build-dir' in sys.argv else out.parents[2]/'docs/diagnostics/parmenides/endings'
    requests=json.loads((root/'panel-render-requests.json').read_text())
    log=(evidence/'engine.log').read_text()
    match=re.search(r'Duration: N/A, start:\s*([0-9.]+)',log)
    if not match:raise RuntimeError('Offscreen recording start timestamp missing')
    epoch=float(match.group(1))
    movie=root/'rendered-panels/panel-render.mp4'
    shutil.copy2((recording_cwd or out)/'output.mp4',movie)
    error=evidence/'fixture-error.json'
    if error.exists():
        # A partial failed sweep cannot provide acceptance. Preserve its full
        # recording and requests without spending minutes auditing endpoints
        # that will necessarily fail the complete-coverage contract.
        failure=dict(build=requests['build'],passed=False,results=[],
            requested_cases=len(requests['results']),error=json.loads(error.read_text()),
            video_sha256=hashlib.sha256(movie.read_bytes()).hexdigest())
        (root/'panel-render-audit.json').write_text(json.dumps(failure,indent=2)+'\n')
        (root/'panel-transition-audit.json').write_text(json.dumps(failure,indent=2)+'\n')
        return
    rows=[]
    transition_rows=[]
    try:
        for index,request in enumerate(requests['results']):
            target=movie.parent/request['file']
            timestamp=request['wall_time']-epoch
            subprocess.run(['ffmpeg','-v','error','-y','-ss',str(timestamp),'-i',str(movie),
                            '-frames:v','1',str(target)],check=True,timeout=15)
            inspected=inspect_frame(Image.open(target),Image.open(out/f'card_{request["card"]:02d}.tga'))
            initial_timestamp=timestamp
            endpoint_end=(requests['results'][index+1]['presentation_start']-epoch
                          if index+1<len(requests['results']) else timestamp+.3)
            # Readiness broadcasts precede PageFlip. At one frame per second,
            # the fixed settled delay can still decode its last hidden frame.
            # Inspect the remaining recorded interval before the next card's
            # first frame completed presentation. Selection receipts alone
            # precede PageFlip and cannot bound encoded frame availability.
            # Only hidden frames may precede the exact readable sheet;
            # wrong text, world geometry or partial/obscured sheets still fail.
            if not inspected['passed']:
                pixels=np.asarray(Image.open(target).convert('RGB'))[:-40]
                hidden=float((pixels.max(axis=2)<20).mean())>.995
                if hidden and endpoint_end>timestamp:
                    temp=movie.parent/'endpoint-samples';temp.mkdir(exist_ok=True)
                    for stale in temp.glob('frame-*.png'):stale.unlink()
                    subprocess.run(['ffmpeg','-v','error','-y','-ss',str(timestamp),'-i',str(movie),
                                    '-t',str(endpoint_end-timestamp),'-vf','fps=30',str(temp/'frame-%03d.png')],
                                   check=True,timeout=25)
                    for number,path in enumerate(sorted(temp.glob('frame-*.png'))):
                        frame_image=Image.open(path).convert('RGB')
                        candidate=inspect_frame(frame_image,Image.open(out/f'card_{request["card"]:02d}.tga'))
                        if candidate['passed']:
                            shutil.copy2(path,target);inspected=candidate;timestamp=initial_timestamp+number/30
                            break
                        pixels=np.asarray(frame_image)[:-40]
                        if float((pixels.max(axis=2)<20).mean())<=.995:
                            inspected=candidate
                            break
            row=dict(request,video_time=timestamp,initial_video_time=initial_timestamp,
                     endpoint_window_end=endpoint_end,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),**inspected)
            rows.append(row)
            if not row['passed']:print(json.dumps(row),flush=True)
            check('offscreen rendered '+request['file']+': full bounds and intended title/body/controls',row['passed'])
            # Sample the unsheltered opening interval at 8 Hz. Hidden frames
            # are allowed only before the separately verified readable endpoint.
            # Record the complete movie as well; sampling is not every-frame proof.
            if 'transition_start' in request:
                temp=root/'rendered-panels/transition-samples';temp.mkdir(exist_ok=True)
                for stale in temp.glob('frame-*.png'):stale.unlink()
                start=request['presentation_start']-epoch
                duration=max(.125,timestamp-start)
                subprocess.run(['ffmpeg','-v','error','-y','-ss',str(start),'-i',str(movie),'-t',str(duration),
                                '-vf','fps=8','-frames:v','200',str(temp/'frame-%03d.png')],check=True,timeout=25)
                sample_cache={}
                for i,frame_path in enumerate(sorted(temp.glob('frame-*.png'))):
                    frame_sha=hashlib.sha256(frame_path.read_bytes()).hexdigest()
                    if frame_sha not in sample_cache:
                        image=Image.open(frame_path).convert('RGB')
                        result=inspect_frame(image,Image.open(out/f'card_{request["card"]:02d}.tga'))
                        pixels=np.asarray(image)[:-40]
                        hidden=float((pixels.max(axis=2)<20).mean())>.995
                        sample_cache[frame_sha]=(dict(result),hidden)
                    cached,hidden=sample_cache[frame_sha]
                    result=dict(cached)
                    result.update(card=request['card'],camera=request['camera'],patient=request['patient'],
                                  video_time=start+i/8,hidden=hidden,
                                  passed=result['passed'] or hidden,
                                  sha256=frame_sha)
                    transition_rows.append(result)
                    if not result['passed']:
                        failure=temp/f'failed-card-{request["card"]:03d}-view-{request["camera"]}-patient-{int(request["patient"])}-{i}.png'
                        shutil.copy2(frame_path,failure);result['failure_file']=str(failure.relative_to(root))
            if len(rows)==1:
                other=next(r for r in requests['results'] if r['card']!=request['card'])
                verify_detector(Image.open(target),Image.open(out/f'card_{request["card"]:02d}.tga'),
                                Image.open(out/f'card_{other["card"]:02d}.tga'),check)
    finally:
        expected_cases={(r['card'],r['camera'],r['patient']) for r in requests['results']}
        sampled_cases={(r['card'],r['camera'],r['patient']) for r in transition_rows}
        required_cases=(4 if '--panel-patient-probe' in sys.argv else
                        6 if '--panel-transition-probe' in sys.argv else 420)
        transitions_passed=len(rows)==required_cases and sampled_cases==expected_cases and all(r['passed'] for r in transition_rows)
        (root/'panel-transition-audit.json').write_text(json.dumps({'build':requests['build'],
            'method':'8 Hz opening-interval pixel samples after the next native update confirms the opening frame completed PageFlip/readback; complete FBO movie retained; black hidden frames allowed before readable endpoint',
            'video_sha256':hashlib.sha256(movie.read_bytes()).hexdigest(),'cases':len(rows),'sampled_cases':len(sampled_cases),'results':transition_rows,
            'passed':transitions_passed},indent=2)+'\n')
        (root/'panel-render-audit.json').write_text(json.dumps({'build':requests['build'],
            'method':'Existing native offscreen FBO video; wall-clock-stamped settled intervals; source-bitmap foreground precision/recall and safe margins',
            'video_sha256':hashlib.sha256(movie.read_bytes()).hexdigest(),'results':rows,
            'passed':len(rows)==required_cases and all(r['passed'] for r in rows)},indent=2)+'\n')
    check('all opening transition pixel samples are hidden or the intended readable sheet',transitions_passed)
