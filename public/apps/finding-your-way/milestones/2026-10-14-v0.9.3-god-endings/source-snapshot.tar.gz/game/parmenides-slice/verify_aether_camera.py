"""Supplemental native overhead views using disclosed diagnostic camera pitch."""
import json,time

def run(b,player,value,check,tap,position,read_pages,groups,ids,out,evidence,capture):
    receipt=json.loads((out/'review-receipt.json').read_text());check('upward camera fixture explicitly diagnostic',receipt['diagnostic_only'])
    for m in (106,107,154,155,176,177,195,196,197,188):b.set_mailbox(m,1,idx=player)
    b.set_mailbox(102,0,idx=player);b.set_mailbox(140,0,idx=player);b.set_mailbox(499,1,idx=player)
    for mode in (0,1):
        if value(101)!=mode:tap(2)
        b.set_mailbox(114,.25,idx=player);position(0,-5)
        for quiet in (0,1):
            b.set_mailbox(108,quiet,idx=player);time.sleep(.7);check('affirmed history enables overhead shells',bool(value(212)));capture(f'aether-upward-{"reduced" if quiet else "normal"}-view-{mode}')
    (evidence/'aether-camera-audit.json').write_text(json.dumps(dict(build=json.loads((out/'build-receipt.json').read_text()),diagnostic_receipt=receipt,passed=True,scope='Explicit diagnostic LookAtZ8.3, no production pitch control implied. Same production meshes/native binaries; normal/reduced overhead framing in both camera modes.'),indent=2)+'\n')
