"""Audit D path identity, off-route geometry and readable inspection surfaces."""
import argparse,json,sys
from pathlib import Path
import bpy
p=argparse.ArgumentParser();p.add_argument('--build-dir',type=Path,required=True);p.add_argument('--baseline-build',type=Path,required=True);p.add_argument('--report',type=Path,required=True)
a=p.parse_args(sys.argv[sys.argv.index('--')+1:]);out=a.build_dir.resolve()
rows=[]
def check(label,condition):
    rows.append(dict(check=label,passed=bool(condition)))
    if not condition:raise AssertionError(label)
def snapshot(obj):
    return dict(faces=[[list(obj.data.vertices[i].co) for i in p.vertices] for p in obj.data.polygons],location=list(obj.location),scale=list(obj.scale),rotation=list(obj.rotation_euler),bbox=list(obj.get('wf_original_bbox',[])))
path_names=('god_path_sides','god_rising_path','god_entry_landing','god_upper_landing','god_poster_landing','god_icon_landing','god_question_landing')
bpy.ops.wm.open_mainfile(filepath=str(a.baseline_build.resolve()/'parmenides_slice.blend'))
baseline={n:snapshot(bpy.context.scene.objects[n]) for n in path_names}
bpy.ops.wm.open_mainfile(filepath=str(out/'parmenides_slice.blend'));objects=bpy.context.scene.objects
success=False
try:
    for name in path_names:check(name+' navigation triangles and actor frame unchanged',snapshot(objects[name])==baseline[name])
    forest=objects['god_forest']
    for poly in forest.data.polygons:
        xs=[(forest.matrix_world@forest.data.vertices[i].co).x for i in poly.vertices]
        check('forest face '+str(poly.index)+' stays outside route/landing envelope',max(xs)<396 or min(xs)>404)
    for name in (o.name for o in objects if o.name.startswith('GodCanopy')):
        obj=objects[name];points=[obj.matrix_world@v.co for v in obj.data.vertices]
        xs=[v.x for v in points]
        check(name+' stays outside walk corridor',max(xs)<397 or min(xs)>403)
        check(name+' is nonphysical mass-zero platform',obj['wf_Mass']==0 and Path(obj['wf_schema_path']).stem=='platform')
    for name in ('GodRouteEdges','GodSummitShrine','final_beingCrown','final_bothCrown','final_notbeingCrown','AetherShell1','AetherShell2'):
        obj=objects[name];check(name+' is mass-zero platform dressing',obj['wf_Mass']==0 and Path(obj['wf_schema_path']).stem=='platform')
    shrine=objects['GodSummitShrine'];check('shrine lies behind final doorway approach',min((shrine.matrix_world@v.co).y for v in shrine.data.vertices)>34)
    for name in ('god_poster','god_icon'):
        obj=objects[name];paint=[p for p in obj.data.polygons if obj.data.materials[p.material_index].name.startswith('art_god_inspections')]
        check(name+' original painting appears only on front display',len(paint)==2 and all(p.normal.y<-.99 for p in paint))
        uv=obj.data.uv_layers.active
        check(name+' front painting retains nonmirrored horizontal coordinates',all(uv.data[l].uv.x>uv.data[k].uv.x for face in paint for l in face.loop_indices for k in face.loop_indices if obj.data.vertices[obj.data.loops[l].vertex_index].co.x>obj.data.vertices[obj.data.loops[k].vertex_index].co.x))
    check('D artwork uses existing permanent asset route',all(obj['wf_Moves Between Rooms']=='True' for obj in objects if obj.get('art_stage')=='god-final'))
    both=objects['final_bothCrown']
    check('Both opposing triangle faces are visible from doorway approach',sum(p.normal.y<-.99 and min(both.data.vertices[i].co.z for i in p.vertices)>3.65 for p in both.data.polygons)==2)
    content=json.loads((out/'content.json').read_text());old=json.loads((a.baseline_build/'content.json').read_text())
    check('complete dialogue and exact final outgoing links unchanged',content==old)
    success=True
finally:
    a.report.parent.mkdir(parents=True,exist_ok=True);a.report.write_text(json.dumps(dict(build=json.loads((out/'build-receipt.json').read_text()),passed=success and bool(rows) and all(x['passed'] for x in rows),results=rows),indent=2)+'\n')
print('D path/clearance/inspection checks',len(rows))
