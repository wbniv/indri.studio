"""Render-only area isolation probes; never modifies production or engine files.

Rebuilds recorded scene9 fixtures with actor visibility gated by their authored
area. Collision, transforms, meshes, textures, actor IDs and room lists stay
unchanged. Fixed-frame differences reveal geometry from another area.
"""
import argparse
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

from PIL import Image, ImageChops

ROOT = Path(__file__).resolve().parent
TOOLS = Path('/home/will/finding-your-way-rooms/game/parmenides-slice')
spec = importlib.util.spec_from_file_location('rooms_split', TOOLS / 'rooms_split.py')
rooms = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rooms)
AREAS = ('temple', 'love', 'reason', 'truth', 'god', 'being', 'both', 'notbeing', 'surgery')
SCRIPT = re.compile(r"(\{ 'STR' \{ 'NAME' \"Script\" \} \{ 'STR' )(\"(?:[^\"\\]|\\.)*\")( \} \})")


def floats(s):
    return [float(x) for x in re.findall(r'(-?\d+\.\d+)\(1\.15\.16\)', s)]


def isolate(level, gates, hide_actor=None):
    reverse = {v: int(k) for k, v in gates.items()}
    head, objects = rooms.split_objects(level)
    pairs, inventory, revised = {}, [], []
    for obj in objects:
        name = rooms.obj_name(obj)
        mesh = re.search(r'"Mesh Name".*?\{ \'STR\' "([^\"]*)"', obj)
        vis = re.search(r"\{ 'I32' \{ 'NAME' \"Visibility Mailbox\" \} \{ 'DATA' (\d+)l \} \{ 'STR' \"\d+\" \} \}", obj)
        if mesh and mesh[1] and not name.startswith(('card_', 'Player')) and vis and int(vis[1]):
            pos = floats(obj.split('"Position"')[1].split('//')[0])
            box = floats(obj.split('"Global Bounding Box"')[1].split('//')[0])
            x = pos[0] + (box[0] + box[3]) / 2
            candidates = [i for i in range(9) if abs(x - i * 100) < 50]
            assert len(candidates) == 1, (name, x)
            realm = candidates[0]
            logical = reverse[int(vis[1])]
            key = (logical, realm)
            if key not in pairs:
                pairs[key] = 521 + len(pairs)  # Preserve shared Player gate 520.
            actual = pairs[key]
            if hide_actor:
                actual = 0 if name == hide_actor else int(vis[1])
            inventory.append(dict(actor=name, area=AREAS[realm], realm=realm,
                                  world_bbox_center_x=x, old_gate=int(vis[1]),
                                  logical=logical, diagnostic_gate=actual))
            if not hide_actor or name == hide_actor:
                obj = obj[:vis.start()] + f'{{ \'I32\' {{ \'NAME\' "Visibility Mailbox" }} {{ \'DATA\' {actual}l }} {{ \'STR\' "{actual}" }} }}' + obj[vis.end():]
        revised.append(obj)
    assert max(pairs.values()) < 640
    patched = head + ''.join("\n\t{ 'OBJ'" + obj for obj in revised)
    if hide_actor:
        assert any(row['actor'] == hide_actor for row in inventory), hide_actor
        return patched, inventory
    scripts = [m for m in SCRIPT.finditer(patched) if 'fy-visual' in json.loads(m[2])]
    assert len(scripts) == 1
    match = scripts[0]
    original = json.loads(match[2])
    script = original
    # Retain shared Player and modal UI gates; replace all other derived gates.
    for logical, actual in gates.items():
        if actual == 520:
            continue
        pattern = rf'(?m)^{logical} read-mailbox 140 read-mailbox 0 = & [^\n]*{actual} write-mailbox\n'
        script, count = re.subn(pattern, '', script)
        assert count == 1, (logical, actual, count)
    new = ''.join(f'{logical} read-mailbox 102 read-mailbox {realm} = & 140 read-mailbox 0 = & {actual} write-mailbox\n'
                  for (logical, realm), actual in pairs.items())
    boundary = ';\n: fy-show-card'
    assert script.count(boundary) == 1
    script = script.replace(boundary, new + boundary)
    patched = patched[:match.start(2)] + json.dumps(script) + patched[match.end(2):]
    # Verify every exported object field except visibility and Player script.
    def strip(text):
        text = re.sub(r"\{ 'I32' \{ 'NAME' \"Visibility Mailbox\" \}[^\n]*", 'VISIBILITY', text)
        return SCRIPT.sub(lambda m: m[1] + 'SCRIPT' + m[3], text)
    assert strip(level) == strip(patched)
    return patched, inventory


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--loop', action='store_true')
    ap.add_argument('--fixtures', default='g0v0,g1v0,g1v1,g2v0,g3v0,g3v1,g4v0')
    ap.add_argument('--frames', default='200,323,400,575,650,800')
    ap.add_argument('--hide-actor', help='Independent single-actor visibility-zero probe')
    ap.add_argument('--capture-only', action='store_true', help='Reuse this audit\'s verified compiled diagnostic fixtures')
    ap.add_argument('--analyze-only', action='store_true', help='Validate and summarize existing captures without rendering')
    ap.add_argument('--label', help='Separate capture output name when reusing builds')
    a = ap.parse_args()
    label = 'loop' if a.loop else 'tours'
    if a.hide_actor:
        label += '-' + a.hide_actor
    out = ROOT.parents[1] / 'docs/diagnostics/parmenides/rooms-vista-review/area-audit' / (a.label or label)
    out.mkdir(parents=True, exist_ok=True)
    source_root = TOOLS / ('build-rooms/loopfx/scene9' if a.loop else 'build-rooms/scene9/review-fixtures')
    binary = Path('/home/will/wf-rooms-counters/engine/wf_game') if a.loop else Path('/home/will/tmp/rooms/wf_game-mbrfix-rel')
    base_root = ROOT / 'build-visibility-audit' / label / 'baseline'
    probe_root = ROOT / 'build-visibility-audit' / label / 'isolated'
    for fx in a.fixtures.split(','):
        if a.capture_only or a.analyze_only:
            prior = out.parent / label / (fx + '-actor-ownership.json')
            if prior != out / prior.name:
                shutil.copy2(prior, out / prior.name)
            continue
        group, view = int(fx[1]), int(fx[3])
        dirname = f'group-{group}-view-{view}'
        source = source_root / dirname
        gates = json.loads((source / 'visual-gates.json').read_text())
        level = (source / 'parmenides_slice.lev').read_text()
        isolated, inventory = isolate(level, gates, a.hide_actor)
        (out / (fx + '-actor-ownership.json')).write_text(json.dumps(inventory, indent=2) + '\n')
        for variant, target, data in [('baseline', base_root / dirname, level), ('isolated', probe_root / dirname, isolated)]:
            target.mkdir(parents=True, exist_ok=True)
            # Only original compiler inputs; never signing keys or packaged APKs.
            for origin in (ROOT / 'build/v0.7-polish', source):
                for p in origin.iterdir():
                    if p.is_file() and (p.suffix in ('.iff', '.tga') or p.name in ('actors.json', 'content.json', 'visual-gates.json')):
                        if p.name not in ('cd.iff', 'parmenides_slice.iff', 'parmenides_slice-standalone.iff'):
                            shutil.copy2(p, target / p.name)
            (target / 'parmenides_slice.lev').write_text(data)
            log = rooms.compile_level(target)
            (out / (fx + '-' + variant + '-build.log')).write_text(log)
            assert 'falls outside every room' not in log
        assert rooms.sha256(base_root / dirname / 'parmenides_slice-standalone.iff') == rooms.sha256(source / 'parmenides_slice-standalone.iff'), 'baseline must reproduce original compiled level'
        print('built', label, fx, 'baseline exact; area mesh inventory', len(inventory), flush=True)
    for variant, root in [('baseline', base_root), ('isolated', probe_root)]:
        if a.analyze_only:
            continue
        with (out / (variant + '-capture.log')).open('w') as log:
            subprocess.run([sys.executable, str(TOOLS / 'e3_parity.py'), 'capture', '--binary', str(binary),
                            '--fixtures', a.fixtures, '--fixture-root', str(root), '--frames', a.frames,
                            '--extra=--no-fps', '--out', str(out / variant)], stdout=log, stderr=subprocess.STDOUT, check=True)
        print('captured', variant, flush=True)
    manifests = [json.loads((out / variant / 'manifest.json').read_text()) for variant in ('baseline', 'isolated')]
    assert manifests[0]['binary_sha256'] == manifests[1]['binary_sha256']
    assert all(m['isolated_display'] for m in manifests)
    assert manifests[0]['gl_renderer'] == manifests[1]['gl_renderer']
    assert all(c['ok'] and c['no_human_input'] for m in manifests for c in m['captures'].values())
    rows = []
    for fx in a.fixtures.split(','):
        for frame in map(int, a.frames.split(',')):
            rel = Path(fx) / f'{frame}.png'
            base = Image.open(out / 'baseline' / rel).convert('RGB')
            probe = Image.open(out / 'isolated' / rel).convert('RGB')
            for variant in ('baseline', 'isolated'):
                log = gzip.open(out / variant / fx / f'{frame}.log.gz', 'rt', errors='replace').read()
                assert 'zforth compile error' not in log
            # The first-person final-dark temple view is legitimately black in
            # the recorded baseline. Capture completion and script errors are
            # checked independently; black pixels alone are not a failed render.
            delta = ImageChops.difference(base, probe)
            changed = sum(p != (0, 0, 0) for p in delta.get_flattened_data())
            rows.append(dict(fixture=fx, frame=frame, changed_pixels=changed, bbox=delta.getbbox()))
            print(rows[-1], flush=True)
    (out / 'results.json').write_text(json.dumps(dict(binary=str(binary), binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
                                                   baseline_exact=True, exported_fields_preserved=True,
                                                   hidden_actor=a.hide_actor, no_human_input=True, rows=rows), indent=2) + '\n')


if __name__ == '__main__':
    main()
