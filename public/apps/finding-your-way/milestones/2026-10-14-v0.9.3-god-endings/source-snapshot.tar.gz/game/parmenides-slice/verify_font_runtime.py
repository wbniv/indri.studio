#!/usr/bin/env python3
"""Real engine/input/font captures on a private container Xvfb display."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from texture_slots import runtime_args

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--runtime',type=Path,required=True)
    p.add_argument('--engine-src',type=Path,required=True)
    p.add_argument('--build-dir',type=Path,required=True)
    p.add_argument('--evidence',type=Path,required=True)
    a=p.parse_args();a.evidence.mkdir(parents=True,exist_ok=True)
    sys.path.insert(0,str(a.engine_src/'tests'))
    from debug_bridge_client import BridgeClient
    content=json.loads((a.build_dir/'content.json').read_text())
    metrics=json.loads((a.build_dir/'glyph-atlas.json').read_text())
    ids=json.loads((a.build_dir/'actors.json').read_text())['ids'];player=ids['Player']
    checks=[];captures=[]
    def check(name,condition):
        checks.append(dict(check=name,passed=bool(condition)))
        if not condition:raise AssertionError(name)
    xvfb=subprocess.Popen(['Xvfb',':96','-screen','0','1920x1080x24','-nolisten','tcp'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    engine=None;b=None
    try:
        time.sleep(.5)
        env=dict(os.environ,DISPLAY=':96')
        log=(a.evidence/'engine.log').open('w')
        engine=subprocess.Popen([str(a.runtime),'-L'+str(a.build_dir/'parmenides_slice-standalone.iff'),
             '--debug-port','7826','--debug-bind','127.0.0.1','-width=1920','-height=1080','--no-fps',
             *runtime_args(a.build_dir)],cwd=a.build_dir,env=env,stdout=log,stderr=subprocess.STDOUT)
        b=BridgeClient(port=7826,timeout=20)
        for mb in (110,111,129,140,629,630,631,632,103,170,101,102):b.watch(player,mb)
        value=lambda mb:b.mailbox_values.get((player,mb))
        def wait(predicate,label,timeout=20):
            deadline=time.monotonic()+timeout
            while time.monotonic()<deadline:
                if engine.poll() is not None:raise RuntimeError('engine exited: inspect engine.log')
                if predicate():return
                time.sleep(.02)
            raise AssertionError(label+': '+str({m:value(m) for m in (110,111,129,140,629,630,631,632)}))
        def ready(beat):wait(lambda:value(140)==beat and value(129) and value(632)==beat and value(630)>0,'text ready')
        def tap(bit):
            with b._lock:start=len(b._inbox)
            b.inject_input('joystick1_raw',bit,3)
            pressed=False
            def released():
                nonlocal start,pressed
                with b._lock:messages=b._inbox[start:];start=len(b._inbox)
                for row in messages:
                    if row.get('op')=='mailbox' and row.get('idx')==player and row.get('mailbox')==111:
                        if int(row['value'])&bit:pressed=True
                        elif pressed:return True
                return False
            wait(released,'input press/release');time.sleep(.15)
        def capture(name):
            target=a.evidence/(name+'.png');target.unlink(missing_ok=True)
            b.send({'op':'screenshot','filename':str(target)})
            wait(lambda:target.exists() and target.stat().st_size>0,'presented screenshot')
            from PIL import Image
            frame=Image.open(target).convert('RGB')
            if value(140):
                check(name+' opaque reader covers the actual surface',all(frame.getpixel(point)==(32,43,54) for point in ((0,0),(frame.width-1,0),(0,frame.height-1),(frame.width-1,frame.height-1))))
                # Compare the actual first heading glyph against its original R8
                # texels at the expected native-pixel position. This detects
                # renderer resampling even when layout geometry is correct.
                import numpy as np
                px=(36 if frame.height<900 else 54)*(2+int(value(631)))/2
                variant=next(v for v in metrics['variants'] if v[1]==1 and v[2]==px)
                glyph=next(g for g in metrics['glyphs'] if g[0]==variant[0] and g[1]==ord('T'))
                _,_,gx,gy,gw,gh,bx,by,_=glyph
                atlas=Image.open(a.build_dir/'glyph-atlas.png').convert('L')
                alpha=np.asarray(atlas.crop((gx,gy,gx+gw,gy+gh)),dtype=float)[...,None]/255
                expected=np.rint(np.array([32,43,54])*(1-alpha)+np.array([236,215,162])*alpha)
                x=int(frame.width*.04+.5)+bx;y=int(frame.height*.04+.5)+variant[3]+by
                actual=np.asarray(frame.crop((x,y,x+gw,y+gh)),dtype=float)
                check(name+' heading glyph matches original atlas texels at 1:1',np.max(np.abs(actual-expected))<=1)

            captures.append(dict(surface=list(frame.size),file=target.name,beat=value(140),page=value(629),pages=value(630),size=value(631),camera=value(101)))
        wait(lambda:value(110) is not None,'initial clock')
        ready(content['groups']['intro'][0]);capture('intro-1080-native')
        check('no pre-rendered card actors',not any(name.startswith('card_') for name in ids))
        def render_inventory(height):
            # Changing the beat invalidates the acknowledgement from the old
            # layout, so readiness proves a draw at this output and baked size.
            for size in range(3):
                b.set_mailbox(631,size,player)
                for beat in content['runtime_beats']:
                    b.set_mailbox(140,beat['id'],player);ready(beat['id'])
                    check(f'runtime beat {beat["id"]} rendered at {height}p size {size}',value(632)==beat['id'])
            b.set_mailbox(631,0,player)
        render_inventory(1080)
        prosecutor=content['groups']['prosecutor'][0]
        b.set_mailbox(170,0,player);b.set_mailbox(631,0,player);b.set_mailbox(140,prosecutor,player);ready(prosecutor)
        capture('prosecutor-1080-standard')
        total=int(value(630));check('full prosecutor needs display pagination',total>1)
        for page in range(total):
            check('no early prosecutor completion '+str(page),value(170)==0)
            check('display page before Continue '+str(page),value(629)==page and value(140)==prosecutor)
            tap(1)
            if page+1<total:wait(lambda:value(629)==page+1,'display page advances within semantic beat')
        wait(lambda:value(140)==0 and value(170)==1,'encounter completes only after final display page')
        b.set_mailbox(140,prosecutor,player);ready(prosecutor);tap(2048)
        wait(lambda:value(631)==1,'UP selects baked 150% size');capture('prosecutor-1080-150')
        tap(2048);wait(lambda:value(631)==2,'UP selects baked 200% size');capture('prosecutor-1080-200')
        tap(4096);wait(lambda:value(631)==1,'DOWN selects baked 150% size')
        tap(16384);wait(lambda:value(140)==0,'LEFT closes reading without advancing encounter');capture('npc-signs-1080')
        from Xlib.display import Display
        d=Display(':96');windows=d.screen().root.query_tree().children
        window=next(w for w in windows if w.get_geometry().width>=1000)
        window.configure(width=1280,height=720);d.sync();time.sleep(.4)
        b.set_mailbox(631,0,player);b.set_mailbox(140,prosecutor,player);ready(prosecutor);capture('prosecutor-720-standard')
        tap(2048);tap(2048);capture('prosecutor-720-200')
        render_inventory(720)
        d.close()
        report=dict(passed=all(row['passed'] for row in checks),checks=checks,captures=captures,
                    runtimeArguments=runtime_args(a.build_dir),
                    engineSha256=hashlib.sha256(a.runtime.read_bytes()).hexdigest(),
                    levelSha256=hashlib.sha256((a.build_dir/'parmenides_slice-standalone.iff').read_bytes()).hexdigest(),
                    atlasSha256=hashlib.sha256((a.build_dir/'dialogue-glyphs.bin').read_bytes()).hexdigest())
        (a.evidence/'results.json').write_text(json.dumps(report,indent=2)+'\n')
        print(f'PASS {len(checks)} real runtime checks; {len(captures)} presented captures',flush=True)
    finally:
        if b:b.close()
        for proc in (engine,xvfb):
            if proc and proc.poll() is None:
                proc.terminate()
                try:proc.wait(timeout=10)
                except subprocess.TimeoutExpired:proc.kill();proc.wait()

if __name__=='__main__':main()
