// Exercise the actual exported fy-advance word in the engine's zForth VM.
// Codex (gpt-6.1-sol, effort high), 2026-10-09.
#include <zforth.h>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iterator>
#include <string>
static float mailboxes[640];
static int completed=0,checks=0;
static void Check(bool value,const char* label){++checks;if(!value){std::fprintf(stderr,"FAIL %s\n",label);std::exit(1);}}
extern "C" zf_input_state zf_host_sys(zf_ctx* ctx,zf_syscall_id id,const char*){
    if(id==128||id==129){int index=int(zf_pop(ctx));Check(index>=0&&index<640,"mailbox bounds");
        if(id==128)zf_push(ctx,mailboxes[index]);else mailboxes[index]=zf_pop(ctx);
    }else if(id==130){++completed;mailboxes[140]=0;}else zf_abort(ctx,ZF_ABORT_EXTERNAL);
    return ZF_INPUT_INTERPRET;
}
extern "C" void zf_host_trace(zf_ctx*,const char*,va_list){}
extern "C" zf_cell zf_host_parse_num(zf_ctx* ctx,const char* text){char* end;float value=std::strtof(text,&end);if(*end)zf_abort(ctx,ZF_ABORT_NOT_A_WORD);return value;}
int main(int argc,char** argv){
    Check(argc==2,"supply actual chapter.fth");std::ifstream input(argv[1]);
    std::string source{std::istreambuf_iterator<char>(input),{}};
    size_t begin=source.find(": fy-advance "),end=source.find(';',begin);
    Check(begin!=std::string::npos&&end!=std::string::npos,"exported advance word exists");
    source=source.substr(begin,end-begin+1);
    zf_ctx ctx;zf_init(&ctx,0);zf_bootstrap(&ctx);
    // Same dictionary/control-flow helpers as scripting_zforth.cc's core bootstrap.
    Check(zf_eval(&ctx,": @ 0 @@ ; : , 0 ,, ; : !j 64 !! ; : ,j 64 ,, ; : here h @ ; : < - <0 ; : if ' jmp0 , here 0 ,j ; immediate : else ' jmp , here 0 ,j swap here swap !j ; immediate : then here swap !j ; immediate")==ZF_OK,"engine control-flow helpers");
    Check(zf_eval(&ctx,": read-mailbox 128 sys ; : write-mailbox 129 sys ; : fy-semantic-advance 130 sys ;")==ZF_OK,"mailbox and completion host setup");
    Check(zf_eval(&ctx,source.c_str())==ZF_OK,"compile actual exported advance word");
    auto advance=[&](){Check(zf_eval(&ctx,"fy-advance")==ZF_OK,"evaluate actual word");};
    for(int pages=1;pages<=8;++pages){
        completed=0;mailboxes[140]=41;mailboxes[629]=0;mailboxes[630]=float(pages);mailboxes[632]=42;
        advance();Check(completed==0&&mailboxes[629]==0,"different beat acknowledgement cannot advance");mailboxes[632]=0;
        for(int page=0;page<pages;++page){
            for(int i=0;i<3;++i){advance();Check(completed==0&&mailboxes[629]==page,"unrendered page cannot advance or complete");}
            // Simulate the renderer's acknowledgement only after presenting this page.
            mailboxes[632]=41;advance();Check(mailboxes[632]==0,"Continue invalidates render acknowledgement");
            if(page+1<pages)Check(mailboxes[629]==page+1&&completed==0,"one rendered page advances exactly once");
            else Check(completed==1&&mailboxes[140]==0,"completion requires acknowledged final page");
        }
    }
    std::printf("PASS %d checks; actual zForth page-ready protocol\n",checks);
}
