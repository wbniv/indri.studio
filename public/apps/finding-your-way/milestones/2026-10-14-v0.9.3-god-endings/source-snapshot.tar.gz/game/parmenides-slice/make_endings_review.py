"""Create the identity-bound E gallery from real Blender/native evidence."""
import argparse
import hashlib
import html
import json
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('--build-dir',type=Path,required=True)
p.add_argument('--evidence',type=Path,required=True);a=p.parse_args()
out=a.build_dir.resolve();e=a.evidence.resolve()
b=json.loads((out/'build-receipt.json').read_text());assert b['artStage']=='endings-surgery'
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
assert digest(Path(b['apk']))==b['sha256'];rows=[]
for folder,name,key,method in (('blender','manifest.json','views','Actual editable Blender geometry; review cameras/lighting'),
                             ('final-native','capture-manifest.json','shots','Actual native recorded FBO frame')):
    manifest=json.loads((e/folder/name).read_text());assert manifest['build']['sha256']==b['sha256']
    for row in manifest[key]:
        rel=folder+'/'+row['file'];sha=digest(e/rel)
        if row.get('sha256'):assert row['sha256']==sha
        rows.append(dict(file=rel,sha256=sha,method=method))
assert len(rows)==61
(e/'review-manifest.json').write_text(json.dumps(dict(build=b,images=rows,
    scope='E endings/surgery artwork, actual native effects and patient poses; A–D retained. F is v0.7 polish; optimization is v0.8.',
    feedback='Max after A–F; no intermediate Will style approval or delivery implied'),indent=2)+'\n')
css='body{margin:2rem;background:#20272b;color:#e6dcc4;font:16px/1.5 sans-serif}a{color:#d9b75f}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(310px,1fr));gap:1rem}figure{margin:0;padding:.8rem;background:#303b45}img{width:100%;max-height:540px;object-fit:contain}figcaption{margin-top:.5rem}video{width:100%;max-width:1100px}code{overflow-wrap:anywhere}'
parts=['<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Iteration E — endings and surgery</title><style>'+css+'</style><h1>Iteration E — endings and surgery</h1>',
       '<p>Original Blender assets and actual exported native frames. The visible ending effects pause during source reading; masked surgeons keep the established patient camera. Max supplies feedback after A–F.</p>',
       '<p>APK <code>'+b['sha256']+'</code>. <a href="README.md">Verification scope, partial glove/background/framing caveats and retained failures</a>.</p>',
       '<video controls preload="metadata" src="final-native/art-proof.mp4"></video><div class="grid">']
for row in rows:
    name=html.escape(row['file'],quote=True)
    parts.append(f'<figure><a href="{name}"><img loading="lazy" src="{name}" alt="{name}"></a><figcaption>{name}<br>{html.escape(row["method"])}</figcaption></figure>')
parts.append('</div>');(e/'review.html').write_text('\n'.join(parts)+'\n')
print('E gallery:',len(rows),'images')
