import { chromium, firefox } from '/home/will/finding-your-way/node_modules/@playwright/test/index.mjs';
import assert from 'node:assert/strict';
import { mkdirSync,writeFileSync } from 'node:fs';
const [base,out]=process.argv.slice(2);mkdirSync(out,{recursive:true});
const engine=process.env.FYW_BROWSER||'chromium';
const browser=engine==='firefox'?await firefox.launch({headless:false}):await chromium.launch({executablePath:'/usr/bin/google-chrome',headless:true,args:['--no-sandbox','--enable-unsafe-swiftshader']});
const results=[];
try {
 for(const [name,width,height,touch] of (engine==='firefox'?[['desktop',1280,900,false]]:[['desktop',1280,900,false],['phone',390,844,true]])){
  const ctx=await browser.newContext({viewport:{width,height},hasTouch:touch});const page=await ctx.newPage();
  const requests=[],errors=[],reader=[];page.on('request',r=>requests.push(r.url()));page.on('pageerror',e=>errors.push(e.stack));
  page.on('console',m=>{const match=m.text().match(/BITMAP_TEXT beat=1 surface=(\d+)x(\d+) body_px=(\d+)/);if(match)reader.push({width:+match[1],height:+match[2],pixels:+match[3]});});
  const app=base+'/apps/finding-your-way/';await page.goto(app,{waitUntil:'networkidle'});
  assert.equal(await page.locator('iframe.fyw-browser-frame').count(),0);
  assert.equal(requests.some(u=>/play\/bundles|wf_game\.(js|wasm|data)/.test(u)),false);
  const apkLinks=await page.locator('a[href$=".apk"]').count();assert(apkLinks>0,'Android downloads missing');
  await page.locator('#web-3d-play summary strong').scrollIntoViewIfNeeded();
  if (!await page.locator('#web-3d-play').evaluate(e=>e.open)) await page.locator('#web-3d-play summary').click();
  const cta=page.locator('#web-3d-play .web-play-button');
  await cta.waitFor({state:'visible'});
  await page.waitForFunction(()=>document.querySelector('#web-3d-play .web-play-button').getBoundingClientRect().height>=55.5);
  assert(parseFloat(await cta.evaluate(e=>getComputedStyle(e).minHeight))>=56,'Browser play button is too small');
  assert.equal(await cta.evaluate(e=>getComputedStyle(e).textDecorationLine),'none');
  await page.screenshot({path:out+'/'+name+'-play-button.png',fullPage:true});
  await cta.click();await page.waitForURL('**/apps/finding-your-way/play/');
  const player=page.frameLocator('.fyw-browser-frame');await player.getByRole('button',{name:'Play',exact:true}).waitFor();
  assert.equal(requests.some(u=>/wf_game\.(js|wasm|data)/.test(u)),false);
  await page.screenshot({path:out+'/'+name+'-page-before-play.png',fullPage:true});
  await player.getByRole('button',{name:'Play',exact:true}).click();
  const frame=page.frames().find(f=>new URL(f.url()).pathname.endsWith('/frame.html'));assert(frame, page.frames().map(f=>f.url()).join('\n'));
  await frame.waitForFunction(()=>document.querySelector('#overlay').hidden,null,{timeout:60000});
  await frame.waitForFunction(()=>document.fullscreenElement?.id==='stage');
  await page.waitForTimeout(1500);
  await player.locator('#canvas').focus();
  const surface=await frame.evaluate(()=>[Module.canvas.width,Module.canvas.height]);
  const basePixels=reader.at(-1)?.pixels || (surface[1]>=900?42:28);
  async function size(expected){
   const next=page.waitForEvent('console',{predicate:m=>m.text().includes('body_px='+expected+' '),timeout:15000});
   await page.keyboard.down('ArrowUp');try{await next;}finally{await page.keyboard.up('ArrowUp');await page.waitForTimeout(500);}
  }
  await size(basePixels*3/2);await size(basePixels*2);
  await page.screenshot({path:out+'/'+name+'-fullscreen-largest.png',fullPage:true});
  await player.getByRole('button',{name:'Exit fullscreen',exact:true}).click();await frame.waitForFunction(()=>!document.fullscreenElement);
  await page.waitForTimeout(1000);
  assert.equal(await frame.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
  assert.equal(errors.length,0,errors.join('\n'));
  await player.getByRole('button',{name:'Game menu',exact:true}).click();
  assert.equal(await player.locator('#menu button svg[aria-hidden="true"]').count(),4);
  await page.screenshot({path:out+'/'+name+'-menu-icons.png',fullPage:true});
  await player.getByRole('button',{name:'Resume game',exact:true}).click();
  await page.screenshot({path:out+'/'+name+'-page-after-fullscreen.png',fullPage:true});
  await page.getByRole('link',{name:'← App details and downloads',exact:true}).click();await page.waitForURL(app);
  assert.equal(await page.locator('iframe.fyw-browser-frame').count(),0);
  assert.equal(await page.locator('a[href$=".apk"]').count(),apkLinks);
  results.push({name,playOpensFullscreen:true,fullscreenExit:true,prominentPlayButton:true,menuIcons:true,largestReader:true,surface,reader,apkLinks,noGameDownloadBeforePlay:true,backNavigation:true,errors});await ctx.close();
 }
 writeFileSync(out+'/results.json',JSON.stringify({passed:true,base,browser:await browser.version(),results,limits:'Ubuntu 24.10 desktop browser; phone viewport/touch emulation, not real-device acceptance. Static preview does not apply Cloudflare response headers.'},null,2)+'\n');
 console.log('PASS Indri app/page navigation, lazy loading, iframe fullscreen, largest reader and retained APK links');
}finally{await browser.close();}
