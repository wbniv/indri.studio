"""Build labelled Android rendering fixtures using the unchanged native runtime.

The Android release omits the desktop debug bridge. These diagnostic APKs add
only a bounded, level-owned tour to the Player script; they are never archived
as a production release or presented as proof of remote-driven full gameplay.
All device operation/recording remains owned by the existing coordinator.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import zipfile

import build

ROOT=Path(__file__).resolve().parent
BASE=ROOT/'build'
SCENES=[('temple',0,3,1,'intro'),('love',1,96,1,'first'),
        ('reason',2,196,0,'white'),('truth',3,294,0,'prosecutor'),
        ('god',4,400,1,'young_man'),('being',5,500,0,'ending_10a'),
        ('both',6,600,0,'ending_10b'),('notbeing',7,700,0,'ending_10c'),
        ('surgery',8,800,0,'ending_101b')]
SCENES=[(*row,{}) for row in SCENES]
SCENES += [
    ('temple-final-bright',0,3,1,'return_9a',{106:1,107:1,154:1,155:1,176:1,177:1,195:1,196:1,197:1,188:1}),
    ('temple-final-dark',0,3,1,'return_9p',{106:1,107:-1,154:1,155:-1,176:1,177:-1,195:1,196:-1,197:16,188:1}),
    ('temple-post-love-notbeing',0,3,1,'return_notbeing',{106:1,107:-1}),
    ('reason-transformed',2,204,5,'wild',{150:1,151:1,152:1,157:1}),
    ('god-summit',4,400,30,'god_question',{190:1,191:1,192:1,193:1}),
    ('love-temple-sign',1,100,-2,'journal',{}),
]

def tour(original,scenes,mode,content):
    # Reuse helpers to keep the diagnostic addition below the pinned zForth
    # dictionary limit; repeating six time-window branches per scene overflowed.
    defs=[': fy-review-setup\n']
    for i,(name,realm,x,y,key,history) in enumerate(scenes):
        from god_scene import height
        # Keep the first-person eye in front of actors, rather than beyond them.
        if mode==1 and realm<=4 and name not in ('god-summit','love-temple-sign','reason-transformed'):y-=2
        z=height(y)+.16 if realm==4 else .15
        heading=.75 if name in ('god-summit','love-temple-sign') else .25
        setters=f'{heading} 114 write-mailbox '+''.join(f'{v} {mb} write-mailbox ' for mb,v in history.items())
        defs.append(f'471 read-mailbox {i} = if {x} {y} fy-teleport {z} INDEXOF_Z_POS write-mailbox {realm} 102 write-mailbox {setters}{content["groups"][key][0]} 474 write-mailbox then\n')
    defs.append(';\n: fy-review-tick INDEXOF_DELTA_TIME read-mailbox 0 max 0.1 min 470 read-mailbox + 470 write-mailbox fy-stop\n')
    defs.append(f'470 read-mailbox 5 >= 470 read-mailbox {5+18*len(scenes)} < & if\n')
    defs.append('470 read-mailbox 5 - 18 / 0 | 471 write-mailbox\n')
    defs.append('470 read-mailbox 5 - 471 read-mailbox 18 * - 473 write-mailbox\n')
    defs.append(f'471 read-mailbox 1 + 475 read-mailbox <> if 471 read-mailbox 1 + 475 write-mailbox fy-reset-reason fy-reset-truth fy-reset-god 0 106 write-mailbox 0 107 write-mailbox 0 140 write-mailbox {mode} 101 write-mailbox fy-review-setup 0 476 write-mailbox then\n')
    # Patient motion is fixed in production. Do not bypass that contract with
    # diagnostic raw engine movement or a turn during the upward shot.
    defs.append('473 read-mailbox 3 >= 473 read-mailbox 5 < & 102 read-mailbox 8 <> & if 2048 INDEXOF_INPUT write-mailbox then\n')
    defs.append('473 read-mailbox 5 >= 473 read-mailbox 9 < & 102 read-mailbox 8 <> & if 473 read-mailbox 5 - 4 / 0.25 + fy-wrap 114 write-mailbox then\n')
    defs.append('473 read-mailbox 9 >= 476 read-mailbox 0 = & if fy-review-setup 1 476 write-mailbox then\n')
    defs.append('473 read-mailbox 10 >= 476 read-mailbox 1 = & if 474 read-mailbox 140 write-mailbox 2 476 write-mailbox then\n')
    defs.append('473 read-mailbox 12 >= 476 read-mailbox 2 = & if fy-advance 3 476 write-mailbox then\n')
    defs.append('473 read-mailbox 14 >= 476 read-mailbox 3 = & if 0 140 write-mailbox 4 476 write-mailbox then\n')
    defs.append('then ;\n')
    tail=original.splitlines(keepends=True)[-1]
    assert tail.startswith('fy-init fy-input ')
    replacement=tail.replace('fy-input ','fy-input fy-review-tick ',1)
    revised=original[:-len(tail)]+''.join(defs)+replacement
    phases=[]
    for i,(name,realm,x,y,key,history) in enumerate(scenes):
        start=5+i*18
        for a,z,label in [(3,5,'native-forward'),(5,9,'full-turn'),(9,10,'approach'),(10,12,'open'),(12,14,'advance'),(14,18,'close')]:
            if realm==8 and label in ('native-forward','full-turn'):label='fixed-patient-motion'
            phases.append(dict(scene=name,realm=realm,camera=mode,phase=label,source_group=key,history=history,start=start+a,end=start+z))
    return revised,phases

def make(group,mode,lifecycle=False,scene_only=None,diagnostic_version_code=None,render_scope=0):
    if render_scope not in (0, 1):raise ValueError('Render scope must be 0 or 1')
    scenes=SCENES[group*3:group*3+3]
    if scene_only:
        scenes=[row for row in scenes if row[0]==scene_only]
        if not scenes:raise ValueError('Scene is not in this group')
    suffix=('-'+scene_only) if scene_only else ''
    name='lifecycle-reading'+suffix+f'-view-{mode}' if lifecycle else f'group-{group}-view-{mode}'+suffix
    out=BASE/'review-fixtures'/(name+('-current' if render_scope else ''))
    out.mkdir(parents=True,exist_ok=True)
    # Copy only compiler inputs, avoiding recordings, signing keys and old APKs.
    for p in BASE.iterdir():
        if p.is_file() and (p.suffix in ('.iff','.tga') or p.name in ('runtime-provenance.json','actors.json','content.json','visual-gates.json','texture-slots.json','room-layout.json')):
            shutil.copy2(p,out/p.name)
    shutil.copy2(BASE/'development-signing.p12',out/'development-signing.p12')
    content=json.loads((BASE/'content.json').read_text())
    original=(BASE/'chapter.fth').read_text()
    revised,phases=tour(original,scenes,mode,content)
    if lifecycle:
        # Park at a real multi-page account. Ordinary remote input advances it;
        # no timed tour can change the page while Home/resume is being checked.
        tail=original.splitlines(keepends=True)[-1]
        if scene_only=='surgery':
            setup=f': fy-review-start 470 read-mailbox 0 = if 1 470 write-mailbox 800 0 fy-teleport 8 102 write-mailbox 0.25 114 write-mailbox {mode} 101 write-mailbox 2 189 write-mailbox 2 222 write-mailbox 1 223 write-mailbox 0 140 write-mailbox then ;\n'
            phases=[dict(scene='surgery',realm=8,camera=mode,phase='remote opens source from patient view; Home/resume')]
        else:
            setup=': fy-review-start 470 read-mailbox 0 = if 1 470 write-mailbox 96 0 fy-teleport 1 102 write-mailbox 0.25 114 write-mailbox '+str(content['groups']['first'][0])+' 140 write-mailbox then ;\n'
            phases=[dict(scene='love',realm=1,camera=0,phase='remote-driven multi-page reading and Home/resume')]
        revised=original[:-len(tail)]+setup+tail.replace('fy-init ','fy-init fy-review-start ',1)
    lev=(BASE/'parmenides_slice.lev').read_text()
    # Native exporter uses JSON-compatible escapes for the script string.
    pattern=r"(\{ 'STR' \{ 'NAME' \"Script\" \} \{ 'STR' )(\"(?:[^\"\\]|\\.)*\")( \} \})"
    count=0
    def replace(m):
        nonlocal count
        if json.loads(m[2])==original:
            count+=1;return m[1]+json.dumps(revised)+m[3]
        return m[0]
    lev=re.sub(pattern,replace,lev);assert count==1,count
    (out/'parmenides_slice.lev').write_text(lev)
    (out/'chapter.fth').write_text(revised)
    tool=lambda n:build.WF/'wftools'/(n+'-rs')/'target/release'/n
    run=lambda *args:subprocess.run([str(a) for a in args],cwd=out,check=True)
    level='parmenides_slice'
    run(tool('iffcomp'),'-binary','-o='+level+'.lev.bin',level+'.lev')
    run(tool('levcomp'),level+'.lev.bin',build.WF/'wfsource/source/oas/objects.lc',level+'.lvl',build.WF/'wfsource/source/oas','--mesh-dir','.','--iff-txt',level+'.iff.txt','--textile-ini',level+'.ini')
    run(tool('textile'),'-ini='+level+'.ini','-Tlinux','-transparent=0,0,0','-pagex=1024','-pagey=2048','-permpagex=2048','-permpagey=2048','-palx=256','-paly=8','-alignx=w','-aligny=h','-flipyout')
    run(tool('iffcomp'),'-binary','-o='+level+'.iff',level+'.iff.txt')
    (out/(level+'-standalone.iff.txt')).write_text("{ 'L4' { 'ALGN' .align( 2048 ) } { 'RAM' 'OBJD' 4194304l 'PERM' 16777216l 'ROOM' 8388608l 'FLAG' 1l 1l } { 'ALGN' .align( 2048 ) } [ \"parmenides_slice.iff\" ] }\n")
    run(tool('iffcomp'),'-binary','-o='+level+'-standalone.iff',level+'-standalone.iff.txt')
    if (BASE/'dialogue-glyphs.bin').exists():
        from glyph_atlas import append_to_level
        append_to_level(out/(level+'-standalone.iff'), (BASE/'dialogue-glyphs.bin').read_bytes())
    from level_settings import attach
    attach(out/(level+'-standalone.iff'), out/'actors.json', out, build.WF, scope=render_scope)
    run(tool('cdpack'),build.WF/'wfsource/source/game/shell.fth',level+'-standalone.iff','-o',out/'cd.iff')
    previous=build.OUT;build.OUT=out
    production=json.loads((BASE/'build-receipt.json').read_text())
    old_stage,old_version,old_code,old_layout=build.ART_STAGE,build.VERSION,build.VERSION_CODE,build.ROOM_LAYOUT
    build.ART_STAGE=production.get('artStage','baseline');build.VERSION=production['version'];build.VERSION_CODE=production['versionCode'] if diagnostic_version_code is None else int(diagnostic_version_code)
    build.ROOM_LAYOUT=production.get('roomLayout','two')
    if build.VERSION_CODE<=0:raise ValueError('Diagnostic versionCode must be positive')
    if build.ART_STAGE!='baseline':
        for name in ('art-manifest.json','art-textures.json'):
            shutil.copy2(BASE/name,out/name)
    try:build.package()
    finally:build.OUT=previous;build.ART_STAGE=old_stage;build.VERSION=old_version;build.VERSION_CODE=old_code;build.ROOM_LAYOUT=old_layout
    receipt=json.loads((out/'build-receipt.json').read_text())
    production=json.loads((BASE/'build-receipt.json').read_text())
    with zipfile.ZipFile(receipt['apk']) as diag,zipfile.ZipFile(production['apk']) as normal:
        for n in normal.namelist():
            if n.startswith('META-INF/') or n=='assets/cd.iff':continue
            if n=='AndroidManifest.xml' and diagnostic_version_code is not None:
                # A comparison may share a code to permit update installation.
                # Require every manifest node/attribute except that exact field.
                manifests=[subprocess.check_output([str(build.TOOLS/'aapt'),'dump','xmltree',path,'AndroidManifest.xml'],text=True) for path in (receipt['apk'],production['apk'])]
                clean=lambda xml:'\n'.join(line for line in xml.splitlines() if 'android:versionCode(' not in line)
                assert clean(manifests[0])==clean(manifests[1]),'Unexpected diagnostic manifest change'
                assert f'0x{int(diagnostic_version_code):x}' in next(line for line in manifests[0].splitlines() if 'android:versionCode(' in line)
                continue
            assert diag.read(n)==normal.read(n),n
    receipt.update(diagnostic_only=True,production_apk_sha256=production['sha256'],
                   diagnostic_version_code_override=diagnostic_version_code,
                   changed_level_source='Only Player script adds '+('initial reading fixture' if lifecycle else 'bounded rendering tour'),phases=phases,
                   scope='Native movement plus scripted fixture/page selection; not remote-driven route acceptance',
                   source_script_sha256=hashlib.sha256(original.encode()).hexdigest(),duration=65,
                   render_scope=render_scope)
    (out/'review-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print('DIAGNOSTIC FIXTURE',out/'review-receipt.json',flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--group',type=int,choices=range(5),required=True);p.add_argument('--mode',type=int,choices=(0,1),required=True);p.add_argument('--lifecycle',action='store_true');p.add_argument('--scene-only');p.add_argument('--build-dir',type=Path);p.add_argument('--art-proof',action='store_true');p.add_argument('--temple-love',action='store_true');p.add_argument('--render-scope',type=int,choices=(0,1),default=0);a=p.parse_args()
    if a.build_dir:BASE=a.build_dir.resolve()
    if a.art_proof:
        if a.group!=0:raise ValueError('Art proof uses only group 0')
        SCENES=[('temple',0,3,0,'intro',{}),('love-corner',1,96,0,'first',{}),('love-props',1,100,5,'paper',{})]
    if a.temple_love:
        if a.group!=0:raise ValueError('Temple/Love review uses group 0')
        SCENES=[('temple-return',0,0,-3,'return_being' if a.mode==0 else 'return_notbeing',{106:1,107:1 if a.mode==0 else -1}),('love-first',1,96,0,'first',{}),('love-starlet',1,104,1,'starlet',{})]
    make(a.group,a.mode,a.lifecycle,a.scene_only,render_scope=a.render_scope)
