| Date | Change |
|------|--------|
| [2026-10-07](https://github.com/wbniv/finding-your-way/commit/bcc0c9f) | docs: record verified v0.7 publication and archive caveats |
| [2026-10-07](https://github.com/wbniv/finding-your-way/commit/d47d821) | Verify v0.7 dialogue presentation boundaries and complete release audit |
| [2026-10-07](https://github.com/wbniv/finding-your-way/commit/455673a) | Implement v0.7 polish and collision-independent dialogue camera |
| [2026-10-07](https://github.com/wbniv/finding-your-way/commit/ff73d8a) | Implement iteration B Temple and Love art |
| [2026-10-06](https://github.com/wbniv/finding-your-way/commit/af56b47) | Build iteration A original Blender art and verified native proof |
| [2026-10-06](https://github.com/wbniv/finding-your-way/commit/9b5d4f3) | Fix v0.5.5 patient framing and replace only surgery review captures |
| [2026-10-06](https://github.com/wbniv/finding-your-way/commit/5ad2c03) | Verify v0.5.5 moving views and dialogue transitions; pin author comparison media |
| [2026-10-06](https://github.com/wbniv/finding-your-way/commit/c87adc5) | Verify v0.5.5 dialogue visibility and shared mesh winding |
| [2026-10-06](https://github.com/wbniv/finding-your-way/commit/48d1cb3) | Correct milestone numbering to v0.5 and v0.5.5 |
| [2026-10-06](https://github.com/wbniv/finding-your-way/commit/a636379) | Implement and verify complete endings for v5.0 |
| [2026-10-06](https://github.com/wbniv/finding-your-way/commit/4c8c488) | Complete God realm and verify four-realm milestone with fixed atlas runtime |
| [2026-10-05](https://github.com/wbniv/finding-your-way/commit/20c4820) | Implement Truth realm and verify eight Temple histories |

<!--history-meta v1
bcc0c9f	author	Will Norris
bcc0c9f	added	2
bcc0c9f	deleted	0
bcc0c9f	files	1
d47d821	author	Will Norris
d47d821	added	2
d47d821	deleted	0
d47d821	files	1
455673a	author	Will Norris
455673a	added	8
455673a	deleted	0
455673a	files	1
ff73d8a	author	Will Norris
ff73d8a	added	27
ff73d8a	deleted	0
ff73d8a	files	1
af56b47	author	Will Norris
af56b47	added	3
af56b47	deleted	1
af56b47	files	1
9b5d4f3	author	Will Norris
9b5d4f3	added	4
9b5d4f3	deleted	1
9b5d4f3	files	1
5ad2c03	author	Will Norris
5ad2c03	added	3
5ad2c03	deleted	2
5ad2c03	files	1
c87adc5	author	Will Norris
c87adc5	added	4
c87adc5	deleted	4
c87adc5	files	1
48d1cb3	author	Will Norris
48d1cb3	added	6
48d1cb3	deleted	6
48d1cb3	files	1
a636379	author	Will Norris
a636379	added	13
a636379	deleted	9
a636379	files	1
4c8c488	author	Will Norris
4c8c488	added	10
4c8c488	deleted	9
4c8c488	files	1
20c4820	author	Will Norris
20c4820	added	32
20c4820	deleted	0
20c4820	files	1
20c4820	body	Checkpoint the Blender-authored native adventure, level Forth, source-preserving dialogue, and reproducible build/audit/archive tasks. Truth adds courtroom testimony, evidence inspection and presentation, both counsels, replay safety and eight Temple returns.\n\nVerified 1067 native runtime checks, 165 source checks, 494 exported-asset checks, and all 123 dialogue cards across 379 sequences. Chromecast 1 job J-0d55b0bd86cc passed install, launch, remote keys and Home/resume. Engine libraries are unchanged; God/endings and phone acceptance remain open. Authored with Codex (GPT-6).
-->
