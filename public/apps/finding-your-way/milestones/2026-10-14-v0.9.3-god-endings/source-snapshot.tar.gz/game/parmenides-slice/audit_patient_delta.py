"""Compare frozen Blender inputs and exports before reusing unaffected captures."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

import bpy

ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--before',type=Path,required=True)
parser.add_argument('--evidence',type=Path,required=True)
args=parser.parse_args(sys.argv[sys.argv.index('--')+1:])
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def scene(path):
    bpy.ops.wm.open_mainfile(filepath=str(path))
    rows={}
    for obj in bpy.context.scene.objects:
        row=dict(type=obj.type,transform=[list(r) for r in obj.matrix_world],
                 properties={k:repr(obj[k]) for k in obj.keys()})
        if obj.type=='MESH':
            row.update(vertices=[list(v.co) for v in obj.data.vertices],
                       faces=[(list(p.vertices),p.material_index) for p in obj.data.polygons],
                       materials=[m.name for m in obj.data.materials])
        rows[obj.name]=row
    return rows

before=scene(args.before)
after=scene(ROOT/'build/parmenides_slice.blend')
assert before.keys()==after.keys(),'Actor set changed'
changed=[name for name in before if before[name]!=after[name]]
expected={'surgeon_1','surgeon_2','surgeon_3','surgical_lamp'}
assert set(changed)==expected,changed
old=json.loads((args.evidence/'before/export-hashes.json').read_text())
new={name:digest(ROOT/'build'/name) for name in old}
changed_exports=[name for name in old if old[name]!=new[name]]
assert (args.evidence/'before/chapter.fth').read_bytes()==(ROOT/'build/chapter.fth').read_bytes()
assert (args.evidence/'before/content.json').read_bytes()==(ROOT/'build/content.json').read_bytes()
mesh_changes={n for n in changed_exports if n.endswith('.iff') and n not in {'cd.iff','parmenides_slice.iff','parmenides_slice-standalone.iff'}}
assert mesh_changes=={n+'.iff' for n in expected},mesh_changes
assert not any(n.endswith('.tga') for n in changed_exports),'Texture changed'
result=dict(passed=True,build=json.loads((ROOT/'build/build-receipt.json').read_text()),
            prior_build=json.loads((args.evidence/'before/build-receipt.json').read_text()),
            changed_actors=changed,changed_exports=changed_exports,
            before_blend_sha256=digest(args.before),after_blend_sha256=digest(ROOT/'build/parmenides_slice.blend'),
            exports_before=old,exports_after=new,
            scope='Only three surgeons and lamp differ in original Blender actors/geometry. All scripts, cards, textures, camera, dialogue and unrelated actors remain byte-identical. Prior captures retain their original build identity; they are not new-build tests.')
(args.evidence/'delta-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print('Verified changed actors:',changed)
