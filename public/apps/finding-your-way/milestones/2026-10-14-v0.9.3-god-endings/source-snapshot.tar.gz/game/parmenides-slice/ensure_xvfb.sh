#!/usr/bin/env bash
# ensure_xvfb.sh: print the path of an Xvfb launcher, provisioning one without root.
#
# e3_parity.py renders its captures on a private virtual X display so that no
# window opens on the desktop and nothing the user types can reach the game.
# Uses a system Xvfb when there is one; otherwise downloads the xvfb and
# libunwind8 .debs with `apt-get download` (no sudo), unpacks them under
# $WF_PARITY_CACHE (default ~/.cache/wf-parity) and writes a wrapper that sets
# LD_LIBRARY_PATH. Idempotent: a second run only prints the path.
set -euo pipefail

usage() {
    cat <<'EOF'
Usage: ensure_xvfb.sh [-h|--help]

Prints the path of an executable Xvfb (system, or a root-free unpack of the
Ubuntu/Debian xvfb package under $WF_PARITY_CACHE, default ~/.cache/wf-parity).
EOF
}
case "${1:-}" in
    -h|--help) usage; exit 0 ;;
    "") ;;
    *) usage >&2; exit 2 ;;
esac

if command -v Xvfb >/dev/null 2>&1; then
    command -v Xvfb
    exit 0
fi

cache="${WF_PARITY_CACHE:-$HOME/.cache/wf-parity}/xvfb"
wrapper="$cache/Xvfb"
if [ -x "$wrapper" ]; then
    echo "$wrapper"
    exit 0
fi

command -v apt-get >/dev/null 2>&1 || { echo "ensure_xvfb.sh: no Xvfb and no apt-get to fetch one" >&2; exit 1; }
command -v xkbcomp >/dev/null 2>&1 || { echo "ensure_xvfb.sh: xkbcomp (x11-xkb-utils) is required by Xvfb" >&2; exit 1; }

mkdir -p "$cache/debs" "$cache/root"
(
    cd "$cache/debs"
    apt-get download xvfb libunwind8 >&2
)
for deb in "$cache"/debs/*.deb; do
    dpkg -x "$deb" "$cache/root"
done

cat > "$wrapper" <<EOF
#!/usr/bin/env bash
export LD_LIBRARY_PATH="$cache/root/usr/lib/x86_64-linux-gnu\${LD_LIBRARY_PATH:+:\$LD_LIBRARY_PATH}"
exec "$cache/root/usr/bin/Xvfb" -xkbdir /usr/share/X11/xkb "\$@"
EOF
chmod +x "$wrapper"
echo "$wrapper"
