#!/usr/bin/env python3
"""Build a desktop fixture whose Player applies verifier teleports during its update.

The source fixture's chapter script and .lev must match exactly. --inputs supplies
mesh .iff and texture .tga compiler inputs (which room fixtures may have pruned).
Only the Player script changes; room data and all actor indices are preserved.
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil

from rooms_split import compile_level
from glyph_atlas import append_to_level
from level_settings import attach

LEVEL = 'parmenides_slice'
HOOK = '''
\\ Verifier-only request; position writes occur within Level::update.
: fy-verifier-teleport
  476 read-mailbox 475 read-mailbox <> if
    478 read-mailbox INDEXOF_Y_POS write-mailbox
    477 read-mailbox INDEXOF_X_POS write-mailbox
    479 read-mailbox INDEXOF_Z_POS write-mailbox
    476 read-mailbox 475 write-mailbox
  then ;
'''


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument('--fixture', type=Path, required=True)
    parser.add_argument('--inputs', type=Path, required=True,
                        help='directory holding original mesh .iff and texture .tga compiler inputs')
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    source, inputs, out = (p.resolve() for p in (args.fixture, args.inputs, args.out))
    if out in (source, inputs) or source in out.parents or inputs in out.parents:
        parser.error('--out must be outside the source directories')
    if out.exists() and any(out.iterdir()):
        parser.error('--out must be a new or empty directory')
    out.mkdir(parents=True, exist_ok=True)
    metadata = {'actors.json', 'content.json', 'visual-gates.json',
                'build-receipt.json', 'runtime-provenance.json',
                'development-signing.p12', 'chapter.fth', LEVEL + '.lev',
                'texture-slots.json', 'room-layout.json', 'dialogue-glyphs.bin',
                'glyph-atlas.json', 'font-labels.json'}
    for directory in (source, inputs):
        for item in directory.iterdir():
            if item.is_file() and (item.suffix in {'.iff', '.tga'} or
                                   directory == source and item.name in metadata):
                target = out / item.name
                if not target.exists():
                    shutil.copy2(item, target)
    old_script = (source / 'chapter.fth').read_text()
    for mailbox in (475, 476, 477, 478, 479):
        if f'{mailbox} read-mailbox' in old_script or f'{mailbox} write-mailbox' in old_script:
            raise RuntimeError(f'verifier mailbox {mailbox} already used by source script')
    tail = old_script.splitlines(keepends=True)[-1]
    if not tail.startswith('fy-init fy-input '):
        raise RuntimeError('unexpected chapter entry point')
    new_script = old_script[:-len(tail)] + HOOK + tail.replace('fy-input ', 'fy-input fy-verifier-teleport ', 1)
    lev = (source / (LEVEL + '.lev')).read_text()
    encoded_old = json.dumps(old_script)
    if lev.count(encoded_old) != 1:
        raise RuntimeError('source script not found exactly once in .lev')
    (out / 'chapter.fth').write_text(new_script)
    (out / (LEVEL + '.lev')).write_text(lev.replace(encoded_old, json.dumps(new_script)))
    compile_level(out)
    standalone = out / (LEVEL + '-standalone.iff')
    if (source / 'dialogue-glyphs.bin').exists():
        append_to_level(standalone, (source / 'dialogue-glyphs.bin').read_bytes())
    attach(standalone, out / 'actors.json', out, Path('/home/will/WorldFoundry-wbniv'), scope=0)
    receipt = {'sourceFixture': str(source), 'compilerInputs': str(inputs),
               'sourceLevelSha256': sha(source / (LEVEL + '-standalone.iff')),
               'scriptSha256': sha(out / 'chapter.fth'),
               'levelSha256': sha(out / (LEVEL + '-standalone.iff')),
               'positionMailboxes': {'request': 476, 'x': 477, 'y': 478, 'z': 479, 'ack': 475}}
    (out / 'verifier-hook-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(out / (LEVEL + '-standalone.iff'))
    print('SHA-256', receipt['levelSha256'])


if __name__ == '__main__':
    main()
