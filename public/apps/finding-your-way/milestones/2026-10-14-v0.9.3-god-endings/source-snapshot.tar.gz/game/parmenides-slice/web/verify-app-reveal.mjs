import { chromium, firefox } from '/home/will/finding-your-way/node_modules/@playwright/test/index.mjs';
import assert from 'node:assert/strict';
import { mkdirSync, writeFileSync } from 'node:fs';

const [base, out] = process.argv.slice(2);
mkdirSync(out, { recursive: true });
const engine = process.env.FYW_BROWSER || 'chromium';
const browser = engine === 'firefox'
  ? await firefox.launch({ headless: false })
  : await chromium.launch({ executablePath: '/usr/bin/google-chrome', headless: true, args: ['--no-sandbox'] });
const app = base + '/apps/finding-your-way/';
const results = [];
try {
  for (const [name, width, height] of [['desktop', 1280, 900], ['phone', 390, 844]]) {
    for (const reducedMotion of ['no-preference', 'reduce']) {
      const context = await browser.newContext({ viewport: { width, height: 500 }, reducedMotion });
      const page = await context.newPage();
      const errors = [], requests = [];
      page.on('pageerror', error => errors.push(error.message));
      page.on('request', request => requests.push(request.url()));
      await page.goto(app, { waitUntil: 'networkidle' });
      const webEdition = page.locator('#web-edition');
      assert.equal(await webEdition.locator('h2').textContent(), 'Web edition');
      assert.equal(await webEdition.locator('.fyw-shot').count(), 4);
      assert(await webEdition.evaluate(el => Boolean(document.querySelector('.world-foundry-credit').compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING)), 'Web edition follows World Foundry logo');
      assert.equal(await page.locator('a[href$=".apk"]').count(), 9);
      const pageText = await page.locator('article').textContent();
      assert(!/[\d,]+ (automated checks|story\/control assertions|reader checks)/.test(pageText), 'release test counts removed');
      assert(!pageText.includes('verified merged candidate'));
      assert.equal(await page.locator('#web-3d-play').evaluate(el => el.open), false, 'offscreen section starts collapsed');
      const reveal = await page.evaluate(async () => {
        const details = document.querySelector('#web-3d-play');
        const title = details.querySelector('summary strong');
        const heights = [], visibleHeights = [];
        const top = title.getBoundingClientRect().top + scrollY - innerHeight + title.getBoundingClientRect().height + 116;
        window.scrollTo({ top, behavior: 'instant' });
        const start = performance.now();
        await new Promise(resolve => {
          function sample() {
            const bounds = details.querySelector('.install-body').getBoundingClientRect();
            heights.push(bounds.height);
            visibleHeights.push(Math.max(0, Math.min(bounds.bottom, innerHeight) - Math.max(0, bounds.top)));
            if (performance.now() - start < 700) requestAnimationFrame(sample);
            else resolve();
          }
          requestAnimationFrame(sample);
        });
        return {
          open: details.open,
          heights,
          visibleHeights,
          transition: getComputedStyle(details, '::details-content').transitionDuration,
          animatedDetailsSupported: CSS.supports('selector(details::details-content)') && CSS.supports('interpolate-size', 'allow-keywords'),
        };
      });
      assert.equal(reveal.open, true, 'title visibility opens the section');
      if (reducedMotion === 'reduce') assert(reveal.transition.split(',').every(value => parseFloat(value) === 0));
      if (reducedMotion === 'no-preference') {
        const finalHeight = Math.max(...reveal.heights);
        assert(finalHeight > 0 && reveal.heights.some(height => height > 0 && height < finalHeight - 1), 'content expands through intermediate heights');
        assert(reveal.heights.some((height, index) => height > 0 && height < finalHeight - 1 && reveal.visibleHeights[index] > 16), 'expansion is visible inside the viewport');
      }
      const cta = page.locator('#web-3d-play .web-play-button');
      await cta.scrollIntoViewIfNeeded();
      assert(await cta.isVisible());
      await page.screenshot({ path: `${out}/${name}-${reducedMotion}.png` });
      await page.setViewportSize({ width, height });
      await page.locator('#web-3d-play summary').click();
      await page.evaluate(() => window.scrollTo({ top: 0, behavior: 'instant' }));
      await page.waitForTimeout(400);
      await page.locator('#web-3d-play summary strong').scrollIntoViewIfNeeded();
      await page.waitForTimeout(400);
      assert.equal(await page.locator('#web-3d-play').evaluate(el => el.open), false, 'manual close survives scrolling away and back');
      assert.equal(requests.some(url => /play\/bundles|wf_game\.(js|wasm|data)/.test(url)), false, 'no eager game download');
      assert.deepEqual(errors, []);
      if (reducedMotion === 'no-preference') {
        await page.evaluate(() => window.scrollTo({ top: document.querySelector('.world-foundry-credit').getBoundingClientRect().top + scrollY - 24, behavior: 'instant' }));
        await page.screenshot({ path: `${out}/${name}-web-edition.png` });
      }
      results.push({ name, reducedMotion, revealViewport: { width, height: 500 }, ...reveal, manualClosePreserved: true, lazy: true, errors });
      await context.close();
    }
  }
  const context = await browser.newContext({ javaScriptEnabled: false });
  const page = await context.newPage();
  await page.goto(app);
  assert.equal(await page.locator('#web-3d-play').evaluate(el => el.open), true, 'no-JS default is open');
  assert(await page.locator('#web-3d-play .web-play-button').isVisible());
  results.push({ javaScript: false, open: true, playLinkVisible: true });
  await context.close();
  writeFileSync(out + '/results.json', JSON.stringify({ base, engine, results }, null, 2) + '\n');
  console.log(JSON.stringify({ engine, passed: results.length, base }));
} finally {
  await browser.close();
}
