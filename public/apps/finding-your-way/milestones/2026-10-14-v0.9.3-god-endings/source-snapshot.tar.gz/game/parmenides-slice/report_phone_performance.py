"""Summarize verified coordinator presented-frame evidence, without FPS HUD claims."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import statistics


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def thermal(path):
    text = path.read_text()
    status = re.search(r'^Thermal Status: (\d+)', text, re.M)
    # Cached values can differ substantially from the current HAL readings.
    current = text.split('Current temperatures from HAL:', 1)[-1].split('Current cooling devices', 1)[0]
    sensors = {name: dict(celsius=float(value), status=int(state)) for value, name, state in
               re.findall(r'Temperature\{mValue=([-\d.]+), mType=-?\d+, mName=([^,}]+), mStatus=(\d+)\}', current)}
    return dict(service_status=int(status[1]) if status else None, current_hal=sensors)


def analyze(folder):
    timestamps = json.loads((folder / 'presents-ns.json').read_text())
    assert len(timestamps) >= 11 and timestamps == sorted(set(timestamps))
    pairs = list(zip(timestamps, timestamps[1:]))
    raw_intervals = [(b-a)/1e6 for a, b in pairs]
    coordinator = json.loads((folder / 'summary.json').read_text())
    assert coordinator['interval_count'] == len(raw_intervals)
    assert abs(coordinator['fps'] - 1000/statistics.mean(raw_intervals)) < 1e-6
    samples = json.loads((folder / 'samples.json').read_text())
    sample_frames = []
    for sample in samples:
        frames = set()
        for line in sample['raw'].splitlines()[1:]:
            cells = line.split()
            if len(cells) == 3 and all(c.isdigit() for c in cells) and 0 < int(cells[1]) < 2**63-1:
                value = int(cells[1])
                if value >= coordinator.get('measurement_anchor_ns', 0):
                    frames.add(value)
        sample_frames.append(frames)
    nonempty_frames = [frames for frames in sample_frames if frames]
    missing_bridges = {(max(a), min(b)) for a, b in zip(nonempty_frames, nonempty_frames[1:])
                       if a and b and max(a) < min(b)}
    missing_bridges.intersection_update(pairs)
    # Nonoverlapping reads leave presentation coverage uncertain. Their bridge
    # cannot establish a renderer frame time; overwrite is not the only cause.
    usable = [(b, (b-a)/1e6) for a, b in pairs if (a, b) not in missing_bridges]
    intervals = [dt for _, dt in usable]
    assert len(intervals) >= 10
    ordered = sorted(intervals)
    windows = []
    start = timestamps[0]
    for offset in range(0, 180, 30):
        selected = [dt for t, dt in usable if offset <= (t-start)/1e9 < offset+30]
        if selected:
            windows.append(dict(start_seconds=offset, intervals=len(selected), fps=1000/statistics.mean(selected)))
    poll_gaps = [b['host_seconds']-a['host_seconds'] for a, b in zip(samples, samples[1:])]
    # Android 17 retained only 64 rows in the actual Pixel probe. Derive the
    # observed capacity rather than assuming the older 128-record buffer.
    capacity = max(map(len, sample_frames))
    buffer_seconds = statistics.median(intervals) * capacity / 1000
    meminfo = (folder / 'meminfo.txt').read_text()
    pss = re.search(r'^\s*TOTAL PSS:\s*(\d+)', meminfo, re.M)
    if not pss:
        pss = re.search(r'^\s*TOTAL\s+(\d+)', meminfo, re.M)
    return dict(fps=1000/statistics.mean(intervals), raw_coordinator_fps=coordinator['fps'],
                intervals=len(intervals), observed_seconds=(timestamps[-1]-timestamps[0])/1e9,
                covered_seconds=sum(intervals)/1000, missing_sampling_gaps=len(missing_bridges),
                missing_sampling_seconds=sum((b-a)/1e9 for a,b in missing_bridges),
                observed_sf_capacity=capacity,
                **{f'p{p}_ms': ordered[int((len(ordered)-1)*p/100)] for p in (50, 90, 95, 99)},
                worst_ms=max(intervals), over_33_333_ms_percent=100*sum(v > 1000/30 for v in intervals)/len(intervals),
                over_66_667_ms_percent=100*sum(v > 1000/15 for v in intervals)/len(intervals),
                window_30_seconds=windows, refresh_ms=coordinator['refresh_ms'], layer=coordinator['layer'],
                poll_count=len(samples), max_poll_gap_seconds=max(poll_gaps),
                empty_sample_indices=[i for i, frames in enumerate(sample_frames) if not frames],
                full_duration_observed=(timestamps[-1]-timestamps[0])/1e9 >=
                    coordinator['duration_seconds']-max(poll_gaps)-coordinator['refresh_ms']/1000,
                poll_gaps_exceeding_sf_buffer=sum(v > buffer_seconds for v in poll_gaps),
                pss_mib=int(pss[1])/1024 if pss else None, thermal=thermal(folder / 'thermal.txt'),
                evidence_sha256={name: digest(folder/name) for name in
                                 ('presents-ns.json', 'samples.json', 'summary.json', 'thermal.txt', 'meminfo.txt', 'idle.png')})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--evidence', type=Path, required=True)
    args = parser.parse_args()
    root = args.evidence.resolve()
    folder = root / 'campaign'
    receipt = json.loads((folder / 'receipt.json').read_text())
    assert receipt['result'] == 'completed' and receipt['cleanup_verified']
    request = receipt['job']['request']
    production = json.loads((root / 'production-build-receipt.json').read_text())
    assert request['restore_apk'] == production['sha256'] + '.apk'
    results = []
    for variant in request['variants']:
        build = json.loads((root / (variant['label'] + '-build-receipt.json')).read_text())
        assert variant['apk'] == build['sha256'] + '.apk'
        assert build['nativeLibraries'] == production['nativeLibraries'] and build['diagnostic_only']
        result = analyze(folder / variant['label'] / 'run-1')
        result.update(label=variant['label'], apk_sha256=build['sha256'], level_sha256=build['cd_sha256'],
                      warmup_seconds=variant['warmup'], phases=build['phases'])
        results.append(result)
    report = dict(job=receipt['job']['id'], measured_at=datetime.fromtimestamp(receipt['finished'], timezone.utc).isoformat(),
                  device=receipt['device'], production_apk_sha256=production['sha256'],
                  production_level_sha256=production['cd_sha256'], native_libraries=production['nativeLibraries'],
                  duration_per_workload_seconds=request['duration'], measured_workloads=results,
                  cleanup_verified=True, earlier_production_check_thermal=thermal(root/'initial-check/thermal.txt'),
                  earlier_production_check_finished=json.loads((root/'initial-check/receipt.json').read_text())['finished'],
                  meets_mean_30_fps_target=all(r['fps'] >= 30 and r['missing_sampling_gaps'] == 0
                      and not r['empty_sample_indices'] and r['full_duration_observed'] for r in results),
                  scope='Four scripted rendering/movement stress workloads; not full route or physical touchscreen acceptance')
    (root / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    lines = ['# Iteration B phone performance', '',
             f"- [x] Pixel 8 Pro, Android {receipt['device']['android']}, ARM64; coordinator job `{report['job']}` completed with verified cleanup.",
             '- [x] Temple and Love in follow and first-person views; each measured for 180 seconds, with 180 seconds initial warm-up and 30 seconds before each later workload.',
             '- [x] Production phone APK restored after the diagnostic campaign.',
             '- [ ] Complete route, reading and physical touchscreen acceptance remain separate.', '',
             '| Workload | Presented fps | p50 / p95 / p99 (ms) | >33.33 ms | Worst (ms) | PSS (MiB) | Thermal status |',
             '| --- | ---: | --- | ---: | ---: | ---: | ---: |']
    for r in results:
        lines.append(f"| {r['label']} | {r['fps']:.2f} | {r['p50_ms']:.2f} / {r['p95_ms']:.2f} / {r['p99_ms']:.2f} | {r['over_33_333_ms_percent']:.2f}% | {r['worst_ms']:.2f} | {r['pss_mib']:.1f} | {r['thermal']['service_status']} |")
    lines += ['', 'These are SurfaceFlinger presented-frame intervals, deduplicated across polling reads, rather than the engine FPS counter. The nominal display refresh and its missed-refresh percentage are retained in JSON; the table compares intervals against the proposed 30 fps budget. Slow-frame percentages are observations, with no invented universal acceptance threshold.', '',
              'Each fixture changes only the Player script to repeat an eight-second native forward/turn loop. Temple uses the restored bright history. Love deliberately retains all four arrival crowds; production normally disperses them. Geometry, texture inputs and the phone native library are shared with the production candidate. Screen recording was disabled during measurement.', '',
              'Thermal readings are snapshots from the current HAL section, not the cached temperature list or continuous telemetry. The earlier production-check snapshot has its own timestamp and is not a campaign-start temperature. Failed attempts and short probes preceded the successful campaign; no controlled cold start is claimed. Workloads run in a fixed order on one device, with app restarts between variants; these data do not isolate temperature from scene differences or establish performance on other phones. See JSON for every sensor, 30-second windows and polling gaps. Nonoverlapping consecutive SurfaceFlinger reads leave unobserved presentation intervals; their cause is not established. Those bridge intervals are excluded from frame-time statistics, their duration and the raw coordinator rate are reported separately, and any such hole keeps the sustained target unverified.', '',
              f"Production phone APK: `{production['sha256']}`. Production level: `{production['cd_sha256']}`. The TV archive remains unchanged; this phone candidate uses the separately verified touch runtime. Diagnostic APK and level hashes are listed individually in JSON and build receipts.", '',
              'Max will provide art feedback after all production iterations; Will’s style approval is not a gate.', '',
              'Generated with Codex. Exact tool version, model and reasoning effort were unavailable for verification and are not inferred.', '']
    (root / 'README.md').write_text('\n'.join(lines))
    print(json.dumps({r['label']: dict(fps=r['fps'], p99_ms=r['p99_ms'], thermal=r['thermal']['service_status']) for r in results}, indent=2))


if __name__ == '__main__':
    main()
