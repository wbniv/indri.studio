# Iteration A phone touch fix

`engine.patch` applies to WorldFoundry commit `1aecfbe5f3aeb0fc394522c4c5d35f126de551df`. The controller server starts only in Android TV mode, so touchscreen devices no longer show the pairing prompt.

Local touch uses the Aquarium browser controller’s circular joystick: a draggable knob, half-radius dead zone, diagonal steering, and pointer capture until release. Action fingers remain independent while steering. The density-aware layout shares drawing and input geometry, stays above the bottom gesture area, labels A–D, highlights held buttons, and clears held input on pause or focus loss.

`engine-current-checkout.patch` adapts the same changes to the shared engine checkout’s existing diagnostics and text input; it was applied without replacing those unrelated changes. `integration-preconditions.json` records the files it was prepared against.

The C++ test in the patch passed 155 checks:

```sh
c++ -std=c++17 -I wfsource/source tests/android_touch_controls_test.cc -o /tmp/android-touch-test
/tmp/android-touch-test
```

For a clean Android build, unpack the pinned `engine/vendor/jolt-physics-5.5.0.tar.gz` into the matching directory before running `./gradlew assembleCondoRelease --offline` from `android`. Package its native libraries with `../../package_touch_review.py`; the immutable iteration A assets are verified byte-for-byte. The early Pixel package uses the completed arm64 library with debug symbols removed via the NDK’s `llvm-strip --strip-debug`.

`0.6-proof.1-touch.1` was the initial arrow-pad review: the Pixel resume check passed, the pairing prompt was absent, and the user confirmed arrows plus A/B/C worked. `engine-arrow-review.patch` and `source-arrow-review.json` preserve that version.

`0.6-proof.1-touch.2` replaces the arrows with the requested Aquarium joystick. It was installed after an administrator coordinator refresh restored the same Pixel endpoint. Will confirmed that the joystick works and requested a smaller ring placed closer to the bottom edge. This confirms the basic joystick interaction, while D and simultaneous steering/action fingers remain unverified. The recording download was truncated and could not be decoded, then cleanup failed with an offline device; that recording is invalid. D’s reduced-motion effect remains pending: with reading sheets closed, it freezes the Goddess’s subtle decorative wing settling; meaningful walking stays active.

`0.6-proof.1-touch.3` applies `layout-feedback.patch` after `engine.patch`: the outer ring is 20% smaller, the knob keeps its size, and the bottom margin drops from 12 dp to 6 dp. Gesture inset clearance remains in force. Drawing and input share the same radius; the smaller circle retains the half-radius dead zone and pointer capture. The layout tests pass 157 checks, including the exact ring edge and a point just outside it. `source-layout-review.json` records the incremental arm64 build: only native entry and display objects were recompiled; all other engine archive members were verified unchanged. The Pixel install/input/Home-resume check passed (`J-61094e9dfaae`); the intro and resumed-game screenshots show the whole ring above the gesture bar. Hands-on acceptance of the adjusted layout remains pending.

The layout delta was also applied to the shared checkout after a clean `git apply --check`; its own touch test passes the same 157 checks. `integration-layout.json` records the resulting source hashes and reverse-patch check. The prior joystick/arrow review patches and receipts remain unchanged.
