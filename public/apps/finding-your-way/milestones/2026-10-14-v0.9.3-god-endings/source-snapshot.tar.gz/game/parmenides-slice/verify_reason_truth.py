"""Actual native C art/motion/state review; fixtures never replace route QA."""
import json
import time
from art_reason_truth import SIGNS

def run(b,player,value,check,tap,position,read_pages,groups,ids,out,evidence,capture):
    scene9=json.loads((out/'room-layout.json').read_text())['layout']=='scene9'
    fixture_position=position
    def position(x,y,z=None):
        # Cancellation uses a native Left press; after the sheet closes it can
        # also turn the player. Each image fixture declares its north-facing
        # approach instead of inheriting the preceding cancellation heading.
        b.set_mailbox(114,.25,idx=player)
        fixture_position(x,y,z)
    names=['reason_grove','gavel','ReasonRain0',*[n for n in ids if n.startswith('ReasonCanopy')]]
    for mb in (486,487,175,150,152,153,154,155,170,171,172,176,177):b.watch(player,mb)
    for name in names+list(SIGNS):
        for mb in (3011,3012,3013,3014,3020):b.watch(ids[name],mb)
    def setm(m,v):b.set_mailbox(m,v,idx=player)
    def av(name,m):return b.mailbox_values.get((ids[name],m))
    def wait(label,predicate):
        deadline=time.monotonic()+30
        while time.monotonic()<deadline and not predicate():time.sleep(.025)
        check(label,bool(predicate()))
    def sample(seconds=.8):
        deadline=time.monotonic()+30;start=value(110);rows=[];last=None
        while time.monotonic()<deadline:
            t=value(110)
            if t is not None and t!=last:
                rows.append(dict(clock=t,grove=value(486),gavel=value(487),drop=av('ReasonRain0',3011)));last=t
                if t>=start+seconds:break
            time.sleep(.02)
        check('C native time advances',bool(rows) and rows[-1]['clock']>=start+seconds)
        return rows
    samples=[]
    for mode in (0,1):
        if scene9 and value(102)==3:
            position(300,-8);tap();check('C Truth returns to Temple for next view',value(102)==0)
        if value(101)!=mode:tap(2)
        for mb in (150,151,152,153,154,155,157,170,171,172,173,174,175,176,177,486,487):setm(mb,0)
        setm(108,0)
        if scene9:
            setm(106,1);setm(107,1);position(7,8);tap()
            check('C Reason room entered through Temple portal',value(102)==2)
        else:setm(102,2)
        setm(140,0);position(196,-1)
        wait('initial ordered plane keeps grove hidden',lambda:value(163)==0 and value(486)==0)
        capture(f'reason-white-view-{mode}',scene9)
        position(196,1);tap();check('White Self retains exact source account',value(140)==groups['white'][0])
        tap(16384);check('White cancellation preserves ordered plane',value(150)==0 and value(163)==0)
        tap();read_pages('C White source camera='+str(mode),groups['white']+groups['grove'])
        wait('authored grove growth reaches final state',lambda:value(486)==1)
        check('grove never chooses a philosophy',value(154)==0 and value(155)==0)
        position(200,0);capture(f'reason-grove-view-{mode}')
        position(204,4);capture(f'reason-wild-view-{mode}')
        position(200,3);tap();read_pages('C apparatus camera='+str(mode),groups['apparatus_order']+groups['apparatus_limit'])
        check('apparatus retains choice-neutral completion',value(152)==1 and value(154)==0 and value(155)==0)
        s=sample(1.0);samples+=s
        check('rain drops actually move',max(r['drop'] for r in s)-min(r['drop'] for r in s)>.02)
        position(200,0);capture(f'reason-apparatus-view-{mode}')
        setm(151,1);position(200,8);capture(f'reason-younger-view-{mode}')
        setm(108,1);setm(150,0);wait('replay clears cosmetic grove progress',lambda:value(486)==0)
        setm(150,1);wait('reduced motion uses complete stable grove',lambda:value(486)==1)
        check('reduced grove leaves source choices untouched',value(154)==0 and value(155)==0)
        s=sample(.4);samples+=s
        check('reduced drops stay stable',max(r['drop'] for r in s)-min(r['drop'] for r in s)<.001)
        capture(f'reason-reduced-view-{mode}');setm(108,0)
        # Court source availability uses the existing flags; both actual
        # inspection sheets and their cancellation remain independently usable.
        if scene9:
            position(200,-8);tap();check('C Reason returns to Temple before Truth',value(102)==0)
            setm(154,1);setm(155,1);setm(156,1);position(-7,8);tap()
            check('C Truth room entered through Temple portal',value(102)==3)
            if value(140):read_pages('C courtroom intro camera='+str(mode),groups['truth_intro'])
        else:setm(102,3)
        setm(140,0);position(300,-3);capture(f'truth-gallery-view-{mode}',scene9)
        position(294,-2);capture(f'truth-prosecutor-view-{mode}')
        position(306,-2);capture(f'truth-defence-view-{mode}')
        setm(170,1);setm(171,1);position(300,3);capture(f'truth-student-view-{mode}')
        setm(172,1)
        for x,key,flag in ((294,'facts',173),(306,'interpretations',174)):
            position(x,7);tap();check(key+' inspection retains exact source-derived sheet',value(140)==groups[key][0])
            tap(16384);check(key+' cancellation cannot commit a verdict',value(176)==0 and value(177)==0)
            tap();read_pages('C exhibit '+key+' camera='+str(mode),groups[key]);check(key+' independently completes',value(flag)==1)
            position(x,4);capture(f'truth-{key}-view-{mode}')
        position(300,12);tap();read_pages('C evidence presentation camera='+str(mode),groups['present'])
        wait('gavel response ends at stable rest',lambda:value(487)==1)
        check('presentation remains choice-neutral',value(175)==1 and value(176)==0 and value(177)==0)
        position(300,8);capture(f'truth-presented-view-{mode}')
        position(300,10.4);capture(f'truth-judge-view-{mode}')
        setm(108,1);setm(175,0);wait('presentation replay resets response',lambda:value(487)==0)
        setm(175,1);wait('reduced presentation settles immediately',lambda:value(487)==1)
        check('gavel rest keeps authored orientation',abs(av('gavel',3013)-.25)<.002)
        capture(f'truth-reduced-view-{mode}');setm(108,0)
        setm(140,groups['facts'][0]);before=value(486);s=sample(.5);samples+=s
        check('modal reading holds cosmetic progress',all(abs(r['grove']-before)<.001 for r in s))
        setm(140,0)
        expected=(value(114)-.25)%1
        wait('Reason/Truth signs face current view',lambda:all(av(n,3014) is not None and abs((av(n,3014)-expected+.5)%1-.5)<.002 for n in SIGNS))
    receipt=out/('build-receipt.json' if (out/'build-receipt.json').exists() else 'level-receipt.json')
    (evidence/'reason-truth-audit.json').write_text(json.dumps(dict(build=json.loads(receipt.read_text()),passed=True,
        scope='Both native views; exact Reason and exhibit sheets, cancellation, source-neutral growth/apparatus/presentation, cosmetic replay, reduced motion and wayfinding',samples=samples),indent=2)+'\n')
