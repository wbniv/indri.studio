"""Controlled fixed-frame vista isolation using level-only diagnostic copies."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import shutil

TOOLS=Path('/home/will/finding-your-way-rooms/game/parmenides-slice')
spec=importlib.util.spec_from_file_location('rooms_split',TOOLS/'rooms_split.py')
rooms=importlib.util.module_from_spec(spec);spec.loader.exec_module(rooms)
OUT=Path('/home/will/finding-your-way/docs/diagnostics/parmenides/rooms-vista-review/isolation')
FIXTURES=TOOLS/'build-rooms/loopfx'
BINARY=Path('/home/will/wf-rooms-counters/engine/wf_game')
TAIL='fy-init fy-input fy-review-tick fy-god-safety fy-ending-safety fy-camera fy-modal-camera fy-reading-ready fy-visual fy-cards'
ids=json.loads((FIXTURES/'control/group-0-view-0/actors.json').read_text())['ids']
cases={
    'state-control':('control',[]),
    'state-scene9':('scene9',[]),
    'without-grove':('control',[ids['reason_grove']]),
    'without-canopies':('control',[v for k,v in ids.items() if k.startswith('ReasonCanopy')]),
    'without-reason-people':('control',[ids[k] for k in ('WhiteSelf','WildSelf','Child') if k in ids]),
    'without-younger-self':('control',[ids['YoungerSelf']]),
    'without-weather-machine':('control',[ids['weather_machine']]),
    'without-weather-order':('control',[ids['weather_order']]),
    'without-reason-being-door':('control',[ids['reason_being']]),
    'without-reason-notbeing-door':('control',[ids['reason_notbeing']]),
    'without-reason-return-door':('control',[ids['reason_back']]),
    'positive-control-pillar':('control',[ids['pillar3']]),
    'without-reason-signs':('control',[ids[k] for k in ('white_sign','wild_sign','child_sign','apparatus_sign','rbeing_sign','rnotbeing_sign','rback_sign')]),
    'without-old-lady':('control',[ids['OldLady']]),
    'without-court-gallery':('control',[ids[k] for k in ('CourtGallery0','CourtGallery1','CourtGallery2')]),
    'without-court-gallery-0':('control',[ids['CourtGallery0']]),
    'without-court-gallery-1':('control',[ids['CourtGallery1']]),
    'without-court-gallery-2':('control',[ids['CourtGallery2']]),
    'without-court-principals':('control',[ids[k] for k in ('Prosecutor','DefenceAttorney','Student','Judge')]),
    'without-prosecutor':('control',[ids['Prosecutor']]),
    'without-defence-attorney':('control',[ids['DefenceAttorney']]),
    'without-student':('control',[ids['Student']]),
    'without-judge':('control',[ids['Judge']]),
    'isolate-actors-28-123':('control',list(range(28,124))),
    'isolate-actors-338-429':('control',list(range(338,430))),
    'isolate-actors-28-77':('control',list(range(28,78))),
    'isolate-actors-78-104':('control',list(range(78,105))),
    'isolate-actors-105-123':('control',list(range(105,124))),
    'without-court-structure':('control',[ids['court_structure']]),
    'isolate-love-actors':('control',list(range(28,39))),
    'isolate-court-props':('control',[i for i in range(53,78) if i not in (57,59,62,65,76)]),
    'without-court-structure-complete':('control',[ids['court_structure']]),
    'scene9-without-court-structure':('scene9',[ids['court_structure']]),
    'without-court-floor':('control',[ids['court_floor']]),
    'without-truth-doors':('control',[ids[k] for k in ('truth_being_exit','truth_notbeing_exit','truth_back_portal')]),
    'court-architecture-disabled':('control',[]),
}
OUT.mkdir(parents=True,exist_ok=True)
from PIL import Image,ImageChops
reports={}
for name,(side,hidden) in cases.items():
    prior=json.loads((OUT/'results.json').read_text()) if (OUT/'results.json').exists() else {}
    if (OUT/name/'g0v0/188.png').exists() and name in prior:
        reports[name]=prior[name]
        continue
    dest=Path('/home/will/finding-your-way/game/parmenides-slice/build-vista-isolation')/name/'group-0-view-0'
    source=dest.parents[1]/('source-'+side)
    source.mkdir(parents=True,exist_ok=True)
    for p in (FIXTURES/'control/group-0-view-0').iterdir():
        if p.is_file():shutil.copy2(p,source/p.name)
    # Prior experiment builds removed copied compiler inputs. Restore missing
    # original meshes/textures from the unchanged v0.7 chapter export.
    production=Path('/home/will/finding-your-way/game/parmenides-slice/build/v0.7-polish')
    for p in production.iterdir():
        if p.suffix in ('.iff','.tga') and not (source/p.name).exists():shutil.copy2(p,source/p.name)
    addition=''.join(f' .001 INDEXOF_Z_SCALE {i} write-actor-mailbox' for i in hidden)
    if name in ('without-court-structure-complete','scene9-without-court-structure'):
        addition=''.join(f' 0 INDEXOF_{axis}_SCALE 52 write-actor-mailbox' for axis in 'XYZ')
    retargets=[TAIL+'=>'+TAIL+addition]
    if name=='court-architecture-disabled':
        _,objects=rooms.split_objects((source/'parmenides_slice.lev').read_text())
        for obj in objects:
            if rooms.obj_name(obj) in ('court_structure','court_floor'):
                changed=obj.replace("{ 'NAME' \"Model Type\" } { 'DATA' 1l } { 'STR' \"Mesh\" }", "{ 'NAME' \"Model Type\" } { 'DATA' 0l } { 'STR' \"None\" }")
                changed=changed.replace("{ 'NAME' \"Model Type\" } { 'STR' \"Mesh\" }", "{ 'NAME' \"Model Type\" } { 'STR' \"None\" }")
                assert changed!=obj
                retargets.append(obj+'=>'+changed)
    extra=[arg for r in retargets for arg in ('--retarget',r)]
    with (OUT/(name+'-build.log')).open('w') as log:
        # Build both layouts from the identical original unsplit source.
        subprocess.run([sys.executable,str(TOOLS/'rooms_split.py'),'--fixture',str(source),
            '--out',str(dest),'--layout',side,*extra],stdout=log,stderr=subprocess.STDOUT,check=True)
    with (OUT/(name+'-capture.log')).open('w') as log:
        subprocess.run([sys.executable,str(TOOLS/'e3_parity.py'),'capture','--binary',str(BINARY),
            '--fixtures','g0v0','--fixture-root',str(dest.parent),'--frames','188',
            '--extra=--no-fps','--out',str(OUT/name)],stdout=log,stderr=subprocess.STDOUT,check=True)
    pic=Image.open(OUT/name/'g0v0/188.png').convert('RGB')
    import gzip
    engine_log=gzip.open(OUT/name/'g0v0/188.log.gz','rt',errors='replace').read()
    assert 'zforth compile error' not in engine_log, 'diagnostic script failed'
    assert pic.getbbox(), 'capture is black'
    original=Image.open(OUT.parents[0]/('after.png' if side=='scene9' else 'before.png')).convert('RGB')
    bbox=ImageChops.difference(original,pic).getbbox()
    region=(1087,214,1093,235)
    delta=ImageChops.difference(original,pic)
    changed=sum(1 for p in delta.crop(region).get_flattened_data() if p!=(0,0,0))
    reports[name]={'hidden_actors':hidden,'difference_from_original_bbox':bbox,'marked_region_changed_pixels':changed}
    print(name,reports[name],flush=True)
    (OUT/'results.json').write_text(json.dumps(reports,indent=2)+'\n')
