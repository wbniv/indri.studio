// Exercise the linked engine renderer and its existing LMalloc, with real WebGL.
#include <gfx/renderer_backend.hp>
#include <game/bitmap_text.hp>
#include <hal/halbase.h>
#include <emscripten/html5.h>
#include <GLES3/gl3.h>
#include <cstdio>
#include <cstdlib>
#include <vector>
extern RendererBackend* ModernBackendInstance();
extern void ModernBackendSimulateSurfaceLoss();
static void Check(bool ok,const char* message){if(!ok){fprintf(stderr,"FAIL %s\n",message);abort();}}
extern "C" int scratchBytesFree(){return HALScratchLmalloc.BytesFree();}
int main(){
    alignas(16) static unsigned char backing[180000];
    LMalloc scratch(backing,sizeof(backing),"glyph fixture");_HALScratchLmalloc=&scratch;
    EmscriptenWebGLContextAttributes a;emscripten_webgl_init_context_attributes(&a);
    a.majorVersion=2;a.preserveDrawingBuffer=true;
    auto context=emscripten_webgl_create_context("#canvas",&a);
    Check(context>0,"WebGL2 context");emscripten_webgl_make_context_current(context);
    auto* backend=ModernBackendInstance();unsigned char coverage=255;
    auto texture=backend->CreateTexture(1,1,RB_TEX_COVERAGE8,&coverage);
    std::vector<bitmaptext::Quad> quads(769,{0,0,8,8,0,0,1,1,0,0xFF0000FFu});
    for(size_t i=0;i<quads.size();++i){quads[i].x0=i*.125f;quads[i].x1=quads[i].x0+8;quads[i].y0=i*.0625f;quads[i].y1=quads[i].y0+8;quads[i].rgba|=(i&255)<<16;}
    for(int count:{1,255,256,257,769}){
        void* outer=scratch.Allocate(32);const auto before=scratch.BytesFree();
        glViewport(3,4,21,22);glEnable(GL_CULL_FACE);glEnable(GL_SCISSOR_TEST);glDisable(GL_BLEND);glDepthMask(GL_TRUE);
        EM_ASM({window.glyphCase=({count:$0,uploads:[],draws:[],freeBefore:$1});},count,before);
        backend->DrawGlyphs(quads.data(),count,32,32,texture,false);
        Check(scratch.BytesFree()==before,"balanced nested arena borrow");
        GLint viewport[4];glGetIntegerv(GL_VIEWPORT,viewport);GLboolean mask;glGetBooleanv(GL_DEPTH_WRITEMASK,&mask);
        Check(viewport[0]==3&&viewport[1]==4&&viewport[2]==21&&viewport[3]==22,"restored viewport");
        Check(glIsEnabled(GL_CULL_FACE)&&glIsEnabled(GL_SCISSOR_TEST)&&!glIsEnabled(GL_BLEND)&&mask,"restored raster state");
        Check(glGetError()==GL_NO_ERROR,"GL error");
        EM_ASM({window.glyphCase.freeAfter=$0;window.glyphResults.push(window.glyphCase);},scratch.BytesFree());
        scratch.Free(outer);Check(scratch.Empty(),"empty arena between calls");
    }
    EM_ASM({window.glyphCase=null;});
    backend->DestroyTexture(texture);ModernBackendSimulateSurfaceLoss();
    texture=backend->CreateTexture(1,1,RB_TEX_COVERAGE8,&coverage);
    backend->DrawGlyphs(quads.data(),1,32,32,texture,false);Check(scratch.Empty(),"arena balanced after surface loss");backend->DestroyTexture(texture);
    puts("PASS real glyph batches, nested arena balance, GL state and surface-loss rebuild");
    EM_ASM({window.glyphDone=true;});
}
