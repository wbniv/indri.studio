"""Build identity-bound D device tours; only Player diagnostic Forth differs."""
import argparse,json
from pathlib import Path
import build_review_fixtures as fixtures
p=argparse.ArgumentParser();p.add_argument('--build-dir',type=Path,required=True);p.add_argument('--group',type=int,choices=(0,1),required=True);p.add_argument('--mode',type=int,choices=(0,1),required=True);a=p.parse_args()
fixtures.BASE=a.build_dir.resolve()
fixtures.SCENES=[
 ('god-young',4,400,-2,'young_man',{}),
 ('god-icon',4,403,15,'icon',{190:1,191:1}),
 ('god-summit',4,400,30,'god_question',{190:1,191:1,192:1,193:1}),
 ('final-bright',0,3,1,'return_9a',{106:1,107:1,154:1,155:1,176:1,177:1,195:1,196:1,197:1,188:1}),
 ('final-dark',0,3,1,'return_9p',{106:1,107:-1,154:1,155:-1,176:1,177:-1,195:1,196:-1,197:16,188:1}),
 ('god-poster',4,397,3,'poster',{190:1}),
]
fixtures.make(a.group,a.mode)
path=fixtures.BASE/'review-fixtures'/f'group-{a.group}-view-{a.mode}'/'review-receipt.json'
receipt=json.loads(path.read_text());receipt['phases'].insert(0,dict(scene='startup-intro',realm=0,camera=0,phase='initial-source-sheet',source_group='intro',start=0,end=5,optional=True));path.write_text(json.dumps(receipt,indent=2)+'\n')
