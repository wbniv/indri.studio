"""Blender and native winding audit; run with blender --background --python ... -- ... ."""
import bpy,json,collections,argparse,sys,struct,bmesh
from pathlib import Path
ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--scene',type=Path,default=ROOT/'build/parmenides_slice.blend')
parser.add_argument('--report',type=Path,required=True)
parser.add_argument('--require-outward',action='store_true')
args=parser.parse_args(sys.argv[sys.argv.index('--')+1:])
bpy.ops.wm.open_mainfile(filepath=str(args.scene))
rows=[]
for obj in bpy.context.scene.objects:
 if obj.type!='MESH' or obj.get('wf_Model Type')!='Mesh':continue
 mesh=obj.data
 positions=[v.co.copy() for v in mesh.vertices]
 faces=[tuple(p.vertices) for p in mesh.polygons]
 edges=collections.defaultdict(list)
 for i,f in enumerate(faces):
  for a,b in zip(f,f[1:]+f[:1]):edges[tuple(sorted((a,b)))].append(i)
 neighbors=collections.defaultdict(set)
 for ff in edges.values():
  for i in ff:neighbors[i].update(ff)
 unseen=set(range(len(faces)));components=[]
 while unseen:
  todo=[unseen.pop()];component=set(todo)
  while todo:
   nxt=neighbors[todo.pop()]&unseen;unseen-=nxt;component|=nxt;todo.extend(nxt)
  # Preserve original disconnected solids (adjacent arch segments share
  # geometric corners). Weld duplicate poles only within this component.
  weld={};mapping={}
  for i in component:
   for v in faces[i]:
    key=tuple(round(x,6) for x in positions[v])
    if key not in weld:weld[key]=v
    mapping[v]=weld[key]
  cf={i:tuple(mapping[v] for v in faces[i]) for i in component}
  ce=collections.defaultdict(list)
  for i,f in cf.items():
   for a,b in zip(f,f[1:]+f[:1]):ce[tuple(sorted((a,b)))].append(i)
  closed=all(len(ff)==2 for ff in ce.values())
  inconsistent=0
  for e,ff in ce.items():
   if len(ff)!=2:continue
   dirs=[]
   for i in ff:
    f=cf[i];dirs.append(next((a,b) for a,b in zip(f,f[1:]+f[:1]) if tuple(sorted((a,b)))==e))
   if dirs[0]==dirs[1]:inconsistent+=1
  used={v for i in component for v in faces[i]};center=sum((positions[v] for v in used),positions[next(iter(used))]*0)/len(used)
  volume=0
  for i in component:
   f=faces[i]
   for k in range(1,len(f)-1):
    a,b,c=(positions[n]-center for n in (f[0],f[k],f[k+1]));volume+=a.dot(b.cross(c))/6
  components.append({'faces':len(component),'closed':closed,'inconsistent_edges':inconsistent,'signed_volume':volume,'inward':closed and volume<-.000001})
 # Compare exported primitive order after WF's documented face-hand adapter.
 native=args.scene.parent/(obj.name.lower()+'.iff')
 data=native.read_bytes()
 def chunk(tag):
  start=data.index(tag)+4;size=struct.unpack_from('<I',data,start)[0]
  return data[start+4:start+4+size]
 vd=chunk(b'VRTX');fd=chunk(b'FACE')
 nv=[struct.unpack_from('<iii',vd,i+12) for i in range(0,len(vd),24)]
 nf=[struct.unpack_from('<hhhh',fd,i) for i in range(0,len(fd),8)]
 native_points=set(nv)
 def quant(co):
  point=tuple(int(c*65536) for c in co)
  if point in native_points:return point
  options=[tuple(point[j]+d[j] for j in range(3)) for d in __import__('itertools').product((-1,0,1),repeat=3)]
  options=[p for p in options if p in native_points]
  if not options:raise AssertionError('Exported vertex missing in '+obj.name)
  return min(options,key=lambda p:sum(abs(p[j]-point[j]) for j in range(3)))
 def key(points,material):
  return min(tuple(points[i:]+points[:i]) for i in range(3))+(material,)
 bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.triangulate(bm,faces=bm.faces)
 expected=collections.Counter()
 for f in bm.faces:
  points=[quant(l.vert.co) for l in f.loops][::-1]
  if len(set(points))==3:expected[key(points,f.material_index)]+=1
 bm.free()
 actual=collections.Counter(key([nv[a],nv[b],nv[c]],m) for a,b,c,m in nf)
 rows.append({'name':obj.name,'mirror_determinant':obj.matrix_world.determinant(),'components':components,
              'native_winding_matches':actual==expected,'exported_triangles':len(nf)})
args.report.parent.mkdir(parents=True,exist_ok=True)
bad=sum(c['inward'] for r in rows for c in r['components'])
inconsistent=sum(c['inconsistent_edges'] for r in rows for c in r['components'])
mirrored=sum(r['mirror_determinant']<0 for r in rows)
exported=all(r['native_winding_matches'] for r in rows)
receipt=args.scene.parent/('build-receipt.json' if (args.scene.parent/'build-receipt.json').exists() else 'level-receipt.json')
report={'build':json.loads(receipt.read_text()),
'method':'Original connected surfaces with component-local pole welding; closed edge incidence, directed-edge consistency, signed volume, transform determinant and native triangle order after WF face-hand conversion',
'objects':rows,'inward_components':bad,'inconsistent_edges':inconsistent,'mirrored_objects':mirrored,
'native_winding_matches':exported,'passed':bad==0 and inconsistent==0 and mirrored==0 and exported}
args.report.write_text(json.dumps(report,indent=2)+'\n')
print('AUDIT:',len(rows),'meshes;',bad,'inward closed components;',inconsistent,'inconsistent edges;',mirrored,'mirrored objects; exported ordering matches:',exported)
if args.require_outward and not report['passed']:raise SystemExit('Mesh winding verification failed')
