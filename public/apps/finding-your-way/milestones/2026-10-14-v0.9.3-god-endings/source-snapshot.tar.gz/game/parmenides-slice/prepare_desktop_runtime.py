"""Rebuild the recorded WF checkpoint in isolation; never edit the shared engine."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT=Path(__file__).resolve().parent
WF=Path('/home/will/WorldFoundry-wbniv')
parser=argparse.ArgumentParser();parser.add_argument('--build-dir',type=Path,required=True)
parser.add_argument('--fast-debug',action='store_true',help='Use the pinned build script’s WF_ASAN=0 option; engine sources stay unchanged')
args=parser.parse_args();out=args.build_dir.resolve()
provenance=json.loads((out/'runtime-provenance.json').read_text())
checkout=ROOT/'build/desktop-runtime'/(provenance['sourceCommit'][:12]+('-fast-debug' if args.fast_debug else ''))
checkout.mkdir(parents=True,exist_ok=True)
archive=checkout/'checkpoint.tar'
if not archive.exists():
    subprocess.run(['git','archive','--format=tar','-o',str(archive),provenance['sourceCommit'],
                    'engine','wfsource','scripts'],cwd=WF,check=True)
if not (checkout/'engine/build_game.sh').exists():
    with tarfile.open(archive) as bundle:bundle.extractall(checkout,filter='data')
# Versioned vendor archives belong to this checkpoint. Extract those actually
# needed by its canonical desktop configuration, avoiding shared build caches.
for name,pattern in [('jolt-physics-5.5.0','jolt-physics-5.5.0.tar.gz'),
                     ('lua-5.4.8','lua-5.4.8.tar.gz'),('zforth-41db72d1','zforth-41db72d1.tar.gz')]:
    destination=checkout/'engine/vendor'/name
    if not destination.exists():
        source=checkout/'engine/vendor'/pattern
        if not source.exists():raise RuntimeError('Missing pinned vendor archive: '+str(source))
        destination.mkdir()
        with tarfile.open(source) as bundle:
            for member in bundle.getmembers():
                parts=Path(member.name).parts
                if len(parts)<2:continue
                member.name=str(Path(*parts[1:]));bundle.extract(member,destination,filter='data')
env=dict(os.environ,WF_ENABLE_FENNEL='0',WF_JS_ENGINE='none',WF_WASM_ENGINE='none',
         WF_ENABLE_WREN='0',WF_FORTH_ENGINE='zforth',WF_PILOT_ENGINE='builtin',WF_PHYSICS_ENGINE='jolt',
         WF_ASAN='0' if args.fast_debug else '1')
subprocess.run(['bash','engine/build_game.sh'],cwd=checkout,env=env,check=True)
binary=checkout/'engine/wf_game'
receipt=dict(sourceCommit=provenance['sourceCommit'],sourceArchiveSha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
             executable=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
             unchangedEngineSource=True,environment={key:env[key] for key in env if key.startswith('WF_')})
(out/'desktop-rebuild.json').write_text(json.dumps(receipt,indent=2)+'\n')
provenance.setdefault('originalDesktopExecutableSha256',provenance['desktopExecutableSha256'])
provenance['desktopExecutableSha256']=receipt['sha256'];provenance['desktopRebuild']=receipt
(out/'runtime-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
# Desktop provenance is metadata; preserve the already packaged Android bytes.
build_path=out/'build-receipt.json'
if build_path.exists():
    build=json.loads(build_path.read_text())
    build['engineProvenance']=provenance
    build_path.write_text(json.dumps(build,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
