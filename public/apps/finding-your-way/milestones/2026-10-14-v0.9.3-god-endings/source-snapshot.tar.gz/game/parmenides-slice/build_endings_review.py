"""Build exact-mesh/native E device tours; only diagnostic Player Forth differs."""
import argparse
import copy
import json
from pathlib import Path

import build_review_fixtures as fixtures

p=argparse.ArgumentParser();p.add_argument('--build-dir',type=Path,required=True)
p.add_argument('--group',type=int,choices=(0,1),required=True)
p.add_argument('--mode',type=int,choices=(0,1),required=True)
a=p.parse_args();fixtures.BASE=a.build_dir.resolve()
fixtures.SCENES=[
    ('being-release',5,500,0,'ending_10a',{108:0,114:.75,189:1,222:1,488:0}),
    ('both-passage',6,600,-2,'ending_10b',{108:0,189:2,222:1,488:0}),
    ('surgery-normal',8,800,0,'ending_101b',{108:0,189:2,222:2,223:1,489:0}),
    ('notbeing-closure',7,700,0,'ending_10c',{108:0,114:.75,189:3,222:1,488:0}),
    ('notbeing-visage',7,700,0,'ending_10c_last',{108:0,189:3,222:1,488:1.5}),
    ('surgery-reduced',8,800,0,'ending_101b',{108:1,189:2,222:2,223:1,489:0}),
]
base_tour=fixtures.tour
def ending_tour(original,scenes,mode,content):
    # The ordinary two-page diagnostic phases show NotBeing pages 201/202.
    # The separate visage scene displays its final canonical page too; its
    # alias exists only in this in-memory builder, never in production content.
    selected=copy.deepcopy(content)
    selected['groups']['ending_10c_last']=[content['groups']['ending_10c'][-1]]
    revised,phases=base_tour(original,scenes,mode,selected)
    for phase in phases:
        key=phase['source_group']
        phase['source_page_ids']=selected['groups'][key]
        if key=='ending_10c_last':phase['source_group']='ending_10c'
    return revised,phases
fixtures.tour=ending_tour
fixtures.make(a.group,a.mode)
folder=fixtures.BASE/'review-fixtures'/f'group-{a.group}-view-{a.mode}'
path=folder/'review-receipt.json';receipt=json.loads(path.read_text())
receipt['phases'].insert(0,dict(scene='startup-intro',realm=0,camera=0,
    phase='initial-source-sheet',source_group='intro',start=0,end=5,optional=True))
receipt['scope']='E asset rendering and all four complete source accounts via scripted fixtures; native regression separately proves routes, cancellation and sole coda.'
path.write_text(json.dumps(receipt,indent=2)+'\n')
recipes=Path(__file__).resolve().parents[2]/'docs/diagnostics/parmenides/graphics-v0.6/endings-surgery/recipes'
recipes.mkdir(parents=True,exist_ok=True)
(recipes/f'group-{a.group}-view-{a.mode}.json').write_text(json.dumps(dict(
    device='chromecast-test-01',app='parmenides',workflow='record',apk=receipt['apk'],
    warmup=0,runs=1,duration=65,trace='idle'),indent=2)+'\n')
