"""Original painted diffuse sources; ordinary image materials in the WF exporter.

No borrowed imagery, new engine flags, address offsets or external asset packs.
The shared sheet is a production-art UV atlas, not a packed-dialogue workaround.
"""
import hashlib
import json
import random

COLORS = dict(stone='#B7AE94', cream='#E6DCC4', gold='#D9B75F', ink='#303B45',
              blue='#536B89', skin='#C99B78', hair='#49382E', brown='#806044',
              red='#9D626B', street='#697275', green='#667A49', purple='#74657D',
              plaster='#D8C2AE', glass='#436477', steel='#73858D', paper='#E5D7BA')
TILE = 64
SIZE = TILE * 4
PADDING = 4

def generate(out, stage="proof"):
    from PIL import Image, ImageDraw, ImageFont
    rng = random.Random(6001)
    sheet = Image.new('RGB', (SIZE, SIZE))
    for index, (name, color) in enumerate(COLORS.items()):
        tile = Image.new('RGB', (128, 128), color);d = ImageDraw.Draw(tile)
        base = tile.getpixel((0, 0))
        def tint(delta):return tuple(max(0,min(255,c+delta)) for c in base)
        # Broad asymmetrical brush planes and restrained contact wear. Quiet
        # surfaces survive minification; no grain/noise pasted over every face.
        d.polygon([(0,0),(92,0),(46,54),(0,84)],fill=tint(10))
        d.polygon([(128,42),(128,128),(50,128),(84,77)],fill=tint(-12))
        for stroke in range(14):
            x=rng.randrange(12,115);y=rng.randrange(12,115)
            length=rng.randrange(13,40)
            delta=rng.choice((-7,-4,4,7))
            if name in ('brown','hair'):
                d.line([(x,y),(min(124,x+length),y+2)],fill=tint(delta),width=2)
            elif name in ('cream','blue','red','purple','green'):
                d.line([(x,y),(x+3,min(124,y+length))],fill=tint(delta),width=3)
            elif name in ('gold','steel','glass'):
                d.polygon([(x,y),(x+5,y),(min(126,x+length),min(126,y+length)),
                           (min(123,x+length-4),min(126,y+length))],fill=tint(delta+5))
            else:d.line([(x,y),(min(124,x+length),y-3)],fill=tint(delta),width=3)
        tile=tile.resize((TILE,TILE),Image.Resampling.LANCZOS);d=ImageDraw.Draw(tile)
        # Bleed the interior edge into a four-pixel gutter; art UVs never touch
        # neighboring tiles, including on oblique seams.
        interior=tile.crop((PADDING,PADDING,TILE-PADDING,TILE-PADDING))
        d.rectangle((0,0,TILE-1,TILE-1),fill=base)
        tile.paste(interior,(PADDING,PADDING))
        for n in range(PADDING):
            span=TILE-2*PADDING
            tile.paste(interior.crop((0,0,span,1)),(PADDING,n))
            tile.paste(interior.crop((0,span-1,span,span)),(PADDING,TILE-1-n))
            tile.paste(tile.crop((PADDING,0,PADDING+1,TILE)),(n,0))
            tile.paste(tile.crop((TILE-PADDING-1,0,TILE-PADDING,TILE)),(TILE-1-n,0))
        sheet.paste(tile,((index%4)*TILE,(index//4)*TILE))
    sheet.save(out/'art_surfaces.tga');sheet.save(out/'art_surfaces.png')
    paper=Image.new('RGB',(256,256),'#E5D7BA');d=ImageDraw.Draw(paper)
    bold=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf',19)
    small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf',10)
    d.rectangle((9,9,246,246),outline='#BAAB8D',width=2)
    d.text((128,18),'THE DAILY WAY',font=bold,fill='#303B45',anchor='mt')
    d.line((18,46,238,46),fill='#796B59',width=2)
    d.text((128,56),'An advice column',font=small,fill='#49382E',anchor='mt')
    d.polygon([(18,85),(124,85),(124,137),(18,137)],fill='#B7AE94')
    d.ellipse((57,93,81,118),fill='#806044')
    d.polygon([(45,134),(57,118),(81,118),(95,134)],fill='#9D626B')
    for column in (18,136):
        for row in range(11):
            y=151+row*7 if column==18 else 85+row*13
            d.line((column,y,column+88-(row%3)*11,y),fill='#796B59',width=2)
    d.line((129,83,129,228),fill='#BAAB8D',width=1)
    paper=paper.resize((128,128),Image.Resampling.LANCZOS)
    paper.save(out/'art_newspaper.tga');paper.save(out/'art_newspaper.png')
    if stage in ('temple-love','reason-truth','god-final','endings-surgery','polish'):generate_tapestries(out)
    if stage in ('god-final','endings-surgery','polish'):generate_god_inspections(out)
    textures={name:dict(size=list(Image.open(out/name).size),sha256=hashlib.sha256((out/name).read_bytes()).hexdigest())
              for name in ('art_surfaces.tga','art_newspaper.tga')+(('art_tapestries.tga',) if stage in ('temple-love','reason-truth','god-final','endings-surgery','polish') else ())+(('art_god_inspections.tga',) if stage in ('god-final','endings-surgery','polish') else ())}
    (out/'art-textures.json').write_text(json.dumps(dict(textures=textures,tiles=list(COLORS),padding=PADDING),indent=2)+'\n')

def material(out, filename):
    import bpy
    mat=bpy.data.materials.new(filename);mat.use_nodes=True;mat.diffuse_color=(1,1,1,1)
    tex=mat.node_tree.nodes.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(out/filename))
    mat.node_tree.links.new(tex.outputs['Color'],mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'])
    return mat

def tile_uv(color, a, b):
    i=list(COLORS).index(color)
    # Image rows are top down; Blender V is bottom up. Coordinates always stay
    # in the ordinary [0,1] texture domain, inset half a texel beyond the gutter.
    return ((i%4*TILE+PADDING+.5+a*(TILE-2*PADDING-1))/SIZE,
            1-(i//4*TILE+PADDING+.5+b*(TILE-2*PADDING-1))/SIZE)


def generate_tapestries(out):
    """Eight original nested scene paintings, quiet faded and vivid counterparts.

    Each realm repeats miniature scenes at decreasing scales, rather than
    replacing the established fractal brief with a single destination emblem.
    """
    from PIL import Image,ImageDraw,ImageEnhance
    sheet=Image.new('RGB',(256,128))
    for realm in range(4):
        tile=Image.new('RGB',(64,64),('#9D626B','#74657D','#536B89','#667A49')[realm]);d=ImageDraw.Draw(tile)
        d.rectangle((5,5,58,58),outline='#D9B75F',width=2)
        def scene(x,y,size,depth):
            if realm==0:  # Paired figures and their shared bond.
                for dx in (.28,.70):
                    d.ellipse((x+size*(dx-.09),y+size*.15,x+size*(dx+.09),y+size*.33),fill='#E6DCC4')
                    d.polygon([(x+size*dx,y+size*.32),(x+size*(dx-.14),y+size*.70),(x+size*(dx+.14),y+size*.70)],fill='#E6DCC4')
                d.line((x+size*.30,y+size*.45,x+size*.70,y+size*.45),fill='#D9B75F',width=1)
            elif realm==1:  # Ordered apparatus giving way to recursive branches.
                d.rectangle((x+size*.16,y+size*.15,x+size*.83,y+size*.75),outline='#E6DCC4')
                d.line((x+size*.5,y+size*.7,x+size*.5,y+size*.35),fill='#D9B75F')
                for side in (-1,1):d.line((x+size*.5,y+size*.48,x+size*(.5+side*.23),y+size*.23),fill='#D9B75F')
            elif realm==2:  # Testimony figures within nested evidence frames.
                d.rectangle((x+size*.1,y+size*.1,x+size*.9,y+size*.8),outline='#D9B75F')
                d.rectangle((x+size*.24,y+size*.25,x+size*.75,y+size*.6),outline='#E6DCC4')
                d.line((x+size*.5,y+size*.3,x+size*.5,y+size*.55),fill='#E6DCC4',width=2)
            else:  # Devotional ascent and its enclosing sky.
                d.arc((x+size*.12,y+size*.08,x+size*.87,y+size*.77),180,350,fill='#D9B75F')
                d.line([(x+size*.18,y+size*.75),(x+size*.42,y+size*.5),(x+size*.60,y+size*.54),(x+size*.8,y+size*.25)],fill='#E6DCC4',width=2)
            if depth:
                for dx,dy in ((.02,.76),(.53,.76)):scene(x+size*dx,y+size*dy,size*.43,depth-1)
        scene(7,7,50,2)
        faded=ImageEnhance.Color(tile).enhance(.18);faded=ImageEnhance.Contrast(faded).enhance(.45)
        fd=ImageDraw.Draw(faded)
        for x,y in ((14,47),(43,51),(29,20)):fd.line((x,y,x+7,y-3),fill='#B7AE94',width=2)
        for variant,img in ((0,faded),(1,tile)):
            # Bleed the four-pixel gutter for filtered native oblique views.
            core=img.crop((4,4,60,60));img=core.resize((64,64))
            img.paste(core,(4,4));sheet.paste(img,(realm*64,variant*64))
    sheet.save(out/'art_tapestries.tga');sheet.save(out/'art_tapestries.png')


def generate_god_inspections(out):
    """Original small diptych: changing-model poster and foundation icon.

    Inspection sheets retain the complete accessible prose. Painted lettering
    only supplies a handmade prop silhouette; no brand or borrowed image.
    """
    from PIL import Image,ImageDraw,ImageFont
    sheet=Image.new('RGB',(128,64),'#E5D7BA');d=ImageDraw.Draw(sheet)
    small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',6)
    d.rectangle((4,4,59,59),fill='#D8C2AE')
    d.text((32,6),'MODELS',font=small,fill='#303B45',anchor='mt')
    # Separate broken frames surround an intentional empty centre.
    for x,y,w,h,c in ((8,18,21,15,'#9D626B'),(34,18,21,17,'#536B89'),(9,40,19,15,'#667A49'),(35,41,19,13,'#74657D')):
        d.line((x+w,y,x,y,x,y+h),fill=c,width=3)
        d.line((x+w,y+h,x+w-7,y+h),fill=c,width=3)
    d.rectangle((68,4,123,59),fill='#536B89')
    d.arc((75,10,117,43),180,355,fill='#D9B75F',width=2)
    d.ellipse((90,17,102,29),fill='#E6DCC4')
    d.polygon([(96,29),(86,43),(106,43)],fill='#D9B75F')
    d.line((83,34,109,34),fill='#E6DCC4',width=2)
    d.polygon([(78,53),(83,46),(105,46),(113,53),(108,57),(80,57)],fill='#B7AE94')
    # Bleed each four-pixel gutter. The native front UV stays inside it.
    for x in (0,64):
        core=sheet.crop((x+4,4,x+60,60));tile=core.resize((64,64));tile.paste(core,(4,4));sheet.paste(tile,(x,0))
    sheet.save(out/'art_god_inspections.tga');sheet.save(out/'art_god_inspections.png')
