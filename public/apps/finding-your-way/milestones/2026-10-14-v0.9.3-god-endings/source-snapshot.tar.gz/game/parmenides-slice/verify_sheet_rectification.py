"""Recheck rejected transition frames without recapturing already passing views.

The detector's new boundary rectification is reached only after the unchanged
original comparison fails. Retain the original report and exact failure image.
"""
import argparse
import hashlib
import json
from pathlib import Path
from PIL import Image
from verify_panel_render import inspect_frame,verify_detector

p=argparse.ArgumentParser();p.add_argument('--build-dir',type=Path,required=True);p.add_argument('--evidence',type=Path,required=True)
a=p.parse_args();out=a.build_dir.resolve();e=a.evidence.resolve()
target=e/'panel-transition-audit.json';original=e/'panel-transition-before-rectification.json'
if not original.exists():original.write_bytes(target.read_bytes())
r=json.loads(original.read_text());build=json.loads((out/'build-receipt.json').read_text())
assert r['build']['sha256']==build['sha256']
checks=[]
def check(label,condition):
    checks.append(dict(check=label,passed=bool(condition)));print(label,condition)
    if not condition:raise AssertionError(label)
changed=[]
for row in r['results']:
    if row['passed']:continue
    frame_path=e/row['failure_file'];assert hashlib.sha256(frame_path.read_bytes()).hexdigest()==row['sha256']
    frame=Image.open(frame_path);template=Image.open(out/f'card_{row["card"]:02d}.tga')
    measured=inspect_frame(frame,template);check('tilted native source plate matches without lowering thresholds',measured['passed'] and measured['rectified'])
    other=Image.open(out/'card_208.tga');verify_detector(frame,template,other,check)
    # Keep the intended title/footer, but substitute an unrelated paragraph.
    wrong=template.convert('RGB').copy();wrong.paste(other.convert('RGB').resize(template.size).crop((0,22,template.width,97)),(0,22))
    check('rectified detector rejects unrelated body with the same title/footer',not inspect_frame(frame,wrong)['passed'])
    changed.append(dict(original=row.copy(),corrected=measured))
    row.update(measured,rectification_recheck=True)
r.update(passed=r['cases']==420 and r['sampled_cases']==420 and all(row['passed'] for row in r['results']),
    method=r['method']+('; rejected tilted plates additionally compared after fitting their four actual opaque edges; thresholds unchanged' if changed else '; all original samples passed, no rectification rechecks needed'),
    original_report=original.name,original_report_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),
    rectification_rechecks=len(changed))
target.write_text(json.dumps(r,indent=2)+'\n')
(e/'rectification-audit.json').write_text(json.dumps(dict(build=build,passed=r['passed'] and all(c['passed'] for c in checks),
    checks=checks,frames=changed,scope='Only original rejected frames; already passing comparisons unchanged; no new scene capture'),indent=2)+'\n')
print('Transition samples:',len(r['results']),'; rectified rechecks:',len(changed),'; passed:',r['passed'])
