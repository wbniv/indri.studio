"""Build disclosed C device tours; only the Player diagnostic script changes."""
import argparse
import json
from pathlib import Path
import build_review_fixtures as fixtures

p=argparse.ArgumentParser();p.add_argument('--build-dir',type=Path,required=True);p.add_argument('--group',type=int,choices=(0,),required=True);p.add_argument('--mode',type=int,choices=(0,1),required=True);a=p.parse_args()
fixtures.BASE=a.build_dir.resolve()
fixtures.SCENES=[
    ('reason-white',2,196,-1,'white',{}),
    ('reason-grove',2,204,4,'wild',{150:1}),
    ('truth-present',3,300,8,'present',{170:1,171:1,172:1,173:1,174:1,175:1}),
]
fixtures.make(a.group,a.mode)

# A zero-warmup recording also sees the canonical introduction before the tour
# starts at clock five. Declare and validate that page rather than ignoring it.
path=fixtures.BASE/'review-fixtures'/f'group-{a.group}-view-{a.mode}'/'review-receipt.json'
receipt=json.loads(path.read_text())
receipt['phases'].insert(0,dict(scene='startup-intro',realm=0,camera=0,phase='initial-source-sheet',source_group='intro',start=0,end=5,optional=True))
path.write_text(json.dumps(receipt,indent=2)+'\n')
