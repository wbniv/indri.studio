"""Painted landscape for the God ascent in the cumulative chapter art stage.

The navigable hill, encounter actors and existing summit keep their geometry.
All terrain and plants here are visual-only, outside the walking corridor.
"""

import json
import math
import random

STAGE = 'chapter-art'
GOD_MAILBOX = 495
GOD_FORTH = f'102 read-mailbox 4 = {GOD_MAILBOX} write-mailbox\n'


def generate_sources(out):
    from PIL import Image, ImageDraw

    sky = Image.new('RGB', (256, 128))
    px = sky.load()
    for y in range(128):
        t = y / 127
        high = (98, 129, 151)
        low = (225, 203, 162)
        t = max(0, min(1, (t - .10) / .90)) ** 1.35
        for x in range(256):
            px[x, y] = tuple(round(high[k] * (1 - t) + low[k] * t) for k in range(3))
    d = ImageDraw.Draw(sky)
    rng = random.Random(90413)
    for x in range(0, 256, 5):
        crown = 101 + rng.randrange(-10, 8)
        d.polygon(((x - 5, 121), (x + 2, crown), (x + 9, 121)), fill=(70, 99, 88))
        d.rectangle((x, crown + 12, x + 3, 128), fill=(65, 80, 72))
    sky.save(out / 'art_god_sky.tga')

    path = Image.new('RGB', (512, 512), (157, 150, 127))
    d = ImageDraw.Draw(path)
    rng = random.Random(90414)
    for row in range(32):
        y0 = row * 16
        shade = rng.randrange(-10, 11)
        base = (174 + shade, 167 + shade, 142 + shade)
        d.rectangle((7, y0 + 2, 504, y0 + 14), fill=base)
        d.line((8, y0 + 14, 504, y0 + 14), fill=(99, 104, 84), width=2)
        for side in (0, 1):
            x0, x1 = (0, 34) if side == 0 else (476, 511)
            d.rectangle((x0, y0, x1, y0 + 15), fill=(84 + shade // 2, 104 + shade // 2, 76))
            for i in range(6):
                x = rng.randrange(x0, x1 + 1)
                y = rng.randrange(y0, y0 + 16)
                d.line((x, y, x + 4, y - 2), fill=(118, 133, 85), width=2)
        if row % 3 == 1:
            x = rng.randrange(80, 430)
            d.line((x, y0 + 3, x + 8, y0 + 8, x + 3, y0 + 12), fill=(126, 123, 105))
    path.save(out / 'art_god_path.tga')
    (out / 'god-style-sources.json').write_text(json.dumps({
        'art_god_sky.tga': list(sky.size),
        'art_god_path.tga': list(path.size),
        'method': 'deterministic original painted sources',
    }, indent=2) + '\n')


def _paint_top(scene, name, material, bounds):
    obj = scene.objects[name]
    mesh = obj.data
    slot = len(mesh.materials)
    mesh.materials.append(material)
    uv = mesh.uv_layers.active.data
    x0, x1, y0, y1 = bounds
    faces = []
    for face in mesh.polygons:
        if face.normal.z < .8:
            continue
        face.material_index = slot
        faces.append(face.index)
        for loop in face.loop_indices:
            p = obj.matrix_world @ mesh.vertices[mesh.loops[loop].vertex_index].co
            uv[loop].uv = ((p.x - x0) / (x1 - x0), (p.y - y0) / (y1 - y0))
    obj['art_stage_overlay'] = STAGE
    return faces


def dress(M, scene, out, setup_material):
    from art_style_proof import _explicit, kit_type, sky_dome
    from god_scene import height

    Base = M.__bases__[0]
    sky_kit = sky_dome(kit_type(Base))
    sky = sky_kit.object('god_sky', (400, 13, 0), kind='platform', visibility=GOD_MAILBOX)
    sky['art_stage'] = STAGE
    sky['art_role'] = 'painted daylight and distant forest at the God ascent'
    sky['wf_original_bbox'] = (-.05, -.05, 49, .05, .05, 49.1)
    sky['wf_had_authored_bbox'] = True
    sky.data.uv_layers.new(name='Painted diffuse')
    _explicit(sky, sky_kit.uvfns)
    sky.data.materials.clear()
    sky_mat = setup_material(out, 'art_god_sky.tga')
    sky_mat['wf_prelit'] = True
    sky.data.materials.append(sky_mat)
    if 'style_regions' in sky:
        del sky['style_regions']

    path_mat = setup_material(out, 'art_god_path.tga')
    path_mat['wf_prelit'] = True
    painted = {
        'god_path_sides': _paint_top(scene, 'god_path_sides', path_mat, (397, 403, -5, 27.5)),
        'god_rising_path': _paint_top(scene, 'god_rising_path', path_mat, (397, 403, -5, 27.5)),
        'god_entry_landing': _paint_top(scene, 'god_entry_landing', path_mat, (394, 406, -9.5, -4.5)),
        'god_upper_landing': _paint_top(scene, 'god_upper_landing', path_mat, (393, 407, 27, 35)),
    }

    terrain = M()
    rng = random.Random(90415)
    for side in (-1, 1):
        for row in range(19):
            y0 = -10 + row * 2.6
            y1 = y0 + 2.6
            near = 3.25 + (row % 3) * .08
            far = 18 + (row % 4) * 1.4
            z0, z1 = height(y0), height(y1)
            terrain.part([
                (side * near, y0, z0 - .42),
                (side * far, y0, z0 - 2.4),
                (side * far, y1, z1 - 2.4),
                (side * near, y1, z1 - .42),
            ], [(0, 3, 2, 1)] if side < 0 else [(0, 1, 2, 3)],
                'green' if row % 4 else 'stone')
            if row % 3 == 0:
                x = side * (5.8 + rng.random() * 5)
                y = y0 + rng.random() * 2.5
                z = height(y) - .9
                terrain.sphere((x, y, z), (.55, .45, .3), 'stone', 7, 3)
            for i in range(3):
                x = side * (5.5 + rng.random() * 11)
                y = y0 + rng.random() * 2.5
                z = height(y) - .48 - (abs(x) - 3.25) * .12
                h = .45 + rng.random() * .65
                terrain.beam((x, y, z), (x + side * .06, y + .04, z + h), .04, 'brown')
                terrain.sphere((x, y, z + h), (.26, .24, .28), 'green', 6, 3)
    ground = terrain.object('god_landscape', (400, 0, 0), kind='platform', visibility=GOD_MAILBOX)
    ground['art_stage'] = STAGE
    ground['art_role'] = 'visual forest floor, stones and low growth beyond the route'
    ground['wf_original_bbox'] = (-.05, -.05, 49, .05, .05, 49.1)
    ground['wf_had_authored_bbox'] = True

    (out / 'god-style-sheets.json').write_text(json.dumps({
        'sky': {'size': [256, 128], 'prelit': True, 'mesh': sky.name},
        'painted': painted,
        'dressing': [ground.name],
    }, indent=2) + '\n')
    return {
        'stage': STAGE,
        'areas': ['God ascent and summit'],
        'added': [sky.name, ground.name],
        'painted': painted,
        'visibility': {'god': GOD_MAILBOX},
        'collision': 'existing slope and landings unchanged; new landscape has nonphysical bounds outside the route',
        'sources': ['art_god_sky.tga', 'art_god_path.tga'],
    }
