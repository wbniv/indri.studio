#!/usr/bin/env python3
"""Turn a coordinator ``simpleperf`` perf.data into named functions, with no ADB.

``perf.data`` records build ids and the on-device path of every binary. Release APKs strip
their native libraries, so function names come from the *unstripped* ``libwf_game.so`` that the
caller kept from the Gradle build (``app/.cxx/**/obj/<abi>/``). This script:

1. runs the NDK host ``simpleperf report --sort dso`` to find the device path of the app library,
2. copies the unstripped library to that path under a scratch symbol directory (simpleperf then
   checks the build id and refuses a mismatch, which is reported rather than hidden),
3. reports the flat profile (self time per symbol) and, if the profile has call graphs, the
   inclusive time (``--children``), as one markdown file.

System libraries (the Mali driver, libc, libGLES) stay unresolved by symbol on purpose: they
need device copies and the coordinator forbids pulling them over raw ADB. They still appear by
dso, which is what separates "our code" from "the driver".

Usage:
    report_simpleperf.py PERF.data --lib UNSTRIPPED_libwf_game.so [--out report.md] [--top 40]
"""
import argparse
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

NDK = Path('/home/will/android-sdk-local/ndk/26.2.11394342')
SIMPLEPERF = NDK / 'simpleperf/bin/linux/x86_64/simpleperf'
APP_LIB = 'libwf_game.so'


def run(args):
    done = subprocess.run([str(a) for a in args], capture_output=True, text=True)
    if done.returncode:
        raise SystemExit(f'{args[0]} failed ({done.returncode}):\n{done.stderr[-1500:]}')
    return done.stdout, done.stderr


def device_paths(perf):
    out, _ = run([SIMPLEPERF, 'report', '-i', perf, '--sort', 'dso', '--percent-limit', '0'])
    return sorted({line.split()[-1] for line in out.splitlines() if APP_LIB in line})


def table(text, limit):
    """Keep the header and the first `limit` data rows of a simpleperf report table."""
    rows, header = [], []
    for line in text.splitlines():
        if line.startswith('#') or not line.strip():
            continue
        if line.lstrip().startswith('Overhead') or line.lstrip().startswith('Children'):
            header = [line]
            continue
        rows.append(line)
    return '\n'.join(header + rows[:limit])


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.split('\n')[0])
    parser.add_argument('perf', type=Path)
    parser.add_argument('--lib', type=Path, required=True, help=f'unstripped {APP_LIB} from the same build')
    parser.add_argument('--out', type=Path)
    parser.add_argument('--top', type=int, default=40)
    args = parser.parse_args(argv)
    if not SIMPLEPERF.exists():
        raise SystemExit(f'NDK host simpleperf missing: {SIMPLEPERF}')
    paths = device_paths(args.perf)
    if not paths:
        raise SystemExit(f'No {APP_LIB} in {args.perf}: the app was not sampled or the dso name differs')
    with tempfile.TemporaryDirectory(prefix='symfs-') as scratch:
        for path in paths:
            target = Path(scratch) / path.lstrip('/')
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(args.lib, target)
        base = [SIMPLEPERF, 'report', '-i', args.perf, '--symfs', scratch, '--percent-limit', '0.2']
        flat, flat_err = run(base + ['--sort', 'dso,symbol'])
        by_dso, _ = run(base + ['--sort', 'dso'])
        by_thread, _ = run(base + ['--sort', 'comm,tid'])
        inclusive = ''
        try:
            inclusive, _ = run(base + ['--children', '--sort', 'dso,symbol'])
        except SystemExit:
            inclusive = ''
    mismatch = [l for l in flat_err.splitlines() if 'build id' in l.lower() or 'mismatch' in l.lower()]
    resolved = sum(1 for l in flat.splitlines() if APP_LIB in l and not re.search(r'\[\+?[0-9a-fx]+\]|unknown', l))
    md = [f'# simpleperf: {args.perf.name}', '',
          f'- device path(s): {", ".join(paths)}', f'- unstripped library: `{args.lib}`',
          f'- app-library symbol rows resolved in the top section: {resolved}',
          f'- build-id warnings: {mismatch if mismatch else "none"}', '',
          '## By shared object', '```', table(by_dso, args.top), '```', '',
          '## By thread', '```', table(by_thread, 12), '```', '',
          '## Self time by symbol', '```', table(flat, args.top), '```']
    if inclusive:
        md += ['', '## Inclusive time by symbol (`--children`)', '```', table(inclusive, args.top), '```']
    text = '\n'.join(md) + '\n'
    if args.out:
        args.out.write_text(text)
        print(args.out)
    else:
        print(text)
    return 1 if mismatch else 0


if __name__ == '__main__':
    sys.exit(main())
