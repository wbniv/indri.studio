"""Native regression for stuck modal height and restoration on close."""
import json
import time


def run(b, player, value, check, tap, position, ids, out, evidence):
    rows=[]
    for name in ('Camera','FollowShot','CamTarget'):
        for mailbox in (3009,3010,3011):b.watch(ids[name],mailbox)
    def pose():
        actual=[b.mailbox_values.get((ids['Camera'],m)) for m in (3009,3010,3011)]
        shot=[b.mailbox_values.get((ids['FollowShot'],m)) for m in (3009,3010,3011)]
        origin=[b.mailbox_values.get((ids['CamTarget'],m)) for m in (3009,3010,3011)]
        p=[value(m) for m in (3009,3010,3011)]
        if any(v is None for v in actual+shot+origin+p):return None
        expected=[x-y+z for x,y,z in zip(shot,origin,p)]
        return dict(actual=actual,expected=expected,error=max(abs(x-y) for x,y in zip(actual,expected)))
    def settled(label, reading):
        deadline=time.monotonic()+8
        stable=None
        while time.monotonic()<deadline:
            sample=pose()
            ok=sample is not None and sample['error']<.02 and (bool(value(129)) if reading else value(140)==0)
            stable=(stable or time.monotonic()) if ok else None
            if stable is not None and time.monotonic()-stable>.25:
                rows.append(dict(check=label,reading=reading,**sample))
                check(label,True);return
            time.sleep(.02)
        rows.append(dict(check=label,reading=reading,pose=pose(),card=value(140),ready=value(129)))
        check(label,False)
    try:
        for mode in (0,1):
            if value(101)!=mode:tap(2)
            # (5,2.8) overlaps the authored pillar1 camera footprint at (5,-1).
            # These anchors test recovery/restoration near geometry. The short
            # probe also passed on the old build; it does not independently
            # reproduce the intermittent exhaustive-sweep collision stall.
            for x,y in ((5,2.8),(10,9),(0,-3),(3,0),(0,5)):
                b.set_mailbox(140,0,idx=player);b.set_mailbox(102,0,idx=player)
                b.set_mailbox(114,.25,idx=player);position(x,y)
                for card in (146,150,197):
                    label=f'anchor {x},{y} view {mode} card {card}'
                    b.set_mailbox(140,card,idx=player);time.sleep(.15)
                    settled(label+' opens at requested reading pose',True)
                    # Stress the observed height difference and stale velocity
                    # during reading, without claiming a reproduction of the
                    # old collision handler's intermittent frozen-height state.
                    actual=pose()['actual']
                    b.send({'op':'scene:set_transform','idx':ids['Camera'],
                            'pos':[actual[0],actual[1],actual[2]+.9]})
                    b.set_mailbox(3020,2,idx=ids['Camera']);time.sleep(.15)
                    settled(label+' recovers displaced camera and velocity',True)
                    b.set_mailbox(140,0,idx=player);time.sleep(.15)
                    settled(label+' restores world pose on close',False)
            b.set_mailbox(102,8,idx=player);position(800,0)
            b.set_mailbox(140,204,idx=player);time.sleep(.15)
            settled(f'patient view {mode} retains requested reading pose',True)
            b.set_mailbox(140,0,idx=player);time.sleep(.15)
            settled(f'patient view {mode} restores world pose',False)
    finally:
        (evidence/'camera-regression.json').write_text(json.dumps(dict(
            build=json.loads((out/'build-receipt.json').read_text()),results=rows,
            passed=len(rows)==94 and all(row.get('error',1)<.02 for row in rows)),indent=2)+'\n')
