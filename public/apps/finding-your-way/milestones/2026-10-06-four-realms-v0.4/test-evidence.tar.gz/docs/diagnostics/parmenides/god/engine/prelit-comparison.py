import importlib.util, subprocess, tempfile
from pathlib import Path
root=Path('/home/will/WorldFoundry-wbniv')
spec=importlib.util.spec_from_file_location('check',root/'tests/test_prelit_winding_invariant.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
run=subprocess.run
def stable(args,*a,**kw):
    if args[0]==str(m.WF_GAME):args=[*args,'--no-fps']
    return run(args,*a,**kw)
subprocess.run=stable
out=Path(tempfile.mkdtemp(prefix='fyw-prelit-no-fps-'))
m.test_prelit_face_colour_is_winding_independent(out)
print('PASS: shipped/reversed prelit scene frames identical with diagnostic FPS disabled; captures:',out)
