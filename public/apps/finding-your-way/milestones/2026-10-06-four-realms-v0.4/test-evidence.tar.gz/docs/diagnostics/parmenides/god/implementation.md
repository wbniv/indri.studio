# God functional milestone — 2026-10-06

God completes the four functional realm prototypes. The rising forest path, two guides, original poster/icon, question stop, deliberate threshold choices and sixteen final Temple histories are playable in the existing World Foundry runtime. Models remain provisional Blender assets, as Will requested. Ending doors enforce the exact source links but show clearly labeled next-milestone sheets; the three ending scenes and surgery coda are not implemented.

## Play sequence

Complete Love, Reason and Truth, then enter GOD from the Temple. Walk up the path, hear the young man and inspect his poster. Meet the holy man further uphill and inspect the icon. Finish YOUR QUESTION beside the upper landing. Both guides withdraw; choose the white BEING or black NOTBEING threshold and finish its answer. Return to the exact final Temple account and finish the goddess's delivery before an ending door becomes available. TEMPLE leaves without choosing. An unfinished visit retains encounters; replaying a completed realm clears downstream state.

```mermaid
flowchart TD
    T[Truth commitment] --> G[God entry landing]
    G --> Y[Young man: full account]
    Y --> P[Inspect original poster]
    Y --> H[Holy man: full account]
    H --> I[Inspect original icon]
    P --> Q[Your question: both accounts and inspections required]
    I --> Q
    Q --> B[White threshold / Being counsel]
    Q --> N[Black threshold / eight unanswered questions]
    B --> F[Exact final Temple account: 9a–9p]
    N --> F
    F --> D[Finish goddess delivery to unlock doors]
    D --> A[10a Being: 9a only]
    D --> X[10b Both: all histories]
    D --> Z[10c NotBeing: all histories]
    A --> M[Explicit ending preview sheets]
    X --> M
    Z --> M
    G -. fall recovery .-> G
    Q -. upper checkpoint recovery .-> Q
```

The safe path rises 5.2 units over 32.5 units of travel. Entry and summit landings support free movement in both perspectives. Falling returns to the entry landing until the summit checkpoint is reached, then to the upper landing. Recovery retains encounter progress and never selects a philosophy. The question plinth and sign sit beside the path so they do not obstruct ascent.

## Source fidelity and final gates

The young man delivers complete `god1a + godaa` prose; the holy man delivers `god2a + godba`; the question uses `godca`. Each of the eight source aliases has identical spoken prose, independently audited. The white answer preserves `godbeinga`; the black answer preserves all eight question repetitions in `godnotbeinga`. Inspection instructions and confirmations are authored adaptations, separate from those accounts. The original poster/icon illustrate claims without presenting their pictures as proof.

All final accounts retain their exact `9a–9p` source text. Door eligibility is read from each page's frontmatter, not a majority score. B means Being; N means NotBeing.

| Final gate | Love | Reason | Truth | God | Eligible doors |
|---|---|---|---|---|---|
| 9a | B | B | B | B | 10a, 10b, 10c |
| 9b | B | B | B | N | 10b, 10c |
| 9c | B | B | N | B | 10b, 10c |
| 9d | B | B | N | N | 10b, 10c |
| 9e | B | N | B | B | 10b, 10c |
| 9f | B | N | B | N | 10b, 10c |
| 9g | B | N | N | B | 10b, 10c |
| 9h | B | N | N | N | 10b, 10c |
| 9i | N | B | B | B | 10b, 10c |
| 9j | N | B | B | N | 10b, 10c |
| 9k | N | B | N | B | 10b, 10c |
| 9l | N | B | N | N | 10b, 10c |
| 9m | N | N | B | B | 10b, 10c |
| 9n | N | N | B | N | 10b, 10c |
| 9o | N | N | N | B | 10b, 10c |
| 9p | N | N | N | N | 10b, 10c |

The bright final Temple adds provisional aether rings and retains the chosen prior tapestries/windows/foundation. The dark final Temple hides the shell. Invisible support under a removed foundation remains a provisional substitute for the source's rescue beat. Final doors remain closed until the exact goddess account is delivered completely; cancelling and replaying it cannot skip that gate.

## Native integration and fixes

- [x] Original geometry and editable Blender master exported directly through the WF Blender exporter; no glTF step or exporter source edits.
- [x] Two adjacent native rooms, with separate ambient/directional lights, keep all realm and final-history assets available.
- [x] 201 cards: 73 permanent, 62 ChapterRoom/Truth, 66 GodRoom/final-history cards. Hidden cards return to their original room positions; only the active card follows the camera.
- [x] Player box collision uses zero exported slope coefficients. The hill uses a separate upward-facing plane collider and decorative shell. This level-data fix avoids the runtime's unsupported slope-versus-slope collision; it does not address visual face normals/culling.
- [x] Will's authorized engine fix carries full atlas coordinates into modern flat/Gouraud textured primitives and checks the bound map's actual dimensions. Legacy single-PixelMap rendering retains its page convention. Engine checkpoint: `1aecfbe5f3aeb0fc394522c4c5d35f126de551df`.
- [x] Removed custom atlas packing and Blender UV-cell remapping. Each card/sign again binds its individual image with ordinary full-image UVs; WF's exporter and textile pack them normally. The asset audit checks every exported image region and exact RGB555 pixels, including real cells above 1,024/1,536 pixels.
- [x] Rebuilt desktop and both Android ABIs; [runtime provenance](engine/runtime-provenance.json) pins the source files, engine patch, executable and native-library hashes. Archives preserve the changed engine source/test files and patch alongside the chapter.

The production primitive regression passes 80 flat/Gouraud cases through origin 1,536 on both axes, with bound maps larger than configured transient slots. Substituting the original material source fails with `FT3 atlas address truncated`. The existing prelit winding comparison initially differed by 48 pixels confined to the FPS counter; with `--no-fps`, the actual rendered scene frames are identical. [Engine evidence](engine/runtime-provenance.json).

The first device screenshot exposed the texture-address issue despite valid source bitmaps and mailbox delivery. Its smoke job `J-24563acb464f` passed application lifecycle checks but is not visual acceptance. The final device evidence below replaces that build after the asset correction. The archived historical APKs remain unchanged.

## Verification evidence

**Verification: PASS.** The rebuilt APK is `7fd2a9d1655591d79a036d37d81c4566ffc34778011d6bf0055a82de8132a069`; level bundle SHA-256 is `de0bb48396c00dd5e7b4a26326d452bc5985f704668c5cd31bacc1e906d4c2aa`. The audits pass **1,860 native runtime checks, 337 source checks and 1,369 asset checks**. The 631 actual dialogue sequences cover all 201 cards with no missing cards. The separate engine primitive regression passes 80 cases. [Combined summary](verification-summary.json), [source audit](text-audit.json), [asset audit](asset-audit.json), [native route results](desktop/results.json), [actual dialogue transcripts](desktop/transcripts.json), [supplemental text/safety checks](desktop/supplemental-text/results.json).

Chromecast 1 job `J-1d65f6420934` completed installation/hash verification, launch, remote Select and Home/resume with verified cleanup. Inspected [Temple signs](cast1-review/after-ok-screenshot.png) show LOVE and THE GODDESS correctly, replacing the unrelated text from the original defective runtime. The [dialogue capture](cast1-review/after-keys-screenshot.png) shows the intended intro without world labels covering it; the [resumed view](cast1-review/resumed-screenshot.png) remains correct. [Device receipt](cast1-review/receipt.json).

The desktop harness uses debug transforms and prior-history fixtures to place encounters and exercise every branch. Native input opens, advances, cancels and commits dialogue; only the intended card may be visible, in exact order and with the correct stopping point. God guide/inspection prose is played completely once in each viewpoint because every history alias is independently audited as identical. Every final history, threshold counsel, door guard and replay reset is exercised in both viewpoints. The ascent and walking off the summit into recovery use actual sustained movement input. Supplemental safety checks start with an unset checkpoint, walk off the entry landing, climb the whole hill to activate the checkpoint and walk off the summit in both viewpoints. Both rescues retain partial encounters without choosing a philosophy.

The Linux debug screenshot path is stale/blank, so desktop PNGs are not treated as visual evidence or included in milestone archives. Real Android screenshots verify launch, readability, remote input and Home/resume; those smoke checks do not establish a complete God traversal or phone acceptance.

## Remaining work

- [ ] Implement the three ending scenes and only `10b → 101b` surgery coda, with complete source dialogue, transitions and completion state.
- [ ] Art passes after functionality: guide departure clips, expressive faces, face-normal/culling investigation, final forest/aether art and source rescue choreography.
- [ ] Phone touch movement/look, safe areas, thermal acceptance, full phone playthroughs, durable saves, voice performance and journal history.

Progress is session-local; relaunching starts again. Open Finding Your Way from the Chromecast launcher for review. Authored with Codex, GPT-6; tool-version and reasoning-effort metadata were unavailable to verify.
