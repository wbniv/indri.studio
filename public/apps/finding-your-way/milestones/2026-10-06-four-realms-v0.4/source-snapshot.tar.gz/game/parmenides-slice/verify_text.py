"""Audit chapter text against canonical sources, independently of gameplay routing."""
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[1]
data = json.loads((ROOT / 'build/content.json').read_text())
cards = {card['id']: card for card in data['cards']}
results = []

def check(label, condition):
    results.append({'check': label, 'passed': bool(condition)})
    if not condition:
        raise AssertionError(label)

def canonical(slug):
    raw = (PROJECT / 'src/content/pages' / (slug + '.md')).read_text()
    body = raw.split('---', 2)[2].split('<details', 1)[0]
    body = re.sub(r'!\[[^\]]*\]\([^)]*\)', '', body)
    if slug=='7h':body=body.split('Another Temple scene, with corresponding responses')[0]
    return ' '.join(body.replace('*', '').replace('_', '').split())

def text_for(*keys):
    return ' '.join(cards[index]['text'] for key in keys for index in data['groups'][key])

try:
    indices = [index for pages in data['groups'].values() for index in pages]
    check('every card belongs to exactly one group', len(indices) == len(set(indices)) == len(cards))
    for key, pages in data['groups'].items():
        check(key + ': group identity and nonempty text', bool(pages) and all(cards[index]['key'] == key and cards[index]['text'] for index in pages))
        check(key + ': no image/frontmatter markup in delivery', not any('![](' in cards[index]['text'] or 'slug:' in cards[index]['text'] for index in pages))
    for key, slugs in {'first': ('loveb',), 'starlet': ('lovec', 'loved'), 'wild': ('reasonca',),
                       'child': ('reasonda',), 'why_axis': ('reasonbeinga',), 'rain_reply': ('reasonnotbeinga',),
                       'return_5a': ('5a',), 'return_5b': ('5b',), 'return_5c': ('5c',), 'return_5d': ('5d',)}.items():
        check(key + ': complete intended source, no extra words', text_for(key) == ' '.join(canonical(slug) for slug in slugs))
    check('White + transformation: complete reasonaa/reasonba, no other account', text_for('white', 'grove') == canonical('reasonaa') + ' ' + canonical('reasonba'))
    check('White stops before the grove narration', 'You feel a vast crack' not in text_for('white') and text_for('grove').startswith('You feel a vast crack'))
    for stem in ('reasona', 'reasonb', 'reasonc', 'reasond', 'reasonbeing', 'reasonnotbeing'):
        check(stem + ': history aliases have identical spoken content', canonical(stem + 'a') == canonical(stem + 'b'))
    check('apparatus does not contain either concluding account', canonical('reasonbeinga') not in text_for('apparatus_order', 'apparatus_limit') and canonical('reasonnotbeinga') not in text_for('apparatus_order', 'apparatus_limit'))
    check('Reason gate explains a commitment, not just encounters', all(term in text_for('reason_unavailable') for term in ('BEING', 'NOTBEING', 'confirmation', 'TEMPLE portal returns without choosing')))
    for key,slugs in {'truth_intro':('truth1a',),'prosecutor':('truthaa','truthba'),'defence':('truthca',),
                      'student':('truthda',),'truth_counsel_being':('truthbeinga',),
                      'truth_counsel_notbeing':('truthnotbeinga',),**{'return_7'+c:('7'+c,) for c in 'abcdefgh'}}.items():
        check(key+': complete intended source, no extra words',text_for(key)==' '.join(canonical(slug) for slug in slugs))
    editorial=lambda body:re.findall(r'[a-z0-9]+',body.lower().replace("'",'').replace('’',''))
    for stem in ('truth1','trutha','truthb','truthc','truthd','truthbeing','truthnotbeing'):
        for suffix in 'bcd':
            check(stem+suffix+': same account after documented editorial punctuation',editorial(canonical(stem+'a'))==editorial(canonical(stem+suffix)))
    for index,suffix in enumerate('abcd'):
        for choice,next_suffix in (('truthbeing','abcdefgh'[index*2]),('truthnotbeing','abcdefgh'[index*2+1])):
            raw=(PROJECT/'src/content/pages'/(choice+suffix+'.md')).read_text()
            check(choice+suffix+': correct history route',re.search(r'slug: /(7[a-h])',raw).group(1)=='7'+next_suffix)
    check('exhibits never append either lawyer counsel',all(canonical(slug) not in text_for('facts','interpretations','present') for slug in ('truthbeinga','truthnotbeinga')))
    for key,slugs in {'young_man':('god1a','godaa'),'holy_man':('god2a','godba'),
                      'god_question':('godca',),'god_counsel_being':('godbeinga',),
                      'god_counsel_notbeing':('godnotbeinga',),**{'return_9'+c:('9'+c,) for c in 'abcdefghijklmnop'}}.items():
        check(key+': complete intended source, no extra words',text_for(key)==' '.join(canonical(slug) for slug in slugs))
    for stem in ('god1','god2','goda','godb','godc','godbeing','godnotbeing'):
        for c in 'bcdefgh':check(stem+c+': identical spoken history alias',canonical(stem+c)==canonical(stem+'a'))
    check('NotBeing retains all eight source-question repetitions',text_for('god_counsel_notbeing').count('Why are we here?')==8)
    check('poster and icon never append either guide account or counsel',all(canonical(slug) not in text_for('poster','icon') for slug in ('godaa','godba','godbeinga','godnotbeinga')))
    edge_count=0
    for index,c in enumerate('abcdefgh'):
        for stem,suffix in (('godbeing','abcdefghijklmnop'[index*2]),('godnotbeing','abcdefghijklmnop'[index*2+1])):
            raw=(PROJECT/'src/content/pages'/(stem+c+'.md')).read_text()
            check(stem+c+': exact final history route',re.search(r'slug: /(9[a-p])',raw).group(1)=='9'+suffix)
    for c,row in data['god_histories'].items():
        raw=(PROJECT/'src/content/pages'/(c+'.md')).read_text().split('---',2)[1]
        expected=re.findall(r'slug: /(10[abc])',raw);edge_count+=len(expected)
        check(c+': exact source outgoing doors',row['doors']==expected)
    check('all 33 final-gate edges retained',edge_count==33)
    check('only 9a grants the Being ending',[key for key,row in data['god_histories'].items() if '10a' in row['doors']]==['9a'])
finally:
    output = PROJECT / 'docs/diagnostics/parmenides/god/text-audit.json'
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps({'build': json.loads((ROOT / 'build/build-receipt.json').read_text()), 'results': results}, indent=2) + '\n')
print(f'{len(results)} source-content checks passed')
