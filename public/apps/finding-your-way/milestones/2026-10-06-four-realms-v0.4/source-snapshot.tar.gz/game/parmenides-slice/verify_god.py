"""Actual native God encounters, ascent/fall recovery and sixteen final histories."""
import time

def run_safety(b,player,value,check,tap,position,read_pages,groups):
    """Prove entry rescue and an input-driven checkpoint from a clear state."""
    def walk_until(label,predicate,timeout=22):
        b.inject_input('joystick1_raw',2048,2000)
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline and not predicate():time.sleep(.02)
        reached=bool(predicate())
        b.inject_input('joystick1_raw',0,1)
        b.wait_for_mailbox(player,111,0,timeout=3);time.sleep(.15)
        check(label,reached)
    progress={190:1,191:0,192:1,193:0,194:0}
    for mode in (0,1):
        prefix=f'God safety camera={mode}: '
        if value(101)!=mode:tap(2)
        for m in (106,154,176,107,155,177,156,178,195):b.set_mailbox(m,1,idx=player)
        time.sleep(.15)
        position(0,-8);tap();read_pages(prefix+'entry',groups['god_intro'])
        check(prefix+'checkpoint and fall count start clear',value(199)==0 and value(200)==0)
        for m,v in progress.items():b.set_mailbox(m,v,idx=player)
        position(400,-7);b.set_mailbox(114,0,idx=player);time.sleep(.1)
        walk_until(prefix+'actual walking off entry triggers rescue',lambda:value(200)>0)
        check(prefix+'entry rescue retains partial encounters without choosing',
              value(199)==0 and abs(value(3009)-400)<.6 and abs(value(3010)+7)<1 and value(3011)>-.2 and
              all(value(m)==v for m,v in progress.items()) and value(195)==0 and value(196)==0)
        falls=value(200)
        position(400,-7);b.set_mailbox(114,.25,idx=player);time.sleep(.1)
        check(prefix+'checkpoint remains clear before real ascent',value(199)==0)
        walk_until(prefix+'full ascent sets checkpoint',lambda:value(3010)>=29)
        check(prefix+'checkpoint activates during ascent without a fall',value(199)==1 and value(3011)>4.9 and value(200)==falls)
        b.set_mailbox(114,0,idx=player);time.sleep(.1)
        walk_until(prefix+'actual walking off summit triggers rescue',lambda:value(200)>falls)
        check(prefix+'upper rescue retains partial encounters without choosing',
              abs(value(3009)-400)<.6 and abs(value(3010)-30)<1 and value(3011)>4.9 and
              all(value(m)==v for m,v in progress.items()) and value(195)==0 and value(196)==0)
        position(400,-8);tap()

def run(b,player,value,check,tap,position,read_pages,read_argument,groups,content,proc):
    def drive(label,predicate,timeout=22):
        b.inject_input('joystick1_raw',2048,2000)
        deadline=time.monotonic()+timeout
        report=0
        while time.monotonic()<deadline and not predicate():
            if time.monotonic()>report:
                print({'movement':label,'x':value(3009),'y':value(3010),'z':value(3011),'heading':value(114),'falls':value(200),'panel':value(140),'input':value(111)},flush=True)
                report=time.monotonic()+3
            time.sleep(.02)
        reached=bool(predicate())
        b.inject_input('joystick1_raw',0,1)
        b.wait_for_mailbox(player,111,0,timeout=3);time.sleep(.15)
        check(label,reached)
    def fixture(index):
        answers={'love':1 if index<8 else -1,'reason':1 if index%8<4 else -1,'truth':1 if index%4<2 else -1,'god':1 if index%2==0 else -1}
        for mailbox,answer in ((106,1),(154,1),(176,1),(107,answers['love']),(155,answers['reason']),
                               (177,answers['truth']),(156,index//4+1),(178,index//2+1)):
            b.set_mailbox(mailbox,answer,idx=player)
        time.sleep(.15)
        return answers
    if value(102)!=0:
        position(100*int(value(102)),-8);tap()
    position(0,-8);tap();read_pages('God requires a Truth commitment',groups['god_unavailable'])
    for mode in (0,1):
        if value(101)!=mode:tap(2)
        for index,c in enumerate('abcdefghijklmnop'):
            slug='9'+c;prefix=f'{slug} camera={mode}: '
            answers=fixture(index)
            position(0,-8);tap()
            check(prefix+'God entry and fresh downstream state',value(102)==4 and all(value(m)==0 for m in range(188,198)) and value(199)==0 and value(200)==0)
            read_pages(prefix+'onboarding',groups['god_intro'])
            if index==0:
                position(396,31);tap();read_pages(prefix+'threshold waits for encounters',groups['god_locked'])
                position(400,12);tap();read_pages(prefix+'holy man waits for young man',groups['god_wait'])
                position(397,5);tap();read_pages(prefix+'poster waits for its account',groups['god_wait'])
                position(403,17);tap();read_pages(prefix+'icon waits for its account',groups['god_wait'])
                position(400,0);tap();tap();tap(16384)
                check(prefix+'partial young account can cancel',value(140)==0 and value(190)==0)
                read_argument(400,0,'young_man',190)
                check(prefix+'only young encounter completes',value(191)==0 and value(195)==0)
                read_argument(397,5,'poster',192)
                position(400,-8);tap();check(prefix+'return does not commit God',value(102)==0 and value(195)==0)
                position(0,-8);tap();check(prefix+'unfinished visit retains accounts and skips onboarding',value(102)==4 and value(190)==1 and value(192)==1 and value(140)==0)
                read_argument(400,12,'holy_man',191)
                position(398,23);tap();read_pages(prefix+'question waits for both inspections',groups['god_locked'])
                read_argument(403,17,'icon',193)
                check(prefix+'inspection never selects a philosophy',value(194)==0 and value(195)==0 and value(196)==0)
                position(400,-7);b.set_mailbox(114,.25,idx=player);time.sleep(.1)
                before=value(200)
                drive(prefix+'actual forward input ascends the entire hill',lambda:value(3010)>=29)
                check(prefix+'ascent gains height without a rescue',value(3011)>4.9 and value(200)==before and value(199)==1)
                b.set_mailbox(114,0,idx=player);time.sleep(.1)
                drive(prefix+'walking off upper landing triggers rescue',lambda:value(200)>before,timeout=12)
                check(prefix+'rescue returns to upper checkpoint with progress',abs(value(3009)-400)<.6 and abs(value(3010)-30)<1 and value(3011)>4.9 and all(value(m)==1 for m in range(190,194)) and value(195)==0)
                position(396,31);tap();read_pages(prefix+'threshold still needs your question',groups['god_locked'])
                read_argument(398,23,'god_question',194)
                check(prefix+'guides and their labels depart',all(value(m)==0 for m in (201,202,203,204)))
            else:
                # Accounts/inspections are identical across all eight source aliases,
                # audited independently and played fully above in each perspective.
                for mailbox in range(190,195):b.set_mailbox(mailbox,1,idx=player)
                time.sleep(.15)
            position(396 if answers['god']==1 else 404,31);tap()
            key='god_affirm' if answers['god']==1 else 'god_deny'
            counsel='god_counsel_being' if answers['god']==1 else 'god_counsel_notbeing'
            check(prefix+'correct confirmation and labels suppressed',value(140)==groups[key][0] and all(value(m)==0 for m in (203,204,205,220,221,242)))
            tap(16384);check(prefix+'cancel cannot commit',value(140)==0 and value(195)==0 and value(196)==0)
            tap();tap();check(prefix+'source counsel precedes commitment',value(140)==groups[counsel][0] and value(195)==0)
            tap(16384);check(prefix+'counsel can cancel safely',value(140)==0 and value(195)==0)
            tap();read_pages(prefix+'selected source answer',groups[key]+groups[counsel],groups['return_'+slug][0])
            check(prefix+'exact final history, prior choices unchanged',value(102)==0 and value(195)==1 and value(196)==answers['god'] and value(197)==index+1 and all(value(m)==answers[k] for m,k in ((107,'love'),(155,'reason'),(177,'truth'))))
            check(prefix+'doors wait for complete goddess account',value(188)==0 and all(value(m)==0 for m in (214,215,216,217,218,219)))
            check(prefix+'source bright dome or dark Temple',bool(value(207))==(answers['god']==1) and bool(value(212))==(answers['god']==1))
            check(prefix+'source prior Temple features retained under light',bool(value(206))==(answers['god']==1 and answers['truth']==1) and bool(value(229))==(answers['god']==1 and answers['reason']==1) and bool(value(234))==(answers['god']==1 and answers['love']==1))
            if index==0:
                tap(16384);position(0,-11);tap();read_pages(prefix+'final doors require goddess delivery',groups['final_wait'])
                position(3,3);tap()
            read_pages(prefix+'exact final Temple account',groups['return_'+slug])
            expected=content['god_histories'][slug]['doors']
            check(prefix+'exact eligible door meshes and labels',value(188)==1 and all(bool(value(m))==(door in expected) for m,door in ((214,'10a'),(215,'10b'),(216,'10c'),(217,'10a'),(218,'10b'),(219,'10c'))))
            position(3,3);tap();read_pages(prefix+'goddess replays only this final history',groups['return_'+slug])
            for x,door in ((-7,'10a'),(0,'10b'),(7,'10c')):
                position(x,-11);tap()
                read_pages(prefix+'final door '+door,groups['ending_'+door] if door in expected else groups['final_closed'])
                check(prefix+'door marker preserves completed God',value(195)==1 and value(197)==index+1)
            start=value(3010);position(0,-3);start=value(3010);tap(2048,15)
            check(prefix+'final Temple remains traversable',value(3010)>start+.1 and value(3011)>-.2)
    position(0,-8);tap();check('God replay clears final gate and markers',value(102)==4 and all(value(m)==0 for m in range(188,198)))
    read_pages('God replay onboarding',groups['god_intro']);position(400,-8);tap()
    for entry,realm,state in (((-7,8),3,176),((7,8),2,154),((0,8),1,106)):
        for m in range(188,201):b.set_mailbox(m,1,idx=player)
        b.set_mailbox(state,1,idx=player);time.sleep(.15)
        position(*entry);tap();check('earlier realm '+str(realm)+' replay clears downstream God',value(102)==realm and all(value(m)==0 for m in range(188,201)))
        if value(140):tap(16384)
        position(300 if realm==3 else 200 if realm==2 else 100,-8);tap()
    check('God native process alive',proc.poll() is None)
