"""Level Forth for God, safe ascent and exact final-door eligibility."""
RESET=': fy-reset-god '+''.join(f'0 {m} write-mailbox ' for m in range(188,201))+';\n'

def definitions(emit,first):
    emit(f': fy-enter-god 195 read-mailbox 0 <> if fy-reset-god then 400 -7 fy-teleport 4 102 write-mailbox 198 read-mailbox 0 = if {first("god_intro")} else 0 then 140 write-mailbox ;\n')
    emit(': fy-god-ready 190 read-mailbox 191 read-mailbox & 192 read-mailbox & 193 read-mailbox & 194 read-mailbox & ;\n')
    emit(': fy-god-history fy-truth-history 178 read-mailbox 1 - 2 * 196 read-mailbox 1 = if 1 else 2 then + 197 write-mailbox ;\n')
    emit(': fy-god-return-card\n')
    for n,c in enumerate('abcdefghijklmnop',1):emit(f'197 read-mailbox {n} = if {first("return_9"+c)} 140 write-mailbox then\n')
    emit(';\n: fy-commit-god 196 write-mailbox 1 195 write-mailbox 0 188 write-mailbox fy-god-history fy-return fy-god-return-card ;\n')
    emit(r'''
: fy-god-safety 102 read-mailbox 4 = if
  INDEXOF_Y_POS read-mailbox 28 >= INDEXOF_Z_POS read-mailbox 4.9 >= & if 1 199 write-mailbox then
  INDEXOF_Z_POS read-mailbox -1 < if
    200 read-mailbox 1 + 200 write-mailbox
    199 read-mailbox 0 <> if
      400 30 fy-teleport 5.35 INDEXOF_Z_POS write-mailbox fy-cut-camera
    else 400 -7 fy-teleport then 0 140 write-mailbox
  then then ;
''')

def ends(first):
    return {'god_intro':'1 198 write-mailbox 0 140 write-mailbox',
            'young_man':'1 190 write-mailbox 0 140 write-mailbox',
            'holy_man':'1 191 write-mailbox 0 140 write-mailbox',
            'poster':'1 192 write-mailbox 0 140 write-mailbox',
            'icon':'1 193 write-mailbox 0 140 write-mailbox',
            'god_question':'1 194 write-mailbox 0 140 write-mailbox',
            'god_affirm':f'{first("god_counsel_being")} 140 write-mailbox',
            'god_deny':f'{first("god_counsel_notbeing")} 140 write-mailbox',
            'god_counsel_being':'1 fy-commit-god','god_counsel_notbeing':'-1 fy-commit-god',
            **{'return_9'+c:'1 188 write-mailbox 0 140 write-mailbox' for c in 'abcdefghijklmnop'}}

SPOTS=[(400,1,28),(397,6,29),(400,13,30),(403,18,31),(397,24,32),(396,32,33),(404,32,34),(400,-9,35)]

def actions(first,histories):
    result={28:f'{first("young_man")} 140 write-mailbox',
            29:f'190 read-mailbox 0 <> if {first("poster")} else {first("god_wait")} then 140 write-mailbox',
            30:f'190 read-mailbox 0 <> if {first("holy_man")} else {first("god_wait")} then 140 write-mailbox',
            31:f'191 read-mailbox 0 <> if {first("icon")} else {first("god_wait")} then 140 write-mailbox',
            32:f'190 read-mailbox 191 read-mailbox & 192 read-mailbox & 193 read-mailbox & if {first("god_question")} else {first("god_locked")} then 140 write-mailbox',
            33:f'fy-god-ready if {first("god_affirm")} else {first("god_locked")} then 140 write-mailbox',
            34:f'fy-god-ready if {first("god_deny")} else {first("god_locked")} then 140 write-mailbox',35:'fy-return'}
    for focus,slug in ((36,'10a'),(37,'10b'),(38,'10c')):
        eligible='0 '+''.join(f'197 read-mailbox {n} = | ' for n,row in enumerate(histories.values(),1) if slug in row['doors'])
        result[focus]=f'195 read-mailbox 0 <> if 188 read-mailbox 0 <> if {eligible} if {focus-35} 189 write-mailbox {first("ending_"+slug)} else {first("final_closed")} then else {first("final_wait")} then 140 write-mailbox then'
    return result

def visuals(emit,actor,histories):
    emit(r'''
  102 read-mailbox 4 = 194 read-mailbox 0 = & 201 write-mailbox
  102 read-mailbox 4 = 190 read-mailbox 0 <> & 194 read-mailbox 0 = & 202 write-mailbox
  201 read-mailbox 242 read-mailbox & 203 write-mailbox
  202 read-mailbox 242 read-mailbox & 204 write-mailbox
  102 read-mailbox 4 = 242 read-mailbox & dup 205 write-mailbox dup 220 write-mailbox 221 write-mailbox
  195 read-mailbox 0 <> 196 read-mailbox 1 = & 212 write-mailbox
''')
    for vis,label,slug in ((214,217,'10a'),(215,218,'10b'),(216,219,'10c')):
        eligible='0 '+''.join(f'197 read-mailbox {n} = | ' for n,row in enumerate(histories.values(),1) if slug in row['doors'])
        emit(f'195 read-mailbox 0 <> 188 read-mailbox 0 <> & {eligible} & {vis} write-mailbox\n{vis} read-mailbox 140 read-mailbox 0 = & {label} write-mailbox\n')
    emit(f'108 read-mailbox 0 = 140 read-mailbox 0 = & if 110 read-mailbox 0.025 * fy-wrap INDEXOF_ROTATION_C {actor("aether_rings")} write-actor-mailbox then\n')
