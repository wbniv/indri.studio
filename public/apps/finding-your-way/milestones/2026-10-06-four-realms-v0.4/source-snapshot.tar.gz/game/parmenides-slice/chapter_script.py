"""Generate level-owned Forth for the four functional realms."""
import god_script
def make_script(ids, content, animated):
    groups=content['groups']
    first=lambda key:groups[key][0]
    actor=lambda name:ids[name]
    out=[r'''
\ Finding Your Way: Love, Reason and Truth, level-owned state; no engine modifications.
: fy-wrap dup 0 < if 1 + then dup 1 >= if 1 - then ;
: fy-sin fy-wrap dup 0.5 > if 0.5 - -1 else 1 then >r
  2 * dup 1 swap - * dup 16 * swap 4 * 5 swap - / r> * ;
: fy-cos 0.25 + fy-sin ;
: fy-key 111 read-mailbox & 0 <> ;
: fy-pressed dup fy-key over 116 read-mailbox & 0 = & swap
  INDEXOF_HARDWARE_JOYSTICK1_RAW_JUSTPRESSED read-mailbox & 0 <> | ;
: fy-stop 0 INDEXOF_INPUT write-mailbox 0 INDEXOF_XSPEED write-mailbox 0 INDEXOF_YSPEED write-mailbox ;
: fy-toggle 101 read-mailbox 0 = if 1 else 0 then 101 write-mailbox ;
: fy-near INDEXOF_Y_POS read-mailbox - dup * swap INDEXOF_X_POS read-mailbox - dup * + 6.25 < ;
''']
    emit=out.append
    emit(f': fy-cut-camera 126 read-mailbox INDEXOF_X_POS {actor("Camera")} write-actor-mailbox\n')
    emit(f'127 read-mailbox 101 read-mailbox 0 = if 3.8 - else 0.6 + then INDEXOF_Y_POS {actor("Camera")} write-actor-mailbox\n')
    emit(f'INDEXOF_Z_POS read-mailbox 101 read-mailbox 0 = if 2.7 else 1.55 then + INDEXOF_Z_POS {actor("Camera")} write-actor-mailbox\n')
    for axis in 'XYZ':emit(f'0 INDEXOF_{axis}SPEED {actor("Camera")} write-actor-mailbox\n')
    emit(r''';
: fy-teleport 127 write-mailbox 126 write-mailbox
  127 read-mailbox INDEXOF_Y_POS write-mailbox 126 read-mailbox INDEXOF_X_POS write-mailbox
  0.15 INDEXOF_Z_POS write-mailbox fy-stop 0 INDEXOF_ZSPEED write-mailbox
  0.25 114 write-mailbox fy-cut-camera ;
: fy-return 0 -3 fy-teleport 0 102 write-mailbox 0 140 write-mailbox ;
''')
    emit(god_script.RESET)
    emit(r''': fy-reset-truth fy-reset-god
  0 170 write-mailbox 0 171 write-mailbox 0 172 write-mailbox 0 173 write-mailbox 0 174 write-mailbox 0 175 write-mailbox 0 176 write-mailbox 0 177 write-mailbox 0 178 write-mailbox 0 179 write-mailbox ;
: fy-enter-love 100 -5 fy-teleport 1 102 write-mailbox
  106 read-mailbox 0 <> if
    0 103 write-mailbox 0 104 write-mailbox 0 105 write-mailbox
    0 106 write-mailbox 0 107 write-mailbox then
  0 150 write-mailbox 0 151 write-mailbox 0 152 write-mailbox
  0 153 write-mailbox 0 157 write-mailbox
  0 154 write-mailbox 0 155 write-mailbox 0 156 write-mailbox
  fy-reset-truth 0 140 write-mailbox ;
: fy-reset-reason 0 150 write-mailbox 0 151 write-mailbox
  0 152 write-mailbox 0 153 write-mailbox 0 157 write-mailbox
  0 154 write-mailbox 0 155 write-mailbox 0 156 write-mailbox ;
: fy-enter-reason 154 read-mailbox 0 <> if fy-reset-reason then
  fy-reset-truth 200 -5 fy-teleport 2 102 write-mailbox 0 140 write-mailbox ;
: fy-love-ready 103 read-mailbox 104 read-mailbox & 105 read-mailbox & ;
: fy-reason-ready 150 read-mailbox 151 read-mailbox & 152 read-mailbox & 153 read-mailbox & ;
: fy-history 107 read-mailbox 1 = if
  155 read-mailbox 1 = if 1 else 2 then
  else 155 read-mailbox 1 = if 3 else 4 then then 156 write-mailbox ;
''')
    emit(': fy-reason-return-card\n')
    for index,slug in enumerate(('5a','5b','5c','5d'),1):
        emit(f'156 read-mailbox {index} = if {first("return_"+slug)} 140 write-mailbox then\n')
    emit(';\n: fy-commit-love 107 write-mailbox 1 106 write-mailbox fy-return\n')
    emit(f'107 read-mailbox 1 = if {first("return_being")} else {first("return_notbeing")} then 140 write-mailbox ;\n')
    emit(': fy-commit-reason 155 write-mailbox 1 154 write-mailbox fy-history fy-return fy-reason-return-card ;\n')
    emit(f': fy-enter-truth 176 read-mailbox 0 <> if fy-reset-truth then fy-reset-god 300 -5 fy-teleport 3 102 write-mailbox 179 read-mailbox 0 = if {first("truth_intro")} else 0 then 140 write-mailbox ;\n')
    emit(': fy-truth-ready 170 read-mailbox 171 read-mailbox & 172 read-mailbox & 173 read-mailbox & 174 read-mailbox & 175 read-mailbox & ;\n')
    emit(': fy-truth-history fy-history 156 read-mailbox 1 - 2 * 177 read-mailbox 1 = if 1 else 2 then + 178 write-mailbox ;\n')
    emit(': fy-truth-return-card\n')
    for index,suffix in enumerate('abcdefgh',1):
        emit(f'178 read-mailbox {index} = if {first("return_7"+suffix)} 140 write-mailbox then\n')
    emit(';\n: fy-commit-truth 177 write-mailbox 1 176 write-mailbox fy-truth-history fy-return fy-truth-return-card ;\n')
    god_script.definitions(emit,first)
    # A single dispatch table handles every page; no fixed page count assumptions.
    ends={'first':'1 103 write-mailbox 0 140 write-mailbox',
          'starlet':'1 104 write-mailbox 0 140 write-mailbox',
          'paper':'1 105 write-mailbox 0 140 write-mailbox',
          'affirm':'1 fy-commit-love','deny':'-1 fy-commit-love',
          'white':f'1 150 write-mailbox {first("grove")} 140 write-mailbox',
          'apparatus_order':f'1 157 write-mailbox {first("apparatus_limit")} 140 write-mailbox',
          'apparatus_limit':'1 152 write-mailbox 0 140 write-mailbox',
          'wild':'1 151 write-mailbox 0 140 write-mailbox',
          'child':'1 153 write-mailbox 0 140 write-mailbox',
          'reason_affirm':f'{first("why_axis")} 140 write-mailbox',
          'why_axis':'1 fy-commit-reason',
          'reason_deny':f'{first("rain_reply")} 140 write-mailbox',
          'rain_reply':'-1 fy-commit-reason',
          'truth_intro':'1 179 write-mailbox 0 140 write-mailbox',
          'prosecutor':'1 170 write-mailbox 0 140 write-mailbox',
          'defence':'1 171 write-mailbox 0 140 write-mailbox',
          'student':'1 172 write-mailbox 0 140 write-mailbox',
          'facts':'1 173 write-mailbox 0 140 write-mailbox',
          'interpretations':'1 174 write-mailbox 0 140 write-mailbox',
          'present':'1 175 write-mailbox 0 140 write-mailbox',
          'truth_affirm':f'{first("truth_counsel_being")} 140 write-mailbox',
          'truth_deny':f'{first("truth_counsel_notbeing")} 140 write-mailbox',
          'truth_counsel_being':'1 fy-commit-truth',
          'truth_counsel_notbeing':'-1 fy-commit-truth'}
    ends.update(god_script.ends(first))
    emit(': fy-advance 140 read-mailbox 141 write-mailbox\n')
    for key,pages in groups.items():
        for i,page in enumerate(pages):
            action=f'{pages[i+1]} 140 write-mailbox' if i<len(pages)-1 else ends.get(key,'0 140 write-mailbox')
            emit(f'141 read-mailbox {page} = if {action} then\n')
    emit(';\n: fy-focus 0 130 write-mailbox\n')
    spots={0:[(0,9,1),(3,3,2),(7,9,3),(-7,9,10),(0,-9,25),(-7,-12,36),(0,-12,37),(7,-12,38)],
           1:[(96,2,4),(104,3,5),(100,7,6),(94,12,7),(106,12,8),(100,-9,9)],
           2:[(196,1,11),(200,3,12),(204,7,13),(200,11,14),(193,14,15),(207,14,16),(200,-9,17)],
           3:[(294,1,18),(306,1,19),(300,6,20),(294,7,21),(306,7,22),(300,11,23),(293,17,24),(307,17,26),(300,-9,27)],4:god_script.SPOTS}
    for realm,points in spots.items():
        emit(f'102 read-mailbox {realm} = if\n')
        for x,y,focus in points:emit(f'{x} {y} fy-near if {focus} 130 write-mailbox then\n')
        emit('then\n')
    emit(';\n: fy-interact 140 read-mailbox 0 <> if fy-advance else\n')
    actions={1:'fy-enter-love',
             2:f'195 read-mailbox 0 <> if fy-god-return-card else 176 read-mailbox 0 <> if fy-truth-return-card else 154 read-mailbox 0 <> if fy-reason-return-card else 106 read-mailbox 0 = if {first("intro")} else 107 read-mailbox 1 = if {first("return_being")} else {first("return_notbeing")} then then 140 write-mailbox then then then',
             3:f'106 read-mailbox 0 <> if fy-enter-reason else {first("reason_unavailable")} 140 write-mailbox then',
             4:f'{first("first")} 140 write-mailbox',5:f'{first("starlet")} 140 write-mailbox',
             6:f'{first("paper")} 140 write-mailbox',
             7:f'fy-love-ready if {first("affirm")} else {first("locked")} then 140 write-mailbox',
             8:f'fy-love-ready if {first("deny")} else {first("locked")} then 140 write-mailbox',
             9:'fy-return',10:f'154 read-mailbox 0 <> if fy-enter-truth else {first("truth_unavailable")} 140 write-mailbox then',
             11:f'{first("white")} 140 write-mailbox',
             12:f'157 read-mailbox 0 = if {first("apparatus_order")} else {first("apparatus_limit")} then 140 write-mailbox',
             13:f'150 read-mailbox 0 <> if {first("wild")} else {first("reason_wait")} then 140 write-mailbox',
             14:f'151 read-mailbox 152 read-mailbox & if {first("child")} else {first("reason_wait")} then 140 write-mailbox',
             15:f'fy-reason-ready if {first("reason_affirm")} else {first("reason_locked")} then 140 write-mailbox',
             16:f'fy-reason-ready if {first("reason_deny")} else {first("reason_locked")} then 140 write-mailbox',
             17:'fy-return',
             18:f'{first("prosecutor")} 140 write-mailbox',
             19:f'170 read-mailbox 0 <> if {first("defence")} else {first("truth_wait")} then 140 write-mailbox',
             20:f'170 read-mailbox 171 read-mailbox & if {first("student")} else {first("truth_wait")} then 140 write-mailbox',
             21:f'172 read-mailbox 0 <> if {first("facts")} else {first("truth_wait")} then 140 write-mailbox',
             22:f'172 read-mailbox 0 <> if {first("interpretations")} else {first("truth_wait")} then 140 write-mailbox',
             23:f'173 read-mailbox 174 read-mailbox & if {first("present")} else {first("truth_locked")} then 140 write-mailbox',
             24:f'fy-truth-ready if {first("truth_affirm")} else {first("truth_locked")} then 140 write-mailbox',
             26:f'fy-truth-ready if {first("truth_deny")} else {first("truth_locked")} then 140 write-mailbox',
             25:f'176 read-mailbox 0 <> if fy-enter-god else {first("god_unavailable")} 140 write-mailbox then',
             27:'fy-return'}
    actions.update(god_script.actions(first,content['god_histories']))
    for focus,action in actions.items():emit(f'130 read-mailbox {focus} = if {action} then\n')
    emit(f'then ;\n: fy-init 100 read-mailbox 0 = if 1 100 write-mailbox 0.25 114 write-mailbox {first("intro")} 140 write-mailbox then ;\n')
    emit(r'''
: fy-input INDEXOF_HARDWARE_JOYSTICK1_RAW read-mailbox 111 write-mailbox
  INDEXOF_DELTA_TIME read-mailbox 0 max 0.05 min 115 write-mailbox 0 118 write-mailbox
  JOYSTICK_BUTTON_A fy-key if
    112 read-mailbox 115 read-mailbox + 112 write-mailbox
    112 read-mailbox 0.65 >= 113 read-mailbox 0 = & if fy-toggle 1 113 write-mailbox then
  else
    112 read-mailbox 0 > 113 read-mailbox 0 = & if 1 118 write-mailbox then
    INDEXOF_HARDWARE_JOYSTICK1_RAW_JUSTPRESSED read-mailbox JOYSTICK_BUTTON_A & 0 <>
    112 read-mailbox 0 = & if 1 118 write-mailbox then
    0 112 write-mailbox 0 113 write-mailbox
  then
  JOYSTICK_BUTTON_B fy-pressed if fy-toggle then
''')
    emit(f'JOYSTICK_BUTTON_C fy-pressed if 140 read-mailbox 0 = if {first("journal")} else 0 then 140 write-mailbox then\n')
    emit(r'''
  JOYSTICK_BUTTON_D fy-pressed if 108 read-mailbox 0 = if 1 else 0 then 108 write-mailbox then
  \ Remote cancellation: Left closes a sheet, without completing or committing it.
  140 read-mailbox 0 <> JOYSTICK_BUTTON_LEFT fy-pressed & if 0 140 write-mailbox 0 118 write-mailbox then
  fy-focus 118 read-mailbox 0 <> if fy-interact then
  140 read-mailbox 0 <> if fy-stop else
    JOYSTICK_BUTTON_LEFT fy-key if 1 else 0 then JOYSTICK_BUTTON_RIGHT fy-key if 1 else 0 then -
    115 read-mailbox * 6 / 114 read-mailbox + fy-wrap 114 write-mailbox
    114 read-mailbox INDEXOF_ROTATION_C write-mailbox
    111 read-mailbox 6144 & INDEXOF_INPUT write-mailbox
  then
  111 read-mailbox 116 write-mailbox 110 read-mailbox 115 read-mailbox + 110 write-mailbox ;
: fy-camera 114 read-mailbox fy-cos 120 write-mailbox 114 read-mailbox fy-sin 121 write-mailbox
  101 read-mailbox 0 = if -3.8 122 write-mailbox 2.7 123 write-mailbox 1.2 124 write-mailbox
  else 0.6 122 write-mailbox 1.55 123 write-mailbox 1.55 124 write-mailbox then
''')
    for axis,mb in [('X',120),('Y',121)]:
        emit(f'{mb} read-mailbox 122 read-mailbox * INDEXOF_{axis}_POS {actor("FollowShot")} write-actor-mailbox\n')
        emit(f'{mb} read-mailbox 3 * INDEXOF_{axis}_POS {actor("LookAt")} write-actor-mailbox\n')
    emit(f'123 read-mailbox INDEXOF_Z_POS {actor("FollowShot")} write-actor-mailbox\n124 read-mailbox INDEXOF_Z_POS {actor("LookAt")} write-actor-mailbox\n{actor("FollowShot")} INDEXOF_CAMSHOT write-mailbox ;\n')
    emit(': fy-visual 195 read-mailbox 0 = 196 read-mailbox 1 = | 207 write-mailbox\n101 read-mailbox 0 = 250 write-mailbox\n103 read-mailbox 0 = 251 write-mailbox\n104 read-mailbox 0 = 252 write-mailbox\n')
    for i in range(4):
        emit(f'106 read-mailbox 0 = 207 read-mailbox & {230+i} write-mailbox\n106 read-mailbox 0 <> 107 read-mailbox 1 = & 207 read-mailbox & {234+i} write-mailbox\n')
    emit(r'''
  107 read-mailbox -1 <> 207 read-mailbox & 238 write-mailbox 107 read-mailbox -1 = 207 read-mailbox & 239 write-mailbox
  154 read-mailbox 0 <> 207 read-mailbox & 226 write-mailbox
  154 read-mailbox 0 = 155 read-mailbox 1 = | 207 read-mailbox & 228 write-mailbox
  154 read-mailbox 0 <> 155 read-mailbox 1 = & 207 read-mailbox & 229 write-mailbox
  176 read-mailbox 0 = 177 read-mailbox 1 = | 207 read-mailbox & 206 write-mailbox
  176 read-mailbox 0 <> 177 read-mailbox 1 = & 155 read-mailbox 1 = & 207 read-mailbox & 210 write-mailbox
  176 read-mailbox 0 <> 177 read-mailbox 1 = & 155 read-mailbox -1 = & 207 read-mailbox & 211 write-mailbox
  176 read-mailbox 0 <> 207 read-mailbox & 208 write-mailbox
  140 read-mailbox 0 = 176 read-mailbox 0 <> & 207 read-mailbox & 209 write-mailbox
  102 read-mailbox 3 = 172 read-mailbox 0 = & 180 write-mailbox
  102 read-mailbox 3 = 172 read-mailbox 0 = & 181 write-mailbox
  102 read-mailbox 3 = 170 read-mailbox 0 <> & 171 read-mailbox 0 <> & 182 write-mailbox
  102 read-mailbox 3 = 175 read-mailbox 0 <> & 187 write-mailbox
  140 read-mailbox 0 = 207 read-mailbox & 242 write-mailbox
  140 read-mailbox 0 = 154 read-mailbox 0 <> & 207 read-mailbox & 241 write-mailbox
  102 read-mailbox 2 = 150 read-mailbox 0 = & 160 write-mailbox
  102 read-mailbox 2 = 150 read-mailbox 0 <> & 153 read-mailbox 0 = & 161 write-mailbox
  102 read-mailbox 2 = 151 read-mailbox 0 <> & 152 read-mailbox 0 <> & 162 write-mailbox
  102 read-mailbox 2 = 150 read-mailbox 0 <> & 163 write-mailbox
  102 read-mailbox 2 = 157 read-mailbox 0 <> & 164 write-mailbox
  160 read-mailbox 242 read-mailbox & 243 write-mailbox
  161 read-mailbox 242 read-mailbox & 244 write-mailbox
  162 read-mailbox 242 read-mailbox & 245 write-mailbox
  251 read-mailbox 242 read-mailbox & 247 write-mailbox
  252 read-mailbox 242 read-mailbox & 248 write-mailbox
  180 read-mailbox 242 read-mailbox & 185 write-mailbox
  181 read-mailbox 242 read-mailbox & 186 write-mailbox
  182 read-mailbox 242 read-mailbox & 184 write-mailbox
''')
    god_script.visuals(emit,actor,content['god_histories'])
    for name in animated:
        emit(f'108 read-mailbox 0 = if 110 read-mailbox 0.25 * fy-sin 0.004 * 1 + else 1 then INDEXOF_Z_SCALE {actor(name)} write-actor-mailbox\n')
    for card in content['cards']:
        idx=actor('card_%02d'%card['id'])
        emit(f'140 read-mailbox {card["id"]} = {260+card["id"]} write-mailbox\n')
        emit(f'{260+card["id"]} read-mailbox if\n')
        for axis,mb in [('X',120),('Y',121)]:
            emit(f'INDEXOF_{axis}_POS {actor("Camera")} read-actor-mailbox {mb} read-mailbox 3 * + INDEXOF_{axis}_POS {idx} write-actor-mailbox\n')
        emit(f'INDEXOF_Z_POS {actor("Camera")} read-actor-mailbox 101 read-mailbox 0 = if 0.7 - then INDEXOF_Z_POS {idx} write-actor-mailbox\n')
        emit(f'114 read-mailbox 0.25 - INDEXOF_ROTATION_C {idx} write-actor-mailbox\n')
        emit(f'else {400 if card["atlas"]=="god" else 0} INDEXOF_X_POS {idx} write-actor-mailbox -3 INDEXOF_Y_POS {idx} write-actor-mailbox 2 INDEXOF_Z_POS {idx} write-actor-mailbox then\n')
    emit(';\nfy-init fy-input fy-god-safety fy-camera fy-visual\n')
    return ''.join(out)
