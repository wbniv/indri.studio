# Finding Your Way World Foundry Adventure Plan

**Status:** Temple and all four realms functional native prototypes implemented and verified. The God milestone includes Will's authorized engine texture-address fix and removal of the atlas workaround; the tested APK is installed on Chromecast 1. The chapter source checkpoint and archive are being recorded. Ending scenes follow this milestone. Phone acceptance and production art remain open. **Updated:** 2026-10-06.

Build *Parmenides: Finding Your Way* as a single-player 3D adventure in World Foundry: a walkable temple, four explorable realms, physical encounters with competing accounts of each realm, and choices enacted through objects and doorways. Start with a complete Temple → Love → Temple vertical slice before producing the other realms. The slice must demonstrate enjoyable exploration, both camera modes, a philosophical commitment, and a visible consequence in the temple.

**Will's camera requirement:** third-person follow by default, switchable to first-person **free movement**, using World Foundry's existing support. Both modes use the same player, world, interactions and progress. Discrete *Myst*-style viewpoints from the earlier research are superseded.

**Will's release order:** Phase 1 delivers the complete **phone adventure**. Phase 2 adapts layouts and controls for **Chromecast, web, desktop and tablet**. Phone playthroughs are the acceptance target for the first slice and release; desktop development tooling is not a substitute for phone verification.

**Will's production order, 2026-10-05:** build the remaining realms as functional grayboxes first, starting with Reason. Defer art passes, final modeling/texture refinement, decorative animation polish and voice samples until all realms are built and functional. Earlier art-dependent stage gates below are superseded for realm implementation; functional readability, interaction and branching checks continue as each realm is added. The played Temple/Love APK is preserved as a [milestone archive](../../game/milestones/README.md).

**Will's review loop:** after each completed iteration, install its frozen APK on **Chromecast 1** (`chromecast-test-01`) for Will to play/review, using the shared device coordinator. Native install/check tasks now default to that device. Archive the tested APK and its source/evidence, and commit after each milestone. These development reviews continue while the complete phone release gate remains open.

### God milestone engine scope — Will, 2026-10-05

Will explicitly authorized fixing the engine as part of this task and removing the texture workaround. The runtime's legacy texture-page masks wrap atlas origins at 1,024 pixels, causing some signs/cards to sample unrelated text even though their source bitmaps are correct. This is a functional text-delivery defect, so it belongs in this milestone before the APK is archived.

- [x] Carry full atlas coordinates through the modern engine renderer; retain the legacy backend's address convention where needed. Validate against the actual texture dimensions, including permanent and adjacent-room textures.
- [x] Remove custom shared-atlas packing and per-cell Blender UVs from the chapter; restore individual card/sign textures and ordinary exporter/textile packing.
- [x] Add meaningful rendering regression coverage at and beyond 1,024 pixels on both axes, including flat/Gouraud textured primitives and permanent/room assets. Check actual text/sign pixels rather than treating visibility mailboxes as visual proof.
- [x] Rebuild desktop and both Android native ABIs. Record the changed engine source commit and native-library hashes in the chapter receipt; preserve them in the pending archive. The earlier unchanged-runtime claim applies only to historical milestones.
- [x] Rerun all four-realm source, asset, dialogue and route checks, including both viewpoints, hill ascent/fall recovery and all sixteen exact final gates.
- [x] Install the newly frozen APK on Chromecast 1 through the coordinator; inspect actual sign/dialogue captures and Home/resume.
- [x] Commit the tested engine fix separately, with production primitive regression coverage.
- [ ] Commit the verified chapter source checkpoint, archive that exact tested build and commit the milestone archive.

The temporary atlas workaround is not the final implementation. Keep the already functional realm scripts and the separate Player box-collision correction; that collision fix addresses slope-versus-slope behavior, not texture addressing. Do not start final art passes or ending scenes until this milestone's verification and archive are complete.

**Verification: PASS.** Engine checkpoint `1aecfbe5f3aeb0fc394522c4c5d35f126de551df` passes 80 production flat/Gouraud primitive cases at atlas origins through 1,536 on both axes. Running the same test against the original material implementation fails with a truncated atlas address. Desktop and both Android ABI builds pass. The rebuilt chapter passes **1,860 native runtime, 337 source and 1,369 exported bitmap/UV checks**; 631 actual dialogue sequences cover all 201 cards. Both viewpoints pass full ascent, entry and upper-landing fall recovery, all sixteen histories and all 33 final-door edges. Chromecast 1 job `J-1d65f6420934` passes install, launch, remote input and Home/resume; inspected captures show the intended LOVE/THE GODDESS signs and label suppression during dialogue. Archive creation follows the chapter source checkpoint.

The [native prototype](../../game/parmenides-slice/README.md) now implements Temple → Love → changed Temple → Reason → changed Temple → Truth → changed Temple → God → final Temple using original Blender models, the direct WF exporter and level Forth. The archived Temple/Love iteration passed launch, remote Select and Home/resume checks on both Chromecasts; subsequent iterations target Chromecast 1. This early TV preview does not complete the phone release gate or change the release order. See the [God implementation report](../diagnostics/parmenides/god/implementation.md) for current evidence and the [first implementation report](../diagnostics/parmenides/implementation.md) for the played baseline. Proposed puzzles and encounter choreography below are adaptations; the source establishes the setting, arguments, branching history and endings.

### First playthrough feedback — Will, 2026-10-05

Will has played through the installed Temple/Love prototype. The Reason iteration includes the first two functional readability corrections; the face issue remains open for investigation/art work:

- [x] **Street → Temple sign:** moved the readable sign face to the Love street side and rotated it inward; the Reason return sign uses the same orientation. Will's next installed playthrough should confirm the approach in both camera modes.
- [x] **Labels over dialogue/inspection overlays:** world sign labels now share modal visibility suppression, including separate Reason-character labels. Native behavioral checks cover suppression/restoration in both camera modes. Confirm visual readability during Will's next playthrough and the eventual phone acceptance.
- [ ] **Character face rendering investigation:** Will reports something visually wrong when looking at faces, possibly normals or culling; the cause is unconfirmed. Capture close views of the traveler, goddess and both Love speakers from several angles. Inspect face/head/hair geometry for inconsistent winding, inward normals, missing or degenerate triangles and overlapping surfaces, then compare Blender with the exported WF mesh and native rendering. Check front-face convention and backface culling across export before changing materials or making geometry double-sided. Verify the diagnosed correction on both Chromecasts and in both camera modes. If evidence points to an engine defect, prepare the smallest concrete proposal and obtain Will's explicit permission before engine edits.

Recheck the readability corrections on the installed TV preview and eventual baseline phone. Keep the face investigation recorded without making final art a dependency of remaining realm functionality.

### Reason-iteration review — Will, 2026-10-05

- [x] **Love departure consistency:** First Love and the starlet now both withdraw after their completed accounts, with their labels hidden. These are immediate provisional visibility changes; animated walking/door actions belong to the later art pass.
- [x] **Reason entry explanation:** completing the two accounts and newspaper unlocks Love's thresholds, but does not commit. The gate now explicitly instructs Will to choose BEING or NOTBEING and confirm with Select; the TEMPLE return portal leaves without choosing.
- [x] **Unfinished visit retention:** returning to Temple before choosing preserves Love's encounter progress on re-entry, as it does for unfinished Reason. Replaying completed Love starts a new chain and clears its prior commitment and downstream Reason progress.
- [x] **Source-content audit:** independently compare complete retained accounts with their intended source pages, and check shared history aliases for identical spoken prose.
- [x] **Native dialogue delivery audit:** recorded 107 actual dialogue sequences covering all 61 delivered cards, every current speaker/object, gates, conclusions and history-dependent goddess responses. All 349 runtime checks and 77 independent source checks pass. Repeat this as each realm is implemented.

## Existing research and decisions

The [asset classification](../investigations/3d-game-port-asset-classification.md) supplies the environments, characters, props and tonal brief. Its [planning record](3d-game-port-asset-classification.md) records subsequent decisions: realm-themed fractal tapestries, the Platonic *Timaeus* aether dome, full goddess voice acting, and the operating-room coda. The [World Foundry compatibility contract](../investigations/world-foundry-compatibility.md) now connects those assets to the native pipeline.

Retain the stylized low-poly, hand-painted, late-1990s visual direction and the source's collision of sacred and everyday imagery. Create original archetypes for the starlet, candy exhibit, newspaper prose, poster and icon, following the existing replacement briefs. Use a warm, authoritative, sardonic-capable goddess performance; the prior named casting reference describes a performance register, not a request to imitate a person's voice.

The earlier estimate of 144 text screens is replaced by **144 source beats to account for**. Spoken encounters, spatial events, inspectable objects and world changes deliver them. Full arguments can remain accessible through a journal, but progression depends on activity in the world. The visible third-person player requires a new protagonist model and animation set; the old no-protagonist-mesh budget no longer applies.

There are **nine scene families** in this proposal: temple, four realms, three endings and surgery. The opening occurs in the temple. This resolves the old approximate ten-locale count without making an extra opening environment. Logical temple histories remain distinct even where geometry and lighting can be shared.

## Art direction and Blender production

The [art bible](../art-bible.md) and [complete visual reference gallery](../art-bible/references.html) now define the directed palette, shape language, characters, environments, props, surfaces, motion and phone presentation. Use the bible for visual consistency and this plan for production sequencing and gameplay acceptance.

**Established direction:** original stylized low-poly forms, hand-painted diffuse textures, readable late-1990s silhouettes, and the sacred/everyday collage of the 2005 work. The old *Zelda 64* reference guides proportions and readability, not copied designs. The phone release uses that direction; it does not need photorealistic materials to convey the arguments.

**Codex will model every asset in Blender, as requested by Will.** Create the player, principal and background actors, buildings, terrain, trees, furniture, props, doors and ending/coda geometry as original Blender assets. Blender is also canonical for rigs, animation, UVs, materials and scene attributes. Reuse our own mesh/rig kits and variants; do not make purchased model packs, downloaded characters or generated bitmap mockups dependencies of the finished game. Build reproducible Blender scripts and retain editable `.blend` masters alongside export assets.

| Element | Direction to establish in the Blender style set |
|---|---|
| Player | Distinct small-scale silhouette, simple layered clothing and readable feet/hands; neutral identity rather than a licensed hero |
| Goddess | Golden wing silhouette, deliberate posture and expressive face/gestures; warm authority with room for sarcasm |
| Architecture | Temple stone and mosaic contrasted with stylized street façades and courtroom timber; exaggerated landmarks readable on a phone |
| Palette | Temple: weathered stone/gold; Love: muted red/rose; Reason: pale ivory shifting to forest green; Truth: ochre/wood; God: deep green/violet; endings: light, hybrid and void |
| Texture | Painted value/color shapes, restrained surface detail, reusable UV sheets; essential text goes into a readable inspection sheet |
| Lighting and effects | Clear focal contrast and silhouettes; baked lighting/value where appropriate, restrained emissive portals; readable source-specific transformations |
| Animation | Pose-led acting and distinct gestures; common movement base with character-specific performance clips |

**Art approval gate:** model and export one player, the goddess, a temple corner and a Love street corner. Capture both perspectives on the baseline phone in ordinary and reduced-motion presentation. Approve silhouette, palette, texture density, materials and readability before producing the full roster. The schematic illustrations in this plan are layout proposals; actual Blender/World Foundry captures replace them as production evidence.

### Subtle animation and motion review

Review **every setting, scene, character, prop, material/effect and interface element** before final asset production. Record whether it benefits from ambient motion, character performance, an interaction response, a story-driven change, or deliberate stillness. Motion should make the place feel inhabited, direct attention gently and reveal cause and effect. The suggestions below are adaptation proposals, not extra events asserted by the source.

| Setting / assets | Subtle motion opportunities | Constraints and purpose |
|---|---|---|
| Temple / architecture / goddess | Gentle tapestry-edge movement; restrained portal shimmer; goddess breathing, gaze, small wing settling and weight shifts; a brief dust fall or settling detail when the temple changes | Stone and pillars remain stable. Keep the next portal readable; show return-state changes once, then settle into the new state |
| Love / street / bench / NPCs | Small posture changes, glances and hand gestures; sparse background walking; restrained clothing or sign movement; newspaper-sheet lift and machine-handle response | Let the crowd dispersal and door slam remain distinct authored beats. Keep printed evidence still during inspection |
| Reason / ordered plane / apparatus / selves / grove | Apparatus parts ease into alignment when operated; contrasting controlled and relaxed idle poses for the two selves; mild leaf/branch movement after the root transformation | Preserve the ordered plane's deliberate stillness. Roots grow for the story beat, then settle; background sway should not obscure traversal |
| Truth / courtroom / advocates / gallery / exhibits | Advocates breathe and gesture; judge shifts gaze; a few asynchronous gallery posture changes; verdict token settles and plinth responds when placed | No constant crowd fidgeting. Exhibits stop moving during inspection; placement feedback confirms an action without suggesting a correct philosophy |
| God / path / trees / guides / shrine | Low-amplitude canopy and grass movement; occasional distant silhouettes; guide gaze and stance adjustments; restrained shrine cloth movement | No persistent camera shake, forced head bob or swaying essential text. Threat cues retain captions and readable static alternatives |
| Being / Both / NotBeing endings | Slow, authored threshold/light transitions; sparse face or breathing motion where an actor is present; brief response to the chosen door | Preserve intentional quiet and emptiness. Decorative animation must not change door eligibility or extend completion unnecessarily |
| Surgery / shared surgeons / equipment | Small breathing, lean and hand repositioning; sparse instrument movement tied to the authored scene | Preserve the upward patient composition and coda timing. Avoid rocking the patient's camera or adding distracting repeated gestures |
| Shared props / doors / clothing / UI | Door-handle press and hinge settling; a held object settling into its socket; limited cloth secondary motion; short focus/interaction feedback | Static props need no compulsory loop. Essential text, touch targets and layout stay stable; animation never serves as the only feedback |

For each asset-manifest entry, record **motion purpose, trigger, loop/one-shot, amplitude and timing, Blender source/action, native export representation, visible instance count, reduced-motion alternative and measured phone cost**. Reuse compatible actor clips; stagger idle starts so crowds do not move in unison. Prefer simple baked clips or supported object transforms to unproven cloth simulation, skeletal features or procedural shaders. Prove these representations through the WF Blender exporter in Stage 0. Cull or pause offscreen decorative work and lower background update frequency when profiling supports it; keep gameplay interactions responsive.

**Phone motion budget:** first demonstrate one NPC idle, one interaction response and one environmental loop in the Temple/Love slice. Add further layers only after measuring frame time, draw calls, animation memory, battery/thermal behavior and attention on the baseline phone. Use low amplitude and long, varied pauses; avoid filling every surface with constant motion. Decorative motion must not push the release below its existing performance target or interfere with either camera mode, subtitles, touch controls or evidence readability.

**Reduced motion:** provide a saved setting that stops decorative sway, pulses and particles and replaces large transformation/camera effects with a stable final state or short fade. Preserve necessary action feedback, philosophical choices, dialogue, state transitions and completion when clips are skipped. No progress flag depends on a decorative animation finishing. Review ordinary and reduced-motion captures from both camera perspectives, including inspecting evidence while nearby actors and scenery remain active.

### Provisional phone actor model budget

These are proposed working limits, not measured World Foundry limits. Count rendered triangles, visible instances and runtime materials after export. Keep high-detail authoring masters separate from the phone meshes.

| Actor category | Target triangles per visible instance | Texture starting point | Production notes |
|---|---|---|---|
| Player | 3,000–5,000 | One 512² diffuse sheet | One visible protagonist; idle/walk/run/interact/commit set; hide obstructing geometry in first person |
| Goddess and principal NPC | 3,000–5,000 | One 512² sheet; second only when justified | Goddess wings included in the cap; readable face/gesture work gets priority |
| Crowd and courtroom gallery | 500–1,500 | Shared 256² sheets/atlas | One body/rig family, approximately four outfit variants |
| Masked surgeon | 1,500–3,000 | Shared 256² or 512² sheet | Three to five instances of one model/rig with mask/scrub variants |
| Ending visage | 2,000–4,000 | One 512² sheet | Close-view budget; no crowd visible concurrently |

Start with at most **three visible principals including the player, plus eight background actors** in ordinary gameplay. The high end is 27,000 actor triangles; use **30,000 simultaneous actor triangles** as the initial scene budget, including accessories. This is a concurrent workload limit, not a cap on the number of unique characters in the adventure. Large environmental/VFX costs can require lower actor counts. Surgery uses at most five shared surgeon instances and a fixed patient view.

Start with one or two runtime materials per actor and approximately 20 bones for a principal Blender rig, while proving the actual animation export representation in Stage 0. A 20-bone authoring rig does not establish runtime skeletal-import support. Backgrounds share animation clips and update only as needed; test total skinning/deformation, animation storage, script time, texture atlas use and draw calls on the phone before accepting these limits.

Working roster: **15 model designs**—player, goddess, First Love, starlet, White-Clad Self, Wild Self, prosecutor, analyst, judge, old lady, young man, old man, horror visage, surgeon and a shared crowd/gallery body. The Old Woman is voice-only. The two selves, ambient figures and surgeons reuse compatible body/rig structures where sensible. This is a production inventory proposal; do not equate fifteen designs with fifteen unique skeletons or fifteen concurrent actors. Prop and environment meshes are budgeted separately after the first phone export.

There is no external modeling purchase budget in this plan: Codex authors the models in Blender. There is also no verified dollar estimate for the whole project. Track modeling iterations, animation/texture effort, export fixes and device performance during the style set and slice; use those measurements to estimate the remaining production work. Existing full voice-performance ambitions remain a separate production-cost decision.

## Diagrams and mockups

Open the [interactive mockup gallery](world-foundry-adventure/mockups.html) to browse scenes, exercise the proposed Love encounter sequence, and compare the final gate for all sixteen combinations of realm choices. The gallery is a design aid; it does not simulate walking, physics, the camera controller or World Foundry rendering. Its scene images are original illustrated layout studies, not engine screenshots.

![World route through the four realms, temple returns and final endings](world-foundry-adventure/world-route.png)

The rows show the sequential route; each realm returns to the same temple. The final row contains alternative endings, not a sequence of all three. [Editable SVG](world-foundry-adventure/world-route.svg).

```mermaid
flowchart TD
    I["intro.md → intro5.md"] --> T0[Temple opening] --> L[Love street]
    L --> T1[Temple: 2 return histories]
    T1 --> R[Reason plane and grove]
    R --> T2[Temple: 4 return histories]
    T2 --> Q[Truth courtroom]
    Q --> T3[Temple: 8 return histories]
    T3 --> G[God hill ascent]
    G --> T4[Temple: 16 final histories]
    T4 -->|Only source gate 9a| B[Being: 10a]
    T4 --> H[Both: 10b]
    T4 --> N[NotBeing: 10c]
    H --> C[Surgery coda: 101b]
```

### Temple layout and return state

![Temple layout with walkable floor, four portals, pillars and goddess](world-foundry-adventure/temple.png)

![The same temple geometry with an illustrative restored state](world-foundry-adventure/temple-restored.png)

Keep the hub compact enough that the player can see its four pillars and understand the next destination. Portals activate in the original Love → Reason → Truth → God order. The other portals can be inspected while closed. After a realm, frame the changed feature on entry, then restore free control so the player can approach it. Use one geometry kit and a source-derived state manifest for tapestries, windows, floor, walls, dome, goddess delivery and door availability. The restored drawing illustrates the direction of an affirming history; it does not replace the thirty authored return and final-gate beats with a bright/dark toggle.

### Love street and physical commitment

![Love street layout with two exit doors, bench encounter and newspaper evidence](world-foundry-adventure/love.png)

The crowd dispersal and door slam establish loss through action. The bench encounter introduces the opposing account. Both exits remain visible across the street, giving the player a destination to approach after inspecting the newspaper. Doorway focus displays the philosophical meaning of entry; crossing requires a deliberate interaction, preventing an accidental vote from ordinary walking.

![The Love street at eye level in the alternate first-person mode](world-foundry-adventure/love-first-person.png)

The first-person composition shows the same bench, newspaper machine and exits. Switching perspective changes the view, not the scene or the commitment rules. The elevated drawing above exposes layout; this eye-level study shows how landmarks and interaction prompts read during first-person play.

### Reason as a changing space

![Reason layout contrasting pale ordered ground and a living grove](world-foundry-adventure/reason.png)

Use the same playable space before and after roots and foliage transform it. A small ordering apparatus and a route through the grove make the rival accounts tangible. This is proposed encounter design: the apparatus can succeed within its limits, and the grove can be traversed without proving either philosophy objectively correct. The player chooses the interpretation at the exit.

### Truth through evidence and testimony

![Courtroom with two advocates, exhibits, gallery seating and a verdict position](world-foundry-adventure/truth.png)

Make the courtroom accessible on foot. The player approaches exhibits, hears the prosecutor and analyst, and carries a verdict token to one of two plinths. The token is a temporary interaction object, not a currency or a score. Evidence reveals implications of each position; a placement prompt states what the verdict means before committing it.

### God through an ascent

![Wooded hill with a switchback route, conversational landings and summit shrine](world-foundry-adventure/god.png)

Create a walkable climb with broad conversational landings, two guides and a summit shrine. Threat beyond the path is expressed through silhouettes, sound and movement in the trees. The ascent tests attention and navigation without making a difficult jump decide a philosophical outcome. The icon at the summit is newly painted according to the existing art brief.

### Final thresholds

![Three final doors with Being conditionally available, Both and NotBeing available](world-foundry-adventure/endings.png)

The source permits Being only through `9a`; all other final gates offer Both and NotBeing. Four affirmations make Being available, but never force the player to take it. Both leads to the operating-room coda; Being and NotBeing do not. The coda retains the established fixed upward patient view, with three to five masked surgeons and the line “Doctor… he's back.” That authored shot is a cinematic exception to the ordinary perspective toggle.

## Player experience and controls

The ordinary loop is **explore → encounter both accounts → inspect or manipulate evidence → make a physical commitment → see the temple change**. Target a compact adventure with meaningful revisits inside each realm, rather than long travel between conversations. There is no required combat system in this plan; movement, observation, interaction, environmental transformations and philosophical choices supply the play.

![Adventure interaction loop](world-foundry-adventure/interaction-loop.png)

[Editable SVG](world-foundry-adventure/interaction-loop.svg).

Phase 1 maps the action names below to touch controls on the selected phone runtime. Phase 2 reuses that vocabulary for other platform profiles. Bind actual buttons against the selected World Foundry profile during the slice; do not publish invented existing bindings as engine facts.

| Action | Behavior in either perspective |
|---|---|
| Move and look | Continuous movement; the view follows or occupies the same player |
| Interact | Talk, inspect, operate, pick up or place the highlighted nearby target |
| Switch perspective | Third-person ↔ first-person; preserve position, facing and encounter state |
| Recenter | Restore useful framing without moving the player |
| Journal | Recall arguments, inspected evidence and committed realm outcomes |
| Pause | Settings, subtitles, controls, resume and restart |

**Camera contract.** Follow camera is the initial view. The perspective toggle does not teleport, change collisions, complete an encounter or reopen a committed choice. Hide obstructing player geometry in first person. Use the same interaction target arbitration in both modes: nearby eligible object, unobstructed approach/view and a stable focus prompt. A cinematic or inspection view temporarily owns framing and returns to the player's selected perspective on exit. Remember that preference across transitions and saves. Test camera clipping at door frames, pillars, benches, courtroom furniture and forest roots.

```mermaid
stateDiagram-v2
    [*] --> ThirdPerson
    ThirdPerson --> FirstPerson: Switch perspective
    FirstPerson --> ThirdPerson: Switch perspective
    ThirdPerson --> AuthoredShot: Encounter or inspection
    FirstPerson --> AuthoredShot: Encounter or inspection
    AuthoredShot --> PreferredView: End or skip sequence
    PreferredView --> ThirdPerson: Preference is third person
    PreferredView --> FirstPerson: Preference is first person
```

NPC delivery uses voice and subtitles, short natural pauses and optional follow-up questions. Keep the player oriented with gaze, gestures, local sound and readable landmarks. Long source exposition becomes a sequence of situated beats instead of a wall of text. Accessibility requirements include adjustable subtitle size, speaker names, captions for essential sounds, reduced flashing and motion, a persistent inspection transcript, and no mandatory timed response. In Reason and God, provide forgiving traversal and respawn without changing the chosen philosophy.

## Phase 1 phone layout and input

![Phone gameplay with touch movement, look area, interaction and perspective controls](world-foundry-adventure/phone-gameplay.png)

![Phone evidence inspection with readable text and a clear return action](world-foundry-adventure/phone-inspection.png)

**Proposed baseline:** landscape gameplay with two-thumb free movement. Inspection/journal sheets have their own readable layout. Portrait gameplay is not required for the first release; validate this proposed orientation policy during the slice. Record the actual target phone, OS, aspect ratio and World Foundry build route in Stage 0. Do not substitute an Android TV test for a phone or promise an unverified phone OS build.

| Touch region | Proposed behavior | Acceptance check |
|---|---|---|
| Lower left movement pad | Drag to move, with a visible neutral position | Move diagonally while looking; release/cancel never leaves movement held |
| Unoccupied right viewport | Drag to look; sensitivity and invert-Y settings | A look drag does not trigger an interaction |
| Lower right Interact | Contextual action and target name; one action per press | Reachable while moving; rejects stale/distant focus |
| Perspective button | Toggle third-person/first-person free movement | Separate from Interact; preference survives pause and return |
| Pause and Journal | Stable buttons inside device safe areas | Open with one tap; block gameplay input below a sheet |
| Dialogue/evidence sheet | Readable text, scroll/replay, clear Continue/Close | Essential prose is available beyond a tiny world texture |

Reserve thumb zones and safe areas before placing subtitles. Start with a proposed minimum 48 logical-unit tap area and generous spacing, then validate on the actual phone. Distinguish logical UI units from render pixels. Movement and look must work simultaneously. Capture each pointer until release/cancel; opening a sheet, rotating, backgrounding or starting a cinematic clears active movement and look. Avoid hover, right-click, keyboard shortcuts and precise double taps as required actions.

Evidence stays in the world, but inspection opens a readable sheet with the same text and an optional object view. Dissolving newspaper text remains in its transcript. Philosophical commitment uses a spacious card explaining the selected doorway, then an explicit confirmation. Walking into a trigger or tapping through dialogue never records a vote.

Checkpoint at realm entry, encounter milestones and commitment. Background/resume, screen lock, interruptions and application restart preserve coherent state, do not replay a vote, and do not resume a held virtual stick. The installed phone release can finish the story offline.

Proposed performance goal: sustained 30 fps on the selected baseline phone after a representative 15-minute session. Measure frame-time distribution, peak memory, thermal degradation, battery behavior and repeated scene transitions. Reduce crowd/foliage detail and effect complexity while retaining encounters and choices. Set final limits from those measurements.

## Encounter design by realm

Every realm has an exploration beat, both competing accounts, one material interaction and two explicit commitments. These are design proposals to validate during playtesting, not newly discovered requirements in the original text.

| Realm | Playable activity | Argument expressed through the world | Completion condition |
|---|---|---|---|
| Love | Follow First Love, revisit the empty doorway, talk at the bench, operate the newspaper machine and inspect its stable passage | Recognition, abandonment and consolation; words disintegrate after reading but remain accessible in the journal | Both account beats and the newspaper beat are complete; interact with the chosen exit |
| Reason | Test an ordering apparatus, witness its limits, follow the Wild Self through newly revealed roots | The orderly white plane becomes a living grove; the two accounts propose different interpretations of the same change | Both encounters and apparatus/grove beats are complete; choose the final threshold |
| Truth | Inspect the exhibit table, bring an exhibit to either advocate, compare testimony and place a verdict token | Claims about truth and consequences attach to the same evidence; gallery reactions and staging express tension | Both accounts and required evidence beats are complete; deliberately place the token |
| God | Climb switchbacks, stop with each guide, investigate a trailhead poster and summit icon | Skepticism and affirmation accompany the same ascent; neither route turns into a combat test | Both guides and summit beat are complete; choose the exit |

Inspecting one object cannot make a realm irrecoverable. Relevant NPCs remain available until commitment; interrupted dialogue resumes or can be replayed. The two accounts can be heard in flexible order where the source permits it. Presentation can change order, but arguments that depend on preceding claims must retain their logical sequence.

Puzzles unlock understanding and the opportunity to commit. They must not automatically select Being for a clever solution or NotBeing for a failed traversal. New gameplay writing receives a fidelity review against its source pages before production voice recording.

## Narrative and state contract

The canonical input is [the 144 Markdown pages](../../src/content/pages), especially their `next` links, plus the existing [graph tooling](../../scripts/graph.mjs) and [flowchart checks](../../scripts/generate-flowchart.test.mjs). The [web state store](../../src/stores/state.mjs) is a reference for realm terminals, not the runtime implementation of this adventure.

Create an **adaptation manifest** that maps each source slug to a scene, speaker or event, original outgoing choices, gameplay prerequisites, presentation type, outcome and review status. Permitted presentation types include dialogue, ambient line, evidence, environmental event, temple response, ending and journal entry. Every source beat needs a disposition; merging repeated material retains its source IDs and original branch coverage. Do not blindly emit one room or one popup per page.

Author a source-derived transition table covering all **16 histories** of four binary realm commitments. After Love there are two hub routes (`3a–3b`); after Reason four (`5a–5d`); after Truth eight (`7a–7h`); after God sixteen (`9a–9p`). Keep exact gate identity alongside the four answers. The door rule comes from that gate's outgoing links, not from a majority vote or a scalar morality score.

| State group | Proposed contents | Lifetime |
|---|---|---|
| Journey | Schema/content version, four realm outcomes with an unset value, completed stage, current source branch/gate | Entire run |
| Encounter | Heard account flags, evidence inspected, local puzzle phase, commitment pending/complete | Current realm; preserve needed branch evidence at commit |
| Return | Temple presentation ID, next portal, entry point, interrupted sequence marker | Across scene transitions |
| Player | Scene and safe spawn, position/facing where supported, perspective preference, accessibility settings | Across transitions and durable saves |
| Completion | Selected ending, coda status, completion marker | Entire run |

Commit exactly once: validate prerequisites → write the answer and source-derived next branch → record the return checkpoint → transition. Overlapping triggers cannot overwrite an answer. Exiting and re-entering a realm for exploration before commitment must not reset its encounter. After commitment, show the record and continue; a different philosophical history requires a new run or an explicitly selected earlier save.

World Foundry has game-level persistent mailboxes; the inspected code distinguishes them from level-local storage. That establishes a cross-level state mechanism, **not proof of persistence after quitting the application**. Reserve symbolic mailbox names in a reviewed level manifest; confirm available slots instead of hard-coding a range used by another level. Prove process-restart save and restore separately. Reuse a current durable-save path if available; if it needs engine work, prepare that concrete proposal before implementation.

## World Foundry integration

Read-only inspection used `/home/will/WorldFoundry-wbniv`, commit `1feaf974`, and its current source files. This plan does not modify that repository or claim runtime verification. Older capability surveys are historical: Will confirms both free-movement perspectives are supported, so first-person support is not an engine prerequisite in this plan.

![Authoring pipeline from Markdown adaptation and Blender sources to an IFF adventure package](world-foundry-adventure/production-pipeline.png)

[Editable SVG](world-foundry-adventure/production-pipeline.svg).

The verified native asset route is Blender `.blend` → `wf_blender` level `.lev` and model IFF → `iffcomp` / `levcomp` / `textile` → per-scene IFF → `cdpack` and shell → runtime. Export directly with the WF Blender exporter; no glTF exchange step is needed. Blender and the inspected exporter use Z-up with an identity coordinate transform. Choose a consistent human-scale authoring convention and validate it with a player, doorway and stair in the slice.

| Requirement | Grounded approach | Proof required before full production |
|---|---|---|
| Player and two perspectives | Existing `player`, movement and camera support; level action toggles perspective | Same interaction and movement behavior in both views; no camera-induced displacement |
| Walkable spaces | Rooms, authored collision and render meshes; separate decorative shells from collision | Slopes, steps, boundaries, actor room membership and player recovery |
| Interactions | `ActBox` proximity, explicit input edge, Director eligibility checks, visible focus | One press yields one action; triggers never commit merely on overlap |
| Sequences and hub changes | Director scripts, mailboxes, visibility, authored geometry/material variants | Idempotent replay; skip restores control; history-specific presentation |
| NPCs | Existing actor/path mechanisms; compact authored routes and gestures | One exported character plays idle, walk and encounter animation correctly |
| Scripting | Prefer the current zForth level pattern; symbolic mailbox interface and generated tables | No shared-state leakage, bounded work per tick, correct input press/release handling |
| Package and transitions | Per-scene IFFs with a single title shell/manifest; reuse `cdpack` | Temple → realm → temple state survives; entry point and camera restored |
| Voice and subtitles | Existing audio facilities and UI assets where suitable | Interrupt, replay, skip and subtitle timing work; no overlapping dialogue |
| Journal and saves | Adaptation IDs plus current HUD and persistence paths | Long English text, Greek fragments, settings and process-restart restore |

Do not assume the inventory's glTF skeletons, PBR materials, shader graphs, procedural fractals or animation exports transfer unchanged. Make one character and one tapestry the compatibility test. Bake cloth and complex effects into supported mesh/texture animation where practical. Keep an original full-detail `.blend` master and a separate runtime export representation, so simplifying for the engine does not destroy authoring data.

The World Foundry [repository instructions](/home/will/WorldFoundry-wbniv/AGENTS.md) state: “Will requires discussion and explicit permission before modifying any World Foundry engine code.” This request authorizes a plan. Future level, asset and script implementation can be scoped separately; any necessary engine changes need a concrete proposal and approval. Potential integration questions are durable saves, gameplay text/Greek rendering, dialogue audio control and exact animation handoff—not speculative engine rewrites.

### Proposed implementation locations

Keep narrative authority and adaptation review in this repository. Build runtime assets and integration tests in the World Foundry checkout when implementation begins.

| Location | Planned responsibility |
|---|---|
| `finding-your-way/game/adaptation/` | Source-to-scene mapping, dialogue/evidence IDs, transition table, fidelity review |
| `finding-your-way/game/art/` | Asset manifest, replacement briefs, attribution and runtime budgets |
| `WorldFoundry/wflevels/parmenides/` | Shared assets, shell/scene manifest, state and interaction scripts |
| `WorldFoundry/wflevels/parmenides_<scene>/` | Reproducible Blender authoring scripts, `.blend`, exported `.lev`, mesh/texture inputs |
| `WorldFoundry/tests/parmenides/` | Route fixtures, input sequences, mailbox expectations and lifecycle checks |
| `finding-your-way/docs/diagnostics/parmenides/` | Review links to runtime captures, profiling and fidelity findings |

These locations are proposed; only this plan and its design artifacts are created now. Implement the build/run/test/package workflows as project tasks with clear outputs and one repeatable entry point for the slice.

## Phase 1 production stages for the phone release

### Stage 0 Establish the content and runtime contracts

- [ ] Extract and validate the 144-page graph and original sixteen-history gate table.
- [ ] Give every source beat an adaptation disposition; write Love's complete encounter storyboard and review it against the source.
- [ ] Record the baseline phone/OS and existing build path. Prove both camera modes and simultaneous touch move/look on a tiny room with player, doorway, inspectable prop and NPC placeholder.
- [ ] Review settings, scenes, characters, props and effects for useful subtle motion or intentional stillness; add motion entries to the asset manifest.
- [ ] Export one textured mesh, one animated character test and a tapestry test through the native pipeline; prove idle, interaction and environmental motion representations.
- [ ] Prove scene transitions, cross-level state, subtitle/audio behavior and durable save/restore with throwaway fixtures.
- [ ] Record any remaining engine integration proposals with exact missing behavior and smallest useful interface; obtain approval before engine edits.

**Gate:** a buildable phone runtime contract and a reviewed Love adaptation. Resolve feasibility questions before full asset production or final voice recording.

### Stage 1 Build the Temple and Love vertical slice

- [x] Graybox the temple and street; wire free movement, interactions, both accounts, newspaper inspection and both exits. Native desktop behavioral fixtures pass both return choices; complete phone traversal remains below.
- [ ] Add the visible player, provisional NPCs, both camera modes, focus prompt and accessible journal/subtitle path.
- [ ] Add both Love return histories, the next portal activation and a reliable checkpoint.
- [ ] Replace placeholders with representative final art, one tapestry effect and a small goddess voice sample.
- [ ] Add and profile one NPC idle, one prop interaction response and one environmental loop; review both perspectives with reduced motion enabled and disabled.
- [ ] Run complete affirming and denying playthroughs on the phone in both perspectives, including interruptions, restart and skipped sequences.

**Gate:** a reviewer can explore, understand two competing accounts, choose intentionally and notice the consequence without following a reading-page sequence. Capture a continuous runtime playthrough and a small state trace. Target a roughly 10–15 minute slice as a proposed pacing goal; measure it with unfamiliar players before extrapolating.

### Stage 2 Establish the shared adventure systems

- [ ] Extract the slice's interaction, evidence, conversation, commitment, camera-ownership and transition patterns into reusable level scripts/data.
- [ ] Implement the generated history table and all temple presentation mappings; group shared art setups only when the source supports them.
- [ ] Finish process-restart saves, schema versioning, reset/new-run behavior, subtitle settings and journal history.
- [ ] Confirm that animation, VO and texture export remain reproducible on the selected phone build; desktop tooling can support diagnosis.
- [ ] Establish reusable idle/gesture clips, asynchronous background timing, decorative motion suspension and the saved reduced-motion preference.

**Gate:** future realms use the same verified contracts rather than four independent implementations. No unresolved save, camera or dialogue blocker remains hidden in content work.

### Stage 3 Produce Reason and Truth

- [x] Build Reason's apparatus, two selves, younger self, roots/grove transformation and both conclusions with provisional Blender geometry.
- [x] Build Truth's courtroom, advocates, evidence inspection/presentation and both verdict commitments with provisional Blender geometry. Animated token placement remains an art-pass task.
- [x] Add the four post-Reason source histories (`5a–5d`), preserving Love's tapestry state and applying Reason's windows/walls state.
- [x] Add the eight post-Truth source histories (`7a–7h`) to the Temple data, including bright/subdued mosaics and a removed visible foundation. Invisible collision support temporarily substitutes for the rescue beat.
- [ ] Review argument integrity, evidence accessibility and both-camera framing before final voice recording.
- [ ] Review Reason and Truth motion entries, including transformation settling, actor idles and still evidence-inspection views.

**Gate:** eight reachable three-realm histories reproduce their source-derived hub responses, with no puzzle result silently changing an answer.

### Stage 4 Produce God and the endings

- [x] Build the hill route, safe landings, two guides, original poster/icon and both conclusions with provisional Blender geometry.
- [x] Implement the sixteen final-gate histories and their exact 33 door edges from source frontmatter. Only `9a` permits Being; all histories permit Both and NotBeing. Actual ending scenes remain below.
- [ ] Review God, ending and surgery motion; preserve intentional stillness, coda framing and correct transitions when animations are skipped.
- [ ] Author Being's dissolution into light, NotBeing's void and disintegration, Both's threshold and its surgery coda.
- [ ] Preserve Greek/English fragments and attribution in an accessible rendering path; test font coverage or use accessible text alongside baked art.
- [ ] Record and integrate the full goddess performance and principal NPC lines after script review.

**Gate:** all sixteen histories terminate correctly; `10b → 101b` is the sole coda route; skipped cinematic sequences still leave a valid completed state.

### Stage 5 Validate and package the adventure

- [ ] Complete the phone touch profile, safe-area layout, readable sheets and interruption handling; exercise every realm on the phone in both perspectives.
- [ ] Test mid-dialogue interruption, application quit/restart, save mismatch handling, scene reload and returning to a previous checkpoint.
- [ ] Profile representative worst-case scenes: crowd dispersal, temple/aether dome, Reason transformation, courtroom gallery and forest ascent.
- [ ] Deliver one adventure package with a title entry, settings, credits, provenance manifest and reproducible build tasks.
- [ ] Publish a documented evidence index containing actual engine captures; keep the illustrated mockups labeled as design studies.

**Gate:** complete journey and lifecycle evidence on the baseline phone, with no softlock, accidental vote, contradictory door state or inaccessible mandatory text. TV WebView compatibility and other platform layouts belong to Phase 2.

Stages are dependency gates, not calendar promises. Estimate art, VO, integration and QA after Stage 1 produces measured costs. The earlier 35–40 prop and approximately fourteen-rig estimates are inventory starting points; reconcile a unique asset manifest, add the protagonist, distinguish meshes from shared rigs and outfit variants, and count voice work by lines/minutes rather than “audio assets.” Proposed first target: sustained 30 fps on the baseline phone, including a warm sustained session. Other device targets are Phase 2 work. Set triangle, texture, actor and VO-memory budgets from profiling instead of treating historical N64-style art numbers as engine limits.

## Verification and review evidence

| Check | Required evidence |
|---|---|
| Source coverage | Every canonical slug maps to a reviewed gameplay/presentation disposition; original branch IDs remain traceable |
| Route fidelity | Sixteen complete history fixtures, exact `9a–9p` mapping, 33 final gate-to-ending edges and `10b → 101b` |
| Commitment safety | Enter/leave overlapping triggers, hold/release Interact, approach either door twice; answer changes exactly once |
| Exploration | Both accounts/evidence remain reachable in flexible inspection order; no irreversible missed line |
| Perspectives | Toggle at portals, stairs, furniture, roots and NPCs; same targets and outcomes; preferred view restored after authored shots |
| Presentation | Actual before/after temple captures for representative histories plus data coverage for every history |
| Persistence | Exit/restart during a realm and after commitment; correct scene, outcomes, inspection history and camera preference restored |
| Accessibility | Silent playthrough with subtitles/captions; readable evidence after dissolution; Greek and English available |
| Performance and lifecycle | Frame-time, actor/texture/audio memory and repeated scene transitions; no accumulating resources |

During Phase 2, Chromecast verification uses the standing-authorized coordinator tasks for complete device sessions: queue, submit/check/profile/record, watch and evidence retrieval. Freeze the APK before submission. Respect reservations and retain job evidence; do not use raw Chromecast ADB or a direct-control fallback during coordinator downtime. Device testing belongs to implementation, not to the current documentation task.

## Phase 2 layouts for Chromecast web desktop and tablet

Begin after the complete phone adventure passes its release gate. Reuse the same Blender assets, source-derived choices, state machine and encounter data. Adapt presentation and input instead of creating separate narrative versions.

| Target | Layout and control work | Completion evidence |
|---|---|---|
| Chromecast | D-pad/remote interaction, readable distant-view captions, focus navigation and alternate movement/look mapping; optionally controller profile | Actual TV viewing-distance playthrough and coordinator-owned device session; WebView 91 compatibility when applicable |
| Web | Browser build/package, touch or keyboard/mouse controls, responsive sheets, browser focus/visibility and persistence integration | Actual supported browser build, full journey, reload/restore and focus-loss input release |
| Desktop | Keyboard/mouse and controller bindings, camera sensitivity, resizable window/sheets, cursor/focus behavior | Both perspectives, complete journey and save/restart on the supported desktop build |
| Tablet | Larger touch layout, relocated thumb zones, safe areas and rotation policy; use extra space for evidence and journal | Real tablet touch/rotation checks and a complete journey; no assumption that scaling the phone UI is enough |

- [ ] Define an input and layout profile for each target without altering the philosophical transition table.
- [ ] Adapt HUD, captions, evidence, journal and commitment cards for each screen and input method.
- [ ] Confirm the existing build/runtime route for each target before promising packaging or deployment.
- [ ] Test platform-specific interruption, persistence, fullscreen/window/orientation and camera behavior.
- [ ] Profile each target independently and use art-detail variants where needed.
- [ ] Complete the same sixteen-history regression checks and real gameplay/lifecycle evidence for each supported release.

Do not put Phase 2 layout tasks on the phone release's critical path. Keep reusable action names and data now, but ship and evaluate the phone adventure first.

## Immediate next implementation task

Build the **three ending scenes and the `10b → 101b` surgery coda** next, before art passes. Replace the explicitly labeled ending-preview sheets with source-derived transitions, complete ending/coda text and valid completion state. Retain the exact 33 final-gate edges and reuse the level-owned dialogue/camera/commitment contracts. Keep models provisional, audit intended text only, test every eligible ending and the sole coda route, install on Chromecast 1, archive the APK and commit the milestone. Phone controls, durable saves and phone acceptance remain release requirements.

God now supplies the rising forest path, safe landings/checkpoint recovery, young man, holy man, original poster/icon, question stop, both threshold counsels and all sixteen final Temple accounts. Unfinished visits retain encounters; replay clears downstream God/final-gate state. Neither inspection nor traversal chooses a philosophy. The bright Temple has provisional aether rings; the dark Temple hides the shell. Guide departures, source foundation rescue, final motion/art and face rendering remain later work. See the [implementation and evidence report](../diagnostics/parmenides/god/implementation.md).

## Primary technical references

The following local sources establish the pipeline and reusable mechanisms. They are source inspection, not guarantees that every proposed adventure system is already wired end to end.

- [World Foundry level building guide](/home/will/WorldFoundry-wbniv/docs/level-building.md): actor composition, rooms, camera and authoring rules.
- [Blender level exporter](/home/will/WorldFoundry-wbniv/wftools/wf_blender/export_level.py): native `.lev` export, OAD fields, mesh hand and coordinates.
- [Level build script](/home/will/WorldFoundry-wbniv/wftools/wf_blender/build_level_binary.sh): actual IFF/level/texture build chain.
- [Scripting reference](/home/will/WorldFoundry-wbniv/docs/scripting-languages.md) and [zForth bridge](/home/will/WorldFoundry-wbniv/engine/stubs/scripting_zforth.cc): current mailbox vocabulary and per-tick scripting.
- [Mailbox implementation](/home/will/WorldFoundry-wbniv/wfsource/source/game/mailbox.cc) and [game transition implementation](/home/will/WorldFoundry-wbniv/wfsource/source/game/game.cc): game-level storage and level selection.
- [Actor type index](/home/will/WorldFoundry-wbniv/docs/2026-05-03-oas-actor-types.md): player, triggers, Director, CamShot and composable world actors.
- [Level selector and package task](/home/will/WorldFoundry-wbniv/Taskfile.yml): existing `cdpack`/manifest integration.
- [Rebuild the design drawings](world-foundry-adventure/build_mockups.py): generates the gallery, PNG mockups and PNG/SVG diagrams locally using Pillow.
