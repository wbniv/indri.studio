"""Provisional Blender courtroom and source-derived Temple foundation variants."""
import math

def build_truth(Model, cube, arch, label, human):
    cube('court_floor',(300,5,-.35),(28,38,.7),'brown',1000)
    walls=Model()
    for x in (287,313):
        walls.box((x,5,1.25),(.55,37,2.5),'brown')
        for y in (-9,-3,3,9,15,21):
            walls.box((x,y,2.8),(.75,.6,5.6),'stone')
    walls.box((300,23,1.25),(26,.55,2.5),'brown')
    walls.object('court_structure')
    for x in (292,308):
        for y in (-5,-2):
            cube(f'gallery_bench_{x}_{y}',(x,y,.43),(4.5,.8,.86),'brown',1000)
    old_lady=human('OldLady',(292,-5,.86),coat='purple')
    bag=Model();bag.box((0,0,.35),(.4,.3,.55),'purple');bag.object('purple_bag',(293,-5,.85))
    for x,y,name,color in ((294,1,'Prosecutor','ink'),(306,1,'DefenceAttorney','cream')):
        npc=human(name,(x,y,.05),coat=color);npc.rotation_euler.z=-math.pi/2
        npc['wf_Visibility Mailbox']=180 if name=='Prosecutor' else 181
        key='prosecutor_sign' if name=='Prosecutor' else 'defence_sign'
        sign=label(key,key,(x,y-.35,2.5),3.3);sign['wf_Visibility Mailbox']=185 if name=='Prosecutor' else 186
        cube(name.lower()+'_lectern',(x,y-1.3,.55),(1,.6,1.1),'brown',1000)
    student=human('Student',(300,6,.05),coat='green');student.rotation_euler.z=-math.pi/2;student['wf_Visibility Mailbox']=182
    student_sign=label('student_sign','THE STUDENT',(300,5.7,2.5),3);student_sign['wf_Visibility Mailbox']=184
    for x,key,color in ((294,'facts','blue'),(306,'interpretations','gold')):
        cube(key+'_table',(x,7,.4),(1.4,1.2,.8),'brown',1000)
        cube(key+'_document',(x,7,.84),(.95,.65,.04),'cream')
        mark=Model()
        for i in range(5):mark.box((0,-.23+i*.11,0),(.7,.02,.012),color)
        mark.object(key+'_lines',(x,7,.865))
        label(key+'_sign',key,(x,6.7,1.7),3.4)
    cube('hearing_bench',(300,12,.65),(4.5,1.2,1.3),'brown',1000)
    judge=human('Judge',(300,13,.05),coat='ink');judge.rotation_euler.z=-math.pi/2
    label('judge_sign','PRESENT EXHIBITS',(300,10.9,2),3.5)
    gavel=Model();gavel.box((0,0,0),(.6,.09,.09),'gold');gavel.box((.25,0,0),(.16,.35,.2),'brown');gavel.object('gavel',(301.3,11.8,1.35))
    token=Model();token.cone((0,0,0),.23,.06,'gold',sides=12);token.object('presented_exhibits',(300,11.6,1.36),visibility=187)
    arch('truth_being_exit',293,17,'cream');label('tbeing_sign','BEING',(293,16.65,3.85),3.3)
    arch('truth_notbeing_exit',307,17,'ink');label('tnotbeing_sign','NOTBEING',(307,16.65,3.85),4)
    arch('truth_back_portal',300,-9,'gold')
    back=label('tback_sign','TEMPLE',(300,-8.65,3.85),3);back.rotation_euler.z=math.pi
    arch('god_portal',0,-9,'cream',208)
    god_label=label('god_sign','GOD / NEXT CHAPTER',(0,-8.65,3.85),4);god_label.rotation_euler.z=math.pi;god_label['wf_Visibility Mailbox']=209
    for variant,visibility in ((0,211),(1,210)):
        mosaic=Model()
        for i in range(-5,6):
            for j in range(-6,7):
                color=('cream','blue','gold','green')[(i+2*j)%4] if variant else ('stone','brown')[(i+j)%2]
                mosaic.box((i*2,j*2,.008),(1.88,1.88,.016),color)
        mosaic.object('mosaic_lit' if variant else 'mosaic_dim',visibility=visibility)
