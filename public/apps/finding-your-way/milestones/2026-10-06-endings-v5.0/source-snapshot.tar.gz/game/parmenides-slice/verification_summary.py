"""Combine the source, asset and native audits with an exact build identity."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT.parents[1] / 'docs/diagnostics/parmenides/endings'
read = lambda path: json.loads(path.read_text())
build = read(ROOT / 'build/build-receipt.json')
engine=build['engineProvenance']
executable=Path('/home/will/WorldFoundry-wbniv/engine/wf_game')
if hashlib.sha256(executable.read_bytes()).hexdigest()!=engine['desktopExecutableSha256']:
    raise SystemExit('Desktop engine changed after provenance capture: rerun its checks and chapter verification.')
content = read(ROOT / 'build/content.json')
text = read(EVIDENCE / 'text-audit.json')
assets = read(EVIDENCE / 'asset-audit.json')
panels={'results':[]}
if content.get('visual_fixes'):
    panels=read(EVIDENCE/'panel-render-audit.json')
    if not panels['passed'] or panels['build']['sha256']!=build['sha256']:
        raise SystemExit('Complete matching rendered clipping/occlusion audit is required.')
    for row in panels['results']:
        if hashlib.sha256((EVIDENCE/'rendered-panels'/row['file']).read_bytes()).hexdigest()!=row['sha256']:
            raise SystemExit('Rendered frame changed: '+row['file'])
native = [EVIDENCE / 'desktop', EVIDENCE / 'desktop/supplemental-text']
for receipt in [text['build'], assets['build']] + [read(folder / 'build-receipt.json') for folder in native]:
    if receipt['sha256'] != build['sha256']:
        raise SystemExit('Audit build mismatch: rerun native:verify for the current APK.')
runtime = [row for folder in native for row in read(folder / 'results.json')]
transcripts = [row for folder in native for row in read(folder / 'transcripts.json')]
if not all(row['passed'] for row in runtime + text['results'] + assets['results']):
    raise SystemExit('An audit contains a failed check.')
seen = {index for row in transcripts for index in row['cards']}
expected = {card['id'] for card in content['cards']}
if seen != expected:
    raise SystemExit('Dialogue card coverage mismatch: ' + str(seen ^ expected))
summary = {'runtime_checks': len(runtime), 'source_checks': len(text['results']),
           'asset_checks': len(assets['results']), 'dialogue_sequences': len(transcripts),
           'visual_fixes':bool(content.get('visual_fixes')),'known_visual_issues':['Text clipping/occlusion','Face rendering','Camera obstruction'] if not content.get('visual_fixes') else [],
           'rendered_panel_checks':len(panels['results']), 'distinct_cards': len(seen), 'missing_cards': [], 'passed': True,
           'apk_sha256': build['sha256'],'engine_source_commit':engine['sourceCommit'],
           'desktop_executable_sha256':engine['desktopExecutableSha256'],
           'engine_texture_cases':engine['textureCases']}
(EVIDENCE / 'verification-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
