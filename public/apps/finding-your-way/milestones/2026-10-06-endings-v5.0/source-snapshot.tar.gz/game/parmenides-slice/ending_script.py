"""Level-owned ending transitions, exact coda route and session completion."""
RESET=': fy-reset-ending '+''.join(f'0 {m} write-mailbox ' for m in (189,222,223,224,225,253))+';\n'

def definitions(emit,first,actor):
    emit(': fy-enter-ending fy-reset-ending 189 write-mailbox 1 222 write-mailbox 110 read-mailbox 253 write-mailbox\n')
    for selected,x,realm,slug in ((1,500,5,'10a'),(2,600,6,'10b'),(3,700,7,'10c')):
        emit(f'189 read-mailbox {selected} = if {x} 0 fy-teleport {realm} 102 write-mailbox {first("ending_"+slug)} 140 write-mailbox then\n')
    emit(';\n: fy-surgery 2 222 write-mailbox 800 0 fy-teleport 8 102 write-mailbox\n')
    for axis,coord in (('X',800),('Y',-.6),('Z',1.05)):
        emit(f'{coord} INDEXOF_{axis}_POS {actor("Camera")} write-actor-mailbox\n')
    emit(f'{first("ending_101b")} 140 write-mailbox ;\n')
    emit(f': fy-finish-ending 1 225 write-mailbox 3 222 write-mailbox {first("ending_complete")} 140 write-mailbox ;\n')
    emit(': fy-resume-ending\n')
    for realm,slug in ((5,'10a'),(6,'10b'),(7,'10c'),(8,'101b')):
        emit(f'102 read-mailbox {realm} = if 225 read-mailbox 0 <> if {first("ending_complete")} else {first("ending_"+slug)} then 140 write-mailbox then\n')
    emit(';\n')
    # Recover freely explored ending footprints without selecting/completing anything.
    emit(': fy-ending-safety 102 read-mailbox 5 >= if\n')
    for realm,x in ((5,500),(6,600),(7,700),(8,800)):
        emit(f'102 read-mailbox {realm} = if INDEXOF_Z_POS read-mailbox -1 < INDEXOF_X_POS read-mailbox {x} - abs 8 > | INDEXOF_Y_POS read-mailbox abs 8 > | if {x} 0 fy-teleport then then\n')
    emit('then ;\n')

def ends():
    return {'ending_confirm_10a':'1 fy-enter-ending','ending_confirm_10b':'2 fy-enter-ending',
            'ending_confirm_10c':'3 fy-enter-ending',
            'ending_10a':'1 223 write-mailbox fy-finish-ending',
            'ending_10b':'1 223 write-mailbox fy-surgery',
            'ending_10c':'1 223 write-mailbox fy-finish-ending',
            'ending_101b':'1 224 write-mailbox fy-finish-ending',
            'ending_complete':'fy-return'}

def visuals(emit,actor):
    emit('102 read-mailbox 5 = dup 254 write-mailbox 255 write-mailbox\n')
    emit('102 read-mailbox 6 = 256 write-mailbox\n102 read-mailbox 7 = 258 write-mailbox\n')
    emit('102 read-mailbox 7 = 110 read-mailbox 253 read-mailbox - 1.5 < & 257 write-mailbox\n')
    emit('102 read-mailbox 7 = 110 read-mailbox 253 read-mailbox - 1.5 >= & 259 write-mailbox\n')
    emit('102 read-mailbox 8 = dup 213 write-mailbox 140 read-mailbox 0 = & 159 write-mailbox\n')
    # Quiet transform-only motion; reduced motion freezes at a meaningful still.
    for i in range(1,4):
        emit(f'108 read-mailbox 0 = if 110 read-mailbox 0.12 * {i*.2} + fy-sin 0.012 * else 0 then INDEXOF_Z_POS {actor("surgeon_"+str(i))} write-actor-mailbox\n')
    emit(f'108 read-mailbox 0 = if 110 read-mailbox 0.015 * fy-wrap else 0 then INDEXOF_ROTATION_C {actor("being_ripples")} write-actor-mailbox\n')
