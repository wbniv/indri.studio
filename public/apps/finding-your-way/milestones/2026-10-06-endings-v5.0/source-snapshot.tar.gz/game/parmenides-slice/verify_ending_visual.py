"""Render deliberate source/still frames after waiting for native camera cuts."""
import time

def run(b,player,value,check,tap,position,read_pages,groups,ids,capture):
    for name in ('Camera','card_204'):
        for m in (3009,3010,3011,3012,3013,3014):b.watch(ids[name],m)
    for mode in (0,1):
        if value(101)!=mode:tap(2)
        for x,slug in ((-7,'10a'),(0,'10b'),(7,'10c')):
            for m in (106,107,154,155,176,177,188,195,196,197):b.set_mailbox(m,1,idx=player)
            b.set_mailbox(102,0,idx=player);b.set_mailbox(140,0,idx=player);position(x,-11);tap()
            read_pages(slug+' visual entry',groups['ending_confirm_'+slug],groups['ending_'+slug][0])
            capture(slug+'-source-camera'+str(mode))
            tap(16384);capture(slug+'-scene-camera'+str(mode));tap()
            if slug=='10b':
                read_pages('Both visual transition',groups['ending_10b'],groups['ending_101b'][0])
                capture('101b-source-camera'+str(mode))
                print({name:{m:b.mailbox_values.get((ids[name],m)) for m in range(3009,3015)} for name in ('Camera','card_204')},flush=True)
                tap(16384);capture('101b-scene-camera'+str(mode));tap()
                read_pages('surgery visual account',groups['ending_101b'],groups['ending_complete'][0])
            else:read_pages(slug+' visual account',groups['ending_'+slug],groups['ending_complete'][0])
            capture(slug+'-complete-camera'+str(mode))
            read_pages('visual review return',groups['ending_complete'])
