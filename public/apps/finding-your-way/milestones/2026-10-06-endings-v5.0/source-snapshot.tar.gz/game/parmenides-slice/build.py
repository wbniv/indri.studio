#!/usr/bin/env python3
"""Build the four Blender-authored realms and package the existing WF runtime."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import textwrap
import zipfile

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[1]
WF = Path('/home/will/WorldFoundry-wbniv')
OUT = ROOT / 'build'
LEVEL = 'parmenides_slice'
SDK = Path('/home/will/android-sdk-local')
TOOLS = SDK / 'build-tools/34.0.0'
ANDROID = SDK / 'platforms/android-34/android.jar'
RUNTIME = WF / 'android/app/build/outputs/apk/condo/release/worldfoundry-condo-release.apk'

def run(*args, **kwargs):
    subprocess.run([str(a) for a in args], check=True, **kwargs)

def source(slug):
    s = (PROJECT / 'src/content/pages' / (slug + '.md')).read_text().split('---', 2)[2]
    s = s.split('<details')[0]
    s = re.sub(r'!\[[^\]]*\]\([^)]*\)', '', s)
    return re.sub(r'\s+', ' ', re.sub(r'[*_]', '', s)).strip()

def content(visual_fixes=False):
    OUT.mkdir(parents=True, exist_ok=True)
    labels={'love_sign':'LOVE','reason_sign':'REASON','goddess_sign':'THE GODDESS',
            'first_sign':'FIRST LOVE','starlet_sign':'THE STARLET','paper_sign':'ADVICE COLUMN',
            'being_sign':'BEING','notbeing_sign':'NOTBEING','back_sign':'TEMPLE',
            'truth_sign':'TRUTH','white_sign':'WHITE-CLAD SELF',
            'wild_sign':'WILD SELF','child_sign':'YOUNGER SELF','apparatus_sign':'WEATHER / WHY?',
            'rbeing_sign':'BEING','rnotbeing_sign':'NOTBEING','rback_sign':'TEMPLE',
            'prosecutor_sign':'PROSECUTOR','defence_sign':'DEFENCE ATTORNEY','student_sign':'THE STUDENT',
            'facts_sign':'EXHIBIT A / FACTS','interpretations_sign':'EXHIBIT B / ASSUMPTIONS',
            'judge_sign':'PRESENT EXHIBITS','tbeing_sign':'BEING / DEFENCE','tnotbeing_sign':'NOTBEING / PROSECUTOR',
            'tback_sign':'TEMPLE','god_sign':'GOD',
            'young_sign':'THE YOUNG MAN','holy_sign':'THE HOLY MAN',
            'god_poster_sign':'POSTER / MODELS','god_icon_sign':'ICON / FOUNDATION','question_sign':'YOUR QUESTION',
            'gbeing_sign':'BEING','gnotbeing_sign':'NOTBEING','gback_sign':'TEMPLE',
            'final_being_sign':'BEING','final_both_sign':'BOTH','final_notbeing_sign':'NOTBEING'}
    for name,text in labels.items():
        img=Image.new('RGB',(256,32),'#26343c');draw=ImageDraw.Draw(img)
        font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',14)
        draw.text((128,16),text,font=font,fill='#efe4c9',anchor='mm')
        img.save(OUT/(name+'.tga'))
    cards = []
    groups = {}
    def add(key, title, text, source_ids=(), atlas="permanent"):
        pages=[]
        page=[]
        for word in text.split():
            candidate=page+[word]
            if page and (len(candidate)>72 or len(textwrap.wrap(' '.join(candidate),54))>9):
                pages.append(page);page=[]
            page.append(word)
        if page:pages.append(page)
        ids = []
        for words in pages:
            ids.append(len(cards) + 1)
            cards.append(dict(id=len(cards) + 1, key=key, title=title,
                              text=' '.join(words), source=list(source_ids), atlas=atlas))
        groups[key] = ids
    add('intro', 'THE TEMPLE', 'Four realms await: Love, Reason, Truth and God. Begin with Love. Walk toward the red portal and press Select. Directions move and turn. A short Select press interacts; hold Select to switch between third person and first person. The camera changes; your choices do not. Approach a speaker or object to interact. You can revisit the arguments before choosing a doorway.', ['intro', 'intro5'])
    add('first', 'FIRST LOVE', source('loveb'), ['loveb'])
    add('starlet', 'THE STARLET', source('lovec') + ' ' + source('loved'), ['lovec', 'loved'])
    add('paper', 'ADVICE COLUMN', 'One relationship taught me to care for someone even when it cost me. Another makes me wonder whether I only call it love when a bond answers my own needs. Should I trust love as a real force that exceeds advantage, or understand it as a response shaped by cooperation and survival? I do not want a slogan. I want to decide what this experience means. Which way holds my answer?', ['lovee'])
    add('affirm', 'ENTER THE WAY OF BEING?', 'Affirm Love as a real force that exceeds individual advantage. This is your interpretation, not a score. Press Select again to commit and return to the temple. Use Journal or move away after closing this sheet to reconsider.', ['lovebeing', '3a'])
    add('deny', 'ENTER THE WAY OF NOTBEING?', 'Understand Love as an evolved response to cooperation, vulnerability and survival rather than an independent force. This is your interpretation, not a score. Press Select again to commit and return to the temple. Use Journal or move away after closing this sheet to reconsider.', ['lovenotbeing', '3b'])
    add('locked', 'HEAR BOTH ACCOUNTS', 'Before choosing a doorway, hear First Love and the starlet and inspect the newspaper. Approach each of them and press Select. Finish their argument pages to complete an encounter. Ordinary walking never commits a choice.', ['loveb', 'lovec', 'loved', 'lovee'])
    add('return_being', 'RETURN TO THE TEMPLE', 'The tapestries glow with vibrance; their patterns weave and twist. The goddess smiles: "The weave of your love is fascinating." Reason is the next realm. Approach its purple portal and press Select. Explore the changed temple or begin a new interpretation at the Love portal.', ['3a'])
    add('return_notbeing', 'RETURN TO THE TEMPLE', 'The tapestries are gone; the four pillars stand bare. "They were worn out anyway. Out with the old," the goddess quips. The next portal glows blue: Reason awaits. Approach the blue portal and press Select, or revisit Love.', ['3b'])
    add('journal', 'JOURNAL', 'Love: First Love describes a force that can exceed selfish interests. The starlet describes an evolved response to cooperation and survival. The newspaper asks you to interpret a relationship. The two street thresholds represent your deliberate commitment. Select closes this sheet. With a gamepad or phone controller: B switches perspective, C opens/closes Journal, D toggles reduced motion. A long remote Select press switches perspective.', ['loveb', 'lovec', 'loved', 'lovee'])
    white,transformation=source('reasonba').split('You feel a vast crack',1)
    add('white','WHITE-CLAD SELF',source('reasonaa')+' '+white,['reasonaa','reasonab','reasonba','reasonbb'])
    add('grove','THE WHITE PLANE CHANGES','You feel a vast crack'+transformation,['reasonba','reasonbb'])
    add('apparatus_order','ORDERING APPARATUS','Press Select again to operate this model of rain. Warm water rises, cool clouds gather and rain falls. The apparatus can organize an explanation of how the weather works. The next question asks what this explanation can settle. Observe the pattern, then consider what kind of answer it provides. Neither doorway has a correct answer imposed by the apparatus.',['reasonba','reasonbb','reasonbeinga','reasonbeingb'])
    add('apparatus_limit','WHAT THE MODEL CANNOT CHOOSE','The model now shows a chain of causes: heat, vapor, cloud, rain. It can describe a pattern. It cannot choose why your survival matters, what you should value, or whether every question has a final answer. Neither doorway has been selected. Follow the roots, hear your Wild Self and meet the child at the edge of the grove.',['reasonbeinga','reasonbeingb'])
    add('wild','WILD SELF',source('reasonca'),['reasonca','reasoncb'])
    add('child','YOUNGER SELF',source('reasonda'),['reasonda','reasondb'])
    add('reason_affirm','ENTER REASON / BEING?','Take the bright threshold and question the scientific account down the Why Axis. Select continues that account; your commitment happens only after its final question. Left or Journal cancels the sheet. You can reconsider and choose the other threshold.',['reasonbeinga','reasonbeingb'])
    add('why_axis','THE WHY AXIS',source('reasonbeinga'),['reasonbeinga','reasonbeingb'])
    add('reason_deny','ENTER REASON / NOTBEING?','Take the dark threshold and hear the alternative answer to the child. Select continues that account; your commitment happens only after its final reply. Left or Journal cancels the sheet. You can reconsider and choose the other threshold.',['reasonnotbeinga','reasonnotbeingb'])
    add('rain_reply','ANOTHER ANSWER',source('reasonnotbeinga'),['reasonnotbeinga','reasonnotbeingb'])
    add('reason_locked','COMPLETE THE REASON ENCOUNTERS','Hear the White-Clad Self, operate the apparatus and consider its limits, follow the revealed roots to the Wild Self, then meet your Younger Self. Finish the encounter pages before entering either threshold. Walking never commits a choice.',['reasonaa','reasonab','reasonba','reasonbb','reasonca','reasoncb','reasonda','reasondb'])
    add('reason_wait','FOLLOW THE REVEALED ROOTS','Hear the White-Clad Self first. Completing that account reveals the grove and your Wild Self. Complete the apparatus encounter and the Wild Self account before meeting the child at the grove edge.',['reasonba','reasonbb','reasonda','reasondb'])
    add('reason_unavailable','LOVE COMES FIRST','Hear First Love and the starlet and inspect the newspaper, then choose the gold BEING or dark NOTBEING threshold. Select opens its confirmation; Select again commits and returns you to the Temple. The TEMPLE portal returns without choosing, so it does not unlock Reason. Your Love interpretation is kept while you explore Reason.',['3a','3b'])
    for slug in ('5a','5b','5c','5d'):
        add('return_'+slug,'RETURN TO THE TEMPLE',source(slug),[slug])
    from truth_content import add_truth
    add_truth(add, source)
    from god_content import add_god
    god_histories=add_god(add,source,PROJECT/'src/content/pages')
    from ending_content import add_endings
    ending_routes=add_endings(add,source,PROJECT/'src/content/pages')
    for card in cards:
        # Cards are divided among permanent and two adjacent room asset chunks.
        image = Image.new('RGB', (256, 112), '#202b36')
        d = ImageDraw.Draw(image)
        title = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 9)
        font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 8)
        d.line((8, 20, 248, 20), fill='#9c8753', width=1)
        d.text((8, 5), card['title'], font=title, fill='#ecd7a2')
        lines = textwrap.wrap(card['text'], 54)
        if len(lines) > 9:
            raise RuntimeError('Card text overflow: ' + str(card['id']))
        for n, line in enumerate(lines):
            d.text((8, 22 + n * (8 if visual_fixes else 9)), line, font=font, fill='#f3eee3')
        d.text((8, 98 if visual_fixes else 102), 'SELECT: continue   LEFT / C: close', font=font, fill='#c8bea6')
        image.save(OUT / ('card_%02d.tga' % card['id']))
    # Original advice wording replaces the source clipping; the arguments retain source prose.
    manifest = {'visual_fixes':visual_fixes, 'chapter': 'Temple / Love / Temple / Reason / Temple / Truth / Temple / God / Final Temple / Endings / Surgery', 'cards': cards, 'groups': groups,
                'god_histories':god_histories, 'ending_routes':ending_routes,
                'reason_histories': {'5a':{'love':1,'reason':1},'5b':{'love':1,'reason':-1},'5c':{'love':-1,'reason':1},'5d':{'love':-1,'reason':-1}},
                'truth_histories': {'7'+chr(97+i):{'love':1 if i<4 else -1,'reason':1 if i%4<2 else -1,'truth':1 if i%2==0 else -1} for i in range(8)},
                'source_beats': ['intro','intro1','intro2','intro3','intro4','intro5','lovea','loveb','lovef','lovec','loved','lovee','lovebeing','lovenotbeing','3a','3b',
                                 'reasonaa','reasonab','reasonba','reasonbb','reasonca','reasoncb','reasonda','reasondb',
                                 'reasonbeinga','reasonbeingb','reasonnotbeinga','reasonnotbeingb','5a','5b','5c','5d']+
                                [prefix+suffix for prefix in ('truth1','trutha','truthb','truthc','truthd','truthbeing','truthnotbeing') for suffix in 'abcd']+
                                ['7'+suffix for suffix in 'abcdefgh']+
                                [prefix+suffix for prefix in ('god1','god2','goda','godb','godc','godbeing','godnotbeing') for suffix in 'abcdefgh']+
                                ['9'+suffix for suffix in 'abcdefghijklmnop']+['10a','10b','10c','101b'],
                'adaptation_notes': {'paper': 'Original advice-column replacement, not a transcription of the source photograph.',
                                    'first': 'Source loveb account remains approachable for replay; withdrawal is staged after the completed account.',
                                    'starlet': 'Original model and generic evolutionary-biology book replace the named celebrity/book portrait; both Love speakers withdraw after their accounts using provisional visibility changes.',
                                    'apparatus': 'Original causal-model interaction; completing it unlocks deliberation without selecting a philosophy.',
                                    'reason': 'Paired history pages share encounter prose; complete accounts and all four Temple returns are retained.',
                                    'truth': 'Complete source arguments and all eight returns; exhibits and hearing-bench presentation are authored adaptations, not new testimony.',
                                    '7h': 'Trailing authoring directions beginning Another Temple scene are omitted from the delivered return account.',
                                    'truth_aliases': 'Use canonical a-history spoken accounts; c-history prosecutor pages have minor apostrophe/quote-spacing edits, with unchanged argument content.',
                                    'god': 'Complete guide accounts, question, both answers and sixteen final returns. All eight NotBeing question repetitions are retained. Poster/icon inspection is authored adaptation with original geometry; complete endings and the sole surgery route are separate scenes.',
                                    'god_doors': 'Exact final-gate outgoing links are read from canonical frontmatter, not a majority vote.',
                                    'routing': 'The reasondb frontmatter points to a-terminals; explicit Love/Reason history uses the b-terminal routes to 5c/5d.'}}
    (OUT / 'content.json').write_text(json.dumps(manifest, indent=2) + '\n')

def native_build():
    env = dict(os.environ, FYW_WF_ROOT=str(WF), FYW_SLICE_OUT=str(OUT))
    run('blender', '--background', '--python-exit-code', '1', '--python', ROOT/'blender_scene.py', env=env)
    tool = lambda name: WF / 'wftools' / (name + '-rs') / 'target/release' / name
    cwd = {'cwd': OUT}
    run(tool('iffcomp'), '-binary', '-o='+str(OUT/(LEVEL+'.lev.bin')), OUT/(LEVEL+'.lev'), **cwd)
    run(tool('levcomp'), LEVEL+'.lev.bin', WF/'wfsource/source/oas/objects.lc', LEVEL+'.lvl', WF/'wfsource/source/oas',
        '--mesh-dir', '.', '--iff-txt', LEVEL+'.iff.txt', '--textile-ini', LEVEL+'.ini', **cwd)
    run(tool('textile'), '-ini='+LEVEL+'.ini', '-Tlinux', '-transparent=0,0,0', '-pagex=1024', '-pagey=2048',
        '-permpagex=2048', '-permpagey=2048', '-palx=256', '-paly=8', '-alignx=w', '-aligny=h', '-flipyout', **cwd)
    run(tool('iffcomp'), '-binary', '-o='+LEVEL+'.iff', LEVEL+'.iff.txt', **cwd)
    wrapper = "{ 'L4' { 'ALGN' .align( 2048 ) } { 'RAM' 'OBJD' 4194304l 'PERM' 16777216l 'ROOM' 8388608l 'FLAG' 1l 1l } { 'ALGN' .align( 2048 ) } [ \"parmenides_slice.iff\" ] }\n"
    (OUT/(LEVEL+'-standalone.iff.txt')).write_text(wrapper)
    run(tool('iffcomp'), '-binary', '-o='+LEVEL+'-standalone.iff', LEVEL+'-standalone.iff.txt', **cwd)
    run(tool('cdpack'), WF/'wfsource/source/game/shell.fth', LEVEL+'-standalone.iff', '-o', OUT/'cd.iff', **cwd)

def package():
    provenance=json.loads((OUT/'runtime-provenance.json').read_text())
    if provenance['runtimeApkSha256']!=hashlib.sha256(RUNTIME.read_bytes()).hexdigest():
        raise RuntimeError('Runtime changed since its verified provenance receipt')
    for path,digest in provenance['sourceFilesSha256'].items():
        committed=subprocess.check_output(['git','show',provenance['sourceCommit']+':'+path],cwd=WF)
        if hashlib.sha256(committed).hexdigest()!=digest or committed!=(WF/path).read_bytes():
            raise RuntimeError('Engine source differs from its verified checkpoint: '+path)
    assets = OUT / 'apk/assets'
    res = OUT / 'apk/res/drawable'
    assets.mkdir(parents=True, exist_ok=True)
    res.mkdir(parents=True, exist_ok=True)
    shutil.copy2(OUT/'cd.iff', assets/'cd.iff')
    (assets/'wf_args.txt').write_text('--vram-width=5120\n--vram-height=2048\n--vram-slot-width=1024\n--vram-slot-height=2048\n--vram-perm-width=2048\n--vram-perm-height=2048\n')
    with zipfile.ZipFile(RUNTIME) as runtime:
        for name in ('assets/controller.html',):
            (assets/Path(name).name).write_bytes(runtime.read(name))
    layout = {'app':'parmenides','title':'Finding Your Way','threshold':0.5,
              'stick':{'up':2048,'down':4096,'right':8192,'left':16384},
              'buttons':[dict(id='A',bit=1,label='interact',x=.87,y=.68,size=1),
                         dict(id='B',bit=2,label='perspective',x=.87,y=.3,size=1),
                         dict(id='C',bit=4,label='journal',x=.68,y=.68,size=.8),
                         dict(id='D',bit=8,label='reduce motion',x=.68,y=.3,size=.8)],
              'hint':'Move and turn with the stick. A interacts; B switches view; C opens Journal.'}
    (assets/'layout.json').write_text(json.dumps(layout))
    # Launcher artwork is original procedural geometry, not a crop of the concept sheets.
    banner = Image.new('RGB',(640,360),'#19262c');d=ImageDraw.Draw(banner)
    d.rectangle((230,65,410,310),fill='#bbad8c');d.rounded_rectangle((255,92,385,312),65,fill='#283839')
    d.rectangle((253,190,386,320),fill='#283839')
    d.text((320,205),'Π',anchor='mm',font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf',112),fill='#e3c879')
    d.text((28,22),'PARMENIDES',font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',30),fill='#e3c879')
    d.text((28,310),'Finding Your Way',font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',24),fill='#f2eee4')
    banner.save(res/'tv_banner.png')
    icon=Image.new('RGB',(256,256),'#19262c');draw=ImageDraw.Draw(icon)
    draw.rounded_rectangle((62,40,194,216),66,fill='#bbad8c')
    draw.rectangle((62,112,194,216),fill='#bbad8c')
    draw.rounded_rectangle((82,64,174,216),46,fill='#9e5250')
    draw.rectangle((82,112,174,216),fill='#9e5250')
    draw.rectangle((56,210,200,222),fill='#c7a45b')
    draw.text((128,142),'Π',anchor='mm',font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf',96),fill='#e3c879')
    icon.save(res/'icon.png')
    manifest = '''<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="org.worldfoundry.wf_game.parmenides" android:versionCode="50" android:versionName="5.0">
<uses-sdk android:minSdkVersion="21" android:targetSdkVersion="34"/><uses-permission android:name="android.permission.INTERNET"/>
<uses-feature android:name="android.hardware.touchscreen" android:required="false"/><uses-feature android:name="android.software.leanback" android:required="false"/>
<application android:label="Finding Your Way" android:icon="@drawable/icon" android:banner="@drawable/tv_banner" android:isGame="true" android:hasCode="false" android:extractNativeLibs="true">
<activity android:name="android.app.NativeActivity" android:exported="true" android:screenOrientation="landscape" android:configChanges="orientation|keyboardHidden|screenSize|uiMode" android:launchMode="singleTask"><meta-data android:name="android.app.lib_name" android:value="wf_game"/>
<intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/><category android:name="android.intent.category.LEANBACK_LAUNCHER"/></intent-filter></activity></application></manifest>'''
    (OUT/'apk/AndroidManifest.xml').write_text(manifest)
    run(TOOLS/'aapt','package','-f','-M',OUT/'apk/AndroidManifest.xml','-S',OUT/'apk/res','-I',ANDROID,'-A',assets,'-F',OUT/'unsigned.apk')
    native = {}
    with zipfile.ZipFile(RUNTIME) as runtime, zipfile.ZipFile(OUT/'unsigned.apk','a') as bundle:
        for name in runtime.namelist():
            if name.startswith('lib/') and name.endswith('.so'):
                data = runtime.read(name);native[name]=hashlib.sha256(data).hexdigest()
                bundle.writestr(name,data,compress_type=zipfile.ZIP_STORED)
    if not any('armeabi-v7a' in n for n in native):
        raise RuntimeError('Missing Chromecast 32-bit runtime')
    if native!=provenance['nativeLibraries']:
        raise RuntimeError('Native libraries differ from the pinned engine receipt')
    key=OUT/'development-signing.p12'
    if not key.exists():
        run('keytool','-genkeypair','-keystore',key,'-storepass','android','-keypass','android','-alias','androiddebugkey','-keyalg','RSA','-keysize','2048','-validity','3650','-dname','CN=Finding Your Way Development')
    run(TOOLS/'zipalign','-f','4',OUT/'unsigned.apk',OUT/'aligned.apk')
    run(TOOLS/'apksigner','sign','--ks',key,'--ks-pass','pass:android','--out',OUT/'signed.apk',OUT/'aligned.apk')
    run(TOOLS/'apksigner','verify','--verbose',OUT/'signed.apk')
    digest=hashlib.sha256((OUT/'signed.apk').read_bytes()).hexdigest()
    frozen=OUT/('parmenides-'+digest[:16]+'.apk');shutil.copyfile(OUT/'signed.apk',frozen)
    receipt=dict(apk=str(frozen),sha256=digest,package='org.worldfoundry.wf_game.parmenides',nativeCode=True,
                 runtimeApk=str(RUNTIME),runtimeApkSha256=hashlib.sha256(RUNTIME.read_bytes()).hexdigest(),nativeLibraries=native,
                 levelSha256=hashlib.sha256((OUT/'cd.iff').read_bytes()).hexdigest(),engineSourceModified=True,
                 engineSourceCommit=provenance['sourceCommit'],engineProvenance=provenance)
    (OUT/'build-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))

if __name__ == '__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--package-only',action='store_true');parser.add_argument('--content-only',action='store_true');parser.add_argument('--visual-fixes',action='store_true');args=parser.parse_args()
    if not args.package_only:
        content(args.visual_fixes)
        if args.content_only:raise SystemExit(0)
        native_build()
    package()
