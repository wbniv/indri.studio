"""Freeze a tested APK, source provenance and evidence without overwriting milestones."""
import argparse
from datetime import datetime
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
import tempfile

ROOT=Path(__file__).resolve().parent
PROJECT=ROOT.parents[1]
OUT=ROOT/'build'
parser=argparse.ArgumentParser()
parser.add_argument('--name',required=True)
parser.add_argument('--evidence',type=Path,required=True)
parser.add_argument('--source-commit',default='HEAD')
args=parser.parse_args()
args.evidence=args.evidence.resolve()
if not re.fullmatch(r'[a-z0-9][a-z0-9.-]+',args.name):raise SystemExit('Invalid milestone directory name.')
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
read=lambda path:json.loads(path.read_text())
receipt=read(OUT/'build-receipt.json')
engine=receipt['engineProvenance']
engine_git=lambda *params:subprocess.check_output(['git',*params],cwd='/home/will/WorldFoundry-wbniv')
engine_sources={name:engine_git('show',engine['sourceCommit']+':'+name) for name in engine['sourceFilesSha256']}
if any(hashlib.sha256(data).hexdigest()!=engine['sourceFilesSha256'][name] for name,data in engine_sources.items()):
    raise SystemExit('Pinned engine source hashes differ.')
engine_patch=engine_git('show','--format=','--binary',engine['sourceCommit'],'--',*engine_sources)
if hashlib.sha256(engine_patch).hexdigest()!=engine['enginePatchSha256'] or receipt['nativeLibraries']!=engine['nativeLibraries']:
    raise SystemExit('Pinned engine patch/native library identity differs.')
apk=Path(receipt['apk'])
summary=read(args.evidence/'verification-summary.json')
device=read(args.evidence/'cast1-review/receipt.json')
visual=read(args.evidence/'cast1-review/visual-review.json')
if digest(apk)!=receipt['sha256'] or summary['apk_sha256']!=receipt['sha256'] or not summary['passed']:
    raise SystemExit('APK identity or audit verification failed.')
if device['result']!='completed' or not device['cleanup_verified'] or device['job']['request']['apk']!=receipt['sha256']+'.apk' or device['job']['request']['device']!='chromecast-test-01':
    raise SystemExit('Matching completed Chromecast 1 verification is required.')
if not visual['passed'] or visual['apk_sha256']!=receipt['sha256'] or visual['device_job']!=device['job']['id']:
    raise SystemExit('Matching visual device review is required.')
for capture in visual['captures']:
    if digest(args.evidence/'cast1-review'/capture['file'])!=capture['sha256']:
        raise SystemExit('Reviewed device capture changed: '+capture['file'])
git=lambda *params:subprocess.check_output(['git',*params],cwd=PROJECT)
commit=git('rev-parse',args.source_commit+'^{commit}').decode().strip()
sources=sorted(ROOT.glob('*.py'))+[ROOT/'.gitignore',ROOT/'README.md']+sorted((PROJECT/'src/content/pages').glob('*.md'))
sources += [PROJECT/'docs/plans/world-foundry-adventure.md',PROJECT/'docs/art-bible.md']
source_hashes={}
for path in sources:
    relative=str(path.relative_to(PROJECT))
    data=git('show',commit+':'+relative)
    if data!=path.read_bytes():raise SystemExit('Source differs from its checkpoint commit: '+relative)
    source_hashes[relative]=digest(path)
destination=PROJECT/'game/milestones'/args.name
if destination.exists():raise SystemExit('Milestone already exists; refusing overwrite.')
tools=Path('/home/will/android-sdk-local/build-tools/34.0.0')
signature=subprocess.check_output([str(tools/'apksigner'),'verify','--verbose',str(apk)])
badging=subprocess.check_output([str(tools/'aapt'),'dump','badging',str(apk)]).decode()
version=re.search(r"versionName='([^']+)'",badging).group(1)
milestone_version=version.split('-')[0]
archive_apk='parmenides-v'+milestone_version+'-'+receipt['sha256'][:16]+'.apk'
with tempfile.TemporaryDirectory(prefix='fyw-milestone-',dir=destination.parent) as staging:
    stage=Path(staging)
    shutil.copy2(apk,stage/archive_apk)
    archived_receipt=dict(receipt,apk=str(destination/archive_apk),originalBuildApk=str(apk))
    (stage/'build-receipt.json').write_text(json.dumps(archived_receipt,indent=2)+'\n')
    (stage/'signature-verification.txt').write_bytes(signature)
    # Snapshot actual Blender/level inputs and committed task/document versions.
    task_data=git('show',commit+':Taskfile.yml')
    committed_task=stage/'Taskfile.yml';committed_task.write_bytes(task_data)
    with tarfile.open(stage/'source-snapshot.tar.gz','w:gz') as archive:
        for path in sources:archive.add(path,arcname=str(path.relative_to(PROJECT)))
        archive.add(committed_task,arcname='Taskfile.yml')
        for name,data in {**engine_sources,'engine-change.patch':engine_patch}.items():
            info=tarfile.TarInfo('world-foundry-engine/'+name);info.size=len(data)
            archive.addfile(info,io.BytesIO(data))
        for name in ('parmenides_slice.blend','chapter.fth','content.json','actors.json','visual-gates.json','runtime-provenance.json','build-receipt.json'):
            path=OUT/name;archive.add(path,arcname=str(path.relative_to(PROJECT)))
        # Keep generated image inputs alongside the editable Blender scene.
        for path in sorted(OUT.glob('*.tga')):
            if path.name.startswith('atlas_'):continue
            archive.add(path,arcname=str(path.relative_to(PROJECT)))
    committed_task.unlink()
    with tarfile.open(stage/'test-evidence.tar.gz','w:gz') as archive:
        for path in sorted(args.evidence.rglob('*')):
            if path.is_file() and not ('desktop' in path.parts and path.suffix=='.png'):
                archive.add(path,arcname=str(path.relative_to(PROJECT)))
    manifest={'milestone':args.name,'archivedAt':datetime.now().astimezone().isoformat(),
              'version':version,'milestoneVersion':milestone_version,'chapter':read(OUT/'content.json')['chapter'],
              'apk':archive_apk,'sha256':receipt['sha256'],'levelSha256':receipt['levelSha256'],
              'sourceCommit':commit,'sourceFilesSha256':source_hashes,
              'sourceSnapshot':'source-snapshot.tar.gz','sourceSnapshotSha256':digest(stage/'source-snapshot.tar.gz'),
              'testEvidence':'test-evidence.tar.gz','testEvidenceSha256':digest(stage/'test-evidence.tar.gz'),
              'verification':summary,'deviceJob':device['job']['id'],'device':'chromecast-test-01',
              'package':receipt['package'],'engineSourceModified':receipt['engineSourceModified'],
              'engineSourceCommit':receipt['engineSourceCommit'],'engineProvenance':receipt['engineProvenance'],
              'productionOrder':'Complete all realms before art passes; commit and install each milestone on Chromecast 1',
              'knownIssues':['Session-local progress resets on relaunch','Face rendering investigation remains open','Camera obstruction/collision remains open',
                             *(['Text sheets can clip or be obscured; fixes deferred to v5.5 by request'] if not summary.get('visual_fixes') else []),
                             'Phone touch/thermal acceptance, animation, voice and journal history remain open',
                             'Ending dissolution/portal closure use provisional visibility; surgery uses a stable patient camera',
                             'Foundation rescue is provisional invisible collision support; guide departures and aether art are provisional']}
    (stage/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    files=sorted(path for path in stage.iterdir() if path.is_file())
    (stage/'SHA256SUMS').write_text(''.join(digest(path)+'  '+path.name+'\n' for path in files))
    for path in stage.iterdir():path.chmod(0o444)
    stage.rename(destination)
print(destination)
