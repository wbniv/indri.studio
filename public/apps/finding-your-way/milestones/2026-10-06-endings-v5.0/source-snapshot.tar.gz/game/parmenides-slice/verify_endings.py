"""Actual input through every eligible final edge, both views and terminal states."""
import time

def run(b,player,value,check,tap,position,read_pages,groups,content,ids,proc,smoke=False,capture=None):
    def fixture(index, delivered=1):
        row=content['god_histories']['9'+'abcdefghijklmnop'[index]]
        for m,v in ((102,0),(106,1),(154,1),(176,1),(195,1),(188,delivered),(197,index+1),
                    (107,row['love']),(155,row['reason']),(177,row['truth']),(196,row['god']),
                    (140,0),(189,0),(222,0),(223,0),(224,0),(225,0)):
            b.set_mailbox(m,v,idx=player)
        position(0,-3)
        return row
    def near(a,c,tolerance=.04):return abs(a-c)<tolerance
    for mode in (0,1):
        if value(101)!=mode:tap(2)
        for index,c in enumerate('a' if smoke else 'abcdefghijklmnop'):
            row=fixture(index)
            for x,slug,selected,realm in ((-7,'10a',1,5),(0,'10b',2,6),(7,'10c',3,7)):
                prefix=f'Ending 9{c} → {slug} camera={mode}: '
                fixture(index,delivered=0)
                position(x,-11);tap();read_pages(prefix+'waits for goddess',groups['final_wait'])
                check(prefix+'wait cannot choose or finish',value(189)==0 and value(225)==0)
                fixture(index);position(x,-11);tap()
                if slug not in row['doors']:
                    read_pages(prefix+'closed source edge',groups['final_closed'])
                    check(prefix+'forbidden Being cannot enter surgery or complete',value(102)==0 and value(189)==0 and value(222)==0 and value(225)==0)
                    continue
                check(prefix+'opens confirmation without entering',value(140)==groups['ending_confirm_'+slug][0] and value(102)==0 and value(189)==0)
                if index==0:
                    tap(16384);check(prefix+'Left cancels before entry',value(140)==0 and value(189)==0 and value(225)==0)
                    tap();tap(4);check(prefix+'Journal cancels before entry',value(140)==0 and value(189)==0 and value(225)==0)
                if index==0:tap()
                read_pages(prefix+'confirm transition',groups['ending_confirm_'+slug],groups['ending_'+slug][0])
                check(prefix+'scene entered with no premature completion',value(102)==realm and value(189)==selected and value(222)==1 and value(223)==0 and value(224)==0 and value(225)==0 and value(101)==mode)
                check(prefix+'only selected scene is visible',all(bool(value(m))==(realm==r) for m,r in ((254,5),(255,5),(256,6),(258,7),(213,8))))
                if capture and index==0:capture(slug+'-source-camera'+str(mode))
                if index==0:
                    # Cancel at the last source card, proving neither partial nor complete
                    # delivery is credited merely by opening the last page.
                    for _ in groups['ending_'+slug][:-1]:tap()
                    check(prefix+'last source page still not complete',value(225)==0 and value(223)==0)
                    tap(16384)
                    check(prefix+'closing source cannot finish or move to coda',value(140)==0 and value(102)==realm and value(223)==0 and value(224)==0 and value(225)==0)
                    if capture and index==0:capture(slug+'-scene-camera'+str(mode))
                    before=value(3010);tap(2048,15)
                    check(prefix+'scene supports actual free exploration',value(3010)>before+.1 and value(225)==0)
                    position(selected*100+400,0)
                    tap();check(prefix+'Select resumes only this exact source',value(140)==groups['ending_'+slug][0])
                    tap(4);check(prefix+'Journal closes source safely',value(140)==0 and value(223)==0 and value(225)==0)
                    tap(4);check(prefix+'Journal resumes exact source rather than Love journal',value(140)==groups['ending_'+slug][0])
                if slug=='10b':
                    read_pages(prefix+'complete Both account',groups['ending_10b'],groups['ending_101b'][0])
                    check(prefix+'only Both enters coda and remains unfinished',value(102)==8 and value(222)==2 and value(223)==1 and value(224)==0 and value(225)==0 and value(189)==2)
                    check(prefix+'patient camera keeps preference and hides player',value(101)==mode and value(250)==0 and bool(value(213)))
                    if capture and index==0:capture('101b-source-camera'+str(mode))
                    # Inspect live native actor coordinates, not generated script strings.
                    shot=b.mailbox_values.get((ids['FollowShot'],3011))
                    aim=b.mailbox_values.get((ids['LookAt'],3011))
                    check(prefix+'native patient shot points upward',near(shot,.9) and near(aim,3.4))
                    if index==0:
                        tap(2);tap(8)
                        check(prefix+'view and reduced motion cannot alter coda state',value(101)!=mode and value(102)==8 and value(224)==0 and value(225)==0 and near(b.mailbox_values.get((ids['FollowShot'],3011)),.9))
                        tap(2);tap(8)
                        tap(16384)
                        if capture and index==0:capture('101b-scene-camera'+str(mode))
                        before=(value(3009),value(3010));tap(2048,15)
                        check(prefix+'patient framing stays fixed when text closes',value(140)==0 and value(225)==0 and near(value(3009),before[0]) and near(value(3010),before[1]))
                    if index==0:tap()
                    read_pages(prefix+'only surgery source',groups['ending_101b'],groups['ending_complete'][0])
                else:
                    read_pages(prefix+'complete ending source',groups['ending_'+slug],groups['ending_complete'][0])
                check(prefix+'terminal completion matches chosen route',value(225)==1 and value(222)==3 and value(223)==1 and value(224)==(1 if slug=='10b' else 0) and value(189)==selected and value(102)==(8 if slug=='10b' else realm))
                check(prefix+'all four interpretations and exact history preserved',value(197)==index+1 and all(value(m)==row[k] for m,k in ((107,'love'),(155,'reason'),(177,'truth'),(196,'god'))) )
                if index==0:
                    tap(16384);tap();check(prefix+'completed review resumes without duplicating coda',value(140)==groups['ending_complete'][0] and value(225)==1)
                read_pages(prefix+'return for review',groups['ending_complete'])
                check(prefix+'Temple retains completion record and camera preference',value(102)==0 and value(225)==1 and value(189)==selected and value(188)==1 and value(101)==mode)
        # Real realm entry must clear downstream story completion.
        for entry,realm,state in (((0,-8),4,195),((-7,8),3,176),((7,8),2,154),((0,8),1,106)):
            fixture(0)
            for m in (189,222,223,224,225):b.set_mailbox(m,1,idx=player)
            b.set_mailbox(state,1,idx=player);position(*entry);tap()
            check(f'Ending camera={mode}: replay realm {realm} clears completion',value(102)==realm and all(value(m)==0 for m in (189,222,223,224,225)))
            tap(16384)
    check('ending native process alive',proc.poll() is None)
