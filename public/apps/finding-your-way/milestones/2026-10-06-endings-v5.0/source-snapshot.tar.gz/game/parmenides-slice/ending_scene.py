"""Original Blender grayboxes for light, combined passage, void and surgery."""
import math

def build_endings(Model, cube, arch):
    def sphere(model, *args, **kwargs):
        # The shared provisional sphere helper orders rings from north to south;
        # reverse its triangles here so these new close-view surfaces face out.
        start=len(model.faces)
        model.sphere(*args, **kwargs)
        model.faces[start:]=[tuple(reversed(face)) for face in model.faces[start:]]
    # All four scenes share GodRoom's resident text, but have separate footprints.
    support=cube('being_support',(500,0,-.3),(30,30,.6),'cream',1000,visibility=0)
    support['wf_Model Type']='None'
    cube('being_ocean',(500,0,.04),(30,30,.04),'blue',visibility=255)
    rings=Model()
    for radius in (3,6,10):
        for n in range(24):
            a=n*math.tau/24;b=(n+1)*math.tau/24
            rings.beam((radius*math.cos(a),radius*math.sin(a),.09),
                       (radius*math.cos(b),radius*math.sin(b),.09),.08,'gold')
    rings.object('being_ripples',(500,0,0),visibility=255)
    dome=Model()
    for x,y in ((-8,8),(8,8),(-8,-8),(8,-8)):
        dome.cone((x,y,0),.4,7,'cream',.1)
        sphere(dome,(x,y,7),(.6,.6,.6),'gold')
    dome.object('being_light',(500,0,0),visibility=254)
    arch('being_threshold',500,-6,'cream',254)
    cube('both_floor',(600,0,-.3),(18,22,.6),'stone',1000,visibility=256)
    arch('both_passage',600,3,'purple',256)
    triangles=Model()
    for pts,color in (([(-1.3,0,0),(1.3,0,0),(0,0,2)],'cream'),
                      ([(-1.3,.08,2),(1.3,.08,2),(0,.08,0)],'ink')):
        triangles.part(pts,[(0,1,2),(2,1,0)],color)
    triangles.object('both_triangles',(600,3.3,3.2),visibility=256)
    # Dark support is physically safe and visually groundless, without fall motion.
    support=cube('void_support',(700,0,-.3),(40,40,.6),'ink',1000,visibility=0)
    support['wf_Model Type']='None'
    enclosure=Model()
    enclosure.box((0,0,-.012),(40,40,.024),'ink')
    for x in (-20,20):enclosure.box((x,0,8),(.2,40,16),'ink')
    for y in (-20,20):enclosure.box((0,y,8),(40,.2,16),'ink')
    enclosure.box((0,0,16),(40,40,.2),'ink')
    enclosure.object('void_darkness',(700,0,0),visibility=258)
    arch('void_closing_portal',700,-4,'purple',257)
    face=Model()
    sphere(face,(0,0,2.8),(1.05,.42,1.5),'stone',10,6)
    for x in (-.42,.42):sphere(face,(x,-.4,3.15),(.24,.09,.3),'ink',8,4)
    sphere(face,(0,-.42,2.35),(.22,.08,.48),'ink',8,4)
    face.object('void_visage',(700,6,0),visibility=259)
    # No visible Old Woman: her complete source verse is captioned in the account.
    cube('surgery_floor',(800,0,-.3),(16,18,.6),'stone',1000,visibility=213)
    cube('patient_bed',(800,0,.25),(1.25,2.8,.45),'cream',visibility=213)
    cube('surgery_ceiling',(800,0,5),(16,18,.2),'cream',visibility=213)
    lamp=Model()
    lamp.cone((0,0,3.9),1.0,.16,'stone',1.0,16)
    for x,y in ((-.45,0),(.45,0),(0,.45),(0,-.45)):
        sphere(lamp,(x,y,3.84),(.23,.23,.08),'cream',8,4)
    lamp.beam((0,0,4),(0,0,5),.1,'stone')
    lamp.object('surgical_lamp',(800,.9,0),visibility=159)
    for i,(x,y) in enumerate(((-1.15,-.25),(1.15,-.25),(0,1.8)),1):
        surgeon=Model()
        surgeon.box((0,0,3.05),(.75,.5,.85),'blue')
        surgeon.box((0,0,2.47),(.58,.52,.54),'skin')
        surgeon.box((0,0,2.76),(.64,.58,.12),'blue')
        # A deliberate downward face plane is readable from the patient shot.
        # Double-sided flat accents avoid dependence on sphere face culling.
        def face_plane(x,y,z,w,h,color):
            surgeon.part([(x-w/2,y-h/2,z),(x+w/2,y-h/2,z),
                          (x+w/2,y+h/2,z),(x-w/2,y+h/2,z)],
                         [(0,1,2,3),(3,2,1,0)],color)
        face_plane(0,0,2.19,.58,.52,'skin')
        face_plane(0,-.10,2.17,.54,.30,'cream')
        for side in (-1,1):face_plane(side*.12,.12,2.16,.08,.065,'ink')
        face_plane(0,.22,2.15,.60,.075,'blue')
        surgeon.beam((-.38,0,2.9),(-.5,-.2,1.3),.13,'blue')
        surgeon.beam((.38,0,2.9),(.5,-.2,1.3),.13,'blue')
        sphere(surgeon,(-.5,-.2,1.28),(.13,.12,.09),'cream',6,3)
        sphere(surgeon,(.5,-.2,1.28),(.13,.12,.09),'cream',6,3)
        surgeon.object('surgeon_'+str(i),(800+x,y,0),visibility=159)
    tray=Model()
    tray.box((0,0,1.0),(1.2,.6,.09),'stone')
    for i in range(3):tray.box((-.35+i*.3,0,1.06),(.07,.4,.04),'cream')
    tray.object('surgical_instrument_tray',(802,1,0),visibility=159)
