"""Native pixel checks: every card in both views, plus the upward patient shot."""
import hashlib
import json
import subprocess
import re
import time
import numpy as np
from PIL import Image, ImageFilter


def inspect_frame(frame, template):
    actual=np.asarray(frame.convert('RGB'))
    # The prelit sheet's quiet base color survives RGB555 conversion. World
    # meshes are hidden in this modal view, leaving an unambiguous sheet region.
    base=np.array([32,41,49])
    mask=np.max(np.abs(actual.astype(int)-base),axis=2)<=10
    w,h=frame.size
    # Exclude the tiny runtime FPS plate; select the broad sheet band.
    yy=np.where(mask.sum(axis=1)>w*.2)[0]
    if len(yy)<50:return {'passed':False,'reason':'sheet not rendered'}
    y0,y1=int(yy.min()),int(yy.max())+1
    xx=np.where(mask[y0:y1].sum(axis=0)>(y1-y0)*.5)[0]
    if len(xx)<100:return {'passed':False,'reason':'sheet missing or heavily obscured'}
    x0,x1=int(xx.min()),int(xx.max())+1
    bounds=x0>=w*.06 and x1<=w*.94 and y0>=h*.06 and y1<=h*.94
    crop=frame.crop((x0,y0,x1,y1)).resize(template.size,Image.Resampling.BILINEAR)
    got=np.asarray(crop);want=np.asarray(template.convert('RGB'))
    ink_got=np.max(got,axis=2)>110;ink_want=np.max(want,axis=2)>110
    grow=lambda a:np.asarray(Image.fromarray(a.astype('uint8')*255).filter(ImageFilter.MaxFilter(5)))>0
    got_wide=grow(ink_got);want_wide=grow(ink_want)
    regions={}
    for label,(a,z) in {'title':(0,18),'body':(22,97),'controls':(98,109)}.items():
        expected=ink_want[a:z];rendered=ink_got[a:z]
        recall=float((got_wide[a:z]&expected).sum()/max(1,expected.sum()))
        precision=float((want_wide[a:z]&rendered).sum()/max(1,rendered.sum()))
        regions[label]={'recall':recall,'precision':precision}
    return {'passed':bool(bounds and all(r['recall']>=.90 and r['precision']>=.85 for r in regions.values())),
            'bounds':[x0,y0,x1,y1],'safe_bounds':bool(bounds),'regions':regions}


def capture_presented(target, bridge):
    # Run this harness without -record_video. The bridge reads the previous
    # default-framebuffer image; recording uses an FBO and makes that read stale.
    # Wait for the renderer below, and for the matching screenshot acknowledgement.
    target.unlink(missing_ok=True)
    with bridge._lock:start=len(bridge._inbox)
    bridge.send({'op':'screenshot','filename':str(target)})
    deadline=time.monotonic()+8
    while time.monotonic()<deadline:
        with bridge._lock:messages=bridge._inbox[start:]
        if any(m.get('op')=='screenshot_done' and m.get('filename')==str(target) for m in messages):
            return
        time.sleep(.02)
    raise RuntimeError('No matching native screenshot acknowledgement: '+str(target))

def run(b,player,value,check,tap,position,cards,content,ids,out,evidence):
    project=out.parents[2];root=project/'docs/diagnostics/parmenides/endings'
    rendered=root/'rendered-panels';rendered.mkdir(parents=True,exist_ok=True)
    receipt=json.loads((out/'build-receipt.json').read_text())
    results=[]
    gates=json.loads((out/'visual-gates.json').read_text())
    def frame(card,mode,patient=False):
        # Fixtures render every texture; separate native route tests prove that
        # gameplay chooses precisely these pages and terminal transitions.
        b.set_mailbox(140,card['id'],idx=player)
        b.wait_for_mailbox(player,140,card['id'],timeout=4)
        before=value(110) or 0;deadline=time.monotonic()+8
        while (value(110) or 0)<before+.2 and time.monotonic()<deadline:time.sleep(.02)
        time.sleep(.15)
        check('render fixture has exactly its sheet and no world meshes',value(140)==card['id'] and all(value(m)==0 for m in gates.values()))
        filename=f'card-{card["id"]:03d}-view-{mode}'+('-patient' if patient else '')+'.png'
        target=rendered/filename
        capture_presented(target,b)
        inspected=inspect_frame(Image.open(target),Image.open(out/f'card_{card["id"]:02d}.tga'))
        row=dict(card=card['id'],key=card['key'],camera=mode,patient=patient,file=filename,
                 sha256=hashlib.sha256(target.read_bytes()).hexdigest(),**inspected)
        results.append(row)
        if not row['passed']:print(json.dumps(row),flush=True)
        check(f'rendered {filename}: full bounds, intended title/body/controls unobscured',row['passed'])
    try:
        for mode in (0,1):
            if value(101)!=mode:tap(2)
            resident=None
            for card in cards.values():
                if card['atlas']!=resident:
                    # Stand close to architecture/speakers: the reading view
                    # must remain unobscured, including after native room cuts.
                    x,y,realm={'permanent':(10,9,0),'room':(306,1,3),'god':(400,30,4)}[card['atlas']]
                    b.set_mailbox(140,0,idx=player);b.set_mailbox(102,realm,idx=player)
                    b.set_mailbox(114,.25,idx=player);position(x,y)
                    resident=card['atlas'];time.sleep(.2)
                frame(card,mode)
            b.set_mailbox(140,0,idx=player);b.set_mailbox(102,8,idx=player);position(800,0)
            for index in content['groups']['ending_101b']+content['groups']['ending_complete']:
                frame(cards[index],mode,patient=True)
    finally:
        (root/'panel-render-audit.json').write_text(json.dumps({'build':receipt,'method':'Native default-framebuffer captures acknowledged by the debug bridge; full bounds and source-bitmap foreground precision/recall in title, body and controls',
            'results':results,'passed':len(results)==len(cards)*2+4 and all(r['passed'] for r in results)},indent=2)+'\n')
