"""Exact ending accounts; review controls remain separate from source dialogue."""
import re

ROUTES = {'10a': [], '10b': ['101b'], '10c': [], '101b': []}

def add_endings(add, source, pages):
    titles = {'10a': 'THE WAY OF BEING', '10b': 'THE WAY OF BOTH',
              '10c': 'THE WAY OF NONBEING', '101b': 'SURGERY / THE ASSISTANT'}
    routes = {}
    for slug, expected in ROUTES.items():
        routes[slug] = re.findall(r'slug: /(\w+)', (pages/(slug+'.md')).read_text().split('---',2)[1])
        if routes[slug] != expected:
            raise ValueError('Ending source routes changed: '+slug)
        add('ending_'+slug, titles[slug], source(slug), [slug], atlas='god')
    for slug, title in (('10a','BEING'),('10b','BOTH'),('10c','NOTBEING')):
        add('ending_confirm_'+slug, 'ENTER '+title+'?',
            'Select enters this ending. Left or Journal cancels before entry. In the scene, Select reads the complete source account. Closing a source sheet pauses it without completing the story; Select resumes from its first page. BOTH alone continues into surgery. Progress lasts for this session.', atlas='god')
    add('ending_complete', 'STORY COMPLETE / REVIEW',
        'You have finished this ending. BOTH finishes only after the surgery coda. Select returns to the final Temple for review, retaining your four choices and completion record. You can choose another permitted ending. Replaying an earlier realm clears downstream completion. Quitting restarts the chapter.', atlas='god')
    return routes
