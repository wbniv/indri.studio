"""Pin the authorized engine revision and the rebuilt runtime used by the chapter."""
import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

from build import OUT, PROJECT, RUNTIME, WF

parser=argparse.ArgumentParser()
parser.add_argument('--source-commit',default='HEAD')
args=parser.parse_args()
git=lambda *a:subprocess.check_output(['git',*a],cwd=WF)
commit=git('rev-parse',args.source_commit+'^{commit}').decode().strip()
digest=lambda data:hashlib.sha256(data).hexdigest()
paths=('CMakeLists.txt','wfsource/source/gfx/material.cc',
       'tests/texture_atlas_address_test.cc','tests/test-texture-atlas.sh')
hashes={}
for name in paths:
    data=git('show',commit+':'+name)
    if data!=(WF/name).read_bytes():raise SystemExit('Engine differs from checkpoint: '+name)
    hashes[name]=digest(data)
checks={
    'texture-unit':('/tmp/fyw-engine-texture-unit.log','PASS: 80 production FT3/GT3 atlas cases'),
    'old-material-negative':('/tmp/fyw-engine-texture-baseline.log','FT3 atlas address truncated'),
    'prelit-no-fps':('/tmp/fyw-engine-prelit-no-fps.log','PASS: shipped/reversed prelit scene frames identical'),
    'android-build':('/tmp/fyw-engine-texture-android-build.log','BUILD SUCCESSFUL'),
    'desktop-build':('/tmp/fyw-engine-texture-desktop-build.log','Built: /home/will/WorldFoundry-wbniv/engine/wf_game'),
}
evidence=PROJECT/'docs/diagnostics/parmenides/god/engine'
evidence.mkdir(parents=True,exist_ok=True)
logs={}
for key,(name,required) in checks.items():
    data=Path(name).read_bytes()
    if required.encode() not in data:raise SystemExit('Missing engine check: '+key)
    target=evidence/(key+'.log');target.write_bytes(data)
    logs[key]={'path':str(target.relative_to(PROJECT)),'sha256':digest(data)}
with zipfile.ZipFile(RUNTIME) as apk:
    native={name:digest(apk.read(name)) for name in apk.namelist() if name.startswith('lib/') and name.endswith('.so')}
if set(native)!={'lib/arm64-v8a/libwf_game.so','lib/armeabi-v7a/libwf_game.so'}:
    raise SystemExit('Expected both rebuilt Android native libraries')
provenance={
    'recordedAt':datetime.now().astimezone().isoformat(),'sourceCommit':commit,
    'sourceFilesSha256':hashes,'runtimeApkSha256':digest(RUNTIME.read_bytes()),
    'nativeLibraries':native,'desktopExecutableSha256':digest((WF/'engine/wf_game').read_bytes()),
    'enginePatchSha256':digest(git('show','--format=','--binary',commit,'--',*paths)),
    'verification':logs,'textureCases':80,
    'buildCommands':['task build','cd android && ./gradlew assembleCondoRelease --offline'],
    'textureTestCommand':'bash tests/test-texture-atlas.sh',
    'negativeCommand':'WF_ATLAS_MATERIAL_SOURCE=/tmp/fyw-material-before-texture.cc bash tests/test-texture-atlas.sh',
    'renderingCheck':'Existing prelit winding comparison with --no-fps; initial raw frame mismatch was 48 pixels confined to the changing FPS counter',
}
OUT.mkdir(parents=True,exist_ok=True)
(OUT/'runtime-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
shutil.copy2(OUT/'runtime-provenance.json',evidence/'runtime-provenance.json')
print(json.dumps(provenance,indent=2))
