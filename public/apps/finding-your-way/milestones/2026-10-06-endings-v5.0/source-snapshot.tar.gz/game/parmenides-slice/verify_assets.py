"""Verify exported UVs and bitmap pixels, including native texture-page addressing."""
import json
from pathlib import Path
import re
import struct
from PIL import Image

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'build'
content=json.loads((OUT/'content.json').read_text())
lev=(OUT/'parmenides_slice.lev').read_text()
objects={}
for section in re.split(r"\n\t\{\s*'OBJ'",lev)[1:]:
    name=re.search(r"\{ 'NAME' \"([^\"]+)\"",section).group(1)
    objects[name]=section
entries={};atlases={};count=0
for region,stem in (('permanent','Perm'),('room','Room0'),('god','Room1')):
    mapping=(OUT/(stem+'.ruv')).read_bytes()
    n=struct.unpack_from('<I',mapping,8)[0];count+=n
    atlases[region]=Image.open(OUT/(stem+'.tga')).convert('RGB')
    for index in range(n):
        name,frame,u,v,w,h,palx,paly,flags=struct.unpack_from('<33sb6hH',mapping,12+index*48)
        entries[name.split(b'\0')[0].decode()]=(region,u,v,w,h)
results=[]
def check(label,condition):
    results.append({'check':label,'passed':bool(condition)})
    if not condition:raise AssertionError(label)
def vertices(mesh):
    # WF MODL VRTX: 24-byte records, fixed32 UV followed by color and position.
    data=mesh.read_bytes();start=data.index(b'VRTX')+4
    size=struct.unpack_from('<I',data,start)[0];start+=4
    return [struct.unpack_from('<ii',data,start+i) for i in range(0,size,24)]
try:
    names={f'card_{c["id"]:02d}.tga' for c in content['cards']}
    check('one bitmap entry per exported card/sign',len(entries)==count and {n for n in entries if n.startswith('card_')}==names)
    check('individual textures restored without shared-atlas workaround',not any(n.startswith('atlas_') for n in entries))
    for texture,(region,u,v,w,h) in entries.items():
        name=texture[:-4];mesh=OUT/(name+'.iff')
        check(name+': mesh binds its individual bitmap',(texture+'\0').encode() in mesh.read_bytes())
        uv=vertices(mesh)
        check(name+': ordinary full-image Blender UVs restored',set(uv)=={(0,0),(65536,0),(0,65536),(65536,65536)})
        atlas=atlases[region]
        check(name+': full atlas coordinates fit bound texture',u>=0 and v>=0 and u+w<=atlas.width and v+h<=atlas.height)
        crop=atlas.crop((u,atlas.height-v-h,u+w,atlas.height-v)).transpose(Image.Transpose.FLIP_TOP_BOTTOM)
        original=Image.open(OUT/texture).convert('RGB')
        check(name+': atlas contains exactly intended pixels',original.size==(w,h) and original.point(lambda c:c>>3).tobytes()==crop.point(lambda c:c>>3).tobytes())
    for card in content['cards']:
        name=f'card_{card["id"]:02d}';section=objects[name]
        visibility=re.search(r'"Visibility Mailbox".*?\{ \'DATA\' (\d+)l',section).group(1)
        check(name+': actor uses its own mesh and visibility',f'"{name}.iff"' in section and int(visibility)==260+card['id'])
        check(name+': intended resident region',entries[name+'.tga'][0]==card['atlas'])
    boxes=list(entries.values())
    overlaps=any(a!=b and a[0]==b[0] and a[1]<b[1]+b[3] and b[1]<a[1]+a[3] and a[2]<b[2]+b[4] and b[2]<a[2]+a[4] for i,a in enumerate(boxes) for b in boxes[i+1:])
    check('atlas overlaps only for exact deduplicated bitmaps',not overlaps)
    check('real permanent cells exercise wide texture origins',any(r=='permanent' and u>=1024 for r,u,v,w,h in entries.values()))
    check('real room cells exercise tall texture origins',all(any(r==region and v>=1536 for r,u,v,w,h in entries.values()) for region in ('room','god')))
    check('reciprocal room adjacency keeps all dialogue assets available',
          "\"Adjacent Room 1\" } { 'STR' \"GodRoom\"" in objects['ChapterRoom'] and
          "\"Adjacent Room 1\" } { 'STR' \"ChapterRoom\"" in objects['GodRoom'])
    for stem in ('Perm','Room0','Room1'):
        check(stem+': texture below native chunk-size limit',(OUT/(stem+'.tga')).stat().st_size<5*1024*1024)
    coefficients=re.findall(r'"slope[A-D]".*?\{ \'DATA\' ([^\(]+)',objects['Player'])
    check('player box collider has no mesh-derived slope metadata',len(coefficients)==4 and all(float(v)==0 for v in coefficients))
    ending_actors=('being_support','being_ocean','being_ripples','being_light','being_threshold','both_floor','both_passage','both_triangles','void_support','void_darkness','void_closing_portal','void_visage','surgery_floor','patient_bed','surgery_ceiling','surgical_lamp','surgeon_1','surgeon_2','surgeon_3','surgical_instrument_tray')
    for name in ending_actors:
        check(name+': original exported ending geometry',name in objects and (OUT/(name+'.iff')).exists())
    check('ending footprints remain inside resident God room',all(str(x)+'.000' in objects['GodRoom'] for x in (360,850)))
    check('Old Woman remains unseen',not any('old_woman' in name or 'witch' in name for name in objects))
    gates=json.loads((OUT/'visual-gates.json').read_text())
    for name,section in objects.items() if content.get('visual_fixes') else []:
        if name.startswith('card_'):continue
        if '"Model Type"' in section and re.search(r'"Model Type".*?DATA\' 1l',section):
            vis=re.search(r'"Visibility Mailbox".*?DATA\' (\d+)l',section)
            check(name+': world rendering uses modal-safe derived visibility',vis is not None and (int(vis.group(1))==0 or int(vis.group(1)) in gates.values()))
    if content.get('visual_fixes'):check('derived visibility fits the level mailbox allocation',max(gates.values())<640 and len(gates)==len(set(gates.values())))
    else:check('v5.0 excludes the pending global text visibility fixes',not gates)
    check('God room has directional and ambient lights',all(n in objects for n in ('GodDirectional','GodAmbient')))
finally:
    target=ROOT.parents[1]/'docs/diagnostics/parmenides/endings/asset-audit.json'
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(json.dumps({'build':json.loads((OUT/'build-receipt.json').read_text()),'results':results},indent=2)+'\n')
print(f'{len(results)} exported bitmap/UV checks passed')
