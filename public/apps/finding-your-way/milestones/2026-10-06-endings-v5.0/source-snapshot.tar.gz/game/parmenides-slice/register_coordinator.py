"""Prepare/deploy the single reviewed app-registry addition via WF's admin tool.

No device harness or direct device control. The existing administrator deployer
owns draining, service restart, reservation retention and readiness checks.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path

ROOT=Path(__file__).resolve().parent
STAGE=ROOT/'build/coordinator-stage'
SOURCE=Path('/opt/wf-device-coordinator/scripts/wf_device/workflows.py')
HELPER=Path('/home/will/WorldFoundry-wbniv/android/bomberman/deploy-coordinator.py')
def sha(data):return hashlib.sha256(data).hexdigest()
def prepare():
    original=SOURCE.read_bytes()
    old="APPS = {'aquarium', 'condo', 'snowgoons', 'smb', 'qbert', 'patchwork', 'bomberman'}"
    new=old[:-1]+", 'parmenides'}"
    if original.decode().count(old)!=1:raise RuntimeError('Registry changed: inspect before preparing')
    updated=original.decode().replace(old,new,1).encode()
    (STAGE/'scripts/wf_device').mkdir(parents=True,exist_ok=True)
    (STAGE/'android/bomberman').mkdir(parents=True,exist_ok=True)
    (STAGE/'scripts/wf_device/workflows.py').write_bytes(updated)
    compile(updated,str(SOURCE),'exec')
    (STAGE/'android/bomberman/deploy-review.json').write_text(json.dumps({'workflows.py':{'old':sha(original),'new':sha(updated)}},indent=2)+'\n')
    (STAGE/'review.json').write_text(json.dumps({'change':'Add parmenides to APPS only','helper':str(HELPER),'helperSha256':sha(HELPER.read_bytes())},indent=2)+'\n')
    print('Prepared one-line registry change; no engine or workflow implementation changes.')
def deploy():
    if os.geteuid()!=0:raise RuntimeError('The coordinator registry is protected; use the administrator deployment path.')
    review=json.loads((STAGE/'review.json').read_text())
    if sha(HELPER.read_bytes())!=review['helperSha256']:raise RuntimeError('Administrator helper changed after review')
    spec=importlib.util.spec_from_file_location('reviewed_wf_coordinator_deploy',HELPER)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    module.ROOT=STAGE
    module.main()
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--deploy',action='store_true');args=parser.parse_args()
    deploy() if args.deploy else prepare()
