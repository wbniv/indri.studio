"""Original Blender hill, inspectable imagery and provisional aether geometry."""
import math

def height(y):return max(0,min(5.2,(y+5)*.16))

def build_god(Model,cube,arch,label,human):
    # One shallow continuous wedge uses the runtime's existing slope/mesh support.
    m=Model()
    verts=[(-3,-5,-1),(3,-5,-1),(3,27.5,-1),(-3,27.5,-1),
           (-3,-5,0),(3,-5,0),(3,27.5,5.2),(-3,27.5,5.2)]
    m.part(verts,[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],'stone')
    m.object('god_path_sides',(400,0,0))
    surface=Model()
    surface.part([(-3,0,0),(3,0,0),(3,32.5,5.2),(-3,32.5,5.2)],[(0,1,2,3)],'stone')
    surface.object('god_rising_path',(400,-5,0),mass=1000)
    cube('god_entry_landing',(400,-7,-.4),(12,5,.8),'stone',1000)
    cube('god_upper_landing',(400,31,4.8),(14,8,.8),'stone',1000)
    for x,y,key in ((397,6,'poster'),(403,18,'icon'),(397,24,'question')):
        top=height(y)
        cube('god_'+key+'_landing',(x,y,top-.2),(3.5,2.5,.4),'stone',1000)
    forest=Model()
    for side in (-1,1):
        for i in range(12):
            x=400+side*(7+(i%3)*1.8);y=-4+i*3.3;z=height(y)-1.5
            forest.cone((x,y,z),.28,4.5,'brown',.16,7)
            forest.cone((x,y,z+3.4),1.8,3.4,'green',.12,8)
    forest.object('god_forest')
    peak=Model();peak.cone((0,0,0),8,12,'purple',.3,9);peak.object('god_distant_peak',(400,44,3))
    for name,y,coat,visibility,sign,sign_visibility in (
        ('YoungMan',1,'ink',201,'young_sign',203),('HolyMan',13,'cream',202,'holy_sign',204)):
        z=height(y);person=human(name,(400,y,z),coat=coat);person.rotation_euler.z=-math.pi/2
        person['wf_Visibility Mailbox']=visibility
        obj=label(sign,sign,(400,y-.35,z+2.5),3.5);obj['wf_Visibility Mailbox']=sign_visibility
    for x,y,key in ((397,6,'poster'),(403,18,'icon')):
        z=height(y);m=Model();m.box((0,0,1.3),(1.6,.14,2.3),'brown');m.box((0,-.085,1.3),(1.3,.015,2),'cream')
        if key=='poster':
            for i in range(4):
                m.box((-.4+(i%2)*.8,-.11,.75+(i//2)*1.1),(.4,.025,.12),('blue','red','green','purple')[i])
                m.box((-.55+(i%2)*.8,-.11,1+(i//2)*1.1),(.1,.025,.55),'ink')
        else:
            m.cone((0,-.13,1.55),.38,.06,'gold',sides=12)
            m.sphere((0,-.14,1.6),(.15,.06,.16),'skin')
            m.box((0,-.14,1.12),(.4,.04,.6),'gold');m.box((0,-.14,.6),(.85,.04,.15),'stone')
        m.object('god_'+key,(x,y,z))
        obj=label('god_'+key+'_sign',key,(x,y-.4,z+2.8),3.5);obj['wf_Visibility Mailbox']=220 if key=='poster' else 221
    cube('god_question_plinth',(397,24,height(24)+.25),(1,.7,.5),'purple')
    obj=label('question_sign','YOUR QUESTION',(397,23.6,height(24)+2.8),4);obj['wf_Visibility Mailbox']=205
    for x,color,key in ((396,'cream','gbeing'),(404,'ink','gnotbeing')):
        portal=arch('god_'+key,x,32,color);portal.location.z=5.2
        label(key+'_sign',key,(x,31.65,9.05),4)
    back=arch('god_back',400,-9,'gold');back_sign=label('gback_sign','TEMPLE',(400,-8.65,3.85),3);back_sign.rotation_euler.z=math.pi
    for x,key,color,vis,sign_vis in ((-7,'final_being','cream',214,217),(0,'final_both','purple',215,218),(7,'final_notbeing','ink',216,219)):
        portal=arch(key,x,-12,color,vis)
        obj=label(key+'_sign',key,(x,-11.65,3.85),4);obj.rotation_euler.z=math.pi;obj['wf_Visibility Mailbox']=sign_vis
    # Whole-object rings establish the aether change; final motion/art is deferred.
    rings=Model()
    for r,z,color in ((4.7,7.2,'gold'),(3.7,8,'cream'),(2.7,8.7,'blue')):
        for i in range(24):
            a=i*math.tau/24;b=(i+1)*math.tau/24
            rings.beam((r*math.cos(a),r*math.sin(a),z),(r*math.cos(b),r*math.sin(b),z),.16,color)
    rings.object('aether_rings',visibility=212)
