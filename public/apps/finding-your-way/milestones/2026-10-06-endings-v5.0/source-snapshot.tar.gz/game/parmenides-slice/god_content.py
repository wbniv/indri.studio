"""God's complete source accounts and exact final-gate outgoing edges."""
import re

def add_god(add, source, pages):
    aliases=lambda stem:[stem+c for c in 'abcdefgh']
    def card(key,title,text,slugs=()):
        account=key in ('young_man','holy_man','god_question','god_counsel_being','god_counsel_notbeing') or key.startswith('return_9')
        add(key,title,text,slugs,atlas='god' if account else 'permanent')
    card('god_intro','THE HILL',
         'Follow the rising path. Hear the young man, inspect the poster, meet the holy man and inspect the icon. At the upper landing, consider your question before choosing either threshold. Completing the encounters unlocks a choice; it never chooses for you. The TEMPLE doorway leaves without committing. If you fall from the path, you return to a safe landing with your encounters intact.',aliases('god1'))
    card('young_man','THE YOUNG MAN',source('god1a')+' '+source('godaa'),aliases('god1')+aliases('goda'))
    card('holy_man','THE HOLY MAN',source('god2a')+' '+source('godba'),aliases('god2')+aliases('godb'))
    card('poster','POSTER / CHANGING MODELS',
         'This original poster shows several broken frames around one empty centre. Compare the young man\'s claim that traditions give different models of God with his further claim that religion controls people. The picture is a prompt for inspection, not evidence that either claim is true. Inspecting it does not choose a threshold.',aliases('goda'))
    card('icon','ICON / A FOUNDATION',
         'This original icon shows a luminous figure above a rock. The holy man calls God the foundation of meaning, ideals and action. Compare that claim with the young man\'s demand to build your own perspective. This image illustrates an account; it does not prove it or choose for you.',aliases('godb'))
    card('god_question','YOUR QUESTION',source('godca'),aliases('godc'))
    card('god_affirm','ENTER GOD / BEING?',
         'Follow the holy man through the white threshold. Select continues the source\'s answer. Its final page commits Being and returns you to your exact final Temple history. Left or Journal cancels before commitment.',aliases('godbeing'))
    card('god_deny','ENTER GOD / NOTBEING?',
         'Follow the young man through the black threshold. Select continues the source\'s unanswered question, repeated eight times. Its final page commits NotBeing and returns you to your exact final Temple history. Left or Journal cancels before commitment.',aliases('godnotbeing'))
    card('god_counsel_being','THE WHITE THRESHOLD',source('godbeinga'),aliases('godbeing'))
    card('god_counsel_notbeing','THE BLACK THRESHOLD',source('godnotbeinga'),aliases('godnotbeing'))
    card('god_locked','COMPLETE THE HILL ENCOUNTERS',
         'Hear both guides, inspect the poster and icon, and finish YOUR QUESTION at the upper landing. Then choose BEING or NOTBEING and finish its answer. The TEMPLE doorway leaves without choosing. Visiting every encounter alone does not commit God.',aliases('godc'))
    card('god_wait','FOLLOW THE RISING PATH',
         'Hear the young man first. Then inspect his poster and meet the holy man further up the path. After his account, inspect the icon. Finish both accounts and both inspections before considering YOUR QUESTION at the upper landing.',aliases('god1')+aliases('god2'))
    card('god_unavailable','COMMIT TRUTH FIRST',
         'God opens after a Truth commitment. Hear both lawyers and the student, inspect and present both exhibits, choose BEING or NOTBEING and finish that threshold\'s counsel. The TEMPLE doorway leaves without choosing. Your Love, Reason and Truth interpretations will be retained.',['7'+c for c in 'abcdefgh'])
    histories={}
    for index,c in enumerate('abcdefghijklmnop'):
        slug='9'+c
        edges=re.findall(r'slug: /(10[abc])', (pages/(slug+'.md')).read_text().split('---',2)[1])
        histories[slug]={'love':1 if index<8 else -1,'reason':1 if index%8<4 else -1,
                         'truth':1 if index%4<2 else -1,'god':1 if index%2==0 else -1,'doors':edges}
        card('return_'+slug,'THE FINAL TEMPLE',source(slug),[slug])
    card('final_wait','HEAR THE GODDESS',
         'Finish the goddess\'s final Temple account before choosing a way. Approach her and press Select. Your exact four-realm history determines which ending doors can open.',['9'+c for c in 'abcdefghijklmnop'])
    card('final_closed','THIS WAY IS CLOSED',
         'The Being ending is closed for this exact history. Hear the goddess, then choose one of the remaining ways: BOTH or NOTBEING. This restriction comes from the source gate\'s outgoing links.',['9'+c for c in 'bcdefghijklmnop'])
    return histories
