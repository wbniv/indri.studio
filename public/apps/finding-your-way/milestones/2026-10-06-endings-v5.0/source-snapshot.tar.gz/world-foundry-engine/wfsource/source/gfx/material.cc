//=============================================================================
// Material.cc:
// Copyright ( c ) 1997,1998,1999,2000,2001,2002 World Foundry Group  
// Part of the World Foundry 3D video game engine/production environment
// for more information about World Foundry, see www.worldfoundry.org
//==============================================================================
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// Version 2 as published by the Free Software Foundation
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
// or see www.fsf.org

// ===========================================================================
// Description:
//
// Original Author: Kevin T. Seghetti
//============================================================================

#include <gfx/material.hp>
#include <gfx/rendobj2.hp>
#include <gfx/rendobj3.hp>
#include <gfx/vmem.hp>      // VideoMemory::VRAMTransient{Width,Height} for the UV page bound

//============================================================================

Texture emptyTexture = {"",0,320,0,0,0,0,0,0,16};

//============================================================================

Material::Material()
{
}

//============================================================================

Material::Material(const _MaterialOnDisk& mod, const Texture& texture, const PixelMap* texturePixelMap)
:
	_color(mod._color),
	// I should add a smoothing group flag
	_materialFlags(mod._materialFlags),
	_texture(texture),
    _texturePixelMap(texturePixelMap)
{
	ValidateRenderMask(_materialFlags);
	Construct();
	Validate();
}

//============================================================================

pRenderObj3DFunc
Material::Get3DRenderObjectPtr() const
{
	static const pRenderObj3DFunc _rendererList[] =
	{
			#include <gfx/glpipeline/renderer.ext>
	};
	ValidateRenderMask(_materialFlags);
	return _rendererList[_materialFlags&RENDERER_SELECTION_MASK];
}

//============================================================================

Material::Material(Color color, int materialFlags,const Texture& texture,const PixelMap* texturePixelMap)
	:
	_color(color),
   _materialFlags(materialFlags),
	_texture(texture),
    _texturePixelMap(texturePixelMap)

{
	ValidateRenderMask(_materialFlags);
	Construct();
	Validate();
}

//============================================================================

//enum
//{
//	TEXTURE_TRANS_HALF_BACK_HALF_PRIMITIVE,
//	TEXTURE_TRANS_ONE_BACK_ONE_PRIMITIVE,
//	TEXTURE_TRANS_ONE_BACK_NEGATIVE_ONE_PRIMITIVE,
//	TEXTURE_TRANS_ONE_BACK_QUARTER_PRIMITIVE
//};

//-----------------------------------------------------------------------------

void
Material::Construct()
{

   // kts kludge until all models have been updated to be flat shaded

   if(_materialFlags & GOURAUD_SHADED)
      _materialFlags &= ~GOURAUD_SHADED;

	// kts kludge until we can get translucency from material
	if(_materialFlags & TEXTURE_MAPPED)
	{
		// Diagnostic (2026-04-19): log per-texture translucency pickup so we
		// can see which materials flag translucent at load time. Suspects:
		// roof textures (G_*shakes*) picking up bTranslucent from textile-rs
		// setting `has_transparent=true` on any texture whose pixel data
		// contains col_transparent (0x0000 by default) — even a single black
		// pixel flips the flag. Remove once the roof transparency question
		// is answered.
		std::cerr << "material: texture=\"" << _texture.szTextureName
		          << "\"  bTranslucent=" << int(_texture.bTranslucent)
		          << "  bitdepth=" << int(_texture.bitdepth)
		          << "  flags_in=0x" << std::hex << _materialFlags
		          << std::dec
		          << (_texture.bTranslucent ? "  ← flipping HALF_BACK_HALF_PRIM" : "")
		          << std::endl;

		if(_texture.bTranslucent)
			_materialFlags |= TEXTURE_TRANSLUCENCY_HALF_BACK_HALF_PRIMITIVE;
	}

	_renderer3D = Get3DRenderObjectPtr();

	switch ( _materialFlags & POLYGON_TYPE_FLAGS )
	{
		case FLAT_SHADED|SOLID_COLOR:
		{
			POLY_F3 poly;
			setPolyF3(&poly);
			Color color = GetColor();
			setRGB0(&poly, color.Red(),color.Green(),color.Blue());
			_cdColor = *((P_CODE*)&poly.r0);  // copy cd & color
			break;
		}
		case GOURAUD_SHADED|SOLID_COLOR:
		{
//         assert(0);           // kts we don't seem to have color by vertex finished
			POLY_G3 poly;
			setPolyG3(&poly);
			Color color = GetColor();
			setRGB0(&poly, color.Red(),color.Green(),color.Blue());
			setRGB1(&poly, color.Red(),color.Green(),color.Blue());
			setRGB2(&poly, color.Red(),color.Green(),color.Blue());
			_cdColor = *((P_CODE*)&poly.r0);  // copy cd & color
			break;
		}
		case FLAT_SHADED|TEXTURE_MAPPED:
		{
			POLY_FT3 poly;
			setPolyFT3(&poly);
			Color color = GetColor();
			setRGB0((&poly), color.Red(),color.Green(),color.Blue());
			_cdColor = *((P_CODE*)&poly.r0);  // copy cd & color
			break;
		}
		case GOURAUD_SHADED|TEXTURE_MAPPED:
		{
         //assert(0);           // kts we don't seem to have color by vertex finished
			POLY_GT3 poly;
			setPolyGT3(&poly);
			Color color = GetColor();
			setRGB0(&poly, color.Red(),color.Green(),color.Blue());
			setRGB1(&poly, color.Red(),color.Green(),color.Blue());
			setRGB2(&poly, color.Red(),color.Green(),color.Blue());
			_cdColor = *((P_CODE*)&poly.r0);  // copy cd & color
			break;
		}
		default:
			AssertMsg( 0, "_materialFlags = " << std::hex << _materialFlags );
			break;
	}
}

//-----------------------------------------------------------------------------

#define CLIP01(u) \
	if(u > Scalar::one) \
	{ \
		DBSTREAM5( cout << "clipping uv coordinate to 0-1" << std::endl; ) \
		u = Scalar::one; \
	} \
	if(u <  Scalar::zero) \
	{ \
		DBSTREAM5( cout << "clipping uv coordinate to 0-1" << std::endl; ) \
		u = Scalar::zero; \
	} \
	assert(u <= Scalar::one); \
	assert(u >= Scalar::zero);


#define DirectXCalcVRAMuv(uin,vin,resultu,resultv) \
	{ \
	Scalar u(uin); \
	Scalar v(vin); \
	CLIP01(u); \
	CLIP01(v); \
	Scalar vramU = (u *	int(_texture.w-1)) + Scalar(_texture.u,0); \
	AssertMsg(vramU < SCALAR_CONSTANT(Display::VRAMWidth),"u = " << u << ", width= " << _texture.w << ", u = " << _texture.u); \
	AssertMsg(vramU >= Scalar::zero,"u = " << u << ", width= " << _texture.w << ", u = " << _texture.u << ", vramU = " << vramU); \
	resultu = float(vramU.WholePart())/Display::VRAMWidth; \
	Scalar vramV = (v * int(_texture.h-1)) + Scalar(_texture.v,0); \
	AssertMsg(vramV < SCALAR_CONSTANT(Display::VRAMHeight),"vramV = " << vramV); \
	AssertMsg(vramV >= Scalar::zero,"v = " << v << ", height= " << _texture.h << ", v = " << _texture.v << ", vramV = " << vramV); \
	resultv = float(vramV.WholePart())/Display::VRAMHeight; \
	}

//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------

// TEXTURE_PAGE_XSIZE / YSIZE are now runtime — they read the transient slot
// dimensions set by --vram-slot-width / --vram-slot-height (or the 256 default).
// See docs/plans/2026-05-30-uv-int16-widening.md and
// docs/plans/2026-05-30-runtime-vram-cli-overrides.md.
#define TEXTURE_PAGE_XSIZE (VideoMemory::VRAMTransientWidth)
#define TEXTURE_PAGE_XSTART_BOUNDRY 64
#define TEXTURE_PAGE_YSIZE (VideoMemory::VRAMTransientHeight)
#define TEXTURE_PAGE_YSTART_BOUNDRY 256


#define WFdumpTPage(tpage)						\
	((GetGraphType()==1||GetGraphType()==2)?			\
	printf("tpage: (%d,%d,%d,%d)\n",				\
			   ((tpage)>>9)&0x003,((tpage)>>7)&0x003,	\
			   ((tpage)<<6)&0x7c0,((tpage)<<3)&0x300):	\
	printf("tpage: (%d,%d,%d,%d)\n",				\
			   ((tpage)>>7)&0x003,((tpage)>>5)&0x003,	\
			   ((tpage)<<6)&0x7c0,				\
			   (((tpage)<<4)&0x100)+(((tpage)>>2)&0x200)))



#if defined(VIDEO_MEMORY_IN_ONE_PIXELMAP)
#define TexturePage(texture) getTPage(TEXTURE_MODE_16BIT_DIRECT,((_materialFlags>>8)&0x3),(texture).u,(texture).v)
#define CalcVRAMuv(uin,vin,resultu,resultv,texture) \
	{ \
	Scalar u(uin); \
	Scalar v(vin); \
	CLIP01(u); \
	CLIP01(v); \
	Scalar vramU = (u *	int(texture.w-1)) + Scalar(texture.u%TEXTURE_PAGE_XSTART_BOUNDRY,0); \
	AssertMsg(vramU < SCALAR_CONSTANT(TEXTURE_PAGE_XSIZE),"u = " << u << ", width= " << texture.w << ", u = " << texture.u); \
	AssertMsg(vramU >= Scalar::zero,"u = " << u << ", width= " << texture.w << ", u = " << texture.u << ", vramU = " << vramU); \
	resultu = vramU.WholePart(); \
	Scalar vramV = (v * int(texture.h-1)) + Scalar(texture.v%TEXTURE_PAGE_YSTART_BOUNDRY,0); \
	AssertMsg(vramV < SCALAR_CONSTANT(TEXTURE_PAGE_YSIZE),"vramV = " << vramV); \
	AssertMsg(vramV >= Scalar::zero,"v = " << v << ", height= " << texture.h << ", v = " << texture.v << ", vramV = " << vramV); \
	resultv = vramV.WholePart(); \
	}
#else
// Modern backends bind a PixelMap directly. Carry complete atlas coordinates
// in the widened primitive UVs; PSX texture-page masks truncate origins >=1024.
// Permanent and room textures may have different sizes, so validate against
// the bound map rather than the configured transient slot dimensions.
#define TexturePage(texture) 0
#define CalcVRAMuv(uin,vin,resultu,resultv,texture) \
    { \
    Scalar u(uin), v(vin); \
    CLIP01(u); CLIP01(v); \
    Scalar atlasU = (u * int((texture).w-1)) + Scalar((texture).u,0); \
    Scalar atlasV = (v * int((texture).h-1)) + Scalar((texture).v,0); \
    AssertMsg(_texturePixelMap, "textured material has no PixelMap"); \
    AssertMsg(atlasU >= Scalar::zero && atlasU < Scalar(_texturePixelMap->GetBaseXSize(),0), "atlas U outside bound texture: " << atlasU); \
    AssertMsg(atlasV >= Scalar::zero && atlasV < Scalar(_texturePixelMap->GetBaseYSize(),0), "atlas V outside bound texture: " << atlasV); \
    AssertMsg(atlasU.WholePart() <= 65535 && atlasV.WholePart() <= 65535, "atlas UV exceeds primitive storage"); \
    resultu = uint16(atlasU.WholePart()); \
    resultv = uint16(atlasV.WholePart()); \
    }
#endif

//-----------------------------------------------------------------------------

void
Material::InitPrimitive(Primitive& prim, const Vertex3D& vertex0, const Vertex3D& vertex1, const Vertex3D& vertex2) const
{
    Validate();
	switch ( _materialFlags & POLYGON_TYPE_FLAGS )
	{
		case FLAT_SHADED|SOLID_COLOR:
		{
			POLY_F3* poly = (POLY_F3*)&prim;
			setPolyF3(poly);
			Color color = GetColor();
			setRGB0(poly, color.Red(),color.Green(),color.Blue());
			break;
		}
		case GOURAUD_SHADED|SOLID_COLOR:
		{
			POLY_G3* poly = (POLY_G3*)&prim;
			setPolyG3(poly);
			setRGB0(poly, vertex0.color.Red(),vertex0.color.Green(),vertex0.color.Blue());
			setRGB1(poly, vertex1.color.Red(),vertex1.color.Green(),vertex1.color.Blue());
			setRGB2(poly, vertex2.color.Red(),vertex2.color.Green(),vertex2.color.Blue());
			break;

		}
		case FLAT_SHADED|TEXTURE_MAPPED:
		{
			POLY_FT3* poly = (POLY_FT3*)&prim;
			setPolyFT3(poly);
			Color color = GetColor();
			setRGB0(poly, color.Red(),color.Green(),color.Blue());
#pragma message ("KTS: handle 4 & 8 bit textures as soon as I get data from textile")
//			poly->tpage = getTPage(TEXTURE_MODE_16BIT_DIRECT,TEXTURE_TRANS_HALF_BACK_HALF_PRIMITIVE,_texture.u,_texture.v);
			poly->tpage = TexturePage(_texture);

            poly->pPixelMap = _texturePixelMap;

			if(_materialFlags & TEXTURE_TRANSLUCENCY_ON)
				setSemiTrans(poly,1);

//			cout << "vertex uv:" <<
//				vertex0.u << "," << vertex0.v << ";" <<
//				vertex1.u << "," << vertex1.v << ";" <<
//				vertex2.u << "," << vertex2.v << std::endl;

//			WFdumpTPage(poly->tpage);
//			cout << "Texture:" << _texture << std::endl;

			Scalar minU = vertex0.u.Min(vertex1.u).Min(vertex2.u);
			Scalar minV = vertex0.v.Min(vertex1.v).Min(vertex2.v);

			Scalar maxU = vertex0.u.Max(vertex1.u).Max(vertex2.u);
			Scalar maxV = vertex0.v.Max(vertex1.v).Max(vertex2.v);

//			cout << "minUV = " << minU << "," << minV << std::endl;
//			cout << "maxUV = " << maxU << "," << maxV << std::endl;

			Scalar offsetU = minU;
			Scalar offsetV = minV;
			if(maxU-minU > Scalar::one)
			{
				offsetU = (minU+maxU)/Scalar::two;
				// + SCALAR_CONSTANT(0.5);
			}

			if(maxV-minV > Scalar::one)
			{
 				offsetV = (minV+maxV)/Scalar::two;
				// + SCALAR_CONSTANT(0.5);
			}

			offsetU = Scalar(offsetU.WholePart(),0);
			offsetV = Scalar(offsetV.WholePart(),0);
//			cout << "minUV = " << offsetU << "," << offsetV << std::endl;

			uint16 u0;
			uint16 v0;
			CalcVRAMuv(vertex0.u-offsetU,vertex0.v-offsetV,u0,v0,_texture);

			uint16 u1;
			uint16 v1;
			CalcVRAMuv(vertex1.u-offsetU,vertex1.v-offsetV,u1,v1,_texture);

			uint16 u2;
			uint16 v2;
			CalcVRAMuv(vertex2.u-offsetU,vertex2.v-offsetV,u2,v2,_texture);


//			cout << "uv: " <<
//			u0 << "," << v0 << ";" <<
//			u1 << "," << v1 << ";" <<
//			u2 << "," << v2 << std::endl;

			setUV3(poly,u0,v0,u1,v1,u2,v2);
			break;
		}
		case GOURAUD_SHADED|TEXTURE_MAPPED:
		{
//			cout << "Gouraud shadded texture map:" << std::endl;
//			cout << "v0 = " << vertex0 << "; v1 = " << vertex1 << "; v2 " << vertex2 << std::endl;
//			cout << *this << std::endl;

			POLY_GT3* poly = (POLY_GT3*)&prim;
			setPolyGT3(poly);
			setRGB0(poly, vertex0.color.Red(),vertex0.color.Green(),vertex0.color.Blue());
			setRGB1(poly, vertex1.color.Red(),vertex1.color.Green(),vertex1.color.Blue());
			setRGB2(poly, vertex2.color.Red(),vertex2.color.Green(),vertex2.color.Blue());
			poly->tpage = TexturePage(_texture);
            poly->pPixelMap = _texturePixelMap;

			if(_materialFlags & TEXTURE_TRANSLUCENCY_ON)
				setSemiTrans(poly,1);

			Scalar minU = vertex0.u.Min(vertex1.u).Min(vertex2.u);
			Scalar minV = vertex0.v.Min(vertex1.v).Min(vertex2.v);

			Scalar maxU = vertex0.u.Max(vertex1.u).Max(vertex2.u);
			Scalar maxV = vertex0.v.Max(vertex1.v).Max(vertex2.v);

//			cout << "minUV = " << minU << "," << minV << std::endl;
//			cout << "maxUV = " << maxU << "," << maxV << std::endl;

			Scalar offsetU = minU;
			Scalar offsetV = minV;
			if(maxU-minU > Scalar::one)
			{
				offsetU = (minU+maxU)/Scalar::two;
				// + SCALAR_CONSTANT(0.5);
			}

			if(maxV-minV > Scalar::one)
			{
 				offsetV = (minV+maxV)/Scalar::two;
				// + SCALAR_CONSTANT(0.5);
			}

			offsetU = Scalar(offsetU.WholePart(),0);
			offsetV = Scalar(offsetV.WholePart(),0);
//			cout << "minUV = " << offsetU << "," << offsetV << std::endl;

			uint16 u0;
			uint16 v0;
			CalcVRAMuv(vertex0.u-offsetU,vertex0.v-offsetV,u0,v0,_texture);

			uint16 u1;
			uint16 v1;
			CalcVRAMuv(vertex1.u-offsetU,vertex1.v-offsetV,u1,v1,_texture);

			uint16 u2;
			uint16 v2;
			CalcVRAMuv(vertex2.u-offsetU,vertex2.v-offsetV,u2,v2,_texture);

//			cout << "uv's " <<
//				u0 << "," << v0 << ";" <<
//				u1 << "," << v1 << ";" <<
//				u2 << "," << v2 << std::endl;
			setUV3(poly,u0,v0,u1,v1,u2,v2);

#if 0
			cout << "vertex uv:" <<
				vertex0.u << "," << vertex0.v << ";" <<
				vertex1.u << "," << vertex1.v << ";" <<
				vertex2.u << "," << vertex2.v << std::endl;

			WFdumpTPage(poly->tpage);
			cout << "Texture:" << _texture << std::endl;
			cout << "uv: " <<
				u0 << "," << v0 << ";" <<
				u1 << "," << v1 << ";" <<
				u2 << "," << v2 << std::endl;
#endif



			break;
		}
		default:
			AssertMsg( 0, "_materialFlags = " << std::hex << _materialFlags );
			break;
	}
//#endif
}

//============================================================================

//Material::~Material()
//{
//}

//============================================================================
//============================================================================
