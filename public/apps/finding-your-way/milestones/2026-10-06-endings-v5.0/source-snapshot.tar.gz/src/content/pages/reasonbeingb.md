---
title: Untitled Document
realm: reason
images:
  - usaradar.gif
next:
  - slug: /5c
    label: I don’t know
---
Science has been called the purest form of reason. Purest in the sense that it is least tainted with variables which are not quantifiable. Science assumes there is a reason to everything, it must merely be found. Lets see how far pure reason handles a trip down the Why Axis
Scientist, why does it rain?
Because the heat of the sun turns water on the surface of the earth into vapor, which rises into the sky and forms clouds. When the clouds get cold enough and dense enough, the vapor turns back into water and falls back to the earth.
![](/images/usaradar.gif) Why?
Liquids change states at a certain temperature. Vapors are less dense than liquids.
Why?
The molecules move faster when they are warmer, in fact, warmth is molecular motion. Since the molecules are moving around more, less matter takes up more space.
Why is warmth molecular motion?
Well, I guess you could say the sensation of warmth is just our brains way of registering molecular motion.
Why?
Well it would be evolutionarily beneficial to know when molecules are moving very violently and quickly, since our own molecules might get caught up in that motion. We have a sense for molecular motion because it helped us to survive.
Why does it matter if you survive?
Well those ancestors of ours who survived make us, so they explain why we are how we are today.
Why do we need to explain how we are today?
Because by understanding the causes of our different features, we can change our environment to encourage the expression of some features; like long life, good immune system, intelligence, strength, maybe even industriousness, and prevent the expression of other features; poor health, impotence, aggressiveness, weakness, fatness, laziness.
Why should we favor some features over others?
Well I could say that it improves the quality of life of the individual, but you’d just say why, and I’d be stuck with a question of quality. So I’ll just say it improves the chances of survival.
So again, why does it matter if you survive?
Well, you might do something great… which would improve the quality of life of others… or aid their chances of survival… which is pretty much the same question. But basically if you don’t survive, you can’t reproduce, a part of you does not pass on, you just die.
Why does it matter if part of you passes on? Why do we seek this form of immortality? Why don’t we just die?
**I don’t know.**
