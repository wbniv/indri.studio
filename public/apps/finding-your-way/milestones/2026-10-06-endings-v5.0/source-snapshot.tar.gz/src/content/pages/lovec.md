---
title: Untitled Document
realm: love
palette: inverse
images: []
next:
  - slug: /loved
    label: Love is the result of years of evolutionary selection for human teamwork
---
_Put any two people together long enough and they will fall in love. Love is the result of years of evolutionary selection for human teamwork. When one’s mind registers that the interests of an individual, a group, or an idea are analogous to his own, he will love that person, group or idea. An individual human is a pretty worthless specimen. Even if he independently has the brilliant idea to fashion tools to improve his survivability, he will struggle to balance his R and D with maintaining the basic necessities of survival. When humans work together, however, new avenues of existence are opened. Teamwork improves our chances of survival greatly. Therefore we have evolved a very pleasing and fulfilling response to people with whom we most work together. This is love. You love your wife because in order for your offspring to survive, you must cooperate to a great extent. When the need to cooperate drifts further from the environmental pressures that shaped our ancestors, our evolved response, love, diminishes. As children we depend on our parents entirely, so we love them very much. As our needs from our parents become less and less for survival, we love them less actively. Once we find our own mates, we stop needing the familial social network for our sexual success; we seem to love our parents even less._
