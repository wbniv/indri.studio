---
title: Untitled Document
realm: reason
palette: inverse
images:
  - "SJ-Rain-Rain-Go-Away_Z.jpg"
next:
  - slug: /5b
    image: SJ-Rain-Rain-Go-Away_Z.jpg
---
Why is it raining?
God's crying
Why is God crying?
Something you did.
