---
title: Untitled Document
realm: truth
images:
  - 789327.1.jpg
next:
  - slug: /7e
    label: Hold strong
---
![](/images/789327.1.jpg)Although I am bothered by your disregard of the law of the land, the particular rule you're breaking was derived from so many lies that I wash my hands of it altogether.
That being said, your dilemma is a tricky one, there's no denying that.
On the one hand you're endangering your future by holding your tongue.
On the other hand you're damning your roomate if you do not.
While you must protect your prospects at your university, how pleasant will that time be, being labeled as a traitor.
Although you would avoid probation, noone will ever smoke with you again, at least unless you're paying.
If you and your roomate are true friends, betraying him would cause far to much guilt to enjoy the benefits of your treachery with a clear conscience.
Hold strong. You don't know what might happen, but you do know that you'll be friends when its over.
