---
title: Untitled Document
realm: intro
images: []
next:
  - slug: /intro2
    label: beautiful mosaic beneath
---
Your eyes open.

You are in a temple.
Four pillars hold a shattered dome, revealing the pitch black of a starless night.
Draped from those pillars are four faded, moth ridden tapestries, their intricate patterns blurred with dust.
The pillars frame four walls with broken windows, darkness obscuring what lies behind them.
The pillars stand on a dirty floor.
Worn paths of heavy traffic reveal portions of a beautiful mosaic beneath.
