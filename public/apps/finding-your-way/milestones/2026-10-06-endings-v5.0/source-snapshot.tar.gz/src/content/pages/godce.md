---
title: Untitled Document
realm: god
images:
  - darkDoor.jpg
  - lightDoor.jpg
next:
  - slug: /godnotbeinge
    image: darkDoor.jpg
  - slug: /godbeinge
    image: lightDoor.jpg
---
Finishing his speech, the old man steps back into a portal of white.
You turn to see the young man step into a portal of blackness, muttering “pure nonsense” As the two step into their separate ways, you already know your question. This question is not someone elses, it’s yours… and everyones at once. Perhaps the one common concern of all humanity. It’s the question, really.

**Why are we here?
Which way lies the answer?
**
