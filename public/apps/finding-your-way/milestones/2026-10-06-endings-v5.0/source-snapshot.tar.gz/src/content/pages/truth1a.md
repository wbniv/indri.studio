---
title: Untitled Document
realm: truth
palette: truth-gold
images: []
next:
  - slug: /truthaa
    label: "the prosecutor says:"
---
The portal opens into a courtroom.
The court is in session and the prosecution is beginning their closing statement.
An old lady with a purple bag looks at you strangely as you take a seat near the back.
Clearing his throat, the prosecutor says:
