---
title: Untitled Document
realm: love
palette: inverse
images: []
next:
  - slug: /lovee
    label: love is clearly selfish
---
_Even assuming that the love between parents is something permanent and unwaning, it is clear that we are more apt to love those who fulfill our most natural needs; subsistence, reproduction, than those whose contribution is less directly essential to our life. We may need employers to give us work to make a living, but I don’t think most people love their bosses. The further abstracted the benefits of a relationship are from the concrete needs of human beings, the less likely we are to love. Therefore, rather than being selfless, love is clearly selfish. The reason we only feel powerful love to a few individuals in our lifetimes is that the personal cost of loving someone is too high to invest in just anyone. Love only emerges when teamwork is absolutely essential to survival. Therefore we see the most universal forms of love occur in places of extreme evolutionary importance; children love their parents, parents love their children, spouses love one another. Other common forms of love can be explained by this paradigm as well. The powerful bond between soldiers who fight side be side, could be termed as love. A child loves his blanket because without it he would freeze in the night. Patriotism fades in times of peace, but when war erupts, and the danger to the individual’s life becomes clear, nationalism runs rampant. People who feel they have control over their own well being are less likely to love a divinity than those who feel their continued existence lies in the hands of God. Love is the adhesive with which we attach people or ideas to defend our most vulnerable areas._

_“And I bet you thought I was stupid,”_ she accuses, looking hurt.
