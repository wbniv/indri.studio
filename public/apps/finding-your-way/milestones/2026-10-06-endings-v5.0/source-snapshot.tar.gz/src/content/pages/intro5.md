---
title: Untitled Document
realm: intro
images: []
next:
  - slug: /lovea
    label: Enter the Realm of Love
---
You watch the goddess circumambulates the temple, touching the pillars, which begin to glow, filling the temple with a light which blinds you.
As your vision returns you see four closed portals standing before each pillar.
“The portals you see lead to four different realms. The Realm of Love, the Realm of Truth, The Realm of Reason and The Realm of God. As you enter each realm you will encounter two people. These two are locked in endless struggle. One will be the hero of the realm and defend its existence, the other will be its nemesis, and seek to deny its existence. Once you have heard both sides, they will depart by their seperate ways. You will then be compelled to decide on a path. Choose your way wisely.”
The portal directly across from you shudders and begins to glow a vibrant red.
“The first portal opens! Enter the Realm of Love!”
