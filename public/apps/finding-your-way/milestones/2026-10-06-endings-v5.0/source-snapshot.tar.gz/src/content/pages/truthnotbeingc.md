---
title: Untitled Document
realm: truth
palette: inverse
images:
  - "pointing-finger.jpg"
next:
  - slug: /7f
    label: So screw friendship
---
![](/images/pointing-finger.jpg)Hey, Freakin out. Way to go on the smoking weed. You're well on your way to realizing that nothing is anything. As for your situation... tough break. This is one of those damned if you do damned if you dont situations the greeks like to write tradgedies about. This situation is all about cost/benefit analysis. Although it doesn't things like morality and friendship into account it will determine the best course of action, There are 5 possible outcomes, as I see it. 1.You both keep silent. We'll give that a benefit level of -1, since you're kind of screwed but you can take it. 2. Your roomate says its your pot, and you, feeling noble, are stupid enough to take the fall for your buddy. That one gets a -5 since its by far the worst option. 3. Your buddy says its your pot and you deny it, as well you should. Such finger pointing is bound to make things worse. We'll give that a -3 4. You say, to hell with this, and turn in your buddy, and he then claims its yours. Same result as #3, same benefit rating, -3. 5. You turn in your buddy and he takes the blame. While this is not pleasant, like you said, it is his weed after all. Although it is less costly than option 1, it still sucks, so we will give it a benefit value of 0. As you can see, no matter what your roomate does, it is more beneficial for you to tell on him. If he talks its a cost of -3 if you talk and -5 if you hold your tongue. Even if he keeps silent you will still be better of talking, as you lose nothing by talking. Except of course your friendship. How's that friendship thing going for ya? Is he really your friend? Can you count on him? He's no idiot, he takes business courses, he knows all about this kind of analysis. I have no doubt he's thought of this. He knows its in his benefit to talk too. So screw friendship. You don't know if he's your friend, but you do know what's best for you.
