---
title: Untitled Document
realm: love
palette: love-red
images:
  - "HPN-Newspaper-Article2.jpg"
  - darkDoor.jpg
  - lightDoor.jpg
next:
  - slug: /lovenotbeing
    image: darkDoor.jpg
  - slug: /lovebeing
    image: lightDoor.jpg
---
As she walks toward the nearest building, she gives you one last flirtatious glance, turning just in time to run face first into the door. The door covers her blush by fading to darkness, leaving but a frame of black. Looking across the street to the door by which your lover disappeared, you see a brilliant light past the door, which casts no light on the dark street. Looking back, you notice a newspaper machine that you swear wasn’t there a moment before. Finding a quarter in your hand, you buy the latest edition. As you peruse the pages, the letters writhe on the paper in dreamlike nonsense. Leafing through, one article, an advice column, holds its text in place, though you can almost see the letters straining against their pattern. Each word disintegrates the moment you read it, the letters released to return to their dance. The article reads-

![](/images/HPN-Newspaper-Article2.jpg)

Who can help this indecisive soul? Which way holds her answers?
