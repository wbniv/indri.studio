---
title: Untitled Document
realm: love
palette: love-red
images: []
next:
  - slug: /lovec
    label: "“Cheer up, cutie!”"
---
Your love looks up with a start, as if awaking from a dream, and runs wordlessly to the nearest door, slamming it shut. You feel the pain of heartbreak all over again, and lean weeping against a solitary light post. From behind comes a coquettish giggle. _“Cheer up, cutie!”_ it quips. You turn to see the owner of the voice, Britney Spears, sitting on a bench, reading Darwin. Before the cognitive dissonance can take hold she kisses your cheek. _“There are plenty of fish in the sea, And according to Darwin, the best fish is me! (I bet you thought I couldn’t write music! HA!)_
