---
title: Untitled Document
realm: reason
palette: reason-blue
images: []
next:
  - slug: /reasoncb
    label: Reason has led the course of man to his nigh dominion over the world
---
Even the fantastic mystery of life has begun to yield to our reason. Darwin gave us the reason we are how we are, at least to some extent. Though its not as warm and fuzzy as a divine creation, it is far more reasonable, don’t you think. With the logic of Mendel, and the countless other great minds who have turned their cognitive power on life itself, we will no doubt find the reasons for every facet of our existence. Reason has led the course of man to his nigh dominion over the world. Sure a few unreasonable facets remain beyond our control. You glance over your shoulder again. The damn weather just refuses to act logically. Nevertheless, reason has made us great. There is no way to improve ourselves if we cannot examine the world and ourselves critically. Without our reason, we could not learn from the past, nor plan for the future. Through our powers of critical thinking, we have taken control of our destiny. If everyone would just act reasonably the world would function flawlessly.

You feel a vast crack, not loud but huge, like the shift of techtonic plates. The floor lurches beneath you as roots tear into the field of white, spreading, growing, breeding, expanding. The you in white flees straight away from you, screaming in terror. From behind you hear a terrible howl growing, surging, a great growing shout, you turn to see yourself, looking perhaps more like an animal than you might like. You clearly haven’t shaved in quite some time, and what is that in your hair? Twigs? And you reek of liquor, and whats in god’s name are you wearing? You laugh at your reaction to yourself and sit crossed legged before one another. The trees grow overhead and the piercing light is smothered in layers of foliage. A wide grin strikes a deep shadow across your chin as you begin. “Walk with me!” You say:
