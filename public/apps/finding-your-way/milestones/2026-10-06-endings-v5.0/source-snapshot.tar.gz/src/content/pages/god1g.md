---
title: Untitled Document
realm: god
images: []
next:
  - slug: /godag
    label: "_You can't make it to the top"
---
Before you lies a narrow path straight up a massive hill. Though you cannot see what lies at the end, the forest to all sides breaths with death and danger. You notice a man who has noticed you. He is a young man, handsome, with a spark of brilliance in his eye. He saunters up to you, stopping just short of the path and says, matter-of-factly, “ _You can't make it to the top_._This whole ‘god' thing is all just a sick joke._ ”
As you walk along the path, the young man walks beside you.
