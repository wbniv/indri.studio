---
title: Untitled Document
realm: intro
images: []
next:
  - slug: /intro5
    label: "You must prepare yourself for the journey ahead.\""
---
You turn to see three doors.
On the left, an intricately carved archway opens into a place so bright the doorway literaly shines.
On the right, a steel frame reveals nothing but impenatrable darkness behind it.
Between these two stands a door which looks as if it is trying to be both, rigid steel at the bottom, flowing stone at the top, and a twist in the middle that hurts your eyes to look at.
“Behold!” says the goddess, not a little sarcasticly.
“Before you lie three ways. The way of being. The way of not being. And the way of both being and not being. What these ways mean will be made clear upon your quest. These ways are sealed so that only one with true understanding of their nature may pass through. A mind not well suited to the way it takes will not survive, and it is not my intention that you should cease to exist. You must prepare yourself for the journey ahead."
