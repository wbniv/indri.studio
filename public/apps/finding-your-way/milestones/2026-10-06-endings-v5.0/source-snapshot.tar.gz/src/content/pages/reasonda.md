---
title: Untitled Document
realm: reason
palette: reason-blue
images:
  - darkDoor.jpg
  - lightDoor.jpg
next:
  - slug: /reasonnotbeinga
    image: darkDoor.jpg
  - slug: /reasonbeinga
    image: lightDoor.jpg
---
You have led yourself to the edge of this new forest. Beyond the twining vines, and mysterious shadows lies the bright, sharp plane of white. Both of you bid you farewell, melting into their ways, like puzzle pieces, suddenly invisible in the grander picture. A child approaches you. You soon recognize it’s you, just, a slightly younger you. Eye’s full of wonder, mind full of questions. As he looks up at you, pupil’s dilated to such a degree of cuteness that the iris nearly vanishes, it begins to rain. He asks,

Why is it raining?
Which way holds the answer?
