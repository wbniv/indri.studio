---
title: Untitled Document
realm: intro
images: []
next:
  - slug: /intro4
    label: she points behind you
---
“That is a common fixation of men.” You turn, startled, and find yourself in the presence of a goddess.
Golden wings arch from the back of a woman so beautiful she can only be divine.
“What a slovenly place your soul is… an utter mess really… ah yes… you cannot speak, that must be very frustrating. Don't worry, you'll have no need for words where you're going.” Smirking briefly in what you feel is a very ungoddesslike fashion, she points behind you.
