---
title: Untitled Document
realm: truth
palette: truth-gold
images:
  - darkDoor.jpg
  - lightDoor.jpg
next:
  - slug: /truthnotbeingc
    image: darkDoor.jpg
  - slug: /truthbeingc
    image: lightDoor.jpg
---
The jury files out to deliberate. The defence exits to the left by a white door. The prosecutor to the right by a black door. Suddenly, a college student is tapping at your shoulder. “Hey man,” he whispers, “I’ve got a problem.”
So, my roomate/friend picked up a sack of weed today.
He asked if I wanted to have a bowl and I gladly accepted.
It being cold outside, we decided to chance it and smoke in my dorm room.
Apparently someone smelled it because right after we were done, our RA knocks at the door.
He's a nice guy and all, but strictly by the books.
He searched the room and found the bag we'd hidden in the couch.
"Whose is this?" he asks.
If we both deny ownership we'll both get in trouble, but I'm pretty sure they won't be able to stick either of us with possession, since it isn't clear whose pot it is. But it is my friend's pot...

Which lawyer is best suited to counsel this boy?
