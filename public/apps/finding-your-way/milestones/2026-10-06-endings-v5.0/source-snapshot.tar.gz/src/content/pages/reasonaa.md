---
title: Untitled Document
realm: reason
palette: reason-blue
images:
  - evolution.jpg
next:
  - slug: /reasonba
    label: "“Reason is the law of this domain, and reason makes all things clear\""
---
The portal drops you in a plane of pure white. You almost do not notice yourself, standing in front of you, clad all in white, every feature equally illuminated, a you utterly devoid of shadow. A you you’re quite sure doesn’t approve of many of the things you do. You seem hurried, slightly worried, and you’re always looking over your shoulder at whatever might be behind you. “Welcome to your mind” yourself says to you. “Reason is the law of this domain, and reason makes all things clear"

![](/images/evolution.jpg)Reason distinguishes man from the beasts around him. Even a skeptic as complete as Descartes knew that he existed because he was thinking. After positing the existence of God, he decided that God would not deceive us with flawed reasoning. Reason is the essence of the divine in man. Through this gift, we can discern truth from lies, good from bad, right from wrong. Without reason our actions would be devoid of meaning; why should I take one action or the other? What is the purpose in life without reason, it is merely existence. Even atheists trust the power of reasoning mind. In fact they trust their reason to the extent that they use it to disprove God’s existence. Reason sheds light on the mysteries of the world. The reasoning mind discerns the order within chaos. Newton removed any spiritual motive force in the world by demonstrating the logical reasons for almost every physical phenomenon. Before him, people had penned thousands of reasons for the motions of celestial bodies. As the edge of our reason grew finer, we discovered the true nature of the heavens; not spirits of dead ancestors, not concentric spheres of ether singing a divine song as they spun through the night, nor geocentric models of epicycles within cycles, but spheres held together by the mysterious force Newton would explain, whirling around a sun, which itself is orbiting a galaxy, which in turn is hurtling through an endless void. None of these things are manifest to mere observation, they are seen by means of reason.
