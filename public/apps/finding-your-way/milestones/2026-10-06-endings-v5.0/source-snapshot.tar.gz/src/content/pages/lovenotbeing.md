---
title: Untitled Document
realm: love
palette: inverse
images:
  - "HPN-Newspaper-Article4.jpg"
next:
  - slug: /3b
    image: HPN-Newspaper-Article4.jpg
---

