---
title: Untitled Document
realm: god
images: []
next:
  - slug: /9g
    label: "I'll tell you when you get here"
---
**Why are we here?

I'll tell you when you get here.**
