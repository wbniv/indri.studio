---
title: Untitled Document
realm: love
palette: love-red
images: []
next:
  - slug: /loveb
    label: your first love
---
Stepping through the portal, you are thrust into a sea of people on a busy street.
You realize that these are all people you have seen before.
Some wave or nod as they see you, others stride forward, hardly acknowledging your existence.
Suddenly the crowd disperses.
Doors up and down the road slam shut and you are left alone with another figure on the road.
Approaching, you recognize your first love, who smiles and says.
