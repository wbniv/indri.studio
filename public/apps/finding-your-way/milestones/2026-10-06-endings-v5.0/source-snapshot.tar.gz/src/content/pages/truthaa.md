---
title: Untitled Document
realm: truth
palette: inverse
images:
  - court2.jpg
next:
  - slug: /truthba
    label: the concept of absolute truth has been one of the most troublesome
---
_Of all the things that cause trouble for humanity, the concept of absolute truth has been one of the most troublesome. This notion, a mixture of pride and predjudice as well as plain simplistic thinking, has caused more wars, justified more atrocities, and ruined more ![](/images/court2.jpg)thanksgiving dinners than drugs and television combined. The reason absolute truth is so pervasive is that it can be applied to so many things; religion, sexuality, sports affiliation, table manners. It's not just fundamentalists christians blindly clutching their sacred texts. An absolute truth of the Cold War mentality was that Communism is inherently evil, and we're still suffering from that monolithic statement. Capitalism is the only way that works, Democracy is better, we are the Master race, anything can be accomplished with hard work, manifest destiny, representative Democracy is the only option, civilized means better, you are special, the fork goes on the left, cats always land on their feet. These are all concepts which we've heard from some person or another who really ardently believes that they are so. Perhaps you even believe some of these yourself. The point here is not to tear down your beliefs, its to demonstrate the mischief they cause.
When an idea becomes established within a culture to the point that it becomes unquestioned, it becomes a "truth." Now these truth's are very useful, if you have a common understanding of a concept, and a general belief in an ideal, it is an excellent way to motivate and drive people. Think of how nice Christians are (to other Christians (of the same denomination) ... bad example) Think of Nazi Germany. Now there's some motivated efficient people! However these truths can cause problems. When truths no longer fulfill their function, but rather restrain or hurt society, then it's time to get rid of them. The master race thing pittered out, it was time to move on. But you can't just say, "you know that amazing idea that we all believed was true? It was a lie." Established truths are tricksy things to root out._
