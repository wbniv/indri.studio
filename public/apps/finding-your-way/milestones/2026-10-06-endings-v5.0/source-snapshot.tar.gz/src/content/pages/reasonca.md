---
title: Untitled Document
realm: reason
palette: inverse
images: []
next:
  - slug: /reasonda
    label: more likely to listen to our hearts
---
_Reason is man's biggest joke on himself. It is no divine gift. No god breathed his spirit into your creation. We are apes. Apes who are very adept at finding patterns. As we go through life we notice how things work and remember them. When a similar situation arises, we are able to draw general courses of action from previous experience. If we haven't experienced this particular thing before, we look to models provided in stories, or in generalized moral systems to guide our actions. Every person's reason is simply molded by his experience. What may seem like the perfect solution to one person would not even occur to another. If reason were some divine gift we would all come to the same conclusions. Clearly we do not. Furthermore to claim that reason is infallible is to blind oneself to all experience and history._

_What emerges from the chaotic madness of childhood is a basic infrastructure of ideals. These mental paths are not logical, there is no reason to their placement, they are simply arbitrary connections. For the purpose of functioning, the brain treads the paths that have historically created the best outcome. However, those other paths still exist, little alleys of consciousness that lead into realms unknown. That’s why when you look at a cloud, you’re not restricted by the knowledge that it merely water vapor suspended above you. Despite our reason, we see castles in the clouds. So where is your divine spark now? Reason killed God. But without God to justify reason with ideals like truth and right, reason is merely an arbitrary set of ideas. This leaves disciples of pure reason in the dark. Despite having a marvelously well drawn outline of how things work. The why will always escape pure reason. You’ll notice when it comes time to make really important questions (i.e. Should I rush? Is she the one? What should I major in?). We are less likely to listen to reason, and more likely to listen to our hearts._
