---
title: Untitled Document
realm: intro
images: []
next:
  - slug: /intro3
    label: You lose yourself in their dance
---
A breeze stirs the mottled cloth dangling limply from their ionic supports.
What can be seen of the patterns seem to writhe in a motion that seems totally unrelated to the flow of the fabric.
You lose yourself in their dance.
