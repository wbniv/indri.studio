---
title: Untitled Document
realm: god
images: []
next:
  - slug: /godbc
    label: You stop
  - slug: /godbb
    label: The old man glares another moment at his nemesis
---
Suddenly the one approaching is right upon you. You stop, and regard the man.
The road behind him frames his frame completely, like some beam descending from the top of the hill to illuminate him.
He strikes you as a holy man, but you cannot place the culture.
His eyes, though clouded with age, seem deep with wisdom.
Seeing your companion his eyes flash with anger.
What lies are you telling this traveller? He demands.
The young man crosses his arms, looking bored.
The old man glares another moment at his nemesis, but his face softens as he turns toward you,
