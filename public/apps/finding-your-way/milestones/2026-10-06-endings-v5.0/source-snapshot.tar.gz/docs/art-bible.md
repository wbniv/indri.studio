# Finding Your Way Art Bible

**Version:** 1.0 · **Updated:** 2026-10-05 · **Status:** directed visual baseline; Blender style proof and phone validation remain open.

**Art direction:** Codex, acting as director of art at Will’s request.

This bible defines the visual identity and asset standards for *Parmenides: Finding Your Way*, a World Foundry 3D adventure. It gives Codex a shared direction for modeling every environment, character and prop in Blender, painting textures, animating scenes, composing shots and designing the phone interface. Use it alongside the [adventure plan](plans/world-foundry-adventure.md), [asset inventory](investigations/3d-game-port-asset-classification.md) and [WF compatibility contract](investigations/world-foundry-compatibility.md).

The established direction is **original low-poly forms, hand-painted diffuse textures, late-1990s readability and a collision of sacred and everyday imagery**. A worn temple, a mundane city street, a courtroom and a wooded ascent must feel authored by the same hand. The visual world makes philosophical encounters tangible while leaving the player's interpretation open.

Will's requirements are fixed: phone first; third-person follow camera by default, switchable to first-person free movement; all models made by Codex in Blender; direct export through the **WF Blender exporter**. Chromecast, web, desktop and tablet layouts follow in Phase 2. The palettes, proportions and treatments in this bible are the **director’s selected working baseline**. Concept sheets establish visual intent; the Blender style proof will refine construction, readability and animation. Technical budgets and timing ranges remain provisional until measured on the phone. Neither generated concepts nor a selected visual direction establish runtime support or final asset approval.

## Visual pillars

| Pillar | Production rule | Review question |
|---|---|---|
| Readable sculpted forms | Build a few deliberate planes and strong silhouettes; paint broad value changes before fine detail | Does the asset read at normal phone gameplay size? |
| Sacred and everyday collage | Use one rendering language for temple mosaics, newspaper machines, candy exhibits and surgical equipment | Does the juxtaposition carry the source's tone without looking like unrelated asset packs? |
| A world with consequences | Let authored temple features, doors and scene transformations respond to the journey | Can the player notice the change without losing the distinct source histories? |
| Restrained living motion | Small poses and environmental movements surround occasional decisive story events | Is the motion purposeful, affordable and readable in both perspectives? |
| Philosophical openness | Give opposing speakers equal visual dignity and usable staging | Does the image leave room for disagreement rather than mark one account as obviously evil? |

The *Zelda 64* reference establishes a period of visual economy: expressive poses, chunky landmarks, painted surfaces and readable rooms. Create original silhouettes, costumes, symbols and architecture. The game should support reflection, unease and flashes of absurdity; broad cartoon villain coding, photorealistic celebrity likenesses and a uniformly grim fantasy treatment would undermine that mixture.

## Reference sheet and visual authority

![Exact realm base swatches selected for the art direction](art-bible/style-reference.svg)

[Editable palette sheet](art-bible/style-reference.svg). The concept references below supply shape, character and surface studies. They are original art-direction images, not finished Blender assets or World Foundry captures.

Open the [complete visual reference gallery](art-bible/references.html) to examine every sheet at full size. All 15 model designs, all nine scene families and the inventory’s principal prop, material, effect and UI families have reference coverage. The Old Woman remains voice-only. [Generation prompts and revisions](art-bible/prompts.json) record the built-in image-generation workflow.

The current [mockup gallery](plans/world-foundry-adventure/mockups.html) provides layout and interaction references. Elevated drawings expose routes and object placement; their camera angle is not the gameplay camera. Blender turnarounds and actual phone captures become the visual authority after the style proof. Record each accepted revision in this document and link its reference assets.

### Reference coverage and use

| Sheets | Coverage | Modeling or presentation authority |
|---|---|---|
| [Environments 01](art-bible/environments-01-v2.png) | Temple initial/restored, Love, Reason ordered/grove, Truth | Spatial mood, painted planes and clear routes; revised to remove invented prose and keep Reason open |
| [Environments 02](art-bible/environments-02-v2.png) | God, Being, Both, NotBeing, surgery | Remaining scene families and authored coda framing |
| [Characters 01](art-bible/characters-01.png) | Player, goddess, First Love, starlet, shared crowd variants | Working silhouette, costume and face-plane direction |
| [Characters 02](art-bible/characters-02.png) | White Self, Wild Self, prosecutor, analyst, judge, old lady | Related selves and distinct courtroom acting/costumes |
| [Characters 03](art-bible/characters-03.png) | Young man, old man, horror visage, shared surgeon variants | Ascent figures, original ending entity and patient-angle surgeon construction |
| [Props 01](art-bible/props-01.png) | Temple construction, tapestry/dome families, street fixtures and paper/book evidence | Reusable forms, motif scale and original painted artifacts |
| [Props 02](art-bible/props-02-v2.png) | Apparatus, vegetation, umbrella/chart, court objects, icon/poster, endings and surgery props | Remaining principal prop families and deliberate manipulation surfaces |
| [Materials](art-bible/materials.png) | Stone, plaster, wood, cloth, tapestry, gold, steel, glass, skin/hair, leaves/roots | Painted surface language; exact colors come from the palette sheet |
| [Effects](art-bible/effects.png) | Portal, tapestry, mosaic, windows, dome, roots, letters, walls and ending dissolution | Before/after visual intent; runtime method must be proved |
| [Motion](art-bible/motion.png) | Walking, goddess settling, speaker gesture, prop response, environmental sway, surgeon lean | Pose and amplitude studies; timing and contact require animation review |
| [Phone interface](art-bible/phone-interface.png) | Gameplay, inspection, realm symbols and three ending motifs | Spacing, text hierarchy, quiet framing and input separation |
| [Phone interface 02](art-bible/phone-interface-02.png) | First person, journal, settings, dialogue, ending fragments, title and radar study | Remaining principal interface families and accessibility presentation |

A family sheet covers repeated variants; it does not prescribe an identical copy for every instance. Add a dedicated view when a source beat needs a special object or the family study leaves construction ambiguous. Render lettering, exact symbols and evidence content from the reviewed source/UI assets during production. Generated labels and incidental scene details are never narrative authority.

### Director decisions from the reference review

The character sheets govern identity and costume. The player wears the slate-blue jacket, cream shirt, brown trousers and substantial shoes in Characters 01. Cream-robed figures in environment, effect or motion thumbnails are scale/pose studies; they do not change the player design. The White Self remains white-clad, with the related face/body family. The goddess uses the living, expressive design and wing construction in Characters 01, with economical gold folds and no need for dense ornamental geometry.

Use the corrected Environment 01 for the open Reason footprint and unlettered scene surfaces. The corrected Environment 02 controls NotBeing: a closing portal and sparse dissolution in groundless darkness, rather than a traversable skull-lined temple. Surgical lamp and surgeon framing remain in the established upward patient view. Environment studies guide composition; source-derived hub data controls the presence of each tapestry, wall, window, floor and door.

Props 02's corrected candy exhibit uses original anthropomorphic sweets, and its Both door uses the source's opposing-triangle language. Aether rings on a stand are a construction diagram, not an extra tabletop machine to put into the story. Mount the dome treatment overhead as layered shell arcs. Large simple tapestry emblems support distant recognition; they do not replace the established realm-scene fractal imagery in the final painted/animated tapestries.

For materials, retain broad color planes and simplify repeated crack/grain noise when it becomes visible clutter on the phone. Skin comes from the character face studies. Gold is concentrated in the goddess silhouette and selected sacred accents; it must not coat every mundane fixture. Apply the paper-fragment motion study to the source newspaper/lettering beat rather than introducing a new sealed-letter story event. Exact realm and ending symbols follow the [vector symbol sheet](art-bible/symbols.svg); generated symbol variations are studies.

Use UI sheets for composition, then lay out real text and touch hit areas from the phone contract. Placeholder prose and decorative sheet subtitles are excluded from production content. The library is complete at the **concept-family level**; orthographic construction, rig topology, complete action clips and exported atlas sheets are next-stage Blender deliverables.

## Shape language and scale

Use substantial silhouettes: a clear head, hands, feet and torso on characters; visible frames and thresholds on doors; a broad seat and back on benches. Allocate edges to silhouette, expression and interaction surfaces before hidden curvature. Small props can be slightly enlarged for recognition while retaining their recognizable function.

| Family | Shape treatment | Meaning and limits |
|---|---|---|
| Temple and thresholds | Repeated pillars, arches, stepped bases, broad mosaic bands | Orientation, age and continuity; fractured parts expose authored change |
| Love street | Uneven rectangles, shop fronts, domestic door frames, rounded bench details | Familiar social space and loss; a contained street rather than a large city |
| Reason | Repetition and alignment interrupted by branching roots and irregular canopy | Two visual accounts occupying the same space; neither vocabulary is a moral label |
| Truth | Timber planes, benches, exhibit frames and a clear hearing floor | Structure and procedure; both advocates share comparable scale and readability |
| God | Winding path, layered trunks, distinct landings, a compact summit shrine | Ascent and uncertainty; silhouettes beyond the route remain separate from navigable space |
| Surgery | Simple lamp circles, masked heads, broad scrub shapes | Immediate recognition from the patient view; contemporary objects retain the painted style |

**Proposed scale convention:** author one Blender unit as one meter for the proof, with a roughly 1.7-unit player. Start door openings near 1.4 units wide and 2.3 high and clear circulation routes near 2 units wide. These are staging proposals, not claims about existing WF units. Export the player, door, stair and bench together; verify movement, collision, reach and camera clearance before locking the conversion. Grow openings for gameplay clarity when needed.

Set Blender Z-up and follow the exporter's identity axis mapping. Establish the actor-facing convention with the movement proof; do not assume a facing axis. Place object origins at useful pivots: a door hinge, a character's floor contact or a prop's stable support. Separate simplified collision geometry from visible surface detail.

## Color script

The proposed swatches below are base painted colors. Lighting, values and occupied screen area determine the final composition. Start with a dominant neutral, one realm family and a small accent. Preserve local differences through grayscale contrast and silhouette; hue alone must never identify a required action or philosophical choice.

| Scene | Proposed base colors | Composition and emotional use |
|---|---|---|
| Temple | Stone `#B7AE94`, shadow `#42484A`, gold `#D9B75F`, plaster `#D8D0BB` | Weathered shelter; gold concentrates around the goddess and selected sacred features |
| Love | Rose `#9D626B`, faded brick `#78544A`, paper `#E5D7BA`, street `#46505B` | Human warmth and ordinary objects interrupted by absence and silence |
| Reason before | Ivory `#EEEADD`, cool gray `#BAC3C3`, charcoal `#46525A`, small gold `#C7B578` | Ordered clarity with readable floor/contact and a visible white-clad figure |
| Reason after | Leaf `#667A49`, root `#70583D`, pale ground `#DCD8C6`, deep green `#34493C` | Growth consumes the ordered space while traces of its earlier state remain legible |
| Truth | Timber `#8A6848`, ochre `#B89B63`, plaster `#CEC2A6`, ink `#34383F` | Formal attention; evidence and speaker faces sit above background clutter |
| God | Forest `#314C42`, moss `#687B54`, violet `#65556F`, shrine gold `#CBB373` | Uncertainty and discovery; the path has a readable value edge through the trees |
| Being | Light `#EEE7CF`, gold `#D8BD78`, distant gray `#9EAAA4` | Opening and dissolution; retain controls and text against the brightness |
| Both | Stone `#8B8277`, violet `#74657D`, gold `#C2AC77` | A visibly combined threshold and brief passage, with a stable alternative to distortion |
| NotBeing | Void `#141923`, muted violet `#544659`, sparse gray `#94918C` | Darkness, absence and dissolution; captions stay readable without lighting the whole void |
| Surgery | Scrubs `#698B87`, linen `#D8DDD5`, steel `#73858D`, lamp `#EEEBD9` | Clinical clarity rendered with the same broad painted planes |

Realm accents can appear on the matching temple pillar and tapestry. Label the destination and give each realm a distinct motif; four colored lights alone are insufficient navigation. Bright and dark source door presentations remain intact, but scene lighting must not silently make an argument's speaker less approachable or erase a permitted choice.

## Environments and authored state

Build **nine scene families**: temple, Love, Reason, Truth, God, Being, Both, NotBeing and surgery. The intro occurs in the temple. Reuse architecture and dressing where appropriate, while preserving the source-derived 2, 4, 8 and 16 cumulative hub histories after successive realms. Material sharing does not collapse those histories into a generic good/bad switch.

| Scene | Required visual anchors | Production treatment and motion |
|---|---|---|
| Temple | Four pillars and realm portals, goddess, tapestries, mosaic floor, windows, dome and three final thresholds | One reusable stone kit. Show the changed feature on return, then let the player approach it. Restrained tapestry-edge movement, occasional wing settling and sparse dust |
| Love | Door-lined street, dispersing crowd, First Love, starlet, bench, newspaper and exits | Reuse doors with painted variants. Establish the slam and dispersal as authored events; leave breathing, glances and very slight cloth/sign movement afterward |
| Reason | White plane, White-Clad Self, crack/roots, Wild Self and grove | Preserve the same playable footprint through transformation. Ground contacts stay readable; small leaf motion begins after roots settle. The ordering apparatus is a proposed adaptation prop |
| Truth | Judge's bench, advocates, old lady with purple bag, gallery and evidence | An accessible hearing floor with clear approaches to each speaker. Sparse asynchronous posture shifts. Token/plinth presentation is proposed adaptation choreography |
| God | Wooded switchback ascent, young and old guides, landings, summit altar and icon | Layer a small tree/rock kit without hiding the route. Low-amplitude canopy motion; occasional authored distant threat cues; static icon during inspection |
| Being | Bright threshold and authored dissolution | Few strong forms; a gradual authored visual release, with a stable reduced-motion version |
| Both | Combined threshold and passage into the coda | Make the hybrid structure recognizable through geometry and paint. Use restrained transitional motion without compulsory camera warping |
| NotBeing | Portal closing, darkness, original horror visage and disintegration | Keep emptiness. Voice-only Old Woman remains unseen; no additional visible witch model. Restrained authored reveal without flashing |
| Surgery | Three to five masked surgeons and overhead lamps seen from below | One shared surgeon model with variations. Small breathing, lean and hand repositioning; keep the patient camera stable |

**Tapestries:** retain the established realm-themed shifting fractals. Love can suggest paired figures and bonds; Reason ordered structures and branching forms; Truth testimony and nested frames; God ascent and devotional forms. These motifs are proposed treatments of the established brief. Animate slowly through supported texture/geometry techniques or baked sequences. Keep a meaningful still frame for reduced motion; validate export and memory before producing all four.

**Aether dome:** follow the established Platonic *Timaeus* interpretation: concentric crystal-aether shells and embedded visible planets seen from within, expressed through layered sphere rotation. This is the project's selected art interpretation, not a new astronomy specification. Favor readable painted arcs and sparse moving forms over many transparent shells. Prove the actual representation and retain the source's state-dependent dome changes.

Use wear to establish age and contact: softened stone corners, scuffed bench edges, worn steps and folded fabric. Concentrate damage where it carries a source beat or directs attention. Weather and time of day serve the composition; a dynamic weather/day-night system is not required by this bible.

![Temple, Love, Reason and Truth environment direction](art-bible/environments-01-v2.png)

![God, ending and surgery environment direction](art-bible/environments-02-v2.png)

## Characters and costume

**Proposed proportion baseline:** principals around six to six-and-a-half heads tall, with slightly enlarged hands and feet and clear nose/brow planes. Make expressions readable through pose and head direction before spending geometry on small facial features. Height, age, body shape and clothing can vary within that vocabulary. Figures should remain human and expressive rather than plush mascots or anatomically realistic scans.

The working roster contains **15 model designs**, not fifteen separate skeletons or concurrent actors. Share compatible body/rig structures and animation clips while retaining distinct silhouettes and acting. Final costumes and faces remain subject to the Blender style proof.

| Model design | Proposed silhouette and surface brief | Performance direction |
|---|---|---|
| Player | Simple layered neutral clothing, visible hands/feet, clear shoulder/hem shape; minimal ornament | Grounded walk/run, attentive idle and deliberate interaction. Hide obstructing geometry in first person |
| Goddess | Gold wing silhouette, long vertical costume, readable expressive head and hands | Warm authority; small wing settles, composed breathing, precise gestures, space for sardonic delivery |
| First Love | Familiar everyday clothes and a distinct doorway outline | A brief recognizable encounter and decisive withdrawal; avoid a generic faceless silhouette |
| Starlet | Original pop-fashion silhouette, distinct hair mass, generic book accessory | Relaxed bench pose, economical conversational gestures; no celebrity likeness |
| White-Clad Self | Player-related body structure, white layered costume, aligned silhouette | Controlled posture and clipped gestures; paint enough value separation to read against ivory |
| Wild Self | Related body structure with irregular layers and asymmetrical hair/cloth shapes | Loose weight shifts and wry delivery; distinguish through posture as well as costume |
| Prosecutor | Readable upright court attire, open face/hand staging | Principled delivery with a small set of deliberate gestures; maintain equal visual dignity with the analyst |
| Analyst | Precise costume blocks, distinct head/hair and seated outline | Measured movements and economical hands; reserve strong motion for an authored emphasis |
| Judge | Broad seated silhouette and gown shape behind the bench | Gaze shifts and the authored gavel response |
| Old lady | Compact seated outline with unmistakable purple bag | Brief glance and restrained hand/posture response |
| Young man | Clear youthful silhouette and light walking layers | Alert, bright, cynical stance with pauses that allow listening |
| Old man | Weathered face planes and contrasting walking layers | Patient gestures and a grounded pace; avoid coding age as stupidity or unquestionable wisdom |
| Horror visage | Original distorted head/upper-body composition shaped for the ending view | Restrained authored reveal; no traced source photograph and no repeated jump-scare loop |
| Surgeon | Simple scrubs, mask, cap, readable eyes and broad shoulders from below | Shared lean/breathing set with staggered timing and sparse hand movements |
| Crowd and gallery body | Shared body/rig with approximately four outfit variants and readable head shapes | Sparse idle/walk clips, staggered starts; different poses without excessive simultaneous work |

The Old Woman is a **voice-only presence**, with captions carrying her delivery. The two Reason selves are distinct NPCs standing in front of the player; they do not require a real-time mirror. No combat roster, enemy faction costume system or boss animation set is introduced by this document.

Costumes use large cloth planes, a few seams and deliberate accessory placement. Avoid thin straps, dense jewelry and high-frequency fabric patterns that disappear or shimmer on the phone. Include wings and carried accessories in actor budgets. Use limited secondary motion only after the native deformation or transform path is proven.

![Player, goddess, First Love, starlet and crowd character references](art-bible/characters-01.png)

![Reason selves and courtroom character references](art-bible/characters-02.png)

![God guides, original horror visage and surgeon references](art-bible/characters-03.png)

## Props and painted artifacts

Classify each prop as a landmark, background fixture, evidence object or manipulation target. Give an important handle, page, hinge or socket a stable shape and reachable position. Put essential prose in the inspection sheet; its world texture establishes identity and context rather than carrying the only readable version.

| Prop family | Visual brief | Interaction and motion |
|---|---|---|
| Doors and portals | Shared broad frame/leaf kit; distinct shape or motif plus a label for each destination | Useful hinge pivot, deliberate handle response; source bright/dark availability is preserved |
| Newspaper and machine | Original newsprint layout, paper value blocks, recognizable dispensing fixture | Small handle/paper response; narrative letter disintegration is authored, with a readable transcript retained |
| Book and letter | Generic evolutionary-biology hardback and newly composed correspondence/page layout | Stable evidence view; readable title/content presented in the sheet |
| Candy exhibit | Original cartoon candy forms and packaging, drawn for this project | Recognizable evidence without brand mascots, copied logos or branded wrapper colors/layouts |
| Purple bag and umbrella | Broad cloth/leather masses with functional folds and grasp points | Small secondary response when handled; no perpetual simulation requirement |
| Gavel, evidence frames and verdict token | Consistent timber/metal treatment; token and plinth shapes complement the courtroom | A short settle/contact action confirms placement, independent of the interpretation chosen |
| Altar icon | Fresh mother-and-child painting in the Byzantine visual tradition, gold ground and restrained aging | Still during inspection; source photographs are narrative references rather than production textures |
| Zine poster | Original handmade collage and typography expressing the opposing account | No band logo, copied graphic or recognizable album treatment; readable text in the sheet |
| Surgical lamps and instruments | Chunky clinical silhouettes and restrained painted steel highlights | Sparse motions tied to the coda, with no floating clutter around the camera |

Model all three-dimensional objects in Blender. Create original texture artwork and vector interface symbols; purchased/downloaded character or prop packs are not production dependencies. Existing source images inform subject and narrative function. Use fresh paintings, archetypes and layouts where the inventory specifies replacements; avoid tracing the named celebrity, brand graphics, face photograph or icon photograph.

![Temple and street prop reference families](art-bible/props-01.png)

![Realm, ending and surgery prop reference families](art-bible/props-02-v2.png)

## Materials and texture painting

Use painted diffuse color/value as the reliable baseline. Roughness, bloom, complex shader graphs, normal/height maps and physical simulations do not become requirements merely because Blender can display them. Validate any additional runtime feature through the native WF pipeline before relying on it.

| Material | Painted treatment | Detail discipline |
|---|---|---|
| Stone and plaster | Broad warm/cool planes, restrained crevices, selected chips | Keep noise below silhouette and mosaic readability |
| Wood | Few long grain strokes, worn contact edges and clear plank masses | Avoid a fine grain pattern on every courtroom surface |
| Cloth and tapestry | Broad fold values, limited weave cues, readable motifs | Reserve detail for meaningful designs; no dense weave noise during play |
| Metal and gold | Large painted highlight/shadow bands, restrained dark patina | Do not require a reflective environment to identify the material |
| Glass and crystal | Painted light shapes and a clear frame; economical transparency where proven | Use opaque or simplified representations when layered alpha is expensive |
| Skin and hair | Few face planes, warm/cool separation, hair grouped into masses | Expression and silhouette take priority over pores or individual strands |
| Leaves and roots | Grouped foliage shapes, value-separated root bundles and selective edge light | Avoid many overlapping alpha cards and tiny shimmering leaves |
| Paper and tempera | Quiet base value with deliberate page layout or large painted figure | Keep evidence text in the accessible sheet; do not bake illegible paragraphs into tiny atlases |

Paint large color/value shapes first, then selected edge wear and local accents. Maintain consistent detail density among actors, architecture and props. UVs should preserve important faces, hands, icon figures and evidence artwork; share repeated background surfaces deliberately. Add atlas padding and inspect seams and mip behavior after the native texture build, not only in Blender.

Proposed texture starting points are **512² for a player or principal sheet** and **shared 256² sheets/atlases for background figures**. Use a second principal sheet only when justified. Start small environmental/prop sheets at 256² or 512² and approve larger exceptions with on-phone evidence. Record actual exported atlas sizes, format and memory; source PNG size alone does not establish runtime cost. Match perceived detail at normal viewing distance rather than imposing an unverified texel-density number.

![Painted material and surface reference library](art-bible/materials.png)

## Lighting and effects

Light for clear landmarks, usable walkable surfaces and readable faces in both perspectives. Establish one dominant direction or value gradient in a composition, a restrained fill and a small focal accent. Paint or bake value where it helps the phone target; dynamic lighting and shadows require a demonstrated useful result and measured cost.

The temple uses weathered stone against selected warm highlights. Love suggests late urban light and a red/rose atmosphere. Reason contrasts an evenly lit pale state with an encroaching grove while retaining contact cues. Truth gives speakers and evidence a readable hearing floor. God separates the route from darker layered trees. Surgery uses overhead clinical lamps without washing out masks, eyes or subtitles.

Portal light, dust, cracks, roots, letters, tapestry motion and ending dissolution are a small vocabulary of effects. Prioritize **source transformations and interaction feedback** over decorative particles. Prefer a few readable shapes to dense noise. Restrict transparent layers and full-screen effects; do not depend on volumetric fog, reflective glass or bloom to make a location intelligible. Fog, if used, must preserve route/interaction visibility. Reject flicker, rapid pulses and exposure changes that obscure essential content.

![Authored effects and scene-state reference studies](art-bible/effects.png)

## Animation and subtle motion

Use pose-led acting with purposeful hands, head turns and weight shifts. Walk and run remain grounded, with readable foot contact; transitions do not turn philosophical commitments into automatic triggers. Shared actors reuse compatible clips, with different idle phases and gestures that preserve their identity.

**Proposed timing studies:** an interaction response around 0.2–0.5 seconds, an occasional idle shift separated by roughly 6–12 seconds, and environmental loops around 8–20 seconds. These are starting ranges for the slice, not universal timings. Dialogue gestures follow delivery and intention; a door slam, root emergence or ending transition receives its own authored timing. Let stretches of stillness remain part of the atmosphere.

Review every asset for ambient motion, acting, an interaction response, story-driven change or intentional stillness. The [plan's motion review](plans/world-foundry-adventure.md#subtle-animation-and-motion-review) gives scene-level opportunities. Put the following fields in each motion entry: purpose, trigger, loop/one-shot, timing/amplitude, source Blender action, native export representation, visible count, reduced-motion alternative and measured phone cost.

Keep stone, evidence text and essential interface targets stable. Animate the goddess's wings by occasional settling rather than continuous flapping; background gallery figures shift sparsely rather than all fidgeting; leaves move at low amplitude after the Reason transformation settles. Stop or simplify offscreen decorative work where supported and measured. An inspectable object holds a stable presentation even while nearby scenery moves.

**Reduced motion** is a saved preference. Stop decorative sway, pulses and particles, and replace large transformations or camera effects with a stable final state or short fade. Preserve meaningful feedback, source dialogue, decisions and completion when clips are skipped. No progress flag waits for a decorative loop to finish. Build one NPC idle, one prop response and one environmental loop in the Temple/Love proof before expanding the motion library.

![Subtle movement and acting pose references](art-bible/motion.png)

## Cameras and cinematics

Compose for **third-person follow and first-person free movement in the same world**. The player retains position, facing, interactions and story state when switching. Check close door frames, benches, roots and court furniture for clipping or blocked focus. Use landmarks that read at eye level; an attractive elevated composition alone is insufficient.

Gameplay art should leave room for the follow camera and not rely on fixed viewpoints to conceal unfinished surfaces. Place conversational staging so either perspective can see the speaker, relevant prop and exit. Preserve the player's selected perspective after a temporary authored shot. Field of view and follow distance are tuning decisions for the actual phone proof; lens effects, compulsory head bob and camera shake are not required.

Use authored framing sparingly to establish a change or support a specific source beat, then return control. Keep spoken faces large enough for phone readability without turning every exchange into a disconnected cinematic. The surgery coda is the established exception: a fixed upward patient shot beneath three to five surgeons and overhead lamps. Keep that composition steady and preserve its line and reveal when other clips are skipped.

## Phone interface and typography

The interface uses quiet dark panels, warm light text and a restrained gold focus accent, with clear margins and stable controls. Its motifs can echo temple frames and mosaic bands without turning a newspaper transcript or subtitle into decorative calligraphy. Keep artwork behind prose subdued.

Use a readable sans serif for controls and subtitle text, with a restrained serif available for titles and fragment presentation if the real runtime and glyph coverage support it. Final font selection remains open until WF proves Latin, Greek, punctuation, scaling and packaging. Starting type studies are 18–20 logical units for dialogue/evidence and 16–18 for secondary controls on the baseline phone, with user scaling; these are proposed sizes, not already implemented bindings.

Landscape gameplay reserves left movement, right look, separate Interact and perspective buttons, plus Pause and Journal inside device safe areas. Start touch hit areas at 48 logical units with generous spacing. Dialogue and evidence sheets support readable scrolling, speaker names, transcripts and clear return actions. Inspect the complete composition with both thumbs, subtitles and safe areas present.

Give Love, Reason, Truth and God distinct pictograms: paired curves, an ordered grid, a testimony frame and an ascent motif are proposed studies on the reference sheet. Pair destination icons with names. Distinguish Being, Both and NotBeing through frame shape, label and state, as well as source brightness. Focus needs a shape/label change, not only a hue change. Do not add loot, combat, currency or morality meters to this adventure's visual language.

Phase 2 may rearrange panels and controls for remote, mouse/keyboard, desktop and tablet use while retaining these symbols, materials and visual hierarchy. Larger layouts must not require revising the first phone release's art style.

![Phone gameplay, evidence inspection and symbol reference](art-bible/phone-interface.png)

![First-person phone play, journal, settings, dialogue and fragment presentation references](art-bible/phone-interface-02.png)

## Phone budgets and native production

These are **provisional working caps**, inherited from the adventure plan. They are not measured World Foundry limits. Profile exported assets, materials, texture memory and animation on the named baseline phone before authorizing exceptions or full production.

| Actor category | Rendered triangles per instance | Starting texture | Notes |
|---|---|---|---|
| Player | 3,000–5,000 | One 512² sheet | Idle, walk/run, interact and commitment actions |
| Goddess and principal NPC | 3,000–5,000 | One 512² sheet | Wings and accessories included; second sheet only with justification |
| Crowd/gallery | 500–1,500 | Shared 256² sheets/atlas | Shared body/rig and approximately four outfit variants |
| Surgeon | 1,500–3,000 | Shared 256² or 512² | Three to five instances in the coda |
| Horror visage | 2,000–4,000 | One 512² sheet | Close-view exception with no concurrent crowd |

Start with at most three visible principals **including the player**, plus eight background actors: at the upper per-instance limits that is 27,000 actor triangles. The initial concurrent actor cap is 30,000 including accessories. Environmental and effect costs can require lower counts. Use one or two runtime materials per actor and approximately 20 bones in a principal's Blender authoring rig; that rig size does not prove skeletal export support.

Environment triangle, total texture-memory, draw-call, particle and dynamic-light caps remain open until the slice is measured. Do not inherit the earlier inventory's larger per-character estimates or its assumed shader capabilities. Record the scene's total visible workload and thermal behavior. The phone release target remains a stable 30 fps during the plan's warmed 15-minute test; decorative animation receives only the remaining measured allowance.

Author `.blend` masters and export through **`wf_blender` → level `.lev` and model IFF → `iffcomp` / `levcomp` / `textile` → per-scene IFF → `cdpack` / shell → World Foundry**. No glTF exchange step is needed. Keep editable masters separate from simplified runtime geometry. Prove animated characters, tapestry representation, texture packing and collision before building the full roster; Blender viewport support is not runtime certification.

Use simple modules, instanced reuse where supported, and shared texture families. Hand-author lower-detail representations only where profiling shows a benefit and the runtime selection mechanism is verified. Do not assume automatic LOD, skeletal deformation, cloth simulation or material features. Proposed names use descriptive lower-case snake case such as `npc_goddess`, `prop_newspaper_machine`, `env_temple_pillar` and `anim_goddess_wing_settle`; map them to actual exporter name requirements in the proof.

Each asset entry records source beat/scene, narrative role, Blender master and generator, export artifact, triangle/material counts, texture format/memory, collision and pivot, actions/motion entries, original artwork provenance, phone evidence and review status. Existing project folders and build conventions take precedence over a new art-specific convention.

## Style proof and review checklist

The first approval set is a player, goddess, temple corner and Love street corner, with a door, bench and newspaper. Codex supplies reproducible Blender sources, front/side/back or appropriate prop views, neutral-light material comparisons, exported assets and actual phone captures. Include both perspectives, normal/reduced motion and the interface at normal size. The current schematic images cannot substitute for this set.

| Review | Acceptance evidence |
|---|---|
| Silhouette and proportions | Character/landmark recognition at normal phone size and a grayscale comparison |
| Cohesion and palette | All four proof assets shown together under neutral light and in scene lighting |
| Materials and textures | Painted planes remain readable; exported atlas seams, filtering and transparency inspected |
| Movement and cameras | Player/door/stair scale, clearance, target reach and clipping reviewed in both views |
| Motion and accessibility | Idle, prop response and environmental loop shown with reduced motion on/off; stable evidence and captions |
| Native compatibility | Repeatable `.blend` → WF exporter → packaged runtime build, with demanding representations demonstrated |
| Performance | Actual baseline phone, build, warm run, visible workload and measured costs recorded |
| Narrative integrity | Distinct hub histories, source-appropriate transformations and equally usable choice staging |
| Originality | Original designs and texture artwork; replacement briefs followed and provenance recorded |

- [x] Consolidate the established art direction, camera requirements, Blender ownership and native export route.
- [x] Define the directed palette, proportions, environment/character/prop treatment and motion rules.
- [x] Inspect and assemble the complete concept reference set with coverage and art-direction notes.
- [ ] Produce and approve the Blender style proof.
- [ ] Lock scale, character designs, palettes, font selection and proven runtime material/animation representations.
- [ ] Set measured environment, texture-memory, draw-call, effect and lighting budgets from the phone slice.
- [ ] Replace schematic references with approved Blender turnarounds and World Foundry phone captures.
- [ ] Complete the per-asset motion review before the full production pass.

For each review, record what was accepted, required revisions and links to evidence. A change to palette, proportion, texture density or acting should update this bible and the relevant reference sheet together. Avoid expanding the complete roster until the shared style proof is accepted.

## Project reference library

| Reference | Use |
|---|---|
| [Adventure plan](plans/world-foundry-adventure.md) | Release scope, scene sequence, movement/cameras, phone UI, state and subtle motion review |
| [Asset inventory](investigations/3d-game-port-asset-classification.md) | Source-derived characters, objects, environments and image replacement briefs; newer bible/plan budgets take precedence |
| [Research decisions](plans/3d-game-port-asset-classification.md#decisions-made-during-execution) | Tapestry, dome, goddess performance and surgery decisions; historical fixed-camera/no-player assumptions are superseded |
| [WF compatibility contract](investigations/world-foundry-compatibility.md) | Source-inspected native pipeline and remaining runtime proofs |
| [Mockup gallery](plans/world-foundry-adventure/mockups.html) | Original design studies for layout, interaction and the proposed phone composition |
| [General art-direction outline](art-direction.md) | Earlier general checklist; this bible supplies project-specific rules |
| [Source pages](../src/content/pages/) | Canonical narrative, authored branch history and ending/coda conditions |

Reference images added during production should identify their purpose, origin and permissions. Describe a useful property—painted stone planes, a readable garment silhouette, a doorway proportion—so a reference does not become an instruction to copy an entire existing design. Keep technical engine integration in the compatibility contract and production sequencing in the adventure plan; this document owns how the game looks and moves.
