"""Combine the source, asset and native audits with an exact build identity."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT.parents[1] / 'docs/diagnostics/parmenides/truth'
read = lambda path: json.loads(path.read_text())
build = read(ROOT / 'build/build-receipt.json')
content = read(ROOT / 'build/content.json')
text = read(EVIDENCE / 'text-audit.json')
assets = read(EVIDENCE / 'asset-audit.json')
native = [EVIDENCE / 'desktop', EVIDENCE / 'desktop/supplemental-text']
for receipt in [text['build'], assets['build']] + [read(folder / 'build-receipt.json') for folder in native]:
    if receipt['sha256'] != build['sha256']:
        raise SystemExit('Audit build mismatch: rerun native:verify for the current APK.')
runtime = [row for folder in native for row in read(folder / 'results.json')]
transcripts = [row for folder in native for row in read(folder / 'transcripts.json')]
if not all(row['passed'] for row in runtime + text['results'] + assets['results']):
    raise SystemExit('An audit contains a failed check.')
seen = {index for row in transcripts for index in row['cards']}
expected = {card['id'] for card in content['cards']}
if seen != expected:
    raise SystemExit('Dialogue card coverage mismatch: ' + str(seen ^ expected))
summary = {'runtime_checks': len(runtime), 'source_checks': len(text['results']),
           'asset_checks': len(assets['results']), 'dialogue_sequences': len(transcripts),
           'distinct_cards': len(seen), 'missing_cards': [], 'passed': True,
           'apk_sha256': build['sha256']}
(EVIDENCE / 'verification-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
