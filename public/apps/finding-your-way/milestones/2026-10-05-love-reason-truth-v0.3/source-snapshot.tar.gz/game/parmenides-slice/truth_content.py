"""Truth's source accounts, inspectable adaptations and eight history returns."""
def add_truth(add, source):
    def card(key, title, text, slugs=()):
        add(key, title, text, slugs, atlas='room')
    aliases=lambda prefix:[prefix+suffix for suffix in 'abcd']
    card('truth_intro','THE COURTROOM',source('truth1a'),aliases('truth1'))
    card('prosecutor','THE PROSECUTOR',source('truthaa')+' '+source('truthba'),aliases('trutha')+aliases('truthb'))
    card('defence','THE DEFENCE ATTORNEY',source('truthca'),aliases('truthc'))
    card('student','THE STUDENT',source('truthda'),aliases('truthd'))
    card('facts','EXHIBIT A / REPORTED FACTS',
         'The student reports: his roommate bought the bag; both used it in the room; the resident adviser searched and found it. Those are claims in the account, not independently tested evidence. Neither lawyer changes what the student reported. Compare these facts with the assumptions on the other exhibit before deciding which counsel to follow.',aliases('truthd'))
    card('interpretations','EXHIBIT B / ASSUMPTIONS',
         'The student expects that silence may leave ownership uncertain. He does not know whether his roommate will accuse him, accept responsibility or remain silent. Friendship, consequences and uncertainty matter differently to the two lawyers. Distinguish what was reported from what is predicted. Inspecting either exhibit does not select a verdict.',aliases('truthd')+aliases('truthbeing')+aliases('truthnotbeing'))
    card('present','PRESENT BOTH EXHIBITS',
         'Both exhibits are now on the hearing bench: the reported account and the assumptions surrounding it. The accounts have been heard; their interpretation is yours. The white BEING threshold asks the defence attorney for counsel. The black NOTBEING threshold asks the prosecutor. Select a threshold, read that counsel, and confirm your interpretation at its final page. Left cancels before commitment.',aliases('truthd'))
    card('truth_affirm','ASK THE DEFENCE / BEING?',
         'Follow the defence attorney through the white threshold. Select continues the complete advice to the student. The final page commits Being and returns you to the Temple. Left or Journal cancels before that final commitment.',aliases('truthbeing'))
    card('truth_deny','ASK THE PROSECUTOR / NOTBEING?',
         'Follow the prosecutor through the black threshold. Select continues the complete advice to the student. The final page commits NotBeing and returns you to the Temple. Left or Journal cancels before that final commitment.',aliases('truthnotbeing'))
    card('truth_counsel_being','THE DEFENCE / COUNSEL',source('truthbeinga'),aliases('truthbeing'))
    card('truth_counsel_notbeing','THE PROSECUTOR / COUNSEL',source('truthnotbeinga'),aliases('truthnotbeing'))
    card('truth_locked','COMPLETE THE HEARING',
         'Hear the prosecutor and defence attorney, meet the student, inspect both exhibits and present them at the hearing bench. Then choose the white BEING or black NOTBEING threshold. Hearing the accounts and presenting evidence unlocks the choice; it never chooses for you. The TEMPLE portal leaves without committing.',aliases('truthd'))
    card('truth_wait','THE HEARING IS IN SESSION',
         'Hear the prosecutor first, then the defence attorney. Complete both accounts before meeting the student. After hearing his problem, inspect the two exhibits and present them at the hearing bench. Each interaction gives only its own account; the final counsel belongs to your chosen threshold.',aliases('truth1')+aliases('truthd'))
    card('truth_unavailable','COMMIT REASON FIRST',
         'Truth opens after a Reason commitment. Complete Reason, choose BEING or NOTBEING and finish that threshold\'s concluding account. The TEMPLE return portal leaves without choosing. Hearing every encounter alone does not unlock the next realm. Your Love and Reason interpretations will be kept in Truth.',['5a','5b','5c','5d'])
    for suffix in 'abcdefgh':
        slug='7'+suffix
        card('return_'+slug,'RETURN TO THE TEMPLE',source(slug).split('Another Temple scene, with corresponding responses')[0].strip(),[slug])
    card('god_next','GOD IS NEXT',
         'Love, Reason and Truth are complete in this preview. The white God portal marks the next realm to build. Your three interpretations determine this Temple. You can replay Truth; replaying an earlier completed realm starts a new downstream history. Progress lasts for this session; relaunching begins again.',['7'+suffix for suffix in 'abcdefgh'])
