"""Verify exported dialogue actors bind to the intended bitmaps and atlas pixels."""
import json
from pathlib import Path
import re
import struct
from PIL import Image

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'build'
content = json.loads((OUT / 'content.json').read_text())
lev = (OUT / 'parmenides_slice.lev').read_text()
objects = {}
for section in re.split(r"\n\t\{\s*'OBJ'", lev)[1:]:
    name = re.search(r"\{ 'NAME' \"([^\"]+)\"", section).group(1)
    objects[name] = section
entries = {}
atlases={}
count=0
for region,stem in (('permanent','Perm'),('room','Room0')):
    mapping = (OUT / (stem+'.ruv')).read_bytes()
    n = struct.unpack_from('<I', mapping, 8)[0];count+=n
    atlases[region]=Image.open(OUT/(stem+'.tga')).convert('RGB')
    for index in range(n):
        name, frame, u, v, w, h, palx, paly, flags = struct.unpack_from('<33sb6hH', mapping, 12 + index * 48)
        entries[name.split(b'\0')[0].decode()] = (region,u,v,w,h)
results = []

def check(label, condition):
    results.append({'check': label, 'passed': bool(condition)})
    if not condition:
        raise AssertionError(label)

try:
    names = {f'card_{card["id"]:02d}.tga' for card in content['cards']}
    check('one distinct atlas entry for every dialogue bitmap', len(entries) == count and {name for name in entries if name.startswith('card_')} == names)
    for card in content['cards']:
        name = f'card_{card["id"]:02d}'
        section = objects[name]
        visibility = re.search(r'"Visibility Mailbox".*?\{ \'DATA\' (\d+)l', section).group(1)
        check(name + ': actor uses its own mesh and visibility', f'"{name}.iff"' in section and int(visibility) == 260 + card['id'])
        check(name + ': exported mesh uses its own bitmap', (name + '.tga\0').encode() in (OUT / (name + '.iff')).read_bytes())
        region,u,v,w,h = entries[name + '.tga']
        check(name+': intended atlas region',region==card['atlas'])
        atlas=atlases[region]
        original = Image.open(OUT / (name + '.tga')).convert('RGB')
        # -flipyout stores the atlas vertically inverted. Account for the
        # documented output transform and native RGB555 quantization.
        crop = atlas.crop((u, atlas.height - v - h, u + w, atlas.height - v))
        crop = crop.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
        same = original.point(lambda channel: channel >> 3).tobytes() == crop.point(lambda channel: channel >> 3).tobytes()
        check(name + ': atlas contains exactly its intended pixels', original.size == (w, h) and same)
    boxes = [entry for name,entry in entries.items() if name.startswith('card_')]
    overlaps = any(a[0]==b[0] and a[1] < b[1] + b[3] and b[1] < a[1] + a[3] and a[2] < b[2] + b[4] and b[2] < a[2] + a[4]
                   for i, a in enumerate(boxes) for b in boxes[i + 1:])
    check('dialogue atlas regions never overlap', not overlaps)
finally:
    target = ROOT.parents[1] / 'docs/diagnostics/parmenides/truth/asset-audit.json'
    target.write_text(json.dumps({'build': json.loads((OUT / 'build-receipt.json').read_text()), 'results': results}, indent=2) + '\n')
print(f'{len(results)} dialogue asset checks passed')
