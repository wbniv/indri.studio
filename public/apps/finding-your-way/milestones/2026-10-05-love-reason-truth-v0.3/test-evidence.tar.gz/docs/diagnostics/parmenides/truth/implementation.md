# Truth functional milestone — 2026-10-05

Truth extends the native Temple/Love/Reason prototype with an original Blender courtroom, source-derived testimony, evidence comparison and both philosophical commitments. All eight post-Truth histories have distinct source-derived Temple responses. God and the endings remain the next implementation work; Will requests functional realms before art passes.

- [x] Courtroom, advocates, student, old lady/purple bag, judge, benches, lecterns, exhibit tables, hearing bench, gavel, thresholds and inward-facing Temple sign.
- [x] Full prosecutor and defence accounts; the student's problem; separate reported-facts and assumptions exhibits; explicit evidence presentation.
- [x] Both final counsels commit only after their final page. Cancel, incomplete visits and earlier-realm replay preserve coherent progression.
- [x] Eight source-derived returns, prior Love/Reason interpretations, bright/subdued mosaics, removed visible foundation and God marker.
- [x] Source-text and exported-asset audits; native behavioral checks in both cameras; Chromecast 1 installation and launch/remote/resume verification.
- [ ] Will's full installed playthrough review, God/endings, production art, face investigation, animated departures/rescue, durable saves, phone touch/thermal acceptance and final voice work.

## Play sequence

Complete Love and Reason by choosing a threshold and finishing its concluding account. From Temple, enter Truth. Hear the prosecutor, then the defence attorney, then meet the student. Inspect both exhibits in either order and present them at the hearing bench. Select the white Being or black NotBeing threshold and finish its counsel. The Temple doorway leaves without choosing; an unfinished Truth visit retains encounter progress.

```mermaid
flowchart TD
  R[Reason commitment] --> C[Truth courtroom introduction]
  C --> P[Prosecutor account]
  P --> D[Defence account]
  D --> S[Student problem]
  S --> F[Exhibit A: reported facts]
  S --> I[Exhibit B: assumptions]
  F --> H[Present both at hearing bench]
  I --> H
  H --> B[White threshold: defence counsel]
  H --> N[Black threshold: prosecutor counsel]
  B --> TB[Commit Being on final page]
  N --> TN[Commit NotBeing on final page]
  TB --> T[Temple: exact 7a–7h history]
  TN --> T
  T --> G[God marker: next implementation]
```

Presentation unlocks the two thresholds; it does not choose a philosophy. Left or Journal closes dialogue without commitment. The lawyers and their labels withdraw when the student's scene completes, as in the source. Replaying completed Truth resets its own encounters; replaying Reason clears downstream Truth, and replaying Love clears both downstream realms. Relaunching resets the session.

## Source fidelity and authored adaptations

| Delivered account | Canonical source and aliases | Cards |
|---|---|---:|
| Courtroom introduction | `truth1a–d` | 1 |
| Prosecutor | `truthaa–ad` and `truthba–bd` | 16 |
| Defence attorney | `truthca–cd` | 9 |
| Student | `truthda–dd` | 3 |
| Defence counsel | `truthbeinga–d` | 3 |
| Prosecutor counsel | `truthnotbeinga–d` | 6 |
| Each changed Temple return | `7a–7h` | 2 |

The complete intended spoken accounts are retained. The source's c-history prosecutor copies differ only in an apostrophe (`its`/`it's`) and quote spacing; the shared delivery uses the a-history account and records that editorial reconciliation in the content manifest. The trailing `7h` authoring directions beginning “Another Temple scene” are excluded from goddess speech. Original source Markdown remains untouched.

The two exhibit comparisons, hearing-bench instructions, confirmations and prerequisite messages are authored gameplay adaptations. They distinguish the student's reported claims from predictions about the roommate and consequences. They do not append an unrelated lawyer's counsel to an exhibit or testimony interaction. Each threshold alone delivers its chosen counsel.

## Temple history mapping

| Source return | Love | Reason | Truth | Visible foundation |
|---|---|---|---|---|
| `7a` | Being | Being | Being | Bright mosaic |
| `7b` | Being | Being | NotBeing | Absent |
| `7c` | Being | NotBeing | Being | Subdued mosaic |
| `7d` | Being | NotBeing | NotBeing | Absent |
| `7e` | NotBeing | Being | Being | Bright mosaic |
| `7f` | NotBeing | Being | NotBeing | Absent |
| `7g` | NotBeing | NotBeing | Being | Subdued mosaic |
| `7h` | NotBeing | NotBeing | NotBeing | Absent |

Love's tapestry state and Reason's walls/windows remain intact. Truth NotBeing retains invisible collision support when removing the visible foundation, so the player can still reach the goddess and portals. This is provisional handling of the source's fall/rescue beat; the actual rescue animation is deferred. Mosaics are procedural Blender graybox geometry, not a completed art pass.

## Build and verification

Version: **0.3-love-reason-truth**. Package: `org.worldfoundry.wf_game.parmenides`. APK SHA-256: `a5e28d489566587a2fcbbab5afb96bbbd303a40030a0060509999146d30d3ddc`. Embedded level SHA-256: `5e5a0c493d66f2c9d4d111691d0f7f13e8c306e029d0239a80445acac37f7304`.

Models are authored by the chapter's Blender scripts and exported with WF's direct Blender exporter. The imported Snowgoons scaffold supplies actor schemas, room/director/camera infrastructure and player movement only. Courtroom and other environments are original geometry. Both native libraries remain byte-identical to the reused WF runtime; no engine source was modified.

The original 60 dialogue cards remain in the permanent atlas; 63 Truth cards occupy the room atlas. Each native asset chunk stays below the runtime's existing size limit. The build uses matching `5120×2048` VRAM, `1024×2048` room slots and `2048×2048` permanent atlas dimensions. Source pagination now respects both word and rendered-line limits, keeping longer testimony within the existing panel dimensions.

[Verification summary](verification-summary.json): **1,067 runtime checks**, **165 source checks** and **494 exported-asset checks**, all passed. [Actual native transcripts](desktop/transcripts.json) plus the [initial-goddess/journal supplement](desktop/supplemental-text/transcripts.json) cover **379 dialogue sequences and all 123 delivered cards**, with none missing. The asset audit checks each card's native mesh/visibility/atlas classification, texture pixels after RGB555 conversion, and lack of overlap between dialogue-card atlas regions.

Native fixtures exercise both Love outcomes, all four Reason histories and all eight Truth histories in third- and first-person cameras. They cover encounter gates, exact page sequences and stopping points, sole visible panel, modal label suppression, cancellation, unfinished visits, replay cascades, presentation without an automatic vote, Temple state and physical movement with the foundation hidden. Encounter positions and prior-history mailboxes are arranged through the desktop debug bridge; input opens and advances actual native dialogue. This is not a continuous input-only traversal or phone certification.

An initial native audit intermittently sampled a panel before the frame-counted Select release. The harness now waits for observed native input press/release before checking dialogue and visibility; the assertions are unchanged. Linux debug screenshots in this environment are stale/blank and are excluded from the archived visual evidence.

Chromecast 1 job **J-0d55b0bd86cc** installed the matching frozen APK and completed launch, remote-key and Home/resume checks with verified cleanup. [Receipt](cast1-review/receipt.json), [native Temple screenshot](cast1-review/after-keys-screenshot.png) and [resumed screenshot](cast1-review/resumed-screenshot.png) are actual Android evidence. This job is a device smoke check, not a complete courtroom playthrough. The coordinator restored Home; open the Finding Your Way tile for review.

## Archive and next milestone

The [milestone index](../../../../game/milestones/README.md) links the frozen APK, committed source reference, Blender/source snapshot, verification evidence and checksums. Tested source is committed before creating the archive; the archive receives a separate commit to avoid a circular source reference. Previous archives are retained. Will requests a commit and Chromecast 1 installation after each milestone.

Next: God, sixteen exact final-gate histories, three ending doors and the `10b → 101b` coda. Keep geometry provisional until the whole journey works.

Authored with Codex, GPT-6. No verified tool-version or reasoning-effort value was available to include.
